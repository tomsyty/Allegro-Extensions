async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt inPostSendMode');
	let response;
	try {
		response = await sendMessage({ action: 'getInPostSendMode' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania domyślnego sposobu nadawania przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}
	inPostSendMode(response.result);
});

async function inPostSendMode(sendMode) {
	console.log(`inPostSendMode: tryb nadawania nr ${sendMode}`);
	let buttonNodes = Array.from(document.querySelectorAll('button'));
	let orderShipmentsButton = buttonNodes.find(element => element.textContent === 'Zamów przesyłki');
	let saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
	if (orderShipmentsButton !== undefined && saveButton !== undefined) {
		try {
			await observeButton(orderShipmentsButton, saveButton);
			await setPickupOption(sendMode);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		}
		orderShipmentsButton.dataset.lock = orderShipmentsButton.dataset.lock.replace('inPostSendMode,', '');
		if (orderShipmentsButton.dataset.done !== undefined) {
			if (orderShipmentsButton.dataset.done.search('inPostSendMode') === -1) orderShipmentsButton.dataset.done += 'inPostSendMode,';
		}	else orderShipmentsButton.dataset.done = 'inPostSendMode,';	
		return Promise.resolve(true);
	} else {
		console.log('inPostSendMode: oczekiwanie na przyciski');
		const observer = new MutationObserver(mutations => {
			mutations.forEach(async (mutation) => {
				if (mutation.type === 'childList') {
					const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zamów przesyłki')));
					if (addedButton !== undefined) {
						buttonNodes = Array.from(document.querySelectorAll('button'));
						const bothButtons = buttonNodes.filter(element => element.textContent === 'Zamów przesyłki' || element.textContent === 'Zapisz');
						if (bothButtons.length === 2) {
							observer.disconnect();
							console.log('inPostSendMode: przyciski pojawiły się już na stronie');
							return await inPostSendMode(sendMode);
						}
					}	
				}
			});
		});
		observer.observe(document.body, { subtree: true, childList: true });
	}
}

async function setPickupOption(sendMode) {
	const pickupOptions = Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'Zdecyduj, w jaki sposób nadasz przesyłkę')?.parentElement.querySelectorAll('input[type="radio"]');
	if (pickupOptions?.length) {
		pickupOptions.forEach((pickupOption, index) => {
			pickupOption.parentNode.addEventListener('mousedown', (e) => {
				const parentElement = (e.target.nodeName === 'LABEL' ? e.target.parentElement : e.target.parentElement.parentElement);
				parentElement.dataset.clickTimer = setTimeout(async () => {
					pickupOptions.forEach(element => {
						if (element.nextElementSibling.firstElementChild.classList.contains('selected')) element.nextElementSibling.firstElementChild.classList.remove('selected');
					});
					parentElement.children[1].firstElementChild.classList.add('selected');
					delete parentElement?.dataset?.clickTimer;	
					let response;			
					try {
						response = await sendMessage({ action: 'saveInPostSendMode', sendMode: (index + 1)});
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						parentElement.children[1].firstElementChild.classList.remove('selected');
						return Promise.reject(error?.message ? error.message : error);
					}
					toastMessage('Zmieniono domyślny sposób nadania.');
				}, 1000);
			});

			pickupOption.parentNode.addEventListener('mouseup', (e) => {
				const parentElement = (e.target.nodeName === 'LABEL' ? e.target.parentElement : e.target.parentElement.parentElement);
				const clickTimer = parentElement.dataset?.clickTimer;
				clearTimeout(clickTimer);
				delete parentElement.dataset?.clickTimer;
			});
		});
		const clickEvent = new MouseEvent('click', {
			view: window,
			bubbles: true,
			cancelable: false,
		});
		pickupOptions[sendMode - 1].dispatchEvent(clickEvent);
		pickupOptions[sendMode - 1].nextElementSibling.firstElementChild.classList.add('selected');
	} 
	return Promise.resolve(true);
}

async function observeButton(orderShipmentsButton, saveButton) {
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}
	const activeLockingExtensions = Object.keys(readedValue.extensions).filter(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize' || extensionName === 'autoprintLabel' || extensionName === 'inPostSendMode'));
	if (orderShipmentsButton.dataset.lock !== undefined || orderShipmentsButton.dataset.done !== undefined) return Promise.resolve(true);
	orderShipmentsButton.dataset.lock = `${activeLockingExtensions.join(',')},`;

	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.attributeName === 'data-lock') {
				if (orderShipmentsButton.dataset.lock === '') {
					saveButton.disabled = false;
				} else {
					saveButton.disabled = true;
				}
			}
		});    
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['data-lock'] });		
}