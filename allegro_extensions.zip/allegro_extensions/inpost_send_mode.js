async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt inPostSendMode');
	let response;
	try {
		response = await sendMessage({ action: 'getInPostSendMode' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania domyślnego sposobu nadawania przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}

	const observer = new MutationObserver(mutations => {
		mutations.forEach(async (mutation) => {
			if (mutation.type === 'childList') {
				const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.inPostNew === undefined);
				if (addedHeader) {
					addedHeader.dataset.inPostNew = 'false';
					inPostSendMode();
				}	
			}
		});
	});

	observer.observe(document.body, { subtree: true, childList: true });

	let orderId = document.location.href.split('/');
	orderId = orderId[orderId.length - 1].split('?')[0];
	if (orderId.indexOf(',') !== -1) document.body.dataset.multipleOrders = 'true';
	else document.body.dataset.multipleOrders = 'false';
	document.body.dataset.inPostSendMode = response.result;
	console.log(`inPostSendMode: tryb nadawania nr ${response.result}`);
	try {
		await inPostSendMode();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
});

async function inPostSendMode() {
	const multipleOrders = (document.body.dataset.multipleOrders === 'true');
	const sendMode = document.body.dataset.inPostSendMode;
	
	let buttonNodes = Array.from(document.querySelectorAll('button'));
	let orderShipmentsButton;
	let saveButton;
	if (buttonNodes) {
		orderShipmentsButton = buttonNodes.find(element => element.textContent === 'Zamów przesyłki');
		saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
	}

	if (orderShipmentsButton !== undefined && saveButton !== undefined) {
		console.log('inPostSendMode: znaleziono przyciski "Zapisz" i "Zamów przesyłki"');

		if (Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'Zdecyduj, w jaki sposób nadasz przesyłkę')?.parentElement.querySelectorAll('input[type="radio"]')?.length === 0) return;

		if (multipleOrders) {
			saveButton.disabled = true;
			inPostSendModePrepareShipmentContainers();
		}

		try {
			await inPostSendModeObserveOrderShipmentsButton(orderShipmentsButton, multipleOrders);
			await setPickupOption(sendMode);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		}

		if (!multipleOrders) {
			orderShipmentsButton.dataset.lock = orderShipmentsButton.dataset.lock.replace('inPostSendMode,', '');
			if (orderShipmentsButton.dataset.done !== undefined) {
				if (orderShipmentsButton.dataset.done.search('inPostSendMode') === -1) orderShipmentsButton.dataset.done += 'inPostSendMode,';
			}	else orderShipmentsButton.dataset.done = 'inPostSendMode,';	
		} else {
			const shipmentContainer = saveButton.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
			if (shipmentContainer.dataset?.inPost === 'not-processed') shipmentContainer.dataset.inPost = 'ready';
			saveButton.disabled = false;
			let notReadyInPostShipments = Array.from(document.querySelectorAll('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]'))?.filter(div => div.querySelector('H4') !== null && div.dataset?.inPost === 'not-processed');
			if (notReadyInPostShipments.length === 0) {
				orderShipmentsButton.dataset.lock = orderShipmentsButton.dataset.lock.replace('inPostSendMode,', '');
				if (orderShipmentsButton.dataset.done !== undefined) {
					if (orderShipmentsButton.dataset.done.search('inPostSendMode') === -1) orderShipmentsButton.dataset.done += 'inPostSendMode,';
				}	else orderShipmentsButton.dataset.done = 'inPostSendMode,';	
			}
		}	
		return Promise.resolve(true);
	} else {
		console.log('inPostSendMode: oczekiwanie na przyciski "Zapisz" i "Zamów przesyłki"');
		const observer = new MutationObserver(mutations => {
			mutations.forEach(async (mutation) => {
				if (mutation.type === 'childList' && mutation.addedNodes.length) {
					const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zamów przesyłki')));
					if (addedButton !== undefined) {
						buttonNodes = Array.from(document.querySelectorAll('button'));
						const bothButtons = buttonNodes.filter(element => element.textContent === 'Zamów przesyłki' || element.textContent === 'Zapisz');
						if (bothButtons.length === 2) {
							observer.disconnect();
							console.log('inPostSendMode: przyciski "Zapisz" i "Zamów przesyłki" pojawiły się już na stronie');
							try {
								await inPostSendMode();
							} catch (error) {
								toastMessage(`Błąd! ${error?.message ? error.message : error}`);
							}
						}
					}	
				}
			});
		});
		observer.observe(document.body, { subtree: true, childList: true });
	}
}

function inPostSendModePrepareShipmentContainers() {
	let shipmentContainers = Array.from(document.querySelectorAll('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]'))?.filter(div => div.querySelector('H4') !== null && div.dataset?.inPost === undefined);
	for (const shipmentContainer of shipmentContainers) {
		if (Array.from(shipmentContainer.querySelectorAll('span'))?.find(span => span.textContent === 'Metoda dostawy' && span?.nextElementSibling.textContent.indexOf('InPost') !== -1)) {
			console.log(`Zamówienie ${shipmentContainer.querySelector('H4').textContent.split(' z ')[0]} to przesyłka InPost, jeszcze nie uzupełnione`);
			shipmentContainer.dataset.inPost = 'not-processed';
		}
	}
}

async function setPickupOption(sendMode) {
	const pickupOptions = Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'Zdecyduj, w jaki sposób nadasz przesyłkę')?.parentElement.querySelectorAll('input[type="radio"]');
	if (pickupOptions?.length) {
		pickupOptions.forEach((pickupOption, index) => {
			pickupOption.parentNode.addEventListener('mousedown', (e) => {
				const parentElement = (e.target.nodeName === 'LABEL' ? e.target.parentElement : e.target.parentElement.parentElement);
				clearTimeout(parentElement.dataset?.clickTimer);
				parentElement.dataset.clickTimer = setTimeout(async () => {
					pickupOptions.forEach(element => {
						if (element.nextElementSibling.firstElementChild.classList.contains('selected')) element.nextElementSibling.firstElementChild.classList.remove('selected');
					});
					parentElement.children[1].firstElementChild.classList.add('selected');
					delete parentElement?.dataset?.clickTimer;	
					let response;			
					try {
						response = await sendMessage({ action: 'saveInPostSendMode', sendMode: (index + 1)});
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						parentElement.children[1].firstElementChild.classList.remove('selected');
						return Promise.reject(error?.message ? error.message : error);
					}
					toastMessage('Zmieniono domyślny sposób nadania.');
				}, 1000);
			});

			pickupOption.parentNode.addEventListener('mouseup', (e) => {
				const parentElement = (e.target.nodeName === 'LABEL' ? e.target.parentElement : e.target.parentElement.parentElement);
				const clickTimer = parentElement.dataset?.clickTimer;
				clearTimeout(clickTimer);
				delete parentElement.dataset?.clickTimer;
			});
		});
		const clickEvent = new MouseEvent('click', {
			view: window,
			bubbles: true,
			cancelable: false,
		});
		pickupOptions[sendMode - 1].dispatchEvent(clickEvent);
		pickupOptions[sendMode - 1].nextElementSibling.firstElementChild.classList.add('selected');
	} 
	return Promise.resolve(true);
}

async function inPostSendModeObserveOrderShipmentsButton(orderShipmentsButton, multipleOrders) {
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}
	const activeLockingExtensions = Object.keys(readedValue.extensions).filter(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize' || extensionName === 'inPostSendMode'));
	if (orderShipmentsButton.dataset.lock !== undefined || orderShipmentsButton.dataset.done !== undefined) return Promise.resolve(true);
	orderShipmentsButton.dataset.lock = `${activeLockingExtensions.join(',')},`;

	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.attributeName === 'data-lock') {
				const saveButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zapisz');
				if (!multipleOrders) {
					if (orderShipmentsButton.dataset.lock === '') {
						saveButton.disabled = false;
					} else {
						saveButton.disabled = true;
					}
				}
			}
		});    
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['data-lock'] });		
}