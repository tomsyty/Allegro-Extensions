async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showProductName');
	try {
		await awaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
});

async function awaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await awaitOffersTable();
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await awaitOffersTable();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await getProductsNames(parameters);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function getProductsNames(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	parameters.environment = environment;
  let response;
	let productNames = {};
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${error?.message ? error.message : error}`);
	}

  let accessToken = response.result; 
	parameters.accessToken = accessToken;
	let offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="${element.dataset.cy}"]`) === null && element.querySelector('a[href*="/changes-in-product-catalogue/report/"]'));
	
	if (!offersList.length) {	// brak ofert na liście w tabeli, zaczekaj na pojawienie się ich
		const observer = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).filter(element => element.nodeName === 'TR' && element.dataset.cy !== undefined)?.length) {
						observer.takeRecords();
						observer.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await getProductsNames(parameters);
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						return;
					}
				}
			}
		});
		observer.observe(parameters.offersTable, { subtree: true, childList: true });
		return;
	}

	let offers = {};
	for (const offer of offersList) {
		offers[offer.dataset.cy] = null;
	}

	await new Promise(resolve => setTimeout(resolve, 100));
	try {
		await getProductName(parameters, productNames, offers);
	} catch (error) {
		return Promise.reject(error?.message ? error.message : error);
	}
}
		
async function getProductName(parameters, productNames, offers) {
	const offersToGet = Object.keys(offers).filter(element => offers[element] === null);
	
	async function* getOffers(offersToGet) {
		for (const offerId of offersToGet) {
			const offerElement = document.querySelector(`tr[data-cy="${offerId}"]`);
			if (offerElement === null) continue;
			const productIdHrefElement = offerElement.querySelector('a[href*="/changes-in-product-catalogue/report/"]');
			if (productIdHrefElement === null) {
				delete offersToGet[offerId];
				continue;
			}
			const productId = productIdHrefElement.href.slice(productIdHrefElement.href.lastIndexOf('/') + 1);
			if (productNames[productId] !== undefined) {
				if (productNames[productId].name !== '') {	// produkt jest już w pamięci podręcznej i został pobrany
					if (parameters.offersTable.querySelector(`div[data-id="${offerId}"]`) === null) {
						let productDiv;
						if (productNames[productId].rating.total === 0) {
							productDiv = `<div data-id="${offerId}" class="productName">${productNames[productId].name}</div>`;
						} else {
							productDiv = `<div data-id="${offerId}" class="productName">${productNames[productId].name}</div><div data-rating="${offerId}" class="productRating"><span>${productNames[productId].rating.average}/5</span><span class="distributionRating"></span></div>`;
						}
						if (offerElement.children[1].firstElementChild.querySelector(`div[data-id="${offerId}"`) === null) offerElement.children[1].firstElementChild.insertAdjacentHTML('beforeend', productDiv);
						if (productNames[productId].rating.total !== 0) {
							const container = offerElement.children[1].firstElementChild.querySelector('.distributionRating');
							if (container !== null) {
								container.innerHTML = '';
								let tooltip;
								tooltip = container.querySelector(`.distributionRatingTooltip`);
								if (tooltip === null) {
									tooltip = document.createElement('div');
									tooltip.className = 'distributionRatingTooltip';
									tooltip.innerHTML = '';
								}	

								for (let i = 0; i < productNames[productId].rating.distribution.length; i++) {
									const ratingCount = productNames[productId].rating.distribution[i];
									const percentage = ratingCount / Math.max(...productNames[productId].rating.distribution);
									const ratingLine = document.createElement('div');
									ratingLine.classList.add('ratingLine');
									ratingLine.style.width = `${percentage * 100}%`;		
									container.appendChild(ratingLine);
									tooltip.innerHTML += `<div class="row"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${productNames[productId].rating.distribution[i]}</div></div>`;
								}

								container.parentElement.appendChild(tooltip);	
							}
						}
					}
				}
			} else {
				productNames[productId] = {
					name: '',
					rating: {
						average: 0,
						total: 0,
						distribution: []
					}
				}
				let product;
				try {
					product = await getProduct(3, offerElement, offerId, productId, parameters, productNames, offers);
				} catch (error) {
					toastMessage(`Błąd! Podczas pobierania produktu wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				yield product;
			}
		}
	}

	let generatorFunction = getOffers(offersToGet);
	(async () => {
		for await (const value of generatorFunction) {
			console.log(value);
		}
	})();
	
	await new Promise(resolve => setTimeout(resolve, 1000));
	const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="${element.dataset.cy}"]`) === null && element.querySelector('a[href*="/changes-in-product-catalogue/report/"]'));
	if (offersList.length) {
		const nextOffers = {};
		for (const offer of offersList) {				
			nextOffers[offer.dataset.cy] = null;
		}
		await new Promise(resolve => setTimeout(resolve, 1000));
		getProductName(parameters, productNames, nextOffers);
	} else {
		const observer = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).filter(element => element.nodeName === 'TR' && element.dataset.cy !== undefined && parameters.offersTable.querySelector(`div[data-id="${element.dataset.cy}"]`) === null)?.length) {
						observer.takeRecords();
						observer.disconnect();
						const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="${element.dataset.cy}"]`) === null && element.querySelector('a[href*="/changes-in-product-catalogue/report/"]'));
						const offers = {};
						for (const offer of offersList) {
							offers[offer.dataset.cy] = null;
						}
						await new Promise(resolve => setTimeout(resolve, 1000));
						getProductName(parameters, productNames, offers);
						break;	
					}
				}
			}	
		});
		observer.observe(parameters.offersTable, { subtree: true, childList: true });
	}
}

async function getProduct(count, offerElement, offerId, productId, parameters, productNames, offers) {
	let response;
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let resultName;
		try {
			resultName = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (resultName.name !== undefined) {
			productNames[productId].name = resultName.name;

			try {
				response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/rating`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) { 
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
				} else {
					return Promise.reject(error?.message ? error.message : error);
				}
			}

			if (response.status === 200) {
				let rating;
				try {
					rating = await response.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
				}

				productNames[productId].rating.average = rating.averageScore;
				productNames[productId].rating.total = rating.totalResponses;
				if (rating.totalResponses) {
					for (let i=0; i<5; i++) {
						productNames[productId].rating.distribution.push(rating.scoreDistribution[i].count);
					}
				}
			} else if (response.status === 401) {
				if (--count) {
					try {
						response = await chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken' });
					} catch (error) {
						return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
					}
					parameters.accessToken = response.result;
					return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
				} else {
					return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. Nie udało się odświeżyć tokena dostępowego. ${error?.message ? error.message : error}`);
				}
			} else if (response.status === 429) {
				console.log('zbyt duża liczba żądań');
				if (--count) {
					toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
					await new Promise(resolve => setTimeout(resolve, 65000));
					return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
				} else {
					return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
				}
			} else if (response.status === 500) {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. ${error?.message ? error.message : error}`);
				}
			} else {
				return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
			}
		
			if (parameters.offersTable.querySelector(`div[data-id="${offerId}"]`) === null) {
				let productDiv;
				if (productNames[productId].rating.total === 0) {
					productDiv = `<div data-id="${offerId}" class="productName">${resultName.name}</div>`;
				} else {
					productDiv = `<div data-id="${offerId}" class="productName">${resultName.name}</div><div data-rating="${offerId}" class="productRating"><span>${productNames[productId].rating.average}/5</span><span class="distributionRating"></span></div>`;	
				}	
				if (offerElement.children[1].firstElementChild.querySelector(`div[data-id="${offerId}"`) === null) offerElement.children[1].firstElementChild.insertAdjacentHTML('beforeend', productDiv);
				if (productNames[productId].rating.total !== 0) {
					const container = offerElement.children[1].firstElementChild.querySelector('.distributionRating');	
					if (container !== null) {
						container.innerHTML = '';
						let tooltip;
						tooltip = container.querySelector(`.distributionRatingTooltip`);
						if (tooltip === null) {
							tooltip = document.createElement('div');
							tooltip.className = 'distributionRatingTooltip';
							tooltip.innerHTML = '';
							
						}			

						for (let i = 0; i < productNames[productId].rating.distribution.length; i++) {
							const ratingCount = productNames[productId].rating.distribution[i];
							const percentage = ratingCount / Math.max(...productNames[productId].rating.distribution);
							const ratingLine = document.createElement('div');
							ratingLine.classList.add('ratingLine');
							ratingLine.style.width = `${percentage * 100}%`;
							container.appendChild(ratingLine);
							tooltip.innerHTML += `<div class="row"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${productNames[productId].rating.distribution[i]}</div></div>`;
						}

						container.parentElement.appendChild(tooltip);
					}
				}
			}
			return Promise.resolve(resultName.name);
		}
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getProduct(count, offerElement, offerId, productId, parameters, productNames, offers);
		} else {
			return Promise.reject('Błąd serwera, spróbuj ponownie później.');
		}
	} else {
		return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
	}
}