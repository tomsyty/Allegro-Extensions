async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showProductName');
	try {
		await spnAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

async function spnAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable,
		catalogHeaderIndex: (offersTable ? Array.from(offersTable.querySelectorAll('th')).find(e => e.textContent === 'Katalog Allegro').cellIndex : 0)
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await spnAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await spnAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await spnObserveOffersTable(parameters);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function spnObserveOffersTable(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
	}
	
  let accessToken = response.result; 
	parameters.accessToken = accessToken;
	parameters.environment = environment;

	const viewMode = (document.querySelector('button[data-analytics-interaction-value="ExitFullscreen"]') ? 'wide' : 'normal');

	if (viewMode === 'wide') {
	
	}

  let offerProducts = [];
	let products = [];

	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	const observer = new IntersectionObserver(spnIntersectionCallback, options);

	async function spnIntersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.spn = false;
        });

        try {
          await spnProcessOffersList(parameters, offersList, offerProducts, products);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
      }
    });
		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(e => observer.observe(e));
  }

	let offersList;
  do {
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
    const offersListLength = offersList.length;
    await new Promise(resolve => setTimeout(resolve, 2000));
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
    if (offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);
  
  offersList.forEach(offerRow => {
    offerRow.dataset.spn = false;
    observer.observe(offerRow);
  });

	try {
		await spnProcessOffersList(parameters, offersList, offerProducts, products);
	} catch (error) {
		return Promise.reject(getErrorMessage(error));
	}
}

async function spnProcessOffersList(parameters, offersList, offerProducts, products) {
	let offerRow = offersList.shift();
	if (offerRow === undefined) return;
	if (!offerRow.isConnected) return await spnProcessOffersList(parameters, offersList, offerProducts, products);
	offerRow.dataset.spn = true;
	const offerId = offerRow.dataset.cy;
	if (offerProducts[offerId]) {
		offerProducts[offerId].forEach(product => {
			const productId = product.id;
			if (products[product.id]) {
				const product = products[productId];
				if (offerRow.querySelector(`div[id="product_${productId}"]`) === null) {
					let productDiv;
					if (product.rating.total === 0) {
						productDiv = `<div id="product_${productId}" class="productName">${product.name}</div>`;
					} else {
						productDiv = `<div id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
					}	
					if (offerRow.children[parameters.catalogHeaderIndex].querySelector(`div.productRating`) === null) offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('afterend', productDiv);
					if (product.rating.total !== 0) {
						const container = offerRow.children[parameters.catalogHeaderIndex].querySelector('.distributionRating');	
						if (container !== null) {
							container.innerHTML = '';
							let tooltip;
							tooltip = container.querySelector(`.distributionRatingTooltip`);
							if (tooltip === null) {
								tooltip = document.createElement('div');
								tooltip.className = 'distributionRatingTooltip';
								tooltip.innerHTML = '';
								
							}			

							for (let i = 0; i < product.rating.distribution.length; i++) {
								const ratingCount = product.rating.distribution[i];
								const percentage = ratingCount / Math.max(...product.rating.distribution);
								const ratingLine = document.createElement('div');
								ratingLine.classList.add('ratingLine');
								ratingLine.style.width = `${percentage * 100}%`;
								container.appendChild(ratingLine);
								tooltip.innerHTML += `<div class="spnRow"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
							}

							container.parentElement.appendChild(tooltip);
						}
					}
				}
			}
		});
	} else {
		let offer;
		let productId;
		try {
			offer = await spnGetOfferProductData(3, offerId, parameters, offerProducts);
			if (offer?.products) {
				for (let i = 0; i < offer.products.length; i++) {
					if (offer.products[i] === null) continue;
					productId = offer.products[i].id;
					products[productId] = {
						name: '',
						rating: {
							average: 0,
							total: 0,
							distribution: []
						}
					}
					await spnGetProduct(3, offerRow, offerId, productId, parameters, products);
					const product = products[productId];
					console.log(product);
					if (offerRow.querySelector(`div[id="product_${productId}"]`) === null) {
						let productDiv;
						if (product.rating.total === 0) {
							productDiv = `<div id="product_${productId}" class="productName">${product.name}</div>`;
						} else {
							productDiv = `<div id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
						}	
						if (offerRow.children[parameters.catalogHeaderIndex].querySelector(`div.productRating`) === null) offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('afterend', productDiv);
						if (product.rating.total !== 0) {
							const container = offerRow.children[parameters.catalogHeaderIndex].querySelector('.distributionRating');	
							if (container !== null) {
								container.innerHTML = '';
								let tooltip;
								tooltip = container.querySelector(`.distributionRatingTooltip`);
								if (tooltip === null) {
									tooltip = document.createElement('div');
									tooltip.className = 'distributionRatingTooltip';
									tooltip.innerHTML = '';
									
								}			

								for (let i = 0; i < product.rating.distribution.length; i++) {
									const ratingCount = product.rating.distribution[i];
									const percentage = ratingCount / Math.max(...product.rating.distribution);
									const ratingLine = document.createElement('div');
									ratingLine.classList.add('ratingLine');
									ratingLine.style.width = `${percentage * 100}%`;
									container.appendChild(ratingLine);
									tooltip.innerHTML += `<div class="spnRow"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
								}

								container.parentElement.appendChild(tooltip);
							}
						}
					}
				}
			}
		} catch (error) {
			toastMessage(`Błąd! Podczas pobierania oferty ${offerId} wystąpił błąd. ${getErrorMessage(error)}`);
			console.log(JSON.stringify(error));
		}
	}
	return await spnProcessOffersList(parameters, offersList, offerProducts, products);
}

async function spnGetOfferProductData(count, offerId, parameters, offerProducts) {
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać oferty ${offerId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let offerData;
		try {
			offerData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (offerData.productSet !== undefined && offerData.productSet[0].product.id !== null) {
      offerProducts[offerId] = [];
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        try {
					offerProducts[offerId].push({ id: productId });
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts[offerId] });
		} else return Promise.resolve(null);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await spnGetOfferProductData(count, offerId, parameters, offerProducts);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));			
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania parametrów oferty ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów oferty ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		return Promise.reject(`Nie udało się pobrać parametrów oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
	}
}
async function spnGetProduct(count, offerRow, offerId, productId, parameters, products) {
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać produktu ${productId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let product;
		try {
			product = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (product.name !== undefined) {
			products[productId].name = product.name;

			try {
				fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/rating`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) { 
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać statystyk oferty ${offerId}. ${getErrorMessage(error)}`);
				}
			}

			if (fetchResponse.status === 200) {
				let rating;
				try {
					rating = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}

				products[productId].rating.average = rating.averageScore;
				products[productId].rating.total = rating.totalResponses;
				if (rating.totalResponses) {
					for (let i=0; i<5; i++) {
						products[productId].rating.distribution.push(rating.scoreDistribution[i]?.count && rating.scoreDistribution[i].count >= 0 ? rating.scoreDistribution[i].count : 0);
					}
				}
				return Promise.resolve(true);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}  
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					parameters.accessToken = response.result;
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Podczas pobierania statystyk oferty ${offerId} wystąpił błąd. Nie udało się odświeżyć tokena dostępowego.`);
				}
			} else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      		await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania statystyk oferty ${offerId}. Spróbuj ponownie później.`);
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Błąd serwera podczas pobierania statystyk oferty ${offerId}. Spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Nie udało się pobrać statystyk oferty ${oferId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}
			}
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania oferty ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania oferty ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(`Nie udało się pobrać oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}