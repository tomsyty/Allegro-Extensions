async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showProductName');
	if(navigation?.activation.navigationType === 'reload') {
		const itemsInSessionStorage = await chrome.storage.session.get(null);
		Object.entries(itemsInSessionStorage).forEach(([k, v]) => { if(Object.hasOwn(itemsInSessionStorage[k], 'products')) chrome.storage.session.remove(k) });
	}
	try {
		await spnAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

async function spnAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable,
		catalogHeaderIndex: (offersTable ? Array.from(offersTable.querySelectorAll('th')).find(e => e.textContent === 'Katalog Allegro').cellIndex : 0)
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await spnAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await spnAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});

		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await spnObserveOffersTable(parameters);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function spnObserveOffersTable(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
	}
	
  let accessToken = response.result; 
	parameters.accessToken = accessToken;
	parameters.environment = environment;

	const viewMode = (document.querySelector('button[data-analytics-interaction-value="ExitFullscreen"]') ? 'wide' : 'normal');

	if (viewMode === 'wide') {
	
	}

	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	let offersList = [];

	const mutationObserver = new MutationObserver(spnMutationCallback);

	async function spnMutationCallback(mutations, mo) {
		for (const mutation of mutations) {
			if (mutation.type === 'attributes') {
				if (mutation.attributeName === 'data-cy') {
					mutationObserver.disconnect();
					const offerRow = mutation.target;
					offerRow.dataset.spn = false;			
					let currentProduct = offerRow.querySelector('div[id^="product_"]');
					if (currentProduct) currentProduct.remove();
					let productRating = offerRow.querySelector('.productRating');
					if (productRating) productRating.remove();
					if (!offersList.includes(offerRow)) offersList.push(offerRow);
				}
			}
		}

		try {
			await spnProcessOffersList(parameters, offersList);
		} catch (error) {
			return Promise.reject(getErrorMessage(error));
		}

		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(offerRow => {
			intersectionObserver.observe(offerRow);
		});
	}

	const intersectionObserver = new IntersectionObserver(spnIntersectionCallback, options);

	async function spnIntersectionCallback(entries, io) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
				const currentOffersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined || (offerRow.querySelector('div[id^="product_"]')?.dataset?.auctionid !== offerRow.dataset.cy));
				currentOffersList.forEach(offerRow => {
					if (!offersList.includes(offerRow)) {
						offerRow.dataset.spn = false;
						offersList.push(offerRow);
					}
        });
      }
    });

		try {
			await spnProcessOffersList(parameters, offersList);
		} catch (error) {
			return Promise.reject(getErrorMessage(error));
		}

		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(offerRow => {
			intersectionObserver.observe(offerRow);
			mutationObserver.observe(offerRow, {
				attributeFilter: ['data-cy']
			});
		});
  }

	let currentOffersList;
  do {
    currentOffersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined || (offerRow.querySelector('div[id^="product_"]')?.dataset?.auctionid !== offerRow.dataset.cy));

		const currentOffersListLength = currentOffersList.length;
    await new Promise(resolve => setTimeout(resolve, 2000));

    currentOffersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined || (offerRow.querySelector('div[id^="product_"]')?.dataset?.auctionid !== offerRow.dataset.cy));

    if (!currentOffersList || currentOffersList.length === 0 || (currentOffersList.length !== currentOffersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);

	currentOffersList.forEach(offerRow => {
		if (!offersList.includes(offerRow)) {
			offerRow.dataset.spn = false;
			offersList.push(offerRow);
			intersectionObserver.observe(offerRow);
		}
	});

	try {
		await spnProcessOffersList(parameters, offersList);
	} catch (error) {
		return Promise.reject(getErrorMessage(error));
	}
}

async function spnProcessOffersList(parameters, offersList) {
	let offerRow = offersList.shift();
	if (offerRow === undefined) return;
	if (!offerRow.isConnected) return await spnProcessOffersList(parameters, offersList);
	offerRow.dataset.spn = true;
	const offerId = offerRow.dataset.cy;
	if (offerId === offerRow.querySelector('div[id^="product_"]')?.dataset?.auctionid) return;
	let offerFromStorage;
	offerFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	if (offerFromStorage[offerId] && offerFromStorage[offerId]?.products?.length) {
		offerFromStorage[offerId].products.forEach(product => {
			const productId = product.id;
			if (productId) {
				const oldProductDiv = offerRow.querySelector(`div[id^="product_"]`);
				if (oldProductDiv) oldProductDiv.remove();
				const oldProductRating = offerRow.querySelector('.productRating');
				if (oldProductRating) oldProductRating.remove();
				
				let productDiv;
				if (product.rating.total === 0) {
					productDiv = `<div data-auctionid="${offerId}" id="product_${productId}" class="productName">${product.name}</div>`;
				} else {
					productDiv = `<div data-auctionid="${offerId}" id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
				}	
				if (offerRow.children[parameters.catalogHeaderIndex].querySelector(`div.productRating`) === null) {
					if (offerRow.children[parameters.catalogHeaderIndex].lastElementChild.className === 'parametersDiv') offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('beforebegin', productDiv); else offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('afterend', productDiv);
				}
				if (product.rating.total !== 0) {
					const container = offerRow.children[parameters.catalogHeaderIndex].querySelector('.distributionRating');	
					if (container !== null) {
						container.innerHTML = '';
						let tooltip;
						tooltip = container.querySelector(`.distributionRatingTooltip`);
						if (tooltip === null) {
							tooltip = document.createElement('div');
							tooltip.className = 'distributionRatingTooltip';
							tooltip.innerHTML = '';
							
						}			

						for (let i = 0; i < product.rating.distribution.length; i++) {
							const ratingCount = product.rating.distribution[i];
							const percentage = ratingCount / Math.max(...product.rating.distribution);
							const ratingLine = document.createElement('div');
							ratingLine.classList.add('ratingLine');
							ratingLine.style.width = `${percentage * 100}%`;
							container.appendChild(ratingLine);
							tooltip.innerHTML += `<div class="spnRow"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
						}

						container.parentElement.appendChild(tooltip);
					}
				}
			}
		});
	} else {
		let productsIds;
		let product;
		
		let offer = {
			products: []
		};

		const oldProductDiv = offerRow.querySelector(`div[id^="product_"]`);
		if (oldProductDiv) oldProductDiv.remove();
		const oldProductRating = offerRow.querySelector('.productRating');
		if (oldProductRating) oldProductRating.remove();

		try {
			productsIds = await spnGetOfferProductsIds(3, offerId, parameters);
			if (productsIds?.products) {
				for (let i = 0; i < productsIds.products.length; i++) {
					if (productsIds.products[i] === null) continue;
					const productId = productsIds.products[i];
					product = await spnGetProduct(3, offerRow, offerId, productId, parameters);
					offer.products.push(product);
					if (offerRow.querySelector(`div[id="product_${productId}"]`) === null) {
						let productDiv;
						if (product.rating.total === 0) {
							productDiv = `<div data-auctionid="${offerId}" id="product_${productId}" class="productName">${product.name}</div>`;
						} else {
							productDiv = `<div data-auctionid="${offerId}" id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
						}	
						if (offerRow.children[parameters.catalogHeaderIndex].querySelector(`div.productRating`) === null) {
							if (offerRow.children[parameters.catalogHeaderIndex].lastElementChild.className === 'parametersDiv') offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('beforebegin', productDiv); else offerRow.children[parameters.catalogHeaderIndex].lastElementChild.insertAdjacentHTML('afterend', productDiv);
						}
						if (product.rating.total !== 0) {
							const container = offerRow.children[parameters.catalogHeaderIndex].querySelector('.distributionRating');	
							if (container !== null) {
								container.innerHTML = '';
								let tooltip;
								tooltip = container.querySelector(`.distributionRatingTooltip`);
								if (tooltip === null) {
									tooltip = document.createElement('div');
									tooltip.className = 'distributionRatingTooltip';
									tooltip.innerHTML = '';									
								}			

								for (let i = 0; i < product.rating.distribution.length; i++) {
									const ratingCount = product.rating.distribution[i];
									const percentage = ratingCount / Math.max(...product.rating.distribution);
									const ratingLine = document.createElement('div');
									ratingLine.classList.add('ratingLine');
									ratingLine.style.width = `${percentage * 100}%`;
									container.appendChild(ratingLine);
									tooltip.innerHTML += `<div class="spnRow"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
								}

								container.parentElement.appendChild(tooltip);
							}
						}
					}
				}
				await saveDataToSessionStorage({ [`${offerId}`]: Object.assign(offerFromStorage[`${offerId}`] ?? {}, offer) });
			}
		} catch (error) {
			toastMessage(`Błąd! Podczas pobierania oferty ${offerId} wystąpił błąd. ${getErrorMessage(error)}`);
		}
	}
	return await spnProcessOffersList(parameters, offersList);
}

async function spnGetOfferProductsIds(count, offerId, parameters) {
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductsIds(count, offerId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać oferty ${offerId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let offerData;
		try {
			offerData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (offerData.productSet !== undefined && offerData.productSet[0].product.id !== null) {
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));
			return Promise.resolve({ id: offerId, products: productsToGet });
		} else return Promise.resolve(null);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await spnGetOfferProductsIds(count, offerId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));			
			return await spnGetOfferProductsIds(count, offerId, parameters);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania parametrów oferty ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductsIds(count, offerId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów oferty ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		return Promise.reject(`Nie udało się pobrać parametrów oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
	}
}

async function spnGetProduct(count, offerRow, offerId, productId, parameters) {
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać produktu ${productId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let product;
		let productData = {
			id: productId,
			name:'',
			rating: {
				average: 0,
				total: 0,
				distribution: []
			}
		};
		try {
			product = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (product.name !== undefined) {
			productData.name = product.name;

			try {
				fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/rating`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) { 
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters);
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać statystyk oferty ${offerId}. ${getErrorMessage(error)}`);
				}
			}

			if (fetchResponse.status === 200) {
				let rating;
				try {
					rating = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}

				productData.rating.average = rating.averageScore;
				productData.rating.total = rating.totalResponses;
				if (rating.totalResponses) {
					for (let i=0; i<5; i++) {
						productData.rating.distribution.push(rating.scoreDistribution[i]?.count && rating.scoreDistribution[i].count >= 0 ? rating.scoreDistribution[i].count : 0);
					}
				}
				return Promise.resolve(productData);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}  
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					parameters.accessToken = response.result;
					return await spnGetProduct(count, offerRow, offerId, productId, parameters);
				} else {
					return Promise.reject(`Podczas pobierania statystyk oferty ${offerId} wystąpił błąd. Nie udało się odświeżyć tokena dostępowego.`);
				}
			} else if (fetchResponse.status === 404) {
				return Promise.resolve(productData);
			} else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      		await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters);
				} else {
					return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania statystyk oferty ${offerId}. Spróbuj ponownie później.`);
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters);
				} else {
					return Promise.reject(`Błąd serwera podczas pobierania statystyk oferty ${offerId}. Spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters);
				} else {
					return Promise.reject(`Nie udało się pobrać statystyk oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}
			}
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await spnGetProduct(count, offerRow, offerId, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania oferty ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania oferty ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}