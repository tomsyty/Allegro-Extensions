async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showProductName');
	try {
		await spnAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
});

async function spnAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await spnAwaitOffersTable();
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await spnAwaitOffersTable();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await spnObserveOffersTable(parameters);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function spnObserveOffersTable(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${error?.message ? error.message : error}`);
	}
	
  let accessToken = response.result; 
	parameters.accessToken = accessToken;
	parameters.environment = environment;

  let offerProducts = [];
	let products = [];

	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	const observer = new IntersectionObserver(spnIntersectionCallback, options);

	async function spnIntersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.spn = false;
        });

        try {
          await spnProcessOffersList(parameters, offersList, offerProducts, products);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
      }
    });
		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(e => observer.observe(e));
  }

	let offersList;
  do {
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
    const offersListLength = offersList.length;
    await new Promise(resolve => setTimeout(resolve, 2000));
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.spn === undefined);
    if (offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);
  
  offersList.forEach(offerRow => {
    offerRow.dataset.spn = false;
    observer.observe(offerRow);
  });

	try {
		await spnProcessOffersList(parameters, offersList, offerProducts, products);
	} catch (error) {
		return Promise.reject(error?.message ? error.message : error);
	}
}

async function spnProcessOffersList(parameters, offersList, offerProducts, products) {
	let offerRow = offersList.shift();
	if (offerRow === undefined) return;
	if (!offerRow.isConnected) return await spnProcessOffersList(parameters, offersList, offerProducts, products);
	offerRow.dataset.spn = true;
	const offerId = offerRow.dataset.cy;
	if (offerProducts[offerId]) {
		offerProducts[offerId].forEach(product => {
			const productId = product.id;
			if (products[product.id]) {
				const product = products[productId];
				if (offerRow.querySelector(`div[id="product_${productId}"]`) === null) {
					let productDiv;
					if (product.rating.total === 0) {
						productDiv = `<div id="product_${productId}" class="productName">${product.name}</div>`;
					} else {
						productDiv = `<div id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
					}	
					if (offerRow.children[1].firstElementChild.querySelector(`div.productRating`) === null) offerRow.children[1].firstElementChild.insertAdjacentHTML('beforeend', productDiv);
					if (product.rating.total !== 0) {
						const container = offerRow.children[1].firstElementChild.querySelector('.distributionRating');	
						if (container !== null) {
							container.innerHTML = '';
							let tooltip;
							tooltip = container.querySelector(`.distributionRatingTooltip`);
							if (tooltip === null) {
								tooltip = document.createElement('div');
								tooltip.className = 'distributionRatingTooltip';
								tooltip.innerHTML = '';
								
							}			

							for (let i = 0; i < product.rating.distribution.length; i++) {
								const ratingCount = product.rating.distribution[i];
								const percentage = ratingCount / Math.max(...product.rating.distribution);
								const ratingLine = document.createElement('div');
								ratingLine.classList.add('ratingLine');
								ratingLine.style.width = `${percentage * 100}%`;
								container.appendChild(ratingLine);
								tooltip.innerHTML += `<div class="row"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
							}

							container.parentElement.appendChild(tooltip);
						}
					}
				}
			}
		});
	} else {
		let offer;
		let productId;
		try {
			offer = await spnGetOfferProductData(3, offerId, parameters, offerProducts);
			if (offer?.products) {
				for (let i = 0; i < offer.products.length; i++) {
					if (offer.products[i] === null) continue;
					productId = offer.products[i].id;
					products[productId] = {
						name: '',
						rating: {
							average: 0,
							total: 0,
							distribution: []
						}
					}
					await spnGetProduct(3, offerRow, offerId, productId, parameters, products);
					const product = products[productId];
					console.log(product);
					if (offerRow.querySelector(`div[id="product_${productId}"]`) === null) {
						let productDiv;
						if (product.rating.total === 0) {
							productDiv = `<div id="product_${productId}" class="productName">${product.name}</div>`;
						} else {
							productDiv = `<div id="product_${productId}" class="productName">${product.name}</div><div class="productRating"><span>${product.rating.average}/5</span><span class="distributionRating"></span></div>`;	
						}	
						if (offerRow.children[1].firstElementChild.querySelector(`div.productRating`) === null) offerRow.children[1].firstElementChild.insertAdjacentHTML('beforeend', productDiv);
						if (product.rating.total !== 0) {
							const container = offerRow.children[1].firstElementChild.querySelector('.distributionRating');	
							if (container !== null) {
								container.innerHTML = '';
								let tooltip;
								tooltip = container.querySelector(`.distributionRatingTooltip`);
								if (tooltip === null) {
									tooltip = document.createElement('div');
									tooltip.className = 'distributionRatingTooltip';
									tooltip.innerHTML = '';
									
								}			

								for (let i = 0; i < product.rating.distribution.length; i++) {
									const ratingCount = product.rating.distribution[i];
									const percentage = ratingCount / Math.max(...product.rating.distribution);
									const ratingLine = document.createElement('div');
									ratingLine.classList.add('ratingLine');
									ratingLine.style.width = `${percentage * 100}%`;
									container.appendChild(ratingLine);
									tooltip.innerHTML += `<div class="row"><div class="textLeft">${'✩'.repeat(5 - i)}</div><div class="line"></div><div class="textRight">${product.rating.distribution[i]}</div></div>`;
								}

								container.parentElement.appendChild(tooltip);
							}
						}
					}
				}
			}
		} catch (error) {
			toastMessage(`Błąd! Podczas pobierania produktu wystąpił błąd. ${error?.message ? error.message : error}`);
		}
	}
	return await spnProcessOffersList(parameters, offersList, offerProducts, products);
}

async function spnGetOfferProductData(count, offerId, parameters, offerProducts) {
	let response;
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let offerData;
		try {
			offerData = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (offerData.productSet !== undefined && offerData.productSet[0].product.id !== null) {
      offerProducts[offerId] = [];
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        try {
					offerProducts[offerId].push({ id: productId });
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts[offerId] });
		} else return Promise.resolve(null);
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await spnGetOfferProductData(count, offerId, parameters, offerProducts);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject('Błąd serwera, spróbuj ponownie później.');
		}
	} else {
		return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
	}
}
async function spnGetProduct(count, offerRow, offerId, productId, parameters, products) {
	let response;
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let product;
		try {
			product = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (product.name !== undefined) {
			products[productId].name = product.name;

			try {
				response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/rating`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) { 
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(error?.message ? error.message : error);
				}
			}

			if (response.status === 200) {
				let rating;
				try {
					rating = await response.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
				}

				products[productId].rating.average = rating.averageScore;
				products[productId].rating.total = rating.totalResponses;
				if (rating.totalResponses) {
					for (let i=0; i<5; i++) {
						products[productId].rating.distribution.push(rating.scoreDistribution[i].count);
					}
				}
				return Promise.resolve(true);
			} else if (response.status === 401) {
				if (--count) {
					try {
						response = await chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken' });
					} catch (error) {
						return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
					}
					parameters.accessToken = response.result;
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. Nie udało się odświeżyć tokena dostępowego. ${error?.message ? error.message : error}`);
				}
			} else if (response.status === 429) {
				console.log('zbyt duża liczba żądań');
				if (--count) {
					toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
					await new Promise(resolve => setTimeout(resolve, 65000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
				}
			} else if (response.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. ${error?.message ? error.message : error}`);
				}
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
				} else {
					return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
				}
			}
		}
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject('Błąd serwera, spróbuj ponownie później.');
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await spnGetProduct(count, offerRow, offerId, productId, parameters, products);
		} else {
			return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
		}
	}
}