async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt shipmentExistsWarning');

  let orderId = document.location.href.split('/');
	orderId = orderId[orderId.length - 1].split('?')[0];
	if (orderId.indexOf(',') !== -1) {
    document.body.dataset.multipleOrders = 'true';
    document.body.dataset.ordersIds = orderId;
  } else document.body.dataset.multipleOrders = 'false';

  const observer = new MutationObserver(mutations => {
		mutations.forEach(async (mutation) => {
			if (mutation.type === 'childList') {
				const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.shipmentExistsNew === undefined);
				if (addedHeader) {
          addedHeader.dataset.shipmentExistsNew = 'false';
					try {
            const shipmentExists = await checkIfShipmentExists();
            const orderStatus = await checkOrderStatus();
            if (orderStatus.orderStatus === 'CANCELLED') {
              toastMessage(`Uwaga! Zamówienie  ${orderStatus.orderId} zostało anulowane.`);
              window.alert(`Zamówienie ${orderStatus.orderId} zostało anulowane.`);
            } else if (shipmentExists.shipmentExists === true) {
              toastMessage(`Uwaga! Do zamówienia ${shipmentExists.orderId} został już przypisany numer przesyłki.`);
              window.alert(`Do zamówienia ${shipmentExists.orderId} został już przypisany numer przesyłki.`);
            }

            let buttonNodes = Array.from(document.querySelectorAll('button'));
            let saveButton = buttonNodes.find(element => element.textContent === 'Zapisz'); 
            if (saveButton !== undefined) {
              if (shipmentExists.shipmentExists === false) saveButton.classList.add('shipmentNotExists');
              if (orderStatus.orderStatus === 'CANCELLED') {
                saveButton.classList.add('orderCancelled');
                document.querySelectorAll('button > div[aria-label="Zmodyfikuj zamówienie"]').forEach(element => element.parentElement.classList.add('editOrderDisabled'));
              }
            } else {
              console.log('shipmentExistsWarning: oczekiwanie na przycisk "Zapisz"');
              const observer = new MutationObserver(mutations => {
                mutations.forEach(async (mutation) => {
                  if (mutation.type === 'childList') {
                    const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zapisz')));
                    if (addedButton !== undefined) {
                      buttonNodes = Array.from(document.querySelectorAll('button'));
                      const saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
                      if (saveButton) {
                        observer.disconnect();
                        console.log('shipmentExistsWarning: przycisk "Zapisz" pojawił się już na stronie');
                        if (shipmentExists.shipmentExists === false) saveButton.classList.add('shipmentNotExists');
                        if (orderStatus.orderStatus === 'CANCELLED') {
                          saveButton.classList.add('orderCancelled');
                          document.querySelectorAll('button > div[aria-label="Zmodyfikuj zamówienie"]').forEach(element => element.parentElement.classList.add('editOrderDisabled'));
                        }
                      }
                    }	
                  }
                });
              });
              observer.observe(document.body, { subtree: true, childList: true });
            }
            
          } catch (error) {
            toastMessage(`Błąd! ${getErrorMessage(error)}`);
          }
				}	
			}
		});
	});

	observer.observe(document.body, { subtree: true, childList: true });

  if (orderId === undefined) {
    toastMessage('Błąd! W adresie strony nie znaleziono numeru zamówienia. Nie udało się sprawdzić, czy przesyłka już istnieje.');
    return;
  }

  const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.shipmentExistsNew === undefined);
  if (addedHeader) {
    addedHeader.dataset.shipmentExistsNew = 'false';
    try {
      const shipmentExists = await checkIfShipmentExists();
      const orderStatus = await checkOrderStatus();
      if (orderStatus.orderStatus === 'CANCELLED') {
        toastMessage(`Uwaga! Zamówienie ${orderStatus.orderId} zostało anulowane.`);
        window.alert(`Zamówienie ${orderStatus.orderId} zostało anulowane.`);
      } else if (shipmentExists.shipmentExists === true) {
        toastMessage(`Uwaga! Do zamówienia ${shipmentExists.orderId} został już przypisany numer przesyłki.`);
        window.alert(`Do zamówienia ${shipmentExists.orderId} został już przypisany numer przesyłki.`);
      }

      let buttonNodes = Array.from(document.querySelectorAll('button'));
      let saveButton = buttonNodes.find(element => element.textContent === 'Zapisz'); 
      if (saveButton !== undefined) {
        if (shipmentExists.shipmentExists === false) saveButton.classList.add('shipmentNotExists');
        if (orderStatus.orderStatus === 'CANCELLED') {
          saveButton.classList.add('orderCancelled');
          document.querySelectorAll('button > div[aria-label="Zmodyfikuj zamówienie"]').forEach(element => element.parentElement.classList.add('editOrderDisabled'));
        }
      } else {
        console.log('shipmentExistsWarning: oczekiwanie na przycisk "Zapisz"');
        const observer = new MutationObserver(mutations => {
          mutations.forEach(async (mutation) => {
            if (mutation.type === 'childList') {
              const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zapisz')));
              if (addedButton !== undefined) {
                buttonNodes = Array.from(document.querySelectorAll('button'));
                const saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
                if (saveButton) {
                  observer.disconnect();
                  console.log('shipmentExistsWarning: przycisk "Zapisz" pojawił się już na stronie');
                  if (shipmentExists.shipmentExists === false) saveButton.classList.add('shipmentNotExists');
                  if (orderStatus.orderStatus === 'CANCELLED') {
                    saveButton.classList.add('orderCancelled');
                    document.querySelectorAll('button > div[aria-label="Zmodyfikuj zamówienie"]').forEach(element => element.parentElement.classList.add('editOrderDisabled'));
                  }
                }
              }	
            }
          });
        });
        observer.observe(document.body, { subtree: true, childList: true });
      }
      
    } catch (error) {
      toastMessage(`Błąd! ${getErrorMessage(error)}`);
    }
  }
});

async function checkIfShipmentExists(count = 5) {
  const multipleOrders = (document.body.dataset.multipleOrders === 'true'); 
  let orderId;
  let ordersIds;
  let addedHeader;
  let shipmentContainer;
  if (!multipleOrders) {
    orderId = document.location.href.split('/');
    orderId = orderId[orderId.length - 1].split('?')[0];
  } else {
    ordersIds = document.body.dataset.ordersIds.split(',');
    addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:');
    shipmentContainer = addedHeader.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
    orderId = ordersIds[Number(shipmentContainer.querySelector('H4').textContent.split(' z ')[0]) - 1];
    shipmentContainer.querySelectorAll('button > div[aria-label="Usuń zamówienie"]')[1].addEventListener('click', () => {
      ordersIds = ordersIds.filter(id => id !== orderId);
      document.querySelectorAll('button > div[aria-label="Zmodyfikuj zamówienie"]').forEach(element => element.parentElement.classList.remove('editOrderDisabled'));
      if (ordersIds.length > 0) {
        document.body.dataset.ordersIds = ordersIds.join(',');
      }
    });
  }

  let response;
  let fetchResponse;
  let fetchData;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}/shipments` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkIfShipmentExists(count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    return Promise.resolve({ orderId: orderId, shipmentExists: (fetchData.shipments.length ? true : false) });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await checkIfShipmentExists(count);  
    } else {
      return Promise.reject(`Nie udało się czy do zamówienia został przypisany już jakiś numer przesyłki. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await checkIfShipmentExists(count);
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkIfShipmentExists(count);
    } else {
      return Promise.reject(`Błąd serwera podczas sprawdzania czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki, spróbuj ponownie później.`);
    }
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkIfShipmentExists(count);      
    } else {
      return Promise.reject(`Nie udało się sprawdzić czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}

async function checkOrderStatus(count = 5) {
  const multipleOrders = (document.body.dataset.multipleOrders === 'true'); 
  let orderId;
  let ordersIds;
  let addedHeader;
  let shipmentContainer;
  if (!multipleOrders) {
    orderId = document.location.href.split('/');
    orderId = orderId[orderId.length - 1].split('?')[0];
  } else {
    ordersIds = document.body.dataset.ordersIds.split(',');
    addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:');
    shipmentContainer = addedHeader.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
    orderId = ordersIds[Number(shipmentContainer.querySelector('H4').textContent.split(' z ')[0]) - 1];
  }

  let response;
  let fetchResponse;
  let fetchData;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}/` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkOrderStatus(count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić czy zamówienie ${orderId} nie jest anulowane. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    return Promise.resolve({ orderId: orderId, orderStatus: fetchData.status });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await checkOrderStatus(count);  
    } else {
      return Promise.reject(`Nie udało się czy zamówienie nie jest anulowane. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await checkOrderStatus(count);
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkOrderStatus(count);
    } else {
      return Promise.reject(`Błąd serwera podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkOrderStatus(count);      
    } else {
      return Promise.reject(`Nie udało się sprawdzić czy zamówienie ${orderId} nie jest anulowane. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}