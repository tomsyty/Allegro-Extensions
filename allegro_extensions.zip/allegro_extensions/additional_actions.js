async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'backgroundFetch',
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}


window.addEventListener('load', async () => {
	console.log('Załadowano skrypt additionalActions');
	try {
		await additionalActionsAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}

  (function addStylesheet() {	
		const link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0&display=block';
		document.head.appendChild(link);
	})();

  await new Promise(resolve => setTimeout(resolve, 1000));
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="highlight_off"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'highlight_off';
		preloadIconsContainer.appendChild(iconHighlightOff);
	}

  const selectDateTimePreorderDialog = document.createElement('div');
  selectDateTimePreorderDialog.id = 'selectDateTimePreorderDialogContainer';
  selectDateTimePreorderDialog.dataset.selectedDateTime = '';
  selectDateTimePreorderDialog.innerHTML = /* html */ `<dialog id="selectDateTimePreorderDialog">
    <form method="dialog">
      <div class="row">
        <label for="preorderDateTime">Wybierz datę i godzinę wystawienia aukcji / rozpoczęcia wysyłki</label>
        <input type="datetime-local" id="preorderDateTime" name="preorderDateTime" min="${getCurrentDatetimeLocal()}" max="${getMaxDatetimeLocal()}" required>
      </div>
      <div class="row">
        <button id="selectDateTimePreorderCancel" class="actionButton"><span class="material-symbols-outlined fs28">cancel</span>Anuluj</button>
        <button id="selectDateTimePreorderSave" class="actionButton"><span class="material-symbols-outlined fs28">save</span>Zapisz</button>
      </div>
    </form>
  </dialog>`;
  document.body.appendChild(selectDateTimePreorderDialog);

  const selectDateTimePreorderCancelButton = document.getElementById('selectDateTimePreorderCancel');
  selectDateTimePreorderCancelButton.addEventListener('click', (e) => {
    e.preventDefault();
    if (e.target.closest('#selectDateTimePreorderDialogContainer').dataset.selectedDateTime) {
      document.getElementById('preorderDateTime').value = e.target.closest('#selectDateTimePreorderDialogContainer').dataset.selectedDateTime;
    }
    document.getElementById('selectDateTimePreorderDialog').close();
  });

  const selectDateTimePreorderSaveButton = document.getElementById('selectDateTimePreorderSave');
  selectDateTimePreorderSaveButton.addEventListener('click', async (e) => {
    e.preventDefault();
    const selectedDateTime = document.getElementById('preorderDateTime').value;
    if (!selectedDateTime) {
      toastMessage('Wybierz datę i godzinę wystawienia aukcji / rozpoczęcia wysyłki!');
      return;
    }
    const preorderDateTime = e.target.closest('form').querySelector('#preorderDateTime');
    if (preorderDateTime.checkValidity() === false) {
      preorderDateTime.reportValidity();
    } else {
      document.getElementById('selectDateTimePreorderDialog').close();
      document.getElementById('setPublicationDateButton').textContent = `zastosuj datę wystawienia aukcji (${selectedDateTime.replace('T', ' ')})`;
      document.getElementById('setPreorderDateButton').textContent = `zastosuj datę rozpoczęcia wysyłki (${selectedDateTime.replace('T', ' ')})`;
      e.target.closest('#selectDateTimePreorderDialogContainer').dataset.selectedDateTime = selectedDateTime;
      toastMessage(`Wybrano datę i godzinę wystawienia aukcji / rozpoczęcia wysyłki: ${selectedDateTime.replace('T', ' ')}`);
    }
  });

});

function getCurrentDatetimeLocal() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

function getMaxDatetimeLocal() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset()); // adjust for local timezone
  const maxDate = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000); // add 60 days
  const year = maxDate.getFullYear();
  const month = String(maxDate.getMonth() + 1).padStart(2, '0');
  const day = String(maxDate.getDate()).padStart(2, '0');
  const hours = String(maxDate.getHours()).padStart(2, '0');
  const minutes = String(maxDate.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

async function additionalActionsAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await additionalActionsAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await additionalActionsAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await additionalActionsAwaitGroupOperationsBar();
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function additionalActionsAwaitGroupOperationsBar() {
  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	if (offersTable.closest('div[data-box-name="allegro.myAssortment.list"]').querySelector('div#group-operations-bar') === null) {
    const groupOperationsBarObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.id === 'group-operations-bar')) {
            groupOperationsBarObserver.disconnect();
            try {
              await additionalActionsAwaitGroupOperationsBar();
            } catch (error) {
              return Promise.reject(getErrorMessage(error));
            }
            break;
          }
        }
      }
    });
    groupOperationsBarObserver.observe(document, { subtree: true, childList: true });
  } else {
    const groupOperationsBar = offersTable.closest('div[data-box-name="allegro.myAssortment.list"]').querySelector('div#group-operations-bar');
    if (groupOperationsBar.querySelector('div[id="additionalActions"]') !== null) {
      return Promise.resolve(true);
    }
    const additionalActionsContainer = groupOperationsBar.querySelector('div[class="mp7g_oh"]:nth-last-child(7)').cloneNode(true);
    additionalActionsContainer.id = 'additionalActions';
    const additionalActionsButton = additionalActionsContainer.firstElementChild;
    additionalActionsButton.childNodes[0].textContent = 'DODATKOWE AKCJE';

    additionalActionsButton.addEventListener('click', additionalActionsToggleSubmenu);
    additionalActionsButton.addEventListener('blur', additionalActionsButtonBlur);
    
    const additionalActionsSubmenu = additionalActionsContainer.lastElementChild;
    additionalActionsSubmenu.setAttribute('aria-hidden', true);
    additionalActionsSubmenu.style.display = 'none';
    additionalActionsSubmenu.className = 'mjyo_6x msts_pt mp7g_f6 mg9e_0 mvrt_0 mj7a_0 mh36_0 mx7m_1 m911_co mefy_co mnyp_co mdwl_co mlkp_6x msbw_2 mldj_2 mtag_2 mm2b_2 eynyt myre_6m e1bhe mpof_ki mjb5_zq _b4f97_KawpV';
    const selectPreorderDate = document.createElement('button');
    selectPreorderDate.setAttribute('nonvisited', 'true');
    selectPreorderDate.className = `mgn2_14 mp0t_0a mgmw_wo mqu1_21 mli8_k4 mqen_m6 l1o8h m911_5r mefy_5r mdwl_5r m0qj_5r msts_n7 ld19g mj9z_5r l5s4b mzmg_7i msa3_z4 mg9e_8 mj7a_8 mh36_16 mvrt_16 mjsg_q9 mgqx_91 mx7m_1 mnyp_co mlkp_ag mse2_40 m7er_k4 mjyo_6x _b4f97_oHYW7 mpof_z0`;
    selectPreorderDate.id = 'selectPreorderDateButton';
    selectPreorderDate.textContent = 'wybierz datę wystawienia aukcji / rozpoczęcia wysyłki';
    selectPreorderDate.addEventListener('click', performAdditionalAction.bind(null, 'selectDateTime'));
    selectPreorderDate.addEventListener('mouseenter', submenuItemAdditionalActionsMouseEnter);
    selectPreorderDate.addEventListener('mouseleave', submenuItemAdditionalActionsMouseLeave);

    const preorderDate = document.getElementById('preorderDateTime').value.replace('T', ' ');

    const setPublicationDate = selectPreorderDate.cloneNode(false);
    setPublicationDate.id = 'setPublicationDateButton';
    setPublicationDate.textContent = `zastosuj datę wystawienia aukcji (${preorderDate === '' ? 'nie wybrano' : preorderDate})`;
    setPublicationDate.addEventListener('click', performAdditionalAction.bind(null, 'setPublicationDateTime'));
    setPublicationDate.addEventListener('mouseenter', submenuItemAdditionalActionsMouseEnter);
    setPublicationDate.addEventListener('mouseleave', submenuItemAdditionalActionsMouseLeave);

    const setPreorderDate = selectPreorderDate.cloneNode(false);
    setPreorderDate.id = 'setPreorderDateButton';
    setPreorderDate.textContent = `zastosuj datę rozpoczęcia wysyłki (${preorderDate === '' ? 'nie wybrano' : preorderDate})`;
    setPreorderDate.addEventListener('click', performAdditionalAction.bind(null, 'setPreorderDateTime'));
    setPreorderDate.addEventListener('mouseenter', submenuItemAdditionalActionsMouseEnter);
    setPreorderDate.addEventListener('mouseleave', submenuItemAdditionalActionsMouseLeave);

    additionalActionsSubmenu.appendChild(selectPreorderDate);
    additionalActionsSubmenu.appendChild(setPublicationDate);
    additionalActionsSubmenu.appendChild(setPreorderDate);
    groupOperationsBar.children[1].insertAdjacentElement('afterbegin', additionalActionsContainer);
    const groupOperationsBarObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.id === 'group-operations-bar')) {
            groupOperationsBarObserver.disconnect();
            try {
              await additionalActionsAwaitGroupOperationsBar();
            } catch (error) {
              return Promise.reject(getErrorMessage(error));
            }
            break;
          }
        }
      }
    });
    groupOperationsBarObserver.observe(document, { subtree: true, childList: true });
  }
}

function submenuItemAdditionalActionsMouseEnter(e) {
  e.target.closest('div[id="additionalActions"]').dataset.hovered = 'true';
}

function submenuItemAdditionalActionsMouseLeave(e) {
  delete e.target.closest('div[id="additionalActions"]').dataset.hovered;
}

function additionalActionsButtonBlur(e) {
  const additionalActionsContainer =  e.target.closest('div[id="additionalActions"]');
  if (!additionalActionsContainer.dataset?.hovered) {
    const additionalActionsSubmenu = additionalActionsContainer.querySelector('div[aria-hidden="false"]');
    if (additionalActionsSubmenu) {
      additionalActionsSubmenu.setAttribute('aria-hidden', 'true');
      additionalActionsSubmenu.style.display = 'none';
      e.target.nodeName === 'SPAN' ? e.target.style.transform = 'rotate(-90deg)' : e.target.firstElementChild.style.transform = 'rotate(-90deg)';
    }
  }
}

function additionalActionsToggleSubmenu(e) {
  const additionalActionsSubmenu = (e.target.nodeName === 'SPAN' ? e.target.parentElement.nextElementSibling : e.target.nextElementSibling);
  const clickedElement = (e.target.nodeName === 'SPAN' ? e.target : e.target.firstElementChild);

  const currentValue = additionalActionsSubmenu.getAttribute('aria-hidden');
  additionalActionsSubmenu.setAttribute('aria-hidden', currentValue === 'true' ? 'false' : 'true');
  if (additionalActionsSubmenu.getAttribute('aria-hidden') === 'true') {
    additionalActionsSubmenu.style.display = 'none';
    clickedElement.style.transform = 'rotate(-90deg)';
  } else {
    additionalActionsSubmenu.style.display = 'flex';
    clickedElement.style.transform = 'rotate(90deg)';
  }
}

async function performAdditionalAction(action) {
  document.activeElement.blur();
  const dialog = document.getElementById('selectDateTimePreorderDialog');

  const additionaActionsSubmenu = document.querySelector('div[id="additionalActions"] div[aria-hidden="false"]');
  if (additionaActionsSubmenu) {
    additionaActionsSubmenu.style.display = 'none';
    additionaActionsSubmenu.setAttribute('aria-hidden', 'true');
    additionaActionsSubmenu.previousElementSibling.querySelector('span').style.transform = 'rotate(-90deg)';
  }

  const offersTable = document.querySelector('table[aria-label="lista ofert"]');

  const selectedOffers = Array.from(offersTable.querySelectorAll('input[type="checkbox"]:checked')).map(checkbox => checkbox.closest('tr').dataset.cy);
  if (selectedOffers.length === 0) {
    toastMessage('Nie zaznaczono żadnej oferty!');
    return;
  }

  const sandbox =  (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const allegroEnvironment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

  let allegroOfferData;
  let response;
  let fetchResponse;
  let count;
  let allegroAccessToken;
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) { 
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    return;
  }
  allegroAccessToken = response.result;
  let selectedDateTime, selectedDateTimeRFC3339;
  selectedDateTime = document.getElementById('selectDateTimePreorderDialogContainer').dataset.selectedDateTime;
  selectedDateTimeRFC3339 = toRFC3339(selectedDateTime);

  switch (action) {
    case 'selectDateTime': {
      dialog.querySelector('#preorderDateTime').min = getCurrentDatetimeLocal();
      dialog.showModal();
      break;
    } 
    case 'setPublicationDateTime': {
      if (!selectedDateTime || new Date(selectedDateTime) < new Date()) {
        toastMessage(`Błąd! Data i godzina wystawienia aukcji musi być w przyszłości!`);
        return;
      }

      let additionalActionsProgress = document.getElementById('additionalActionsProgress');
      if (additionalActionsProgress === null) {
        let insertionPoint;
        try {
          insertionPoint = offersTable.closest('div[class="msts_pt"]')?.nextElementSibling;
          if (!insertionPoint) throw new Error('Nie znaleziono odpowiedniego miejsca na stronie.');
        } catch (error) {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
          return;
        }
        insertionPoint.insertAdjacentHTML('afterbegin', `<div id="additionalActionsProgressBox"><label for="additionalActionsProgress">Postęp:</label><progress id="additionalActionsProgress" value="0">0%</progress><span id="additionalActionsCloseContainer" class="material-symbols-outlined fs28">close</span></div>`);
        const additionalActionsCloseContainer = document.getElementById('additionalActionsCloseContainer');
        additionalActionsCloseContainer.addEventListener('click', () => {
          additionalActionsCloseContainer.closest('div#additionalActionsProgressBox').remove();
        });
      }
      additionalActionsProgress = document.getElementById('additionalActionsProgress');
      additionalActionsProgress.value = 0;
      additionalActionsProgress.max = selectedOffers.length;

      do {
        const offerId = selectedOffers.shift();
        const checkbox = offersTable.querySelector(`input[id="${offerId}"]`);
        if (checkbox !== null) {
          checkbox.setAttribute('aria-checked', 'false');
          checkbox.setAttribute('value', 'false');
          checkbox.checked = false;
          checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        }

        try {
          response = await aaGetAuctionFromAllegro(allegroEnvironment, allegroAccessToken, offerId, 5); 
        } catch (error) {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
          break;
        }

        if (response.newToken) {
          allegroAccessToken = response.newToken;
        }

        allegroOfferData = response.result;

        if (allegroOfferData?.publication?.status !== 'ACTIVATING') {
          toastMessage(`Uwaga! Aukcja ${offerId} nie jest zaplanowana do wystawienia w przyszłym terminie.`);
          continue;
        }

        if (allegroOfferData?.publication?.startingAt) { 
          try {
            fetchResponse = await backgroundFetch(`https://api.allegro.pl${allegroEnvironment}/sale/product-offers/${offerId}`, {
              'method': 'PATCH',
              'headers': {
                'Authorization': `Bearer ${allegroAccessToken}`,
                'Accept': 'application/vnd.allegro.public.v1+json',
                'Content-Type': 'application/vnd.allegro.public.v1+json'
              },
              'body': JSON.stringify({
                'publication': {  
                  'startingAt': `${selectedDateTimeRFC3339}`
                }
              })
            });
            if (fetchResponse.status === 200 || fetchResponse.status === 202) {
              toastMessage(`Zaktualizowano datę wystawienia aukcji ${offerId} na ${selectedDateTime.replace('T', ' ')}`);
              additionalActionsProgress.value++;
            } else if (fetchResponse.status === 401) {
              if (--count) {
                try {
                  response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                  if (!response.success) throw new Error(response.result);
                } catch (error) {
                  return Promise.reject(getErrorMessage(error));
                }
                if (response.result === undefined) {
                  return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
                }
                allegroAccessToken = response.result;
                selectedOffers.unshift(offerId);
                continue;
              } else {
                return Promise.reject(`Nie udało się zaktualizować aukcji ${offerId}. Nie udało się odświeżyć tokena.`);
              }
            } else if (fetchResponse.status === 403) {
              return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
            } else if (fetchResponse.status === 429) {
              if (--count) {
                toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
                selectedOffers.unshift(offerId);
                continue;
              } else {
                return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas aktualizacji aukcji ${offerId}. Spróbuj ponownie później.`);
              }
            } else if (fetchResponse.status === 500) {
              if (--count) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, 5000));
                selectedOffers.unshift(offerId);
                continue;
              } else {
                return Promise.reject(`Błąd serwera podczas aktualizacji aukcji ${offerId}, spróbuj ponownie później.`);
              }
            } else {
              if (--count) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, 5000));
                selectedOffers.unshift(offerId);
                continue;
              } else {
                return Promise.reject(`Nie udało się zaktualizować aukcji ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
              }
            }
          } catch (error) {
            toastMessage(`Błąd! Nie udało się zaktualizować daty wystawienia aukcji ${offerId}. ${getErrorMessage(error)}`);
            continue;
          }
        }
      } while (selectedOffers.length > 0);
      document.getElementById('additionalActionsProgressBox')?.remove();
      break;
    }

    case 'setPreorderDateTime': {
      if (!selectedDateTime || new Date(selectedDateTime) < new Date()) {
        toastMessage(`Błąd! Data wysyłki musi być w przyszłości!`);
        return;
      }

      let additionalActionsProgress = document.getElementById('additionalActionsProgress');
      if (additionalActionsProgress === null) {
        let insertionPoint;
        try {
          insertionPoint = offersTable.closest('div[class="msts_pt"]')?.nextElementSibling;
          if (!insertionPoint) throw new Error('Nie znaleziono odpowiedniego miejsca na stronie.');
        } catch (error) {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
          return;
        }
        insertionPoint.insertAdjacentHTML('afterbegin', `<div id="additionalActionsProgressBox"><label for="additionalActionsProgress">Postęp:</label><progress id="additionalActionsProgress" value="0">0%</progress><span id="additionalActionsCloseContainer" class="material-symbols-outlined fs28">close</span></div>`);
        const additionalActionsCloseContainer = document.getElementById('additionalActionsCloseContainer');
        additionalActionsCloseContainer.addEventListener('click', () => {
          additionalActionsCloseContainer.closest('div#additionalActionsProgressBox').remove();
        });
      }
      additionalActionsProgress = document.getElementById('additionalActionsProgress');
      additionalActionsProgress.value = 0;
      additionalActionsProgress.max = selectedOffers.length;

      do {
        const offerId = selectedOffers.shift();
        const checkbox = offersTable.querySelector(`input[id="${offerId}"]`);
        if (checkbox !== null) {
          checkbox.setAttribute('aria-checked', 'false');
          checkbox.setAttribute('value', 'false');
          checkbox.checked = false;
          checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        }

        try {
          response = await aaGetAuctionFromAllegro(allegroEnvironment, allegroAccessToken, offerId, 5); 
        } catch (error) {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
          break;
        }

        if (response.newToken) {
          allegroAccessToken = response.newToken;
        }

        allegroOfferData = response.result;

        try {
          fetchResponse = await backgroundFetch(`https://api.allegro.pl${allegroEnvironment}/sale/product-offers/${offerId}`, {
            'method': 'PATCH',
            'headers': {
              'Authorization': `Bearer ${allegroAccessToken}`,
              'Accept': 'application/vnd.allegro.public.v1+json',
              'Content-Type': 'application/vnd.allegro.public.v1+json'
            },
            'body': JSON.stringify({
              'delivery': {  
                'shipmentDate': `${selectedDateTimeRFC3339}`
              }
            })
          });

          if (fetchResponse.status === 200 || fetchResponse.status === 202) {
            toastMessage(`Zaktualizowano datę wysyłki aukcji ${offerId} na ${selectedDateTime.replace('T', ' ')}`);
            additionalActionsProgress.value++;
            
          } else if (fetchResponse.status === 401) {
            if (--count) {
              try {
                response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                if (!response.success) throw new Error(response.result);
              }
              catch (error) {
                return Promise.reject(getErrorMessage(error));
              }
              if (response.result === undefined) {
                return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
              }
              allegroAccessToken = response.result;
              selectedOffers.unshift(offerId);
              continue;
            } else {
              return Promise.reject(`Nie udało się zaktualizować aukcji ${offerId}. Nie udało się odświeżyć tokena.`);
            } 
          } else if (fetchResponse.status === 403) {
            return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
          } else if (fetchResponse.status === 429) {
						if (--count) {
							toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
							selectedOffers.unshift(offerId);
              continue;
						} else {
							return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas aktualizacji aukcji ${offerId}. Spróbuj ponownie później.`);
						}
					} else if (fetchResponse.status === 500) {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							selectedOffers.unshift(offerId);
              continue;
						} else {
							return Promise.reject(`Błąd serwera podczas aktualizacji aukcji ${offerId}, spróbuj ponownie później.`);
						}
					} else {
            if (--count) {
              toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
              await new Promise(resolve => setTimeout(resolve, 5000));
              selectedOffers.unshift(offerId);
              continue;
            } else {
              return Promise.reject(`Nie udało się zaktualizować aukcji ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
            }
          }
        } catch (error) {
          toastMessage(`Błąd! Nie udało się zaktualizować daty wysyłki aukcji ${offerId}. ${getErrorMessage(error)}`);
          continue;
        }
        
      } while (selectedOffers.length > 0);
      document.getElementById('additionalActionsProgressBox')?.remove();
      break;
    }
  }
}

function toRFC3339(datetimeStr) {
  const date = new Date(datetimeStr);

  const offset = -date.getTimezoneOffset(); 
  const sign = offset >= 0 ? "+" : "-";

  const absOffset = Math.abs(offset);
  const hours = String(Math.floor(absOffset / 60)).padStart(2, "0");
  const minutes = String(absOffset % 60).padStart(2, "0");

  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const hh = String(date.getHours()).padStart(2, "0");
  const mi = String(date.getMinutes()).padStart(2, "0");
  const ss = '00';

  return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}${sign}${hours}:${minutes}`;
}

async function aaGetAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed) {
  let fetchResponse;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/vnd.allegro.public.v1+json',
        'Content-Type': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await aaGetAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);      
    } else {
      return Promise.reject(`Nie udało się pobrać aukcji ${offerId} z Allegro. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200) {
    let result;
    try {
      result = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    return Promise.resolve({ result: result, newToken: (tokenRefreshed ? accessToken : undefined) });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      accessToken = response.result;
      return await aaGetAuctionFromAllegro(environment, accessToken, offerId, count, true);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await aaGetAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania aukcji ${offerId} z Allegro. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await aaGetAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania aukcji ${offerId} z Allegro, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await aaGetAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);    
    } else {
      return Promise.reject(`Nie udało się pobrać aukcji ${offerId} z Allegro. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }	
  }
}
