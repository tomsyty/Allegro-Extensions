const allowedCharsArray = [ 
  ' ', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@',
  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 
  'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '§', '€', '$', '°', 
  '±', '²', '³', '´', 'µ', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', '×', 'Ø', 'Ù', 'Ú', 'Û', 
  'Ü', 'Ý', 'Þ', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ð', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 
  'þ', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Č', 'č', 'Ď', 'ď', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ğ', 'ğ', 'Ģ', 'ģ', 'Ī', 'ī', 'İ', 'Ĺ', 'ĺ', 'Ľ', 'ľ', 
  'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ť', 'ť', 'Ū', 'ū', 'Ů', 
  'ů', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'Μ', 'Σ', 'Φ', 'β', 'μ', 'σ', 'φ', 'Ё', 'Є', 'І', 'Ї', 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н',
  'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ь', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 
  'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ь', 'ю', 'я', 'ё', 'є', 'і', 'ї', 'Ґ', 'ґ', 'Ӧ', 'ӧ', 'ą', 'Ą', 'ć', 'Ć', 'ę', 'Ę', 'ł', 'Ł', 'ń', 'Ń', 'ó', 'Ó',
  'ś', 'Ś', 'ź', 'Ź', 'ż', 'Ż', 'á', 'Á', 'č', 'Č', 'ď', 'Ď', 'é', 'É', 'ě', 'Ě', 'í', 'Í', 'ň', 'Ň', 'ó', 'Ó', 'ř', 'Ř', 'š', 'Š', 'ť', 'Ť', 'ú', 'Ú', 'ů', 'Ů', 'ý', 
  'Ý', 'ž', 'Ž', 'á', 'Á', 'ä', 'Ä', 'č', 'Č', 'ď', 'Ď', 'é', 'É', 'í', 'Í', 'ľ', 'Ľ', 'ĺ', 'Ĺ', 'ň', 'Ň', 'ó', 'Ó', 'ô', 'Ô', 'ŕ', 'Ŕ', 'š', 'Š', 'ť', 'Ť', 'ú', 'Ú',
  'ý', 'Ý', 'ž', 'Ž', 'č', 'Č', 'š', 'Š', 'ž', 'Ž', 'ć', 'Ć', 'đ', 'Đ', 'á', 'Á', 'é', 'É', 'í', 'Í', 'ó', 'Ó', 'ö', 'Ö', 'ő', 'Ő', 'ú', 'Ú', 'ü', 'Ü'
];

const allowedKeysArray = [
  'ArrowLeft', 'ArrowUp', 'ArrowDown', 'ArrowRight', 'Delete', 'Backspace', 'PageUp', 'PageDown', 'Home', 'End'
];

(function addStylesheet() {	
  const link = document.createElement('link');
  link.type = 'text/css';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0';
  document.head.appendChild(link);
})();

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', () => {
  console.log('Załadowano skrypt changeAuctionsTitle');	
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}
  if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
    const iconConfirm = document.createElement('span');
    iconConfirm.className = 'material-symbols-outlined';
    iconConfirm.dataset.icon = 'check_circle';
    preloadIconsContainer.appendChild(iconConfirm);
  }
  if (!preloadIconsContainer.querySelector('span[data-icon="cancel"]')) {
    const iconCancel = document.createElement('span');
    iconCancel.className = 'material-symbols-outlined';
    iconCancel.dataset.icon = 'cancel';
    preloadIconsContainer.appendChild(iconCancel);
  }
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  showStockLeftObserveOffersList(sandbox, environment);
});

function showStockLeftObserveOffersList(sandbox, environment) {
	const observedTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (observedTable === null) {
		const offersTableObserver = new MutationObserver(mutations => {
			mutations.forEach(mutation => {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
				    delay(0).then(() => {
						  showStockLeftObserveOffersList(sandbox, environment);
            });
            return;  
					}
				}
			});
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	}	else {
		const urlObserver = new MutationObserver(() => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				const delay = t => new Promise(resolve => setTimeout(resolve, t));
				delay(0).then(() => {
					showStockLeftObserveOffersList(sandbox, environment);
				});
				return;
			}
		});
    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
		  urlObserver.observe(document, {	subtree: true, childList: true });
      observeAuctionsTitle(environment, observedTable);
    }
		urlObserver.observe(document, {	subtree: true, childList: true });
	}  	
}

function observeAuctionsTitle(environment, observedTable) {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(addedNode => {
        if (addedNode.nodeName === 'TR') {
          let link = addedNode.querySelector(`a[href*="https://allegro.pl${environment}/oferta/"]`);
          if (link !== null) {
            const auctionId = link.href.split('-').pop();
            try {
              chrome.storage.session.get([`${auctionId}`]).then(result => {
                if (Object.keys(result).length > 0) {
                  if ((result[auctionId]?.text !== undefined) && (result[auctionId].text !== link.innerText)) { 
                    link.innerText = result[auctionId].text;
                  }               
                }
              }).catch(() => {
                toastMessage('Błąd! Nie udało się odczytać danych z pamięci. Odśwież stronę aby wczytać zmiany.');
              });
            } catch {
              toastMessage('Błąd! Nie udało się odczytać danych z pamięci. Odśwież stronę aby wczytać zmiany.');
            }
          }
        };
      });
    });
  });

  observer.observe(observedTable, { subtree: true, childList: true });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallbackChangeAuctionsTitle(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
  return true;
});

async function asyncOnMessageCallbackChangeAuctionsTitle(request, sender) {
	const action = request.action;

	switch (action) {
    case 'changeAuctionsTitle': {
      const environment = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? '.allegrosandbox.pl' : '');
      const auctionTitleLink = document.querySelector(`a[href*="https://allegro.pl${environment}/oferta/"]:hover`);
      if (auctionTitleLink === null) {
        toastMessage(`Najedź kursorem nad tytuł oferty który chcesz zmienić i wciśnij ${request.shortcut}`);
        break;
      }
      
      let actionsBox = document.getElementById('actionsBox');
      let commonParent;
      if (auctionTitleLink.childElementCount === 2) {
        //auctionTitleLink.children[1].remove();
        commonParent = auctionTitleLink.parentElement.parentElement.parentElement;
      } else commonParent = auctionTitleLink.parentElement;
      if (actionsBox !== null) {
        if (actionsBox.parentElement === commonParent) {
          break;
        }
        document.getElementsByClassName('activeEdit')[0]?.blur();
      }
      
      auctionTitleLink.contentEditable = true;
      auctionTitleLink.focus();
      auctionTitleLink.classList.add('activeEdit');

      actionsBox = document.createElement('div');
      actionsBox.id = 'actionsBox';
      actionsBox.innerHTML = '<span id="charCounter"></span> <span id="confirmButton" class="material-symbols-outlined">check_circle</span> <span id="cancelButton" class="material-symbols-outlined">cancel</span>';

      commonParent.insertAdjacentElement('afterend', actionsBox);
      const charCounter = document.getElementById('charCounter');
      charCounter.innerText = auctionTitleLink.innerText.length;
      auctionTitleLink.dataset.originalText = auctionTitleLink.innerText;
      document.getElementById('confirmButton').addEventListener('mousedown', changeAuctionsTitleConfirmButtonClick.bind(null, environment, auctionTitleLink, auctionTitleLink.innerText, auctionTitleLink.href.split('-').pop()));
      document.getElementById('confirmButton').addEventListener('mouseenter', changeAuctionsTitleConfirmButtonEnter.bind(null, auctionTitleLink));

      auctionTitleLink.addEventListener('blur', auctionTitleLinkBlur, {once: true});
      auctionTitleLink.addEventListener('keydown', auctionTitleLinkKeyDown);
      auctionTitleLink.addEventListener('keyup', auctionTitleLinkKeyUp);
      auctionTitleLink.addEventListener('input', auctionTitleLinkInput);
      auctionTitleLink.addEventListener('paste', auctionTitleLinkPaste);
      break;
    }
  }
}

function setCaretPosition(element, caretPosition) {
  const range = document.createRange();
  const selection = document.getSelection();
  if (caretPosition > element.innerText.length) caretPosition = element.innerText.length;
  range.setStart(element.childNodes[0], caretPosition);
  range.collapse(true);
  selection.removeAllRanges();
  selection.addRange(range);
}

function changeAuctionsTitleConfirmButtonEnter(auctionTitleLink) {
  const text = auctionTitleLink.innerText;
  auctionTitleLink.innerText = text.replaceAll(/[\r\n]/g, ' ').replaceAll(/\s{2,}/g, ' ').trim();
  const keyUpEvent = new KeyboardEvent('keyup');
  auctionTitleLink.dispatchEvent(keyUpEvent);
}

function auctionTitleLinkBlur(e) {
  const auctionTitleLink = e.target;
  auctionTitleLink.innerText = auctionTitleLink.dataset.originalText;
  delete auctionTitleLink.dataset.originalText;
  delete auctionTitleLink.dataset.insertionPoint;
  delete auctionTitleLink.dataset.selectionStart;
  delete auctionTitleLink.dataset.selectionEnd;
  auctionTitleLink.classList.remove('activeEdit', 'wrongValue');
  auctionTitleLink.removeAttribute('contentEditable');
  const actionsBox = document.getElementById('actionsBox');
  if (actionsBox !== null) {         
    actionsBox.remove();
  }

  const additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText !== null) {
    additionalInfoText.remove();
  }
  
  auctionTitleLink.removeEventListener('keydown', auctionTitleLinkKeyDown);
  auctionTitleLink.removeEventListener('keyup', auctionTitleLinkKeyUp);
  auctionTitleLink.removeEventListener('input', auctionTitleLinkInput);
  auctionTitleLink.removeEventListener('paste', auctionTitleLinkPaste);
}

function auctionTitleLinkKeyDown(e) {
  if (e.key === 'Escape') {
    const blurEvent = new Event('blur');
    e.target.dispatchEvent(blurEvent);
  } else if (e.key === 'Enter') {
    e.preventDefault();
    const confirmButton = document.getElementById('confirmButton');
    if (confirmButton !== null) {
      const mouseEnterEvent = new MouseEvent('mouseenter');
      confirmButton.dispatchEvent(mouseEnterEvent);
      const mouseDownEvent = new MouseEvent('mousedown');
      confirmButton.dispatchEvent(mouseDownEvent);
    }
  } else if (e.key == 'z' && e.ctrlKey) {
    if ('history' in e.target.dataset) {
      e.preventDefault();
      e.target.innerText = e.target.dataset.history;
      setCaretPosition(e.target, e.target.dataset.insertionPoint);
      if ('selectionStart' in e.target.dataset) {
        const selection = document.getSelection();
        selection.setBaseAndExtent(e.target.childNodes[0], e.target.dataset.selectionStart, e.target.childNodes[0], e.target.dataset.selectionEnd);
        delete e.target.dataset.selectionStart;
        delete e.target.dataset.selectionEnd;
      }
      delete e.target.dataset.history;
      delete e.target.dataset.insertionPoint;
    }
  } else if (allowedKeysArray.indexOf(e.key) !== -1) {
    return;
  } else if (allowedCharsArray.indexOf(e.key) === -1) {
    e.preventDefault();
  }
}

function auctionTitleLinkInput(e) {
  if ('history' in e.target.dataset) {
    delete e.target.dataset.history;
    delete e.target.dataset.insertionPoint;
    delete e.target.dataset.selectionStart;
    delete e.target.dataset.selectionEnd;
  }
}

function auctionTitleLinkKeyUp(e) {
  let invalidValue = false;
  const charCounter = document.getElementById('charCounter');
  charCounter.innerText = e.target.innerText.length;
  if (charCounter.innerText > 75 || charCounter.innerText === '0') {
    additionalInfoTextAdd('nieprawidłowa długość', e.target.parentElement);
    invalidValue = true;
  } else {
    additionalInfoTextRemove('nieprawidłowa długość');
  }

  if (e.target.innerText.search(/\s{2,}/) !== -1) {
    additionalInfoTextAdd('podwójna spacja', e.target.parentElement);
    invalidValue = true;
  } else {
    additionalInfoTextRemove('podwójna spacja');
  }

  if (e.target.innerText.search(/^\s/) !== -1) {
    additionalInfoTextAdd('spacja na początku', e.target.parentElement);
    invalidValue = true;
  } else {
    additionalInfoTextRemove('spacja na początku');
  }
  
  if (e.target.innerText.search(/\s+$/) !== -1) {
    additionalInfoTextAdd('spacja na końcu', e.target.parentElement);
    invalidValue = true;
  } else {
    additionalInfoTextRemove('spacja na końcu');
  }

  if (invalidValue) e.target.classList.add('wrongValue');
  else e.target.classList.remove('wrongValue');
}

function auctionTitleLinkPaste(e) {
  e.preventDefault();
  const target = (e.target.nodeName === 'A' ? e.target : e.target.parentNode);
  target.dataset.history = target.textContent;
  const clipboardData = e.clipboardData.getData('text');

  let filteredString = clipboardData.replaceAll(/[\r\n]/g, ' ').replaceAll(/\s{2,}/g, ' ');
  const filteredArray = filteredString.split('').map(char => {
    if (allowedCharsArray.indexOf(char) !== -1) return char;
    else return '';
  });

  filteredString = filteredArray.join(''); 
  if (filteredString !== clipboardData) {
    additionalInfoTextAdd('wklejony tekst został zmodyfikowany', target.parentElement);
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    delay(3000).then(() => {
      additionalInfoTextRemove('wklejony tekst został zmodyfikowany');
    });      
  }
  
  let caretPosition = null;
  const selection = document.getSelection();
  const range = document.createRange();

  if (!selection.isCollapsed) {
    target.dataset.selectionStart = selection.anchorOffset;
    target.dataset.selectionEnd = selection.focusOffset;
    selection.deleteFromDocument();
  }
    
  if (range.collapsed) {
    const marker = document.createTextNode('\0');
    selection.getRangeAt(0).insertNode(marker);
    caretPosition = target.innerText.indexOf('\0');
    marker.parentNode.removeChild(marker);
  }

  target.dataset.insertionPoint = caretPosition;
  const linkText = target.innerText;
  const newLinkText = [linkText.slice(0, caretPosition), filteredString, linkText.slice(caretPosition)].join('');
  
  target.innerText = newLinkText;  
  if (newLinkText !== target.innerText) {
    additionalInfoTextAdd('wklejony tekst został zmodyfikowany', target.parentElement);
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    delay(3000).then(() => {
      additionalInfoTextRemove('wklejony tekst został zmodyfikowany');
    });      
  }
  setCaretPosition(target, caretPosition + filteredString.length);
};

async function changeAuctionsTitleConfirmButtonClick(environment, auctionTitleLink, originalText, auctionId) {
  auctionTitleLink.innerText = auctionTitleLink.innerText.replaceAll(/\s{2,}/g, ' ');
  if (auctionTitleLink.innerText.length > 75 || auctionTitleLink.innerText.length === 0) {
    toastMessage('Błąd! Nieprawidłowa długość tytułu aukcji');
    const blurEvent = new Event('blur');
    auctionTitleLink.dispatchEvent(blurEvent);
    return;
  }

  if (auctionTitleLink.innerText === originalText) {
    toastMessage('Nie ma nic do zmiany');
    const blurEvent = new Event('blur');
    auctionTitleLink.dispatchEvent(blurEvent);
    return;
  }

  auctionTitleLink.removeEventListener('blur', auctionTitleLinkBlur);
  auctionTitleLink.removeEventListener('keydown', auctionTitleLinkKeyDown);
  auctionTitleLink.removeEventListener('keyup', auctionTitleLinkKeyUp);
  auctionTitleLink.removeEventListener('input', auctionTitleLinkInput);
  auctionTitleLink.removeEventListener('paste', auctionTitleLinkPaste);

  auctionTitleLink.classList.remove('activeEdit', 'wrongValue');
  const actionsBox = document.getElementById('actionsBox');
  if (actionsBox !== null) {         
    actionsBox.remove();
  }
  const additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText !== null) {
    additionalInfoText.remove();
  }
  auctionTitleLink.removeAttribute('contentEditable');
  
  let result;
  try {
    result = await changeAuctionsTitle();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    auctionTitleLink.innerText = originalText;
  }
  toastMessage(result);

  async function changeAuctionsTitle(count = 5) {
    let fetchResponse;
    let fetchData;
    let response;
    let accessToken;
    try {
      response = await sendMessage({ action: 'getAllegroAccessToken' });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      return Promise.reject(getErrorMessage(error));
    }
    
    accessToken = response.result;
    
    try {
      fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${auctionId}`, {
        'method': 'GET',
        'headers': {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/vnd.allegro.public.v1+json',
          'Accept': 'application/vnd.allegro.public.v1+json'
        }
      });
    } catch (error) {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aktualnego tytułu aukcji. ${getErrorMessage(error)}`);
    }

    if (fetchResponse.status === 200) {
      try {
        fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${auctionId}`, {
          'method': 'PATCH',
          'headers': {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/vnd.allegro.public.v1+json',
            'Accept': 'application/vnd.allegro.public.v1+json'
          },
          body: JSON.stringify({'name': auctionTitleLink.innerText})
        });
      } catch (error) {
        return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić tytułu aukcji. ${getErrorMessage(error)}`);
      }

      if (fetchResponse.status === 200) { 
        try {
          await saveDataToSessionStorage({
            [`${auctionId}`]: {
              text: auctionTitleLink.innerText
            }
          });
        } catch (error) {
          return Promise.resolve('Zmieniono tytuł aukcji, jednak na liście może widnieć poprzedni. Odczekaj chwilę i odśwież stronę celem wczytania zaktualizowanej listy aukcji.');
        }
        return Promise.resolve('Zmieniono!');
      } else if (fetchResponse.status === 202) {
        try {
          await saveDataToSessionStorage({
            [`${auctionId}`]: {
              text: auctionTitleLink.innerText
            }
          });
        } catch (error) {
          return Promise.resolve('Zmieniono tytuł aukcji, jednak na liście może widnieć poprzedni. Odczekaj chwilę i odśwież stronę celem wczytania zaktualizowanej listy aukcji.');
        }
        return Promise.resolve('Trwa wprowadzanie zmian...');
      } else if (fetchResponse.status === 401) {
        if (--count) {	
          try {
            response = await sendMessage({ action: 'refreshAllegroAccessToken' });
            if (!response.success) throw new Error(response.result);
          } catch (error) {
            return Promise.reject(getErrorMessage(error));
          } 
          if (response.result === undefined) {
            return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
          } 
          return await changeAuctionsTitle(count); 
        } else {
          return Promise.reject(`Nie udało się zmienić tytułu aukcji. Nie udało się zalogować użytkownika.`);
        }
      } else if (fetchResponse.status === 403) {
        return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
      } else if (fetchResponse.status === 422) {
        try {
          fetchData = await fetchResponse.json();
        } catch (error) {
          return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
        }
        if (fetchData?.errors[0]?.userMessage !== undefined) {
          return Promise.reject(`Wykryto niepoprawne wartości parametrów. Szczegóły błędu: ${fetchData.errors[0].userMessage}`);
        } else return Promise.reject(`Nie udało się zmienić tytułu aukcji. Wykryto niepoprawne wartości parametrów. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
      } else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await await changeAuctionsTitle(count);
				} else {
					return Promise.reject('Przekroczono limit zapytań do API Allegro podczas zmiany tytułu oferty. Spróbuj ponownie później.');
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
          toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await await changeAuctionsTitle(count);
				} else {
					return Promise.reject(`Błąd serwera podczas zmiany tytułu oferty, spróbuj ponownie później.`);
				}
			} else {
        if (--count) {
          toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
          await new Promise(resolve => setTimeout(resolve, 5000));
          return await changeAuctionsTitle(count); 
        } else {
          try {
            fetchData = await fetchResponse.json();
          } catch (error) {
            return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
          }
          if (fetchData?.errors[0]?.userMessage !== undefined) {
            return Promise.reject(`Nie udało się zmienić tytułu aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}. Szczegóły błędu: ${fetchData.errors[0].userMessage}`);
          } else return Promise.reject(`Nie udało się zmienić tytułu aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
        }											
      }
    } else if (fetchResponse.status === 401) {
      if (--count) {
        try {
          response = await sendMessage({ action: 'refreshAllegroAccessToken' });	
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        if (response.result === undefined) {
          return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
        } 					      												            
        return await changeAuctionsTitle(count); 
      } else {
        return Promise.reject(`Nie udało się zmienić tytułu aukcji. Nie udało się zalogować użytkownika.`);
      }
    } else if (fetchResponse.status === 403) {
      return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
    } else if (fetchResponse.status === 429) {
      if (--count) {
        toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
        await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
        return await changeAuctionsTitle(count);
      } else {
        return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania liczby ofert. Spróbuj ponownie później.');
      }
    } else if (fetchResponse.status === 500) {
      if (--count) {
        toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
        await new Promise(resolve => setTimeout(resolve, 5000));
        return await changeAuctionsTitle(count);
      } else {
        return Promise.reject(`Błąd serwera podczas pobierania liczby ofert, spróbuj ponownie później.`);
      }
    } else {
      if (--count) {
        toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
        await new Promise(resolve => setTimeout(resolve, 5000));
        return await changeAuctionsTitle(count);
      } else {
        try {
          fetchData = await fetchResponse.json();
        } catch (error) {
          return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
        }

        if (fetchData?.errors[0]?.userMessage !== undefined) {
          return Promise.reject(`Nie udało się zmienić tytułu aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}. Szczegóły błędu: ${fetchData.errors[0].userMessage}`);
        } else return Promise.reject(`Nie udało się zmienić tytułu aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
      }
    }
  }
}

function additionalInfoTextAdd(textToAdd, parent) {
  let additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText === null) {
    additionalInfoText = document.createElement('div');
    additionalInfoText.id = 'additionalInfoText';
    additionalInfoText.innerText = textToAdd;
    parent.parentElement.insertAdjacentElement('afterend', additionalInfoText);
  } else {
    let additionalInfoTextArray = additionalInfoText.innerText.split('\n');
    const itemIndex = additionalInfoTextArray.findIndex(element => element === textToAdd);
    if (itemIndex === -1) {
      additionalInfoTextArray.push(textToAdd);
      additionalInfoText.innerText = additionalInfoTextArray.join('\n');
    }
  }
}

function additionalInfoTextRemove(textToRemove) {
  let additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText) {
    let additionalInfoTextArray = additionalInfoText.innerText.split('\n');
    const indexToDelete = additionalInfoTextArray.findIndex(element => element === textToRemove);
    if (indexToDelete !== -1) {
      additionalInfoTextArray.splice(indexToDelete, 1);
      additionalInfoText.innerText = additionalInfoTextArray.join('\n');
      if (additionalInfoTextArray.length === 0) {
        additionalInfoText.remove();
      }
    }
  }
}