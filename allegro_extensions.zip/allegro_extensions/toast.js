function getErrorMessage(error) {
  if (error?.message) return error.message;
  if (typeof error === 'string') return error;
  return JSON.stringify(error);
}

function toastMessage(message, autoreplace) {
	let toast = document.getElementById('aeToast');
	if (toast === null) {
		toast = document.createElement('div');
		toast.id = 'aeToast';
		toast.classList.add('aeToastHidden');
		document.body.appendChild(toast);
	}

	let existingMessages = toast.querySelectorAll('.aeToastMessage');
	if (existingMessages.length) {
		[...existingMessages].filter(element => element.dataset.autoreplace === 'true').forEach(element => element.remove());
		if (!message) {
			if (!toast.childElementCount) toast.classList.add('aeToastHidden');
			return;
		}
		existingMessages = toast.querySelectorAll('.aeToastMessage');
		const existingMessage = [...existingMessages].find(element => (element.innerHTML.split('<span class="aeToastMessageCounter')[0]) === message);
		if (existingMessage !== undefined) {
			const existingMessageCounter = existingMessage.querySelector('.aeToastMessageCounter');
			existingMessageCounter.dataset.counter = Number(existingMessageCounter.dataset.counter) + 1;
			existingMessageCounter.classList.add('aeShowCounter');
			if (!(message.startsWith('Błąd') || message.startsWith('Uwaga'))) {
				const timer = existingMessage.dataset.timer;
				clearTimeout(timer);
				existingMessage.dataset.timer = setTimeout(() => {
					const message = document.getElementById(existingMessage.id);
					message?.remove();
					const toast = document.getElementById('aeToast');
					if (!toast.childElementCount) toast.classList.add('aeToastHidden');
				}, 5000);
			}
			if (toast.firstChild !== existingMessage) {
				toast.insertAdjacentHTML('afterbegin', '<span></span>');
				toast.firstElementChild.replaceWith(existingMessage);
			}
			return;
		}
	}
	const newMessage = document.createElement('span');
	const counter = document.createElement('span');
	counter.classList.add('aeToastMessageCounter');
	counter.dataset.counter = '1';
	newMessage.classList.add('aeToastMessage');
	newMessage.innerHTML = message;
	newMessage.dataset.timer = '';
	newMessage.id = 'message_' + Date.now();
	newMessage.addEventListener('mouseenter', function () {
		const timer = this.dataset.timer;
		clearTimeout(timer);
		this.addEventListener('mouseleave', function () {
			this.remove();
			const toast = document.getElementById('aeToast');
			if (!toast.childElementCount) toast.classList.add('aeToastHidden');
		});
	});
	if (message.startsWith('Błąd')) newMessage.classList.add('aeToastError');
	else if (message.startsWith('Uwaga')) newMessage.classList.add('aeToastWarning');
	else if (autoreplace) {
		newMessage.dataset.autoreplace = 'true';
	} else {
		newMessage.dataset.timer = setTimeout(() => {
			const message = document.getElementById(newMessage.id);
			message.remove();
			let toast = document.getElementById('aeToast');
			if (!toast.childElementCount) toast.classList.add('aeToastHidden');
		}, 5000);
	}
	toast.insertAdjacentElement('afterbegin', newMessage);
	newMessage.appendChild(counter);
	toast.classList.remove('aeToastHidden');
	if (newMessage.querySelectorAll('a').length) {
		for (const link of newMessage.querySelectorAll('a')) {
			if (link.href.indexOf('chrome://') === 0) {
				link.addEventListener('click', (e) => {
					e.preventDefault();
					chrome.tabs.create({ url: e.target.href });
				});
			};
		}
	}
}

(function loadMaterialSymbolsStylesheet() {
	const fontHref = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,300,0,0&display=block';
	const existingLink = Array.from(document.querySelectorAll('link[rel="stylesheet"]')).find(link => link.href.includes('fonts.googleapis.com/css2?family=Material+Symbols+Outlined'));
	if (existingLink) {
		return;
	}
	const link = document.createElement('link');
	link.type = 'text/css';
	link.rel = 'stylesheet';
	link.href = fontHref;
	(document.head || document.documentElement).appendChild(link);
})();