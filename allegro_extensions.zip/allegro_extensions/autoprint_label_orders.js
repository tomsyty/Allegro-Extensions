window.addEventListener('load', () => {
  console.log('Załadowano skrypt autoPrintLabelOrders');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateSendParcelLink' && request.orderId) {
    const sendParcelLinkButton = document.querySelector(`a[orderid="${request.orderId}"]`)?.previousElementSibling.firstChild;
    if (sendParcelLinkButton) {
      sendParcelLinkButton.disabled = true;
    }
  }
  sendResponse({ success: true });
  return true;
});
