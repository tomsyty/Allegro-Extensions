async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt buyerStats');	

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;
  
  try {
    await buyerStatsAwaitOrdersTable();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }
});

async function buyerStatsAwaitOrdersTable() {
  let previousUrl = '';
  const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
            return await buyerStatsAwaitOrdersTable(previousUrl);
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
        previousUrl = window.location.href; 
        urlObserver.disconnect();
				return await buyerStatsAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;

      try {
        await getBuyerStatsPrepare();
      } catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
      } 
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function getBuyerStatsPrepare() {
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let response;
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  const accessToken = response.result;
  let parameters = {
    accessToken: accessToken,
    environment: environment,
    offset: 0
  }

  const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

  let orderRows;
  let intersectionIntervalId;

  const intersectionObserver = new IntersectionObserver(intersectionCallback, options);

  async function intersectionCallback(entries, io) {
    entries.forEach(async (entry) => {
      clearInterval(intersectionIntervalId);
      if (entry.isIntersecting) {
        const buyerNode = entry.target.querySelector('div.buyer-details');
        if (buyerNode !== null) {
          try {
            getBuyerStatsGetOrders(parameters, buyerNode);
          } catch (error) {
            toastMessage(`Błąd! ${getErrorMessage(error)}`);
          }
        }
      }    
    });

    intersectionIntervalId = setInterval(async () => {
			orderRows = document.querySelectorAll('div.order-group-operation');
      orderRows.forEach(orderRow => {
        intersectionObserver.observe(orderRow);
      });
		}, 200);
  }

  do {
    orderRows = document.querySelectorAll('div.order-group-operation');

		const orderRowsLength = orderRows.length;
    await new Promise(resolve => setTimeout(resolve, 2000));

    orderRows = document.querySelectorAll('div.order-group-operation');

    if (orderRows.length === 0 || (orderRows.length !== orderRowsLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);

	[...orderRows].map(orderRow => orderRow.parentElement).forEach(orderRow => {
		intersectionObserver.observe(orderRow);
	});
}

async function getBuyerStatsGetOrders(parameters, buyerNode) {
  if (buyerNode === undefined) return Promise.resolve(true);

  let buyer;
  const buyerLogin = buyerNode.querySelector('a').textContent;
  try {
    buyer = await getBuyerStats(parameters, buyerLogin);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  }

  if (buyer !== undefined && buyerNode.parentElement.querySelector('.buyerStats') === null) {
    let ordersCount = buyer.orders.length;
    let returnsCount = buyer.returns.length;
    let ordersValue = 0;
    let returnsValue = 0;
    let ordersTooltip = /*html*/ `<div class="buyerStatsOrdersTooltip">`;
    buyer.orders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate)).forEach(order => {
      ordersValue += parseFloat(order.orderValue);
      ordersTooltip += /*html*/ `<span class="bsRow">data: ${order.orderDate.split('T')[0]}, wartość: ${order.orderValue} zł</span>`;
    });
    ordersTooltip += `</div>`;

    let returnsTooltip = /*html*/ `<div class="buyerStatsReturnsTooltip">`;
    buyer.returns.sort((a, b) => new Date(b.returnDate) - new Date(a.returnDate)).forEach(returnOrder => {
      returnsValue += parseFloat(returnOrder.returnValue);
      returnsTooltip += /*html*/ `<span class="bsRow">data: ${returnOrder.returnDate.split('T')[0]}, wartość: ${returnOrder.returnValue} zł</span>`;
    });
    returnsTooltip += `</div>`;
    buyerNode.parentElement.insertAdjacentHTML('beforeend', /*html*/ `
      <div class="buyerStats">
        <span class="buyerStatsTooltipWrapper">
          <span class="buyerStatsOrdersLink">zamówienia:</span>
            ${ordersTooltip}
        </span>
        ${ordersCount} (${ordersValue.toFixed(2)} zł),
        <span class="buyerStatsTooltipWrapper">
          <span class="buyerStatsReturnsLink">zwroty:</span>
            ${returnsCount ? returnsTooltip : ''}
        </span>
        ${returnsCount} (${returnsValue.toFixed(2)} zł)
      </div>
    `);
  }
  return Promise.resolve(true);
}

async function getBuyerStats(parameters, buyerLogin, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms?offset=${parameters.offset}&status=READY_FOR_PROCESSING&buyer.login=${buyerLogin}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getBuyerStats(parameters, buyerLogin, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić zamówień. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    let buyerOrders = fetchData.checkoutForms;

    async function getBuyerOrders(buyerOrders, buyer) {
      const order = buyerOrders.shift();
      if (order === undefined && buyer !== undefined) {
        try {
          response = await sendMessage({ action: 'buyerStatsSaveBuyer', buyer: buyer });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        return Promise.resolve(buyer);
      }

      if (order === undefined && buyer === undefined) {
        return Promise.resolve(undefined);
      }

      if (buyer === undefined) {
        try {
          response = await sendMessage({ action: 'buyerStatsGetBuyer', login: order.buyer.login });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        buyer = response.result;
        if (buyer === undefined) { // Nie znaleziono użytkownika - pierwsze zamówienie
          buyer = {
            id: order.buyer.id,
            login: order.buyer.login,
            orders: [{
              orderId: order.id,
              orderDate: order.payment.finishedAt,
              orderValue: order.summary.totalToPay.amount
            }],
            returns: [],
          } 
        }
      } else { // Użytkownik zamawiał już coś wcześniej
        if (buyer.orders.some(o => o.orderId === order.id) === false) { // Nie znaleziono tego zamówienia na liście wcześniejszych zamówień
          let newOrder = {
            orderId: order.id,
            orderDate: order.payment.finishedAt,
            orderValue: order.summary.totalToPay.amount
          }
          buyer.orders.push(newOrder);
        }
      }

      let returns;
      try {
        returns = await buyerStatsGetReturns(parameters, order.id);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }

      if (returns !== true) { 
        returns.forEach(singleReturn => { 
          if (buyer.returns.some(r => (r.orderId === singleReturn.orderId) && (r.returnDate === singleReturn.returnDate)) === false) { // Nie znaleziono tego konkretnego zwrotu
            buyer.returns.push(singleReturn);
          }
        });
      }
      return await getBuyerOrders(buyerOrders, buyer);
    }

    let buyer;
    try {
      buyer = await getBuyerOrders(buyerOrders);
    } catch (error) {
      return Promise.reject(getErrorMessage(error));
    } 

    if (fetchData.totalCount > fetchData.count) {
      parameters.offset += fetchData.count;
      try {
        await getBuyerStats(parameters, buyerLogin);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      } 
    }

    parameters.offset = 0;
    return Promise.resolve(buyer);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getBuyerStats(parameters, buyerLogin, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await getBuyerStats(parameters, buyerLogin, count); 
    } else {
      return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania listy zamówień. Spróbuj ponownie później.');
    }
  } else if (fetchResponse.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getBuyerStats(parameters, buyerLogin, count);
		} else {
			return Promise.reject('Błąd serwera podczas pobierania listy zamówień, spróbuj ponownie później.');
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getBuyerStats(parameters, buyerLogin, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }	
}

async function buyerStatsGetReturns(parameters, orderId, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/customer-returns?orderId=${orderId}`, {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.beta.v1+json',
        'Accept': 'application/vnd.allegro.beta.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić zwrotu. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    if (fetchData.customerReturns.length > 0) {
      let returns = [];
      for (const returnOrder of fetchData.customerReturns) {
        let returnOrderValue = 0;
        returnOrder.items.forEach(item => {
          returnOrderValue += parseFloat(item.price.amount * item.quantity);
        });
        returns.push({
          orderId: returnOrder.orderId,
          returnDate: returnOrder.createdAt,
          returnValue: returnOrderValue
        });
      }
      return Promise.resolve(returns);
    }
    return Promise.resolve(true);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await buyerStatsGetReturns(parameters, orderId, count);
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu dla zamówienia ${orderId}. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await buyerStatsGetReturns(parameters, orderId, count);  
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania zwrotu dla zamówienia ${orderId}. Spróbuj ponownie później.`);
		}
  } else if (fetchResponse.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await buyerStatsGetReturns(parameters, orderId, count);
		} else {
			return Promise.reject(`Błąd serwera podczas sprawdzania zwrotu dla zamówienia ${orderId}, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);  
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu dla zamówienia ${orderId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}
