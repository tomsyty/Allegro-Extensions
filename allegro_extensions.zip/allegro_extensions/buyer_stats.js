async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', () => {
	console.log('Załadowano skrypt buyerStats');	

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;
  
	buyerStatsAwaitOrdersTable();
});

async function buyerStatsAwaitOrdersTable() {
  let previousUrl = '';
  const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
            return await buyerStatsAwaitOrdersTable(previousUrl);
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
        previousUrl = window.location.href; 
        urlObserver.disconnect();
				return await buyerStatsAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;

      try {
        await getBuyerStatsPrepare();
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      } 
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function getBuyerStatsPrepare() {
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let response;
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  const accessToken = response.result;
  let parameters = {
    accessToken: accessToken,
    environment: environment,
    offset: 0
  }

  const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

  const observer = new IntersectionObserver(intersectionCallback, options);
  const observedRows = [];

  async function intersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const buyerNode = entry.target.querySelector('span.buyer-details');
        if (buyerNode !== null) {
          try {
            await getBuyerStatsGetOrders(parameters, buyerNode);
          } catch (error) {
            toastMessage(`Błąd! ${error?.message ? error.message : error}`);
          }
        }
        const orderGroupOperationsBox = document.querySelectorAll('div.order-group-operation');
        let rows = Array.from(orderGroupOperationsBox).map(e => e.parentElement).filter(e => !observedRows.includes(e.querySelector('a[orderid]').getAttribute('orderid')));
        rows.forEach(row => {
          observedRows.push(row.querySelector('a[orderid]').getAttribute('orderid'));
          observer.observe(row);
        });
        observer.unobserve(entry.target);
      }
      
    });
  }

  await new Promise(resolve => setTimeout(resolve, 2000));
  const orderGroupOperationsBox = document.querySelectorAll('div.order-group-operation');
  let rows = Array.from(orderGroupOperationsBox).map(e => e.parentElement);
  rows.forEach(row => {
    observedRows.push(row.querySelector('a[orderid]').getAttribute('orderid'));
    observer.observe(row);
  });
}

async function getBuyerStatsGetOrders(parameters, buyerNode) {
  if (buyerNode === undefined) return Promise.resolve(true);

  let buyer;
  const buyerLogin = buyerNode.querySelector('a').textContent;
  try {
    buyer = await getBuyerStats(parameters, buyerLogin);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  }

  if (buyer !== undefined && buyerNode.parentElement.querySelector('.buyerStats') === null) {
    let ordersCount = buyer.orders.length;
    let returnsCount = buyer.returns.length;
    let ordersValue = 0;
    let returnsValue = 0;
    let ordersTooltip = /*html*/ `<div class="buyerStatsOrdersTooltip">`;
    buyer.orders.forEach(order => {
      ordersValue += parseFloat(order.orderValue);
      ordersTooltip += /*html*/ `<span class="row">data: ${order.orderDate.split('T')[0]}, wartość: ${order.orderValue} zł</span>`;
    });
    ordersTooltip += `</div>`;

    let returnsTooltip = /*html*/ `<div class="buyerStatsReturnsTooltip">`;
    buyer.returns.forEach(returnOrder => {
      returnsValue += parseFloat(returnOrder.returnValue);
      returnsTooltip += /*html*/ `<span class="row">data: ${returnOrder.returnDate.split('T')[0]}, wartość: ${returnOrder.returnValue} zł</span>`;
    });
    returnsTooltip += `</div>`;
    buyerNode.parentElement.insertAdjacentHTML('beforeend', /*html*/ `
      <div class="buyerStats">
        <span class="buyerStatsTooltipWrapper">
          <span class="buyerStatsOrdersLink">zamówienia:</span>
            ${ordersTooltip}
        </span>
        ${ordersCount} (${ordersValue.toFixed(2)} zł),
        <span class="buyerStatsTooltipWrapper">
          <span class="buyerStatsReturnsLink">zwroty:</span>
            ${returnsCount ? returnsTooltip : ''}
        </span>
        ${returnsCount} (${returnsValue.toFixed(2)} zł)
      </div>
    `);
  }
  return Promise.resolve(true);
}

async function getBuyerStats(parameters, buyerLogin, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms?offset=${parameters.offset}&status=READY_FOR_PROCESSING&buyer.login=${buyerLogin}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getBuyerStats(parameters, buyerLogin, count);      
    } else {
      return Promise.reject(`Nie udało się sprawdzić zamówień. ${error?.message ? error.message : error}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    let buyerOrders = fetchData.checkoutForms;

    async function getBuyerOrders(buyerOrders, buyer) {
      const order = buyerOrders.shift();
      if (order === undefined && buyer !== undefined) {
        try {
          response = await sendMessage({ action: 'buyerStatsSaveBuyer', buyer: buyer });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
        return Promise.resolve(buyer);
      }

      if (order === undefined && buyer === undefined) {
        return Promise.resolve(undefined);
      }

      if (buyer === undefined) {
        try {
          response = await sendMessage({ action: 'buyerStatsGetBuyer', login: order.buyer.login });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
        buyer = response.result;
        if (buyer === undefined) { // Nie znaleziono użytkownika - pierwsze zamówienie
          buyer = {
            id: order.buyer.id,
            login: order.buyer.login,
            orders: [{
              orderId: order.id,
              orderDate: order.payment.finishedAt,
              orderValue: order.summary.totalToPay.amount
            }],
            returns: [],
          } 
        }
      } else { // Użytkownik zamawiał już coś wcześniej
        if (buyer.orders.some(o => o.orderId === order.id) === false) { // Nie znaleziono tego zamówienia na liście wcześniejszych zamówień
          let newOrder = {
            orderId: order.id,
            orderDate: order.payment.finishedAt,
            orderValue: order.summary.totalToPay.amount
          }
          buyer.orders.push(newOrder);
        }
      }

      let returns;
      try {
        returns = await buyerStatsGetReturns(parameters, order.id);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }

      if (returns !== true) { 
        returns.forEach(singleReturn => { 
          if (buyer.returns.some(r => (r.orderId === singleReturn.orderId) && (r.returnDate === singleReturn.returnDate)) === false) { // Nie znaleziono tego konkretnego zwrotu
            buyer.returns.push(singleReturn);
          }
        });
      }
      return await getBuyerOrders(buyerOrders, buyer);
    }

    let buyer;
    try {
      buyer = await getBuyerOrders(buyerOrders);
    } catch (error) {
      return Promise.reject(error?.message ? error.message : error);
    } 

    if (fetchData.totalCount > fetchData.count) {
      parameters.offset += fetchData.count;
      try {
        await getBuyerStats(parameters, buyerLogin);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      } 
    }

    parameters.offset = 0;
    return Promise.resolve(buyer);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getBuyerStats(parameters, buyerLogin, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Przekroczono limit zapytań. Wstrzymano na chwilę. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 20000));
      return await getBuyerStats(parameters, buyerLogin, count); 
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getBuyerStats(parameters, buyerLogin, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }	
}

async function buyerStatsGetReturns(parameters, orderId, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/customer-returns?orderId=${orderId}`, {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.beta.v1+json',
        'Accept': 'application/vnd.allegro.beta.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);      
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. ${error?.message ? error.message : error}`);
    }
  }

  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    if (fetchData.customerReturns.length > 0) {
      let returns = [];
      for (const returnOrder of fetchData.customerReturns) {
        let returnOrderValue = 0;
        returnOrder.items.forEach(item => {
          returnOrderValue += parseFloat(item.price.amount * item.quantity);
        });
        returns.push({
          orderId: returnOrder.orderId,
          returnDate: returnOrder.createdAt,
          returnValue: returnOrderValue
        });
      }
      return Promise.resolve(returns);
    }
    return Promise.resolve(true);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await buyerStatsGetReturns(parameters, orderId, count);
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
			toastMessage(`Przekroczono limit zapytań. Wstrzymano na chwilę. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 20000));
			return await buyerStatsGetReturns(parameters, orderId, count);  
		} else {
			return Promise.reject(`Nie udało się sprawdzić zwrotu. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);  
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}
