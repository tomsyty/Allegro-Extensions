async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt autoprintLabel');
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let orderId = document.location.href.split('/');
	orderId = orderId[orderId.length - 1].split('?')[0];
	if (orderId.indexOf(',') !== -1) return;
	
	let previousUrl;
	const urlObserver = new MutationObserver(async () => {
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			await new Promise(resolve => setTimeout(resolve, 100));
			if (location.href.startsWith(`https://salescenter.allegro.com${environment}/ship-with-allegro/swa/create-shipment-status`)) {
				try {
					await autoprintLabel();
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
				}
			}	else if (location.href.startsWith(`https://salescenter.allegro.com${environment}/ship-with-allegro/swa/create-shipment/`)) {
				try {
					await findOrderShipmentsButton();
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
				}
			}				
			return;
		}
	});
	urlObserver.observe(document, { subtree: true, childList: true });	
});

async function findOrderShipmentsButton() {
	let buttonNodes = Array.from(document.querySelectorAll('button'));
	let orderShipmentsButton;
	let saveButton;
	if (buttonNodes) {
		orderShipmentsButton = buttonNodes.find(element => element.textContent === 'Zamów przesyłki');
		saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
	}
	if (orderShipmentsButton !== undefined && saveButton !== undefined) {
		try {
			await autoprintLabelObserveOrderShipmentsButton(orderShipmentsButton);
			saveButton.addEventListener('click', async (e) => {
				if (e.isTrusted) {
					try {
						await saveDataToSessionStorage({ autoprint: false });
					} catch (error) {
						toastMessage(`Błąd! Nie udało się oznaczyć zamówienia jako nie przeznaczonego do automatycznego wydruku. ${getErrorMessage(error)}`);
					}
				}
			});
			const additionalButtons = await createAdditionalButtons(orderShipmentsButton, saveButton);
			await additionalButtonsState(orderShipmentsButton, additionalButtons);
			await watchButtonState(orderShipmentsButton);			
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}

		let orderId = document.location.href.split('/');
		orderId = orderId[orderId.length - 1].split('?')[0];
		window.sendParcelLinkOrderId = orderId;

		return Promise.resolve(true);
	} else {
		console.log('autoPrintLabel: oczekiwanie na przyciski "Zapisz" i "Zamów przesyłki"');
		const observer = new MutationObserver(mutations => {
			mutations.forEach(async (mutation) => {
				if (mutation.type === 'childList' && mutation.addedNodes.length) {
					const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zamów przesyłki')));
					if (addedButton !== undefined) {
						buttonNodes = Array.from(document.querySelectorAll('button'));
						const bothButtons = buttonNodes.filter(element => element.textContent === 'Zamów przesyłki' || element.textContent === 'Zapisz');
						if (bothButtons.length === 2) {
							observer.disconnect();	
							console.log('autoPrintLabel: przyciski "Zapisz" i "Zamów przesyłki" pojawiły się już na stronie');					
							return await findOrderShipmentsButton();
						}
					}	
				}
			});
		});
		observer.observe(document.body, { subtree: true, childList: true });
	}
}

async function autoprintLabelObserveOrderShipmentsButton(orderShipmentsButton) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}
	const activeLockingExtensions = Object.keys(readedValue.extensions).filter(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize' || extensionName === 'inPostSendMode'));
	if (orderShipmentsButton.dataset.lock !== undefined || orderShipmentsButton.dataset.done !== undefined) return Promise.resolve(true);
	orderShipmentsButton.dataset.lock = `${activeLockingExtensions.join(',')},`;

	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.attributeName === 'data-lock') {
				const saveButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zapisz');			
				if (orderShipmentsButton.dataset.lock === '') {
					saveButton.disabled = false;
				} else {
					saveButton.disabled = true;
				}			
			}
		});    
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['data-lock'] });		
}

async function watchButtonState(orderShipmentsButton) {
	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(async (mutation) => {
			if (mutation.attributeName === 'disabled') {
				if (orderShipmentsButton.disabled === false) {
					orderShipmentsButtonObserver.disconnect();
					const additionalSaveButtonTopContainer = document.getElementById('additionalSaveButtonTopContainer');
					if (additionalSaveButtonTopContainer) additionalSaveButtonTopContainer.remove();
					const additionalSaveButtonBottom = document.getElementById('additionalSaveButtonBottom');
					if (additionalSaveButtonBottom) additionalSaveButtonBottom.remove();
					let readedValue;
					try {
						readedValue = await readDataFromSessionStorage(['autoprint']);
					} catch(error) {
						return Promise.reject(`Nie udało się sprawdzić czy zamówienie jest przeznaczone do automatycznego wydruku. ${getErrorMessage(error)}`);
					}
					if (readedValue.autoprint) {
						const event = new Event('click');
						orderShipmentsButton.dispatchEvent(event);
					}
				}
			}
		});    
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['disabled'] });	
}

async function additionalButtonsState(orderShipmentsButton, additionalButtons) {
	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.attributeName === 'data-lock') {
				if (orderShipmentsButton.dataset.lock === '') {
					orderShipmentsButtonObserver.disconnect();
					additionalButtons.top.disabled = false;
					additionalButtons.bottom.disabled = false;
				}
			}
		});    
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['data-lock'] });	
}

async function createAdditionalButtons(orderShipmentsButton, saveButton) {
	const recipientHeader = Array.from(document.querySelectorAll('h5')).find(element => element.textContent === 'Dane dostawy i wysyłki');
	if (recipientHeader !== undefined) {
		saveButton.disabled = true;
		const additionalSaveButtonTop = saveButton.cloneNode(true);
		additionalSaveButtonTop.innerText = 'Zapisz i drukuj';
		additionalSaveButtonTop.id = 'additionalSaveButtonTop';
		if (additionalSaveButtonTop.classList.contains('shipmentNotExists')) additionalSaveButtonTop.classList.remove('shipmentNotExists');
		const additionalSaveButtonBottom = saveButton.cloneNode(true);
		additionalSaveButtonBottom.innerText = 'Zapisz i drukuj';
		additionalSaveButtonBottom.id = 'additionalSaveButtonBottom';	
		if (additionalSaveButtonBottom.classList.contains('shipmentNotExists')) additionalSaveButtonBottom.classList.remove('shipmentNotExists');
		const additionalSaveButtonTopContainer = document.createElement('div');
		additionalSaveButtonTopContainer.id = 'additionalSaveButtonTopContainer';
		additionalSaveButtonTopContainer.appendChild(additionalSaveButtonTop);

		recipientHeader.insertAdjacentElement('afterend', additionalSaveButtonTopContainer);
		saveButton.parentNode.insertBefore(additionalSaveButtonBottom, saveButton);	
		
		additionalSaveButtonTop.addEventListener('click', async (e) => {
			e.target.disabled = true;
			const additionalSaveButtonBottom = document.getElementById('additionalSaveButtonBottom');
			if (additionalSaveButtonBottom !== null) {
				additionalSaveButtonBottom.disabled = true;
			}

			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['extensions']);
			} catch (error) {
				toastMessage(`Błąd! Nie udało się wczytać listy aktywnych rozszerzeń. ${getErrorMessage(error)}`);
				return;
			}

			const shipmentExistsWarningActive = readedValue.extensions.shipmentExistsWarning;
			if (shipmentExistsWarningActive) {
				const locationSplitted = window.location.href.split('/');
				let orderId = locationSplitted[locationSplitted.length - 1]?.split('?')[0];
			
				if (orderId === undefined) {
					toastMessage('Błąd! W adresie strony nie znaleziono numeru zamówienia. Nie udało się sprawdzić, czy przesyłka już istnieje.');
					return;
				}
			
				try {
					const shipmentExists = await checkIfShipmentExists(orderId);
					const orderStatus = await checkOrderStatus();
					if (orderStatus.orderStatus === 'CANCELLED') {
						toastMessage('Błąd! Zamówienie zostało anulowane.');
						saveButton.classList.add('orderCancelled');
						window.alert('Zamówienie zostało anulowane.');
						return;
					}
					if (shipmentExists.shipmentExists === true) {
						toastMessage('Błąd! Do tego zamówienia został już przypisany numer przesyłki.');
						window.alert('Do tego zamówienia został już przypisany numer przesyłki.');
						return;
					}	
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
					return;
				}

				async function checkIfShipmentExists(orderId) {
					let response;
					let fetchResponse;
					let fetchData;
					const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
					const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
					try {
						response = await sendMessage({ action: 'getAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					} 
				
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
				
					let accessToken = response.result;
					try {
						fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}/shipments` , {
							'method': 'GET',
							'headers': {
								'Authorization': `Bearer ${accessToken}`,
								'Content-Type': 'application/vnd.allegro.public.v1+json',
								'Accept': 'application/vnd.allegro.public.v1+json'
							}
						});
					} catch (error) {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkIfShipmentExists(orderId, count);      
						} else {
							return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić czy do zamówienia został przypisany już jakiś numer przesyłki. ${getErrorMessage(error)}`);
						}
					}
					if (fetchResponse.status === 200) {
						try {
							fetchData = await fetchResponse.json();
						} catch (error) {
							return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
						}
						return Promise.resolve({ shipmentExists: (fetchData.shipments.length ? true : false) });
					} else if (fetchResponse.status === 401) {
						if (--count) {
							try {
								response = await sendMessage({ action: 'refreshAllegroAccessToken' });
								if (!response.success) throw new Error(response.result);
							} catch (error) {
								return Promise.reject(getErrorMessage(error));
							}  
							if (response.result === undefined) {
								return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
							}
							return await checkIfShipmentExists(orderId, count);  
						} else {
							return Promise.reject(`Nie udało się czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. Nie udało się zalogować użytkownika.`);
						}
					} else if (fetchResponse.status === 403) {
						return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
					} else if (fetchResponse.status === 429) {
						if (--count) {
							toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
							return await checkIfShipmentExists(orderId, count);
						} else {
							return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. Spróbuj ponownie później.`);
						}
					} else if (fetchResponse.status === 500) {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkIfShipmentExists(orderId, count);
						} else {
							return Promise.reject(`Błąd serwera podczas sprawdzania czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki, spróbuj ponownie później.`);
						}
					} else {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkIfShipmentExists(orderId, count);      
						} else {
							return Promise.reject(`Nie udało się sprawdzić czy do zamówienia ${orderId} został przypisany już jakiś numer przesyłki. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
						}											
					}
				}

				async function checkOrderStatus(count = 5) {
					let orderId = document.location.href.split('/');
					orderId = orderId[orderId.length - 1].split('?')[0];
					
					let response;
					let fetchResponse;
					let fetchData;
					const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
					const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
					try {
						response = await sendMessage({ action: 'getAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					} 
				
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
				
					let accessToken = response.result;
					try {
						fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}/` , {
							'method': 'GET',
							'headers': {
								'Authorization': `Bearer ${accessToken}`,
								'Content-Type': 'application/vnd.allegro.public.v1+json',
								'Accept': 'application/vnd.allegro.public.v1+json'
							}
						});
					} catch (error) {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkOrderStatus(count);      
						} else {
							return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić czy zamówienie nie jest anulowane. ${getErrorMessage(error)}`);
						}
					}
					if (fetchResponse.status === 200) {
						try {
							fetchData = await fetchResponse.json();
						} catch (error) {
							return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
						}
						return Promise.resolve({ orderStatus: fetchData.status });
					} else if (fetchResponse.status === 401) {
						if (--count) {
							try {
								response = await sendMessage({ action: 'refreshAllegroAccessToken' });
								if (!response.success) throw new Error(response.result);
							} catch (error) {
								return Promise.reject(getErrorMessage(error));
							}  
							if (response.result === undefined) {
								return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
							}
							return await checkOrderStatus(count);  
						} else {
							return Promise.reject(`Nie udało się czy zamówienie ${orderId} nie jest anulowane. Nie udało się zalogować użytkownika.`);
						}
					} else if (fetchResponse.status === 403) {
						return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
					} else if (fetchResponse.status === 429) {
						if (--count) {
							toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
							return await checkOrderStatus(count);
						} else {
							return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane. Spróbuj ponownie później.`);
						}
					} else if (fetchResponse.status === 500) {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkOrderStatus(count);
						} else {
							return Promise.reject(`Błąd serwera podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane, spróbuj ponownie później.`);
						}
					} else {
						if (--count) {
							toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await checkOrderStatus(count);      
						} else {
							return Promise.reject(`Nie udało się sprawdzić czy zamówienie ${orderId} nie jest anulowane. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
						}											
					}
				}
			}

			try {
				await saveDataToSessionStorage({ autoprint: true });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się oznaczyć zamówienia jako przeznaczonego do automatycznego wydruku. ${getErrorMessage(error)}`);
			}

			const event = new Event('click');
			saveButton.dispatchEvent(event);
		});	

		additionalSaveButtonBottom.addEventListener('click', (e) => {
			e.target.disabled = true;
			const additionalSaveButtonTop = document.getElementById('additionalSaveButtonTop');
			if (additionalSaveButtonTop !== null) {
				const event = new Event('click');
				additionalSaveButtonTop.dispatchEvent(event);
			}											
		});
		return Promise.resolve({ top: additionalSaveButtonTop, bottom: additionalSaveButtonBottom });
	} else {
		const observer = new MutationObserver(mutations => {
			mutations.forEach(async (mutation) => {
				if (mutation.type === 'childList') {
					const addedNode = Array.from(mutation.addedNodes).find(element => element.nodeName === 'H5' && element.textContent === 'Dane dostawy i wysyłki');
					if (addedNode !== undefined) {							
						observer.disconnect();
						return await createAdditionalButtons(orderShipmentsButton, saveButton);
					}
				}
			});
		});
		observer.observe(document.body, { subtree: true, childList: true });
	}
}

async function autoprintLabel() {
	let downloadButton;
	let response;
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	if (location.href.startsWith(`https://salescenter.allegro.com${environment}/ship-with-allegro/swa/create-shipment-status`)) {
		let readedValue;
		try {
			readedValue = await readDataFromSessionStorage(['autoprint']);
		} catch(error) {
			return Promise.reject(`Nie udało się sprawdzić czy zamówienie jest przeznaczone do automatycznego wydruku. ${getErrorMessage(error)}`);
		}
		if (readedValue.autoprint) {
			chrome.storage.session.remove('autoprint');
			
			try {
				await sendMessage({ action: 'updateSendParcelLink', environment: environment, orderId: window.sendParcelLinkOrderId });
			} catch (error) {
				toastMessage(`Błąd! ${getErrorMessage(error)}`);
			}

			try {
				response = await sendMessage({ action: 'moveTabToNewWindow', screenx: screen.width, screeny: screen.height });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			document.getElementsByTagName('title')[0].innerText = 'Etykieta - oczekiwanie';
			console.log('autoprintLabel: oczekiwanie na główny kontener strony');
			try {
				await waitForMainContainer();
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			console.log('autoprintLabel: oczekiwanie na przycisk "Pobierz etykietę"');
			try {
				downloadButton = await waitForDownloadButton();
			} catch (error) {
				try {
					response = await sendMessage({ action: 'maximizeNewWindow' });
					if (!response.success) throw new Error (response.result);
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return Promise.reject(getErrorMessage(error));
			}

			console.log('autoprintLabel: klikanie przycisku "Pobierz etykietę"');
			const event = new Event('click');
			const delay = t => new Promise(resolve => setTimeout(resolve, t));
			delay(200).then(() => {
				downloadButton.dispatchEvent(event);
			});		
			
			document.getElementsByTagName('title')[0].innerText = 'Etykieta - pobieranie';
			try {
				response = await sendMessage({ action: 'downloadLabel' });
				if (!response.success) throw new Error(response.result);
				if (response.result.backup) {
					await sendMessage({ action: 'maximizeNewWindow' });
					if (window.confirm(`Nie wykryto zakończenia pobierania w sposób automatyczny w ustalonym okresie czasu. Ostatnio znaleziony pobrany plik to ${response.result.filename}. Upewnij się że jest to plik z etykietą którą chcesz wydrukować a nie plik wcześniejszy. Czy wydrukować?`));
					else return Promise.reject(`Odrzucono wydruk pliku ${response.result.filename}`);
				}
			} catch (error) {
				try {
					response = await sendMessage({ action: 'maximizeNewWindow' });
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return Promise.reject(getErrorMessage(error))
			}

			document.getElementsByTagName('title')[0].innerText = 'Etykieta - drukowanie';
			try {
				response = await sendMessage({ action: 'printLabel', filename: response.result.filename });
				if (!response.success) throw new Error(response.result);
				response = await sendMessage({ action: 'closeCallerTab' });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				try {
					response = await sendMessage({ action: 'maximizeNewWindow' });
					if (!response.success) throw new Error(response.result);
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return Promise.reject(getErrorMessage(error))
			}
		} else console.log('autoprintLabel: zamówienie nie jest przeznaczone do automatycznego wydruku');
	}
}

async function waitForMainContainer() {
	let response;
	const formContainer = document.querySelector('div[data-box-name="allegro.wza.form"]');
	if (formContainer !== null) {
		return Promise.resolve(true);
	} else {
		try {
			response = await sendMessage({ action: 'bringWindowToFront' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			return Promise.reject(getErrorMessage(error));
		}
		await new Promise(resolve => setTimeout(resolve, 1000));
		return await waitForMainContainer();
	}
}
	
async function waitForDownloadButton(retriesLeft = 10) {
	if (!retriesLeft--) return Promise.reject('Nie znaleziono przycisku Pobierz etykietę.');
	let response;
	let downloadButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Pobierz etykietę');
	if (downloadButton !== undefined) {
		return Promise.resolve(downloadButton);
	} else {
		try {
			response = await sendMessage({ action: 'bringWindowToFront' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			return Promise.reject(getErrorMessage(error));
		}
		await new Promise(resolve => setTimeout(resolve, 1000));
		console.log('autoprintLabel: nie znaleziono przycisku "Pobierz etykietę", ponawiam oczekiwanie...');
		return await waitForDownloadButton(retriesLeft);
	}
}