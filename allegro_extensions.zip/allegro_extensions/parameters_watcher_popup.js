async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt parameters_watcher_popup.js');
	document.getElementById('runNowButton').addEventListener('click', runNowButtonClick);
  document.getElementById('postponeButton').addEventListener('click', postponeButtonClick);
  document.getElementById('stopButton').addEventListener('click', stopButtonClick);

  let readedValue;
  readedValue = await chrome.storage.session.get(['auctionsWithChangesInProducts']);
  if (readedValue['auctionsWithChangesInProducts'] !== undefined) {
    let changesList = document.getElementById('changesList');
    readedValue['auctionsWithChangesInProducts'].forEach(auction => {
      changesList.innerHTML += `<div><a href="https://salescenter.allegro.com/my-assortment?phrase=${auction.number}" target="_blank"${auction.visited ? ' class="visited"' : ""}>${auction.number}</a></div>`;
    });
    document.querySelectorAll('a').forEach(linkElement => linkElement.addEventListener('click', setVisited));
  }

  chrome.storage.onChanged.addListener((storageObject, storageArea) => {
    if (storageArea === 'session') {
      if ('auctionsWithChangesInProducts' in storageObject && 'newValue' in storageObject['auctionsWithChangesInProducts'] && storageObject['auctionsWithChangesInProducts'].newValue[0]?.visited === false) {
        changesList.innerHTML = storageObject['auctionsWithChangesInProducts'].newValue.map(auction => `<div><a href="https://salescenter.allegro.com/my-assortment?phrase=${auction.number}" target="_blank"${auction.visited ? ' class="visited"' : ""}>${auction.number}</a></div>`).join('');
      }
    }

    document.querySelectorAll('a').forEach(linkElement => linkElement.addEventListener('click', setVisited));
  });

  let currentBadgeText = await chrome.action.getBadgeText({});
  if (currentBadgeText !== '') {
    document.getElementById('runNowButton').disabled = true;
    document.getElementById('postponeButton').disabled = true;
    document.getElementById('stopButton').disabled = false;
    document.getElementById('info').textContent = 'Sprawdzanie parametrów jest w toku.';
  }
});

async function setVisited(e) {
  e.target.classList.add('visited');
  let readedValue = await chrome.storage.session.get(['auctionsWithChangesInProducts']);
  if (readedValue['auctionsWithChangesInProducts'] !== undefined) {
    Array.from(readedValue['auctionsWithChangesInProducts']).forEach(auction => {
      if (auction.number === e.target.innerText) {
        auction.visited = true;
      }
    })
  }
  await chrome.storage.session.set({ auctionsWithChangesInProducts: readedValue['auctionsWithChangesInProducts'] });
}

async function runNowButtonClick(e) {
  e.target.disabled = true;
  document.getElementById('postponeButton').disabled = true;
  document.getElementById('stopButton').disabled = false;
  document.getElementById('info').textContent = 'Sprawdzanie parametrów jest w toku.';
  let response;
  try {
    const currentBadgeText = await chrome.action.getBadgeText({});
		if (currentBadgeText !== '') {
      e.target.disabled = false;
      return;
    }
    await chrome.storage.session.remove('auctionsWithChangesInProducts');
    document.getElementById('changesList').textContent = '';
    document.getElementById('info').textContent = 'Sprawdzanie parametrów jest w toku.';
    response = await sendMessage({ action: 'parametersWatcherRun' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    e.target.disabled = false;
    document.getElementById('postponeButton').disabled = false;
    document.getElementById('stopButton').disabled = true;
  }
}

async function postponeButtonClick() {
  let response;
  try {
    response = await sendMessage({ action: 'parametersWatcherPostpone' });
    if (!response.success) throw new Error(response.result);
    document.getElementById('info').textContent = `Przełożono sprawdzanie parametrów na ${response.result}`;
    await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${response.result}` });
  } catch (error) {
    document.getElementById('info').textContent = 'Nie udało się przełożyć sprawdzania parametrów';
  }
}

async function stopButtonClick(e) {
  e.target.disabled = true;
  try {
    await sendMessage({ action: 'parametersWatcherStop' });
    document.getElementById('runNowButton').disabled = false;
    document.getElementById('postponeButton').disabled = false; 
    document.getElementById('info').textContent = 'Zatrzymano';  
  } catch (error) {
    document.getElementById('info').textContent = 'Nie udało się zatrzymać sprawdzania parametrów. Wyłącz rozszerzenie aby zatrzymać.';
    e.target.disabled = false;
  }
}