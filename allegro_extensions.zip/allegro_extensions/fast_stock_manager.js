async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function readDataFromSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt fastStockManager');

	(function addStylesheet() {	
		const link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0';
		document.head.appendChild(link);
	})();
					
	fastStockManager();
});

function fastStockManager() {
	let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
		const iconCheckCircle = document.createElement('span');
		iconCheckCircle.className = 'material-symbols-outlined';
		iconCheckCircle.dataset.icon = 'check_circle';
		preloadIconsContainer.appendChild(iconCheckCircle);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="cancel"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'cancel';
		preloadIconsContainer.appendChild(iconHighlightOff);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="do_not_disturb_on"]')) {
		const iconRemoveCircle = document.createElement('span');
		iconRemoveCircle.className = 'material-symbols-outlined';
		iconRemoveCircle.dataset.icon = 'do_not_disturb_on';
		preloadIconsContainer.appendChild(iconRemoveCircle);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="add_circle"]')) {
		const iconAddCircle = document.createElement('span');
		iconAddCircle.className = 'material-symbols-outlined';
		iconAddCircle.dataset.icon = 'add_circle';
		preloadIconsContainer.appendChild(iconAddCircle);
	}

	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	fastStockManagerObserveOffersList(environment);
}

function fastStockManagerObserveOffersList(environment) {
	const observedTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (observedTable === null) {
		const offersTableObserver = new MutationObserver(mutations => {
			mutations.forEach(mutation => {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						fastStockManagerObserveOffersList(environment);
					}
				}
			});
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	}	else {
		const urlObserver = new MutationObserver(() => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				fastStockManagerObserveOffersList(environment);
				return;
			}
		});
		urlObserver.observe(document, {	subtree: true, childList: true });
		fastStockManagerObserver(environment, observedTable);
	}  	
}

async function fastStockManagerObserver(environment, observedTable) {
	await new Promise(resolve => setTimeout(resolve, 1000));

	document.querySelectorAll('[data-testid="stock"]').forEach(stockSpan => { 
		stockSpan.addEventListener('mouseenter', fsmAllowEditing); 
	});

	const observer = new MutationObserver(async () => {
		observer.disconnect();
		await new Promise(resolve => setTimeout(resolve, 1000));
		document.querySelectorAll('[data-testid="stock"]').forEach(stockSpan => { 
			stockSpan.addEventListener('mouseenter', fsmAllowEditing);
		});
		fastStockManagerObserver(environment, observedTable);
	});	
	
	observer.observe(observedTable, { subtree: true, childList: true });
}

async function fsmAllowEditing(e) {
	if (document.getElementById('fsmActions') !== null) return;
	const stockSpan = e.target;
	const stockSpanHovered = document.querySelectorAll('span[class~="fsmStockSpanHover"]');
	stockSpanHovered.forEach(stockSpan => stockSpan.classList.remove('fsmStockSpanHover'));
	stockSpan.classList.add('fsmStockSpanHover');
	stockSpan.removeEventListener('mouseenter', fsmAllowEditing);

	let offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	try {
		await saveDataToSessionStorage({
			[`${offerId}`]: {
				defaultStock: (stockSpan.innerText === '-' ? 0 : Number(stockSpan.innerText))
			}
		});
	} catch (error) {
		toastMessage('Błąd! Nie udało się utworzyć obiektu przechowującego informacje o stanie magazynowym aukcji.');
		return;
	}

	stockSpan.addEventListener('wheel', fsmStockSpanWheel);
	stockSpan.addEventListener('keydown', fsmStockSpanKeyDown);
	stockSpan.addEventListener('keyup', fsmStockSpanKeyUp);
	stockSpan.addEventListener('paste', fsmStockSpanPaste);

	stockSpan.contentEditable = true;
	let actionsContainer = document.createElement('div');
	actionsContainer.id = 'fsmActions';
	
	let substractButton = document.createElement('span');
	substractButton.className = 'material-symbols-outlined';
	substractButton.id = 'fsmSubstractButton';
	substractButton.dataset.icon = 'remove_circle';
	substractButton.addEventListener('click', fsmSubstractButtonClick);
	
	let confirmButton = document.createElement('span');
	confirmButton.className = 'material-symbols-outlined';
	confirmButton.id='fsmConfirmButton';
	confirmButton.dataset.icon = 'check_circle';
	confirmButton.addEventListener('click', fsmConfirmButtonClick);
	
	let addButton = document.createElement('span');
	addButton.className = 'material-symbols-outlined';
	addButton.id='fsmAddButton';
	addButton.dataset.icon = 'add_circle';
	addButton.addEventListener('click', fsmAddButtonClick);

	actionsContainer.appendChild(substractButton);
	actionsContainer.appendChild(confirmButton);
	actionsContainer.appendChild(addButton);

	actionsContainer.querySelectorAll('span').forEach(button => {
		button.addEventListener('mouseenter', (e) => {
			e.target.parentNode.dataset.hovered = 'true';
		});
		button.addEventListener('mouseleave', (e) => {
			delete e.target.parentNode.dataset.hovered;
		});
		button.addEventListener('mousedown', (e) => {
			if (e.detail > 1) {
				e.preventDefault();
			}
		}, false);
	});

	stockSpan.parentNode.insertAdjacentElement('beforeend', actionsContainer);
	stockSpan.addEventListener('mouseleave', fsmStockSpanLeave);
	
	actionsContainer.addEventListener('mouseleave', async function(e) {
		const mouseX = e.clientX;
		const mouseY = e.clientY;

		const elementUnderMouse = document.elementFromPoint(mouseX, mouseY);
		if (elementUnderMouse.tagName === 'SPAN' && elementUnderMouse.dataset?.testid) return;

		this.parentNode.querySelectorAll('div[id^="fsm"').forEach(node => {
			node.remove();
		});

		let stockSpanFromStorage;
		try {
			stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		} catch (error) {
			toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
			return;
		}
		if (stockSpanFromStorage[offerId]?.defaultStock != stockSpan.innerText && !stockSpan.hasAttribute('data-pendingchange')) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		stockSpan.addEventListener('mouseenter', fsmAllowEditing);
	});
}

async function fsmStockSpanLeave(e) {
	let stockSpan = e.target;
	await new Promise(resolve => setTimeout(resolve, 200));
	const mouseX = e.clientX;
	const mouseY = e.clientY;
	const elementUnderMouse = document.elementFromPoint(mouseX, mouseY);
	if (elementUnderMouse?.id && elementUnderMouse.id.startsWith('fsm')) return;
	

	const actionsContainer = document.getElementById('fsmActions');
	if (actionsContainer !== null) {
		if (!actionsContainer.hasAttribute('data-hovered')) {
			stockSpan.contentEditable = false;
			stockSpan.classList.remove('fsmStockSpanHover');
			actionsContainer.parentNode.querySelectorAll('div[id^="fsm"').forEach(node => {
				node.remove();
			});
			let stockSpanFromStorage;

			const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
			if (!offerId) {
				toastMessage('Błąd! Nie znaleziono numeru aukcji.');
				return;
			}

			try {
				stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
			} catch (error) {
				toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
				return;
			}
			if (stockSpanFromStorage[offerId]?.defaultStock != stockSpan.innerText && !stockSpan.hasAttribute('data-pendingchange')) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);
			
			stockSpan.addEventListener('mouseenter', fsmAllowEditing);	
		}
	} else {
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
	}
	//stockSpan.addEventListener('mouseenter', fsmAllowEditing);
}

async function fsmStockSpanWheel(e) {
	e.preventDefault()
	const direction = e.deltaY;
	let stockSpan = this;
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (direction < 0) {
		if (Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
	} else {
		if (Number(stockSpanValue) > 0) stockSpan.innerText = Number(stockSpanValue) - 1;
	}

	const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let relativeChange = stockSpan.parentNode.querySelector('#fsmRelativeChange');
	if (relativeChange === null) {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentNode.appendChild(relativeChange);
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}

	let relativeChangeValue = (stockSpanFromStorage[offerId]?.defaultStock - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmStockSpanKeyDown(e) {
	const char = e.which || e.keyCode;
	if (char == 8 || char == 9 || char == 13 || char == 27 || char == 46 || (char >=37 && char <=40) || (char >=48 && char <=57) || (char >=96 && char <=105)) {
		if ((char >=48 && char <=57) || (char >=96 && char <=105)) {
			const stockSpan = this;
			let selection = document.getSelection();
			if (selection && selection.type === 'Range') selection.deleteFromDocument();
			selection = document.getSelection();
			selection.modify('extend', 'backward', 'paragraphboundary');
			let caretPosition = selection.toString().length;
			if (selection.anchorNode !== undefined) selection.collapseToEnd();
			if ((char === 48 || char === 96) && (stockSpan.innerText.startsWith('0') || (caretPosition === 0 && stockSpan.innerText.trim().length > 0))) e.preventDefault();	// Nie wstawiaj zera na początku
			else {
				if (stockSpan.innerText.startsWith('0') && caretPosition !== 0) stockSpan.innerText = stockSpan.innerText.replace('0', '');
				let possibleValue = stockSpan.innerText.substring(0, caretPosition) + String.fromCharCode((char >= 96 ? char - 48 : char)) + stockSpan.innerText.substring(caretPosition);
				if ((Number(possibleValue) > 9999) || (Number(possibleValue) < 0)) e.preventDefault();				
			}
		} else switch (char) {
			case 9:
			case 27: {
				const stockSpan = this;

				const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
				if (!offerId) {
					toastMessage('Błąd! Nie znaleziono numeru aukcji.');
					return;
				}

				let stockSpanFromStorage;
				try {
					stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
				} catch (error) {
					toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
					return;
				}

				if (stockSpan.innerText != stockSpanFromStorage[offerId].defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);				
				let relativeChange = this.parentNode.querySelector('#fsmRelativeChange');
				if (relativeChange !== null) relativeChange.remove();
				break;
			}
			case 13: {
				e.preventDefault();
				fsmConfirmButtonClick(e);
				break;
			}
		}		
	} else e.preventDefault();
}

async function fsmStockSpanKeyUp(e) {
	const char = e.which || e.keyCode;
	if (char == 8 || char == 46 || char == 38 || char == 40 || (char >=48 && char <=57) || (char >=96 && char <=105)) {
		let stockSpan = this;

		let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
		if (char == 38 && Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
		else if (char == 40 && Number(stockSpanValue) > 0)	stockSpan.innerText = Number(stockSpanValue) - 1;

		let relativeChange = stockSpan.parentNode.querySelector('#fsmRelativeChange');
		if (relativeChange === null) {
			relativeChange = document.createElement('div');
			relativeChange.id = 'fsmRelativeChange';
			stockSpan.parentNode.appendChild(relativeChange);
		}

		const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
		if (!offerId) {
			toastMessage('Błąd! Nie znaleziono numeru aukcji.');
			return;
		}

		let stockSpanFromStorage;
		try {
			stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		} catch (error) {
			toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
			return;
		}
			
		let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
		relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
		relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
	}
}

function fsmStockSpanPaste(e) {
	e.preventDefault();
}

async function fsmSubstractButtonClick(e) {
	const stockSpan = e.target.parentNode.parentNode.querySelector('span[data-testid="stock"]');
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (Number(stockSpanValue) > 0) stockSpan.innerText = Number(stockSpanValue) - 1;
	
	let relativeChange = stockSpan.parentNode.querySelector('#fsmRelativeChange');
	if (relativeChange === null) {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentNode.appendChild(relativeChange);
	}

	const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}	
		
	let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmAddButtonClick(e) {
	const stockSpan = e.target.parentNode.parentNode.querySelector('span[data-testid="stock"]');
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
	
	let relativeChange = stockSpan.parentNode.querySelector('#fsmRelativeChange');
	if (relativeChange === null) {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentNode.appendChild(relativeChange);
	}

	const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}	
		
	let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmConfirmButtonClick(e) {
 	const parent = (e.target.nodeName === 'SPAN' ? e.target.parentNode.parentNode : e.target.parentNode);
	let stockSpan = parent.querySelector('span[data-testid="stock"]');
	let response;
	let relativeChange = parent.querySelector('#fsmRelativeChange');
	if (relativeChange === null || relativeChange.innerText === '') {
		parent.querySelectorAll('div[id^="fsm"').forEach(node => {
			node.remove();
		});
		toastMessage('Nie ma nic do zmiany.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}

	let stockSpanInnerText = stockSpan.innerText.trim();
	if (stockSpanInnerText === '') {
		stockSpan.innerText = '0';
		stockSpanInnerText = '0';
	}

	let relativeChangeValue = Number(relativeChange.innerText);
	relativeChange.remove();
	let actionsContainer = parent.querySelector('#fsmActions');

	const offerId = stockSpan.parentNode.parentNode.parentNode.parentNode?.dataset?.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}	

	if (actionsContainer !== null) {
		stockSpan.contentEditable = false;
		stockSpan.addEventListener('mouseenter', fsmAllowEditing);
		actionsContainer.remove();

		stockSpan.dataset.pendingchange = 'true';
	} 

	if (stockSpan.innerText === '0') toastMessage(`Kończenie aukcji ${offerId}`);
	else if (Number(stockSpan.innerText) - relativeChangeValue === 0) toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt. i wznawienie aukcji`);
	else toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt.`);

	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	const parameters = {
		environment: environment,
		accessToken: ''
	}
	
	try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		if (stockSpanFromStorage[offerId].defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == 0 ? '-' : stockSpanFromStorage[offerId].defaultStock);
		delete stockSpan.dataset.pendingchange;
    return;
  }

	parameters.accessToken = response.result;

	async function confirmStockChange(parameters, offerId, relativeChangeValue, count = 5) {
		let fetchResponse, response, result;
		try {
			fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
				'method': 'GET',
				'headers': {
					'Authorization': `Bearer ${parameters.accessToken}`,
					'Content-Type': 'application/vnd.allegro.public.v1+json',
					'Accept': 'application/vnd.allegro.public.v1+json'
				}
			});
		} catch (error) {
			return Promise.reject(`Podczas wysyłania żądania nastąpił błąd. ${error?.message ? error.message : error}`);
		}

		if (fetchResponse.status === 200) {
			try {
				result = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
			}

			if (result.stock.available !== undefined) {
				const stock = {
					'stock': {
						'available': (stockSpanInnerText === '0' ? 0 : Number(result.stock.available) + relativeChangeValue)
					}
				}
				if (stock.stock.available < 0) stock.stock.available = 0;
				else if (result.publication.status === 'ENDED') {
					stock.publication = {
						'status': 'ACTIVE'
					}
				}
				try {
					fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
						'method': 'PATCH',
						'headers': {
							'Authorization': `Bearer ${parameters.accessToken}`,
							'Content-Type': 'application/vnd.allegro.public.v1+json',
							'Accept': 'application/vnd.allegro.public.v1+json'
						},
						body: JSON.stringify(stock)
					});
				} catch (error) {
					return Promise.reject(`Podczas wysyłania żądania nastąpił błąd. ${error?.message ? error.message : error}`);
				}
				
				if (fetchResponse.status === 200) {
					if (stock.stock.available === 0) return Promise.resolve({ message: 'Zakończono!', stock: 0 });
					else if (stock?.publication?.status === 'ACTIVE') return Promise.resolve({ message: 'Zmieniono i wznowiono zakończoną aukcję!', stock: stock.stock.available });
					else return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
				} else if (fetchResponse.status === 202) {
					toastMessage('Trwa wprowadzanie zmian...');
					let responseStatusLocation = fetchResponse.headers.get('Location');
					if (responseStatusLocation) {
						try {
							response = await checkChangeStatus(parameters, responseStatusLocation);
							if (stock.stock.available === 0) return Promise.resolve({ message: 'Zakończono!', stock: stock.stock.available });
							else if (stock?.publication?.status === 'ACTIVE') return Promise.resolve({ message: 'Zmieniono i wznowiono zakończoną aukcję!', stock: stock.stock.available });
							else return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}	
					} else {
						return Promise.reject('Nie udało się potwierdzić wprowadzenia zmiany. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.');
					}
				} else if (fetchResponse.status === 401) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
						await new Promise(resolve => setTimeout(resolve, 5000));
						try {
							response = await sendMessage({ action: 'refreshAllegroAccessToken' });
							if (!response.success) throw new Error(response.result);
						} catch (error) {	
							return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
						}								
						parameters.accessToken = response.result;
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject('Nie udało się zmienić liczby przedmiotów. Nie udało się zalogować użytkownika.');
					}
				} else {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject('Nie udało się zmienić liczby przedmiotów.');
					}
				}
			}		
		} else if (fetchResponse.status === 401) {
			if (--count) {
				try {
					response = await sendMessage({ action: 'refreshAllegroAccessToken' });
					if (!response.success) throw new Error(response.result);
				} catch (error) {
					return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				parameters.accessToken = response.result;
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
		} else if (fetchResponse.status === 403) {
			return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
		} else {
			if (--count) {
				toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Nie udało się zmienić liczby przedmiotów. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			}
		}
	}
	
	try {
		response = await confirmStockChange(parameters, offerId, relativeChangeValue);
		toastMessage(response.message);
		await saveDataToSessionStorage({
			[`${offerId}`]: {
				defaultStock: response.stock
			}
		});

		const stockSpan = document.querySelector('span[class~="fsmStockSpanHover"]');
		if (stockSpan) {
			stockSpan.classList.replace('fsmStockSpanHover', 'fsmUpdatedValue');
			stockSpan.innerText = response.stock;
		}
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		try {
			const stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
			const stockSpan = document.querySelector('span[class~="fsmStockSpanHover"]');
			if (stockSpan) {
				stockSpan.classList.remove('fsmStockSpanHover');
				if (stockSpanFromStorage[offerId].defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == 0 ? '-' : stockSpanFromStorage[offerId].defaultStock);
			}
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		}
	} finally {
		if (stockSpan) {
			stockSpan.contentEditable = false;
			delete stockSpan.dataset.pendingchange;
		}
	}
}

async function checkChangeStatus(parameters, responseStatusLocation, count = 10) {
	let fetchResponse;
	try {
		fetchResponse = await fetch(responseStatusLocation , {
		'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		return Promise.reject('Nie udało się potwierdzić wprowadzenia zmiany. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.');
	}
	if (fetchResponse.status === 202) {
		if (--count) {
			toastMessage(`Sprawdzanie statusu wykonanej zmiany (${10 - count} z 10), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await checkChangeStatus(parameters, responseStatusLocation, count);
		} else {
			return Promise.reject('Nie udało się potwierdzić wprowadzenia zmiany. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.');
		}
	}	else if (fetchResponse.status === 200) {
		return Promise.resolve('Zmieniono!');
	}
}