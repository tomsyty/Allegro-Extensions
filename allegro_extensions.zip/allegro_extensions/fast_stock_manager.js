async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt fastStockManager');

	try {
		await fastStockManager();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

async function fastStockManager() {
	let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
		const iconCheckCircle = document.createElement('span');
		iconCheckCircle.className = 'material-symbols-outlined';
		iconCheckCircle.dataset.icon = 'check_circle';
		preloadIconsContainer.appendChild(iconCheckCircle);
		preloadIconsContainer.textContent = 'check_circle';
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="cancel"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'cancel';
		preloadIconsContainer.appendChild(iconHighlightOff);
		preloadIconsContainer.textContent = 'cancel';
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="do_not_disturb_on"]')) {
		const iconRemoveCircle = document.createElement('span');
		iconRemoveCircle.className = 'material-symbols-outlined';
		iconRemoveCircle.dataset.icon = 'do_not_disturb_on';
		preloadIconsContainer.appendChild(iconRemoveCircle);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="add_circle"]')) {
		const iconAddCircle = document.createElement('span');
		iconAddCircle.className = 'material-symbols-outlined';
		iconAddCircle.dataset.icon = 'add_circle';
		preloadIconsContainer.appendChild(iconAddCircle);
	}

	Array.from(preloadIconsContainer.querySelectorAll('.material-symbols-outlined')).forEach(icon => {
		icon.textContent = '';
		icon.setAttribute('aria-hidden', 'true');
	});

	try {
		await fsmAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
}

async function fsmAwaitOffersTable() {
	const observedTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (observedTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await fsmAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	}	else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await fsmAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});

		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await fsmObserveOffersTable();
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}  	
}

async function fsmObserveOffersTable() {
	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	const offersTable = document.querySelector('table[aria-label="lista ofert"]');

	const mutationObserver = new MutationObserver(fsmMutationCallback);
	//let fsmMutationIntervalId;

	async function fsmMutationCallback(mutations, mo) {
		for (const mutation of mutations) {
			if (mutation.type === 'attributes') {
				if (mutation.attributeName === 'data-cy') {
					//clearInterval(fsmMutationIntervalId);
					mutationObserver.disconnect();				
					const offerRow = mutation.target;
					const offerId = offerRow.dataset.cy;
					const stockSpan = offerRow.querySelector('span[data-testid="stock"]')?.firstElementChild.lastElementChild;
					if (!stockSpan) return;
					if (stockSpan.classList.contains('fsmReadedFromStorage')) return;
					stockSpan.addEventListener('mouseenter', fsmAllowEditing);		
					const offerStockFromStorage = await readDataFromSessionStorage([`${offerId}`]);
					if (offerStockFromStorage[offerId] && offerStockFromStorage[offerId]?.defaultStock) {
						if (stockSpan.textContent != offerStockFromStorage[offerId].defaultStock) {
							stockSpan.textContent = offerStockFromStorage[offerId].defaultStock;
							stockSpan.classList.add('fsmReadedFromStorage');
						} else {
							stockSpan.classList.remove('fsmReadedFromStorage');
						}
					}
				}
			}
		}

		//fsmMutationIntervalId = setInterval(async () => {
			offersTable.querySelectorAll('tr[data-cy]').forEach(offerRow => {
				offerRow.dataset.fsm = true;
				intersectionObserver.observe(offerRow);
			});
		//}, 500);
	}

	const intersectionObserver = new IntersectionObserver(fsmIntersectionCallback, options);
	//let fsmIntersectionIntervalId;

	async function fsmIntersectionCallback(entries, io) {
		entries.forEach(async (entry) => {
			//clearInterval(fsmIntersectionIntervalId);
			if (entry && entry.isIntersecting) {	
				const offerRow = entry.target;
				const stockSpan = offerRow.querySelector('span[data-testid="stock"]')?.firstElementChild.lastElementChild;
				if (!stockSpan) return;
				if (stockSpan.classList.contains('fsmReadedFromStorage')) return;
				stockSpan.addEventListener('mouseenter', fsmAllowEditing);
				const offerId = offerRow.dataset.cy;
				const offerStockFromStorage = await readDataFromSessionStorage([`${offerId}`]);
				if (offerStockFromStorage[offerId] && offerStockFromStorage[offerId]?.defaultStock) {
					if (stockSpan.textContent != offerStockFromStorage[offerId].defaultStock) {
						stockSpan.textContent = offerStockFromStorage[offerId].defaultStock;
						stockSpan.classList.add('fsmReadedFromStorage');
					} else {
						stockSpan.classList.remove('fsmReadedFromStorage');
					}
				}

				//fsmIntersectionIntervalId = setInterval(async () => {
					offersTable.querySelectorAll('tr[data-cy]').forEach(offerRow => {
						offerRow.dataset.fsm = true;
						intersectionObserver.observe(offerRow);
						mutationObserver.observe(offerRow, {
							attributeFilter: ['data-cy']
						});
					});
				//}, 500);
			}
		});
  }

	document.addEventListener('scrollend', async () => {
		await new Promise(resolve => setTimeout(resolve, 2000));
		const offersList = Array.from(offersTable.querySelectorAll('tr[data-cy]'));
		offersList.forEach(async offerRow => {
			const offerId = offerRow.dataset.cy;
			const stockSpan = offerRow.querySelector('span[data-testid="stock"]')?.firstElementChild.lastElementChild;
			if (!stockSpan) return;
			if (stockSpan.classList.contains('fsmReadedFromStorage')) return;
			stockSpan.addEventListener('mouseenter', fsmAllowEditing);		
			const offerStockFromStorage = await readDataFromSessionStorage([`${offerId}`]);
			if (offerStockFromStorage[offerId] && offerStockFromStorage[offerId]?.defaultStock) {
				if (stockSpan.textContent != offerStockFromStorage[offerId].defaultStock) {
					stockSpan.textContent = offerStockFromStorage[offerId].defaultStock;
					stockSpan.classList.add('fsmReadedFromStorage');
				} else {
					stockSpan.classList.remove('fsmReadedFromStorage');
				}
			}

			intersectionObserver.observe(offerRow);
			/*mutationObserver.observe(offerRow, {
				attributeFilter: ['data-cy']
			});*/
		});
	});

	let offersList;
	do {
		offersList = Array.from(offersTable.querySelectorAll('tr[data-cy]'));

		const offersListLength = offersList?.length;
		await new Promise(resolve => setTimeout(resolve, 2000));

		offersList = Array.from(offersTable.querySelectorAll('tr[data-cy]'));
		if (!offersList || offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
		else break;
	} while (1);	

	offersList.forEach(offerRow => {
		offerRow.dataset.fsm = true;
    intersectionObserver.observe(offerRow);
  });
}

async function fsmAllowEditing(e) {
	if (document.getElementById('fsmActions') !== null) return;
	const stockSpan = e.target;
	const stockSpanHovered = document.querySelectorAll('div[class~="fsmStockSpanHover"]');
	stockSpanHovered.forEach(stockSpan => stockSpan.classList.remove('fsmStockSpanHover'));
	stockSpan.classList.add('fsmStockSpanHover');
	stockSpan.removeEventListener('mouseenter', fsmAllowEditing);

	let offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let offer;
	let offerFromStorage;

	try {
		offerFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		offer = {
			defaultStock: (stockSpan.innerText === '-' ? 0 : Number(stockSpan.innerText))
		}
		await saveDataToSessionStorage({
			[`${offerId}`]: Object.assign(offerFromStorage[`${offerId}`] ?? {}, offer)
		});
	} catch (error) {
		toastMessage('Błąd! Nie udało się utworzyć obiektu przechowującego informacje o stanie magazynowym aukcji.');
		return;
	}

	stockSpan.addEventListener('wheel', fsmStockSpanWheel);
	stockSpan.addEventListener('keydown', fsmStockSpanKeyDown);
	stockSpan.addEventListener('keyup', fsmStockSpanKeyUp);
	stockSpan.addEventListener('paste', fsmStockSpanPaste);

	stockSpan.contentEditable = true;
	let actionsContainer = document.createElement('div');
	actionsContainer.id = 'fsmActions';
	
	let substractButton = document.createElement('span');
	substractButton.className = 'material-symbols-outlined';
	substractButton.id = 'fsmSubstractButton';
	substractButton.dataset.icon = 'remove_circle';
	substractButton.addEventListener('click', fsmSubstractButtonClick);
	
	let confirmButton = document.createElement('span');
	confirmButton.className = 'material-symbols-outlined';
	confirmButton.id='fsmConfirmButton';
	confirmButton.dataset.icon = 'check_circle';
	confirmButton.addEventListener('click', fsmConfirmButtonClick);
	
	let addButton = document.createElement('span');
	addButton.className = 'material-symbols-outlined';
	addButton.id='fsmAddButton';
	addButton.dataset.icon = 'add_circle';
	addButton.addEventListener('click', fsmAddButtonClick);

	actionsContainer.appendChild(substractButton);
	actionsContainer.appendChild(confirmButton);
	actionsContainer.appendChild(addButton);

	actionsContainer.querySelectorAll('span').forEach(button => {
		button.addEventListener('mouseenter', (e) => {
			e.target.parentNode.dataset.hovered = 'true';
		});
		button.addEventListener('mouseleave', (e) => {
			delete e.target.parentNode.dataset.hovered;
		});
		button.addEventListener('mousedown', (e) => {
			if (e.detail > 1) {
				e.preventDefault();
			}
		}, false);
	});

	stockSpan.parentNode.parentNode.insertAdjacentElement('afterend', actionsContainer);
	stockSpan.addEventListener('mouseleave', fsmStockSpanLeave);
	
	actionsContainer.addEventListener('mouseleave', async function(e) {
		const mouseX = e.clientX;
		const mouseY = e.clientY;

		const elementUnderMouse = document.elementFromPoint(mouseX, mouseY);
		if (elementUnderMouse && elementUnderMouse.tagName === 'SPAN' && elementUnderMouse.dataset?.testid) return;

		this.parentNode.querySelectorAll('div[id^="fsm"').forEach(node => {
			node.remove();
		});

		let stockSpanFromStorage;
		try {
			stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		} catch (error) {
			toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
			return;
		}
		if (stockSpanFromStorage[offerId]?.defaultStock != stockSpan.innerText && !stockSpan.hasAttribute('data-pendingchange')) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		stockSpan.addEventListener('mouseenter', fsmAllowEditing);
	});
}

async function fsmStockSpanLeave(e) {
	let stockSpan = e.target;
	await new Promise(resolve => setTimeout(resolve, 200));
	const mouseX = e.clientX;
	const mouseY = e.clientY;
	const elementUnderMouse = document.elementFromPoint(mouseX, mouseY);
	if (elementUnderMouse && elementUnderMouse.id && elementUnderMouse.id.startsWith('fsm')) return;
	

	const actionsContainer = document.getElementById('fsmActions');
	if (actionsContainer !== null) {
		if (!actionsContainer.hasAttribute('data-hovered')) {
			stockSpan.contentEditable = false;
			stockSpan.classList.remove('fsmStockSpanHover');
			actionsContainer.parentNode.querySelectorAll('div[id^="fsm"').forEach(node => {
				node.remove();
			});
			let stockSpanFromStorage;

			const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
			if (!offerId) {
				toastMessage('Błąd! Nie znaleziono numeru aukcji.');
				return;
			}

			try {
				stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
			} catch (error) {
				toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
				return;
			}
			if (stockSpanFromStorage[offerId]?.defaultStock && stockSpanFromStorage[offerId].defaultStock != stockSpan.innerText && !stockSpan.hasAttribute('data-pendingchange')) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);
			
			stockSpan.addEventListener('mouseenter', fsmAllowEditing);	
		}
	} else {
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
	}
	//stockSpan.addEventListener('mouseenter', fsmAllowEditing);
}

async function fsmStockSpanWheel(e) {
	e.preventDefault()
	const direction = e.deltaY;
	let stockSpan = this;
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (direction < 0) {
		if (Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
	} else {
		if (Number(stockSpanValue) > 0) stockSpan.innerText = Number(stockSpanValue) - 1;
	}

	const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let relativeChange = stockSpan.closest('span[data-testid="stock"]').nextElementSibling;
	if (relativeChange === null || relativeChange.id !== 'fsmRelativeChange') {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentElement.parentElement.insertAdjacentElement('afterend', relativeChange);
	}	

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}

	let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmStockSpanKeyDown(e) {
	const char = e.which || e.keyCode;
	if (char == 8 || char == 9 || char == 13 || char == 27 || char == 46 || (char >=37 && char <=40) || (char >=48 && char <=57) || (char >=96 && char <=105)) {
		if ((char >=48 && char <=57) || (char >=96 && char <=105)) {
			const stockSpan = this;
			let selection = document.getSelection();
			if (selection && selection.type === 'Range') selection.deleteFromDocument();
			selection = document.getSelection();
			selection.modify('extend', 'backward', 'paragraphboundary');
			let caretPosition = selection.toString().length;
			if (selection.anchorNode !== undefined) selection.collapseToEnd();
			if ((char === 48 || char === 96) && (stockSpan.innerText.startsWith('0') || (caretPosition === 0 && stockSpan.innerText.trim().length > 0))) e.preventDefault();	// Nie wstawiaj zera na początku
			else {
				if (stockSpan.innerText.startsWith('0') && caretPosition !== 0) stockSpan.innerText = stockSpan.innerText.replace('0', '');
				let possibleValue = stockSpan.innerText.substring(0, caretPosition) + String.fromCharCode((char >= 96 ? char - 48 : char)) + stockSpan.innerText.substring(caretPosition);
				if ((Number(possibleValue) > 9999) || (Number(possibleValue) < 0)) e.preventDefault();				
			}
		} else switch (char) {
			case 9:
			case 27: {
				const stockSpan = this;

				const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
				if (!offerId) {
					toastMessage('Błąd! Nie znaleziono numeru aukcji.');
					return;
				}

				let stockSpanFromStorage;
				try {
					stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
				} catch (error) {
					toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
					return;
				}

				if (stockSpan.innerText != stockSpanFromStorage[offerId].defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == '0' ? '-' : stockSpanFromStorage[offerId].defaultStock);				
				let relativeChange = this.closest('span[data-testid="stock"]').nextElementSibling;
				if (relativeChange !== null && relativeChange.id === 'fsmRelativeChange') relativeChange.remove();
				break;
			}
			case 13: {
				e.preventDefault();
				fsmConfirmButtonClick(e);
				break;
			}
		}		
	} else e.preventDefault();
}

async function fsmStockSpanKeyUp(e) {
	const char = e.which || e.keyCode;
	if (char == 8 || char == 46 || char == 38 || char == 40 || (char >=48 && char <=57) || (char >=96 && char <=105)) {
		let stockSpan = this;

		let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
		if (char == 38 && Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
		else if (char == 40 && Number(stockSpanValue) > 0)	stockSpan.innerText = Number(stockSpanValue) - 1;

		let relativeChange = stockSpan.closest('span[data-testid="stock"]').nextElementSibling;
		if (relativeChange === null || relativeChange.id !== 'fsmRelativeChange') {
			relativeChange = document.createElement('div');
			relativeChange.id = 'fsmRelativeChange';
			stockSpan.parentElement.parentElement.insertAdjacentElement('afterend', relativeChange);
		}	

		const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
		if (!offerId) {
			toastMessage('Błąd! Nie znaleziono numeru aukcji.');
			return;
		}

		let stockSpanFromStorage;
		try {
			stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		} catch (error) {
			toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
			return;
		}
			
		let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
		relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
		relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
	}
}

function fsmStockSpanPaste(e) {
	e.preventDefault();
}

async function fsmSubstractButtonClick(e) {
	const stockSpan = e.target.closest('td').querySelector('div[data-testid="placeholder"]').nextElementSibling;
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (Number(stockSpanValue) > 0) stockSpan.innerText = Number(stockSpanValue) - 1;
	
	let relativeChange = stockSpan.closest('span[data-testid="stock"]').nextElementSibling;
	if (relativeChange === null || relativeChange.id !== 'fsmRelativeChange') {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentElement.parentElement.insertAdjacentElement('afterend', relativeChange);
	}

	const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}	
		
	let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmAddButtonClick(e) {
	const stockSpan = e.target.closest('td').querySelector('div[data-testid="placeholder"]').nextElementSibling;
	let stockSpanValue = (stockSpan.innerText === '-' ? '0' : stockSpan.innerText);
	if (Number(stockSpanValue) < 9999) stockSpan.innerText = Number(stockSpanValue) + 1;
	
	let relativeChange = stockSpan.closest('span[data-testid="stock"]').nextElementSibling;
	if (relativeChange === null || relativeChange.id !== 'fsmRelativeChange') {
		relativeChange = document.createElement('div');
		relativeChange.id = 'fsmRelativeChange';
		stockSpan.parentElement.parentElement.insertAdjacentElement('afterend', relativeChange);
	}

	const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		return;
	}	
		
	let relativeChangeValue = (Number(stockSpanFromStorage[offerId].defaultStock) - Number(stockSpan.innerText)) * -1;
	relativeChange.style.transform = `translateX(${10 + (relativeChangeValue.toString().length * 8) - (relativeChangeValue < 0 ? 11 : 0)}px)`;
	relativeChange.innerText = (relativeChangeValue > 0 ? '+' + relativeChangeValue : (relativeChangeValue < 0 ? relativeChangeValue : ''));
}

async function fsmConfirmButtonClick(e) {
 	const parent = e.target.closest('td');
	const stockSpan = parent.querySelector('div[data-testid="placeholder"]').nextElementSibling;
	let response;
	let relativeChange = stockSpan.closest('span[data-testid="stock"]').nextElementSibling;
	if (relativeChange === null || relativeChange.id !== 'fsmRelativeChange') {
		parent.querySelectorAll('div[id^="fsm"]').forEach(node => {
			node.remove();
		});
		toastMessage('Nie ma nic do zmiany.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}

	let stockSpanInnerText = stockSpan.innerText.trim();
	if (stockSpanInnerText === '') {
		stockSpan.innerText = '0';
		stockSpanInnerText = '0';
	}

	let relativeChangeValue = Number(relativeChange.innerText);
	relativeChange.remove();
	let actionsContainer = parent.querySelector('#fsmActions');

	const offerId = stockSpan.closest('tr[data-cy]').dataset.cy;
	if (!offerId) {
		toastMessage('Błąd! Nie znaleziono numeru aukcji.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}

	let stockSpanFromStorage;
	try {
		stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać informacji o stanie magazynowym.');
		stockSpan.contentEditable = false;
		stockSpan.classList.remove('fsmStockSpanHover');
		return;
	}	

	if (actionsContainer !== null) {
		stockSpan.contentEditable = false;
		stockSpan.addEventListener('mouseenter', fsmAllowEditing);
		actionsContainer.remove();

		stockSpan.dataset.pendingchange = 'true';
	} 

	if (stockSpan.innerText === '0') toastMessage(`Kończenie aukcji ${offerId}`);
	else if (Number(stockSpan.innerText) - relativeChangeValue === 0) toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt. i wznawienie aukcji`);
	else toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt.`);

	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	const parameters = {
		environment: environment,
		accessToken: ''
	}
	
	try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
		if (stockSpanFromStorage[offerId]?.defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == 0 ? '-' : stockSpanFromStorage[offerId].defaultStock);
		delete stockSpan.dataset.pendingchange;
    return;
  }

	parameters.accessToken = response.result;

	async function confirmStockChange(parameters, offerId, relativeChangeValue, count = 5) {
		let fetchResponse, response, result;
		try {
			fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
				'method': 'GET',
				'headers': {
					'Authorization': `Bearer ${parameters.accessToken}`,
					'Content-Type': 'application/vnd.allegro.public.v1+json',
					'Accept': 'application/vnd.allegro.public.v1+json'
				}
			});
		} catch (error) {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się wprowadzenia zmiany w ofercie ${offerId} (etap odczytu danych). ${getErrorMessage(error)}`);
		}

		if (fetchResponse.status === 200) {
			try {
				result = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
			}

			if (result.stock.available !== undefined) {
				const stock = {
					'stock': {
						'available': (stockSpanInnerText === '0' ? 0 : Number(result.stock.available) + relativeChangeValue)
					}
				}
				if (stock.stock.available < 0) stock.stock.available = 0;
				else if (result.publication.status === 'ENDED') {
					stock.publication = {
						'status': 'ACTIVE'
					}
				}
				try {
					fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
						'method': 'PATCH',
						'headers': {
							'Authorization': `Bearer ${parameters.accessToken}`,
							'Content-Type': 'application/vnd.allegro.public.v1+json',
							'Accept': 'application/vnd.allegro.public.v1+json'
						},
						body: JSON.stringify(stock)
					});
				} catch (error) {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się wprowadzić zmiany w ofercie ${offerId} (etap zmiany danych). ${getErrorMessage(error)}`);
				}
				
				if (fetchResponse.status === 200) {
					if (stock.stock.available === 0) return Promise.resolve({ message: 'Zakończono!', stock: 0 });
					else if (stock?.publication?.status === 'ACTIVE') return Promise.resolve({ message: 'Zmieniono i wznowiono zakończoną aukcję!', stock: stock.stock.available });
					else return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
				} else if (fetchResponse.status === 202) {
					toastMessage('Trwa wprowadzanie zmian...');
					let responseStatusLocation = fetchResponse.headers.get('Location');
					if (responseStatusLocation) {
						try {
							response = await checkChangeStatus(parameters, responseStatusLocation, offerId);
							if (stock.stock.available === 0) return Promise.resolve({ message: 'Zakończono!', stock: stock.stock.available });
							else if (stock?.publication?.status === 'ACTIVE') return Promise.resolve({ message: 'Zmieniono i wznowiono zakończoną aukcję!', stock: stock.stock.available });
							else return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
						} catch (error) {
							return Promise.reject({ message: getErrorMessage(error), stock: stock.stock.available });
						}	
					} else {
						return Promise.reject({ message: `Nie udało się potwierdzić wprowadzenia zmiany w ofercie ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`, stock: stock.stock.available });
					}
				} else if (fetchResponse.status === 401) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						try {
							response = await sendMessage({ action: 'refreshAllegroAccessToken' });
							if (!response.success) throw new Error(response.result);
						} catch (error) {	
							return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
						}
						if (response.result === undefined) {
							return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
						}								
						parameters.accessToken = response.result;
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject('Nie udało się zmienić liczby przedmiotów. Nie udało się zalogować użytkownika.');
					}
				} else if (fetchResponse.status === 403) {
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				} else if (fetchResponse.status === 429) {
					if (--count) {
						toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas zmiany liczby przedmiotów w ofercie ${offerId}. Spróbuj ponownie później.`);
					}
				} else if (fetchResponse.status === 500) {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject(`Błąd serwera podczas zmiany liczby przedmiotów w ofercie ${offerId}, spróbuj ponownie później.`);
					}
				} else {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
					} else {
						return Promise.reject(`Nie udało się zmienić liczby przedmiotów w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
					}
				}
			}		
		} else if (fetchResponse.status === 401) {
			if (--count) {
				try {
					response = await sendMessage({ action: 'refreshAllegroAccessToken' });
					if (!response.success) throw new Error(response.result);
				} catch (error) {
					return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
				}
				if (response.result === undefined) {
					return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
				}
				parameters.accessToken = response.result;
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Nie udało się odświeżyć tokena dostępowego.`);
			}
		} else if (fetchResponse.status === 403) {
			return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
		} else if (fetchResponse.status === 429) {
			if (--count) {
				toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
				await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas zmiany liczby przedmiotów w ofercie ${offerId}. Spróbuj ponownie później.`);
			}
		} else if (fetchResponse.status === 500) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Błąd serwera podczas zmiany liczby przedmiotów w ofercie ${offerId}, spróbuj ponownie później.`);
			}
		} else {
			if (--count) {
				toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
			} else {
				return Promise.reject(`Nie udało się zmienić liczby przedmiotów w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			}
		}
	}

	let offer;
	let offerFromStorage;
	
	try {
		response = await confirmStockChange(parameters, offerId, relativeChangeValue);
		toastMessage(response.message);
		
		offerFromStorage = await readDataFromSessionStorage([`${offerId}`]);
		offer = {
			defaultStock: response.stock
		}
		await saveDataToSessionStorage({
			[`${offerId}`]: Object.assign(offerFromStorage[`${offerId}`] ?? {}, offer)
		});
		
		const stockSpan = document.querySelector(`tr[data-cy="${offerId}"] span[data-testid="stock"] div[data-testid="placeholder"]`)?.nextElementSibling;
		if (stockSpan) {
			stockSpan.classList.remove('fsmStockSpanHover');
			stockSpan.classList.add('fsmUpdatedValue');
			stockSpan.innerText = response.stock;
		}
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
		try {
			const stockSpanFromStorage = await readDataFromSessionStorage([`${offerId}`]);
			const stockSpan = document.querySelector(`tr[data-cy="${offerId}"] span[data-testid="stock"] div[data-testid="placeholder"]`)?.nextElementSibling;
			if (stockSpan) {
				stockSpan.classList.remove('fsmStockSpanHover');
				if (stockSpanFromStorage[offerId]?.defaultStock) stockSpan.innerText = (stockSpanFromStorage[offerId].defaultStock == 0 ? '-' : stockSpanFromStorage[offerId].defaultStock);
			}
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}
	} finally {
		if (stockSpan) {
			stockSpan.contentEditable = false;
			delete stockSpan.dataset.pendingchange;
		}
	}

	try {
		let readedValue = await readDataFromLocalStorage(['extensions', 'erliFastStockManagerCheckbox']);
		if (readedValue.extensions['erliActions'] && readedValue['erliFastStockManagerCheckbox']) {
			if (response?.stock || response?.stock === 0) {
				response = await synchronizeStockOnErli(offerId, response.stock);
				if (response.success) {
					toastMessage(`Zsynchronizowano stan magazynowy w Erli.`);
				} else {
					toastMessage(`Błąd synchronizacji stanu magazynowego w Erli. ${response.result}`);
				}
			} else {
				response = await synchronizeStockOnErli(offerId, relativeChangeValue, true);
				if (response.success) {
					toastMessage(`Zmieniono stan magazynowy w Erli.`);
				} else {
					toastMessage(`Błąd zmiany stanu magazynowego w Erli. ${response.result}`);
				}
			}
			
		}
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
	
}

async function synchronizeStockOnErli(offerId, stock, relative = false) {
	const sandbox =  (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
	try {
    readedValue = await readDataFromLocalStorage(['erliToken', 'erliTokenSandbox', 'erliAlwaysSyncToSandbox']);
    if (readedValue['erliToken'] === undefined) {
      toastMessage('Nie znaleziono tokena Erli.');
      return;
    }
    if (readedValue['erliTokenSandbox'] === undefined) {
      toastMessage('Nie znaleziono tokena Erli (Sandbox).');
      return;
    }
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    return;
  }
  let erliToken;
  let erliEnvironment;
  if (readedValue['erliAlwaysSyncToSandbox'] === true) {
    erliEnvironment = 'sandbox.erli.dev';
    erliToken = readedValue['erliTokenSandbox'];
  } else { 
    if (sandbox === 'Sandbox') {
      erliEnvironment = 'sandbox.erli.dev';
      erliToken = readedValue['erliTokenSandbox'];
    } else {
      erliEnvironment = 'erli.pl';
      erliToken = readedValue['erliToken'];
    }
  }
	let response;
	const erliOfferData = {
		stock: stock,
		status: (stock > 0 ? 'active' : 'inactive')
	}
	try {
		response = await fsmUpdateStockOnErli(erliEnvironment, erliToken, offerId, erliOfferData, 5, relative);
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
		return Promise.reject({ success: false, result: getErrorMessage(error) });
	}

	if (response.frozen) {
		 const frozenFieldsNames = {
			'stock': 'stan magazynowy',
			'status': 'status'
		};
		return Promise.resolve({ success: false, result: `Aukcja ${offerId} w Erli ma zablokowane do edycji pola: ` + response.frozen.map((field => frozenFieldsNames[field])).join(', ') });
	}
	return Promise.resolve({ success: true });
}

async function fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, relative) {
  let fetchResponse;
  let frozenFields = [];
  let result;

  try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, relative);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200) {
    try {
      result = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    frozenFields = Object.entries(result.frozen).filter(field => field[1] === true && ['price', 'stock', 'status'].indexOf(field[0]) !== -1).map(element => element[0]);
		if (relative) {
			offerData.stock = result.stock + offerData.stock;
		}
  } else if (fetchResponse.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Erli. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, relative);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Erli podczas zmiany stanu magazynowego aukcji ${offerId} w Erli. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, relative);
		} else {
			return Promise.reject(`Błąd serwera podczas zmiany stanu magazynowego aukcji ${offerId} w Erli, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, relative);
    } else {
      return Promise.reject(`Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
  }

  try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'PATCH',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, false);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200 || fetchResponse.status === 202) {
    if (frozenFields?.length) return Promise.resolve({ result: offerId, frozen: frozenFields });
    else return Promise.resolve({ result: offerId });
  } else if (fetchResponse.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Przekroczono limit zapytań, ponawianie próby wysyłania żądania po chwili przerwy (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, false);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Erli podczas zmiany stanu magazynowego aukcji ${offerId} w Erli. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, false);
		} else {
			return Promise.reject(`Błąd serwera podczas zmiany stanu magazynowego aukcji ${offerId} w Erli, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fsmUpdateStockOnErli(environment, accessToken, offerId, offerData, count, false);      
    } else {
      return Promise.reject(`Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
  }
}

async function checkChangeStatus(parameters, responseStatusLocation, offerId, count = 10) {
	let fetchResponse;
	try {
		fetchResponse = await backgroundFetch(responseStatusLocation , {
		'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się potwierdzić wprowadzenia zmiany w aukcji ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`);
	}
	if (fetchResponse.status === 202) {
		if (--count) {
			toastMessage(`Sprawdzanie statusu wykonanej zmiany (${10 - count} z 10), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (10 - count) * (10 - count) * 1000));
			return await checkChangeStatus(parameters, responseStatusLocation, offerId, count);
		} else {
			return Promise.reject(`Nie udało się potwierdzić wprowadzenia zmiany w aukcji ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`);
		}
	}	else if (fetchResponse.status === 200) {
		return Promise.resolve('Zmieniono!');
	}
}