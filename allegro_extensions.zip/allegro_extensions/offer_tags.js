async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
  return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;

	switch (action) {
    case 'offerTags': {
			if (document.body.dataset.offerTagsChangeInProgress) return Promise.resolve(true);
			toastMessage('Przełączanie widoczności tagów ofertowych...');
			document.body.dataset.offerTagsChangeInProgress = true;
			if (document.body.dataset.offerTagsHidden === 'true') document.body.dataset.offerTagsHidden = 'false'; else document.body.dataset.offerTagsHidden = 'true';
      document.querySelectorAll('div[data-tags]').forEach(element => {
        document.body.dataset.offerTagsHidden === 'true' ? element.classList.add('hidden') : element.classList.remove('hidden');
      });
			const offersTable = document.querySelector('table[aria-label="lista ofert"]');
			const spanElement = document.createElement('span');
			spanElement.id = 'offerTagsMutationObserverTriggeerElement';
			offersTable.appendChild(spanElement);
      await new Promise(resolve => setTimeout(resolve, 1000));
      delete document.body.dataset.offerTagsChangeInProgress;
      break;
    }
  }
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt offerTags');
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsDefaultHidden']);
		document.body.dataset.offerTagsHidden = readedValue.offerTagsDefaultHidden;
		await offerTagsAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
});

async function offerTagsAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	const offers = {};
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await offerTagsAwaitOffersTable();
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await offerTagsAwaitOffersTable();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await offerTagsPrepare(parameters, offers);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function offerTagsPrepare(parameters, offers) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	parameters.environment = environment;

	const observer = new MutationObserver(async (mutations) => {
		for (const mutation of mutations) {
			if (mutation.type === 'childList') {
				if (Array.from(mutation.addedNodes).filter(element => (element.nodeName === 'SPAN' && element.id === 'offerTagsMutationObserverTriggeerElement') || (element.nodeName === 'TR' && element.dataset.cy !== undefined))?.length) {
					observer.takeRecords();
					observer.disconnect();
					if (parameters.offersTable.querySelector('span#offerTagsMutationObserverTriggeerElement') !== null) {
						parameters.offersTable.querySelector('span#offerTagsMutationObserverTriggeerElement').remove();
					}
					await new Promise(resolve => setTimeout(resolve, 100));
					try {
						await offerTagsPrepare(parameters, offers);
					} catch (error) {
						return Promise.reject(error?.message ? error.message : error);
					}
					return;
				}
			}
		}
	});
	observer.observe(parameters.offersTable, { subtree: true, childList: true });

	if (document.body.dataset?.offerTagsHidden === 'true') return;

	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${error?.message ? error.message : error}`);
	}

  let accessToken = response.result; 
	parameters.accessToken = accessToken;
	let offersList = [];
	if (document.body.dataset?.offerTagsHidden === 'false') offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.querySelector(`div[data-tags="${element.dataset.cy}"]`) === null);

	if (!offersList.length) {	// brak ofert na liście w tabeli, zaczekaj na pojawienie się ich
		return;
	}

  let offersToGet = [];
	for (const offer of offersList) {
		offersToGet.push(offer.dataset.cy);
	}

	await new Promise(resolve => setTimeout(resolve, 100));
	try {
		await getTags(parameters, offers, offersToGet);
	} catch (error) {
		return Promise.reject(error?.message ? error.message : error);
	}
}

async function getTags(parameters, offers, offersToGet) {
  const offerTagsHidden = document.body.dataset.offerTagsHidden === 'true' ? true : false;
	if (offerTagsHidden) return;
	
	async function getOffers(offersToGet) {
		for (const offerId of offersToGet) {
			const offerElement = document.querySelector(`tr[data-cy="${offerId}"]`);
			if (offerElement === null) continue;
			
			if (offers[offerId] !== undefined) {
				if (offers[offerId] !== null) {	// produkt jest już w pamięci podręcznej i został pobrany
					if (parameters.offersTable.querySelector(`div[data-tags="${offerId}"]`) === null) {
						let tagsDiv;
            
						tagsDiv = `<div data-tags="${offerId}"${offerTagsHidden ? ' class="hidden"' : ''}>`;
            for (const tag of offers[offerId]) {
              tagsDiv += `<div class="offerTag${tag.hidden ? ' hidden' : ''}">${tag.name}</div>`;
            }
            tagsDiv += `</div>`;
						if (document.body.dataset.offerTagsHidden === 'true') return
						if (offerElement.firstElementChild.firstElementChild.children[2].querySelector(`div[data-tags="${offerId}"]`) === null) offerElement.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
          }
        }
			} else {
				try {
					await getTag(3, offerElement, offerId, parameters, offers, offerTagsHidden);
				} catch (error) {
          if (error === 'Użytkownik nie posiada abonamentu oferującego funkcjonalność tagów ofertowych.') {
            return Promise.reject(error);
          }
					toastMessage(`Błąd! Podczas pobierania tagów wystąpił błąd. ${error?.message ? error.message : error}`);
				}
			}
		}
    return Promise.resolve(true);
	}

	try {
    await getOffers(offersToGet);
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
  }
	
	await new Promise(resolve => setTimeout(resolve, 1000));
	const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.querySelector(`div[data-tags="${element.dataset.cy}"]`) === null);
	if (offersList.length) {
		const offersToGet = [];
		for (const offer of offersList) {				
			offersToGet.push(offer.dataset.cy);
		}
		await new Promise(resolve => setTimeout(resolve, 1000));
		getTags(parameters, offers, offersToGet);
	}
}

async function getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden) {
	if (document.body.dataset.offerTagsHidden === 'true') return
	
	let response;
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/tags`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden)
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

  if (response.status === 200) {
    let offerTags;
    try {
      offerTags = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }

    if (offerTags.tags.length === 0) {
      offers[offerId] = null;
    } else {
      for (const tag of offerTags.tags) {
				if (offers[offerId] === undefined) {
					offers[offerId] = [];
				}
        offers[offerId].push({
          id: tag.id,
          name: tag.name,
          hidden: tag.hidden
        });
      };
    }
    if (parameters.offersTable.querySelector(`div[data-tags="${offerId}"]`) === null) {
      let tagsDiv;     
      tagsDiv = `<div data-tags="${offerId}"${offerTagsHidden ? ' class="hidden"' : ''}>`;
      for (const tag of offerTags.tags) {
        tagsDiv += `<div class="offerTag${tag.hidden ? ' hidden' : ''}">${tag.name}</div>`;
      }
      tagsDiv += `</div>`;
			if (document.body.dataset.offerTagsHidden === 'true') return
      if (offerElement.firstElementChild.firstElementChild.children[2].querySelector(`div[data-tags="${offerId}"]`) === null) offerElement.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
    }  
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken' });
      } catch (error) {
        return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden);
    } else if (response.status === 429) {
      console.log('zbyt duża liczba żądań');
      if (--count) {
        toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
        await new Promise(resolve => setTimeout(resolve, 65000));
        return await getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden);
      } else {
        return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
      }
    } else {
      return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
    }
  } else if (response.status === 403) {
    return Promise.reject(`Użytkownik nie posiada abonamentu oferującego funkcjonalność tagów ofertowych.`);
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden)
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getTag(count, offerElement, offerId, parameters, offers, offerTagsHidden)
    } else {
      return Promise.reject('Błąd serwera, spróbuj ponownie później.');
    }
  } else {
		return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
	}
  return Promise.resolve(true);
}