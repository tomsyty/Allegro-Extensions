async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallbackOfferTags(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
  return true;
});

async function asyncOnMessageCallbackOfferTags(request, sender) {
	const action = request.action;

	switch (action) {
    case 'offerTags': {
			if (document.body.dataset.offerTagsChangeInProgress) return Promise.resolve(true);
			toastMessage('Przełączanie widoczności tagów ofertowych...');
			document.body.dataset.offerTagsChangeInProgress = true;
			if (document.body.dataset.offerTagsHidden === 'true') document.body.dataset.offerTagsHidden = 'false'; else document.body.dataset.offerTagsHidden = 'true';
      document.querySelectorAll('div.offerTags').forEach(element => {
        document.body.dataset.offerTagsHidden === 'true' ? element.classList.add('hidden') : element.classList.remove('hidden');
      });
			const offersTable = document.querySelector('table[aria-label="lista ofert"]');
			const spanElement = document.createElement('span');
			spanElement.id = 'offerTagsMutationObserverTriggeerElement';
			offersTable.appendChild(spanElement);
      await new Promise(resolve => setTimeout(resolve, 1000));
      delete document.body.dataset.offerTagsChangeInProgress;
      break;
    }
  }
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt offerTags');
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsDefaultHidden', 'offerTagsSearchMode']);
		document.body.dataset.offerTagsSearchMode = readedValue.offerTagsSearchMode;
		document.body.dataset.offerTagsHidden = readedValue.offerTagsDefaultHidden;
		await otAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

async function otAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await otAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await otAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await otObserveOffersTable(parameters);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function otObserveOffersTable(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
	}

	let accessToken = response.result; 
	parameters.accessToken = accessToken;
	parameters.environment = environment;

	let offerTags = [];

	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	let offersList = [];
	const mutationObserver = new MutationObserver(mutationCallback);

	async function mutationCallback(mutations, mo) {
		const offerTagsHidden = (document.body.dataset.offerTagsHidden === 'true' ? true : false); 
		const offerTagsSearchMode = document.body.dataset.offerTagsSearchMode; 
		for (const mutation of mutations) {
			if (mutation.type === 'attributes') {
				if (mutation.attributeName === 'data-cy') {
					const offerRow = mutation.target;
					const offerId = offerRow.dataset.cy;
					if (offerTags[offerId]) {
						const tags = offerTags[offerId];
						let tagsDiv;     
						tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
						for (let i = 0; i < tags.length; i++) {
							tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}" data-tagid="${tags[i].id}">${tags[i].name}</div>`;
						}	
						tagsDiv += `</div>`;
						const currentlyAssignedTags = offerRow.querySelector('div.offerTags');
						if (currentlyAssignedTags !== null) {
							currentlyAssignedTags.remove();
						}
						offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);	
						const insertedTag = offerRow.firstElementChild.firstElementChild.children[2].lastElementChild;
						if (offerTagsSearchMode === '1' || offerTagsSearchMode === '2') {
							insertedTag.addEventListener('click', otTagClick);
							if (offerTagsSearchMode === '2') {
								insertedTag.addEventListener('longClick', otTagLongClick);
								insertedTag.addEventListener('mousedown', (e) => {
									e.target.dataset.clickTimer = setTimeout(() => {
										delete e.target?.dataset?.clickTimer;
										const longClickEvent = new CustomEvent('longClick');
										insertedTag.dispatchEvent(longClickEvent);
									}, 1000);
								});
								insertedTag.addEventListener('mouseup', (e) => {
									const clickTimer = e.target?.dataset?.clickTimer;
									if (clickTimer) {
										clearTimeout(clickTimer);
										delete e.target?.dataset?.clickTimer;
									}
								});
							}
						}				
					} else {
						let tags;
						try {
							tags = await getOfferTags(3, offerId, parameters);
							offerTags[offerId] = tags;
							let tagsDiv;     
							tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
							if (tags !== null) {
								for (let i = 0; i < tags.length; i++) {
									tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}" data-tagid="${tags[i].id}">${tags[i].name}</div>`;
								}	
							}
							tagsDiv += `</div>`;
							const currentlyAssignedTags = offerRow.querySelector('div.offerTags');
							if (currentlyAssignedTags !== null) {
								currentlyAssignedTags.remove();
							}
							offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
							const insertedTag = offerRow.firstElementChild.firstElementChild.children[2].lastElementChild;
							if (offerTagsSearchMode === '1' || offerTagsSearchMode === '2') {
								insertedTag.addEventListener('click', otTagClick);
								if (offerTagsSearchMode === '2') {
									insertedTag.addEventListener('longClick', otTagLongClick);
									insertedTag.addEventListener('mousedown', (e) => {
										e.target.dataset.clickTimer = setTimeout(() => {
											delete e.target?.dataset?.clickTimer;
											const longClickEvent = new CustomEvent('longClick');
											insertedTag.dispatchEvent(longClickEvent);
										}, 1000);
									});
									insertedTag.addEventListener('mouseup', (e) => {
										const clickTimer = e.target?.dataset?.clickTimer;
										if (clickTimer) {
											clearTimeout(clickTimer);
											delete e.target?.dataset?.clickTimer;
										}
									});
								}
							}
						} catch (error) {
							toastMessage(`Błąd! Podczas pobierania tagów ofertowych dla aukcji ${offerId} wystąpił błąd. ${getErrorMessage(error)}`);
						}
					}
				}
			}
		}
	}

	const intersectionObserver = new IntersectionObserver(intersectionCallback, options);

	async function intersectionCallback(entries, io) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.ot = false;
        });

        try {
          await otProcessOffersList(parameters, offersList, offerTags);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
      }
    });
		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(offerRow => {
			intersectionObserver.observe(offerRow);
			mutationObserver.observe(offerRow, {
				attributeFilter: ['data-cy']
			});
		});
  }

	do {
		offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
		const offersListLength = offersList.length;
		await new Promise(resolve => setTimeout(resolve, 2000));
		offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
		if (offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
		else break;
	} while (1);
	
	offersList.forEach(offerRow => {
    offerRow.dataset.ot = false;
    intersectionObserver.observe(offerRow);
		mutationObserver.observe(offerRow, {
			attributeFilter: ['data-cy']
		});
  });

	try {
		await otProcessOffersList(parameters, offersList, offerTags);
	} catch (error) {
		return Promise.reject(getErrorMessage(error));
	}
}

async function otProcessOffersList(parameters, offersList, offerTags) {
	const offerTagsHidden = (document.body.dataset.offerTagsHidden === 'true' ? true : false); 
	const offerTagsSearchMode = document.body.dataset.offerTagsSearchMode; 
	let offerRow = offersList.shift();
	if (offerRow === undefined) return;
	if (!offerRow.isConnected) return await otProcessOffersList(parameters, offersList, offerTags);
	offerRow.dataset.ot = true;
	const offerId = offerRow.dataset.cy;
	let insertedTag;
	if (offerTags[offerId]) {	
		if (offerRow.querySelector('div.offerTags') !== null) return;
		const tags = offerTags[offerId];
		let tagsDiv;     
		tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
		for (let i = 0; i < tags.length; i++) {
			tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}" data-tagid="${tags[i].id}">${tags[i].name}</div>`;
		}	
		tagsDiv += `</div>`;
		const currentlyAssignedTags = offerRow.querySelector('div.offerTags');
		if (currentlyAssignedTags !== null) {
			currentlyAssignedTags.remove();
		}
		offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
	} else {
		if (offerRow.querySelector('div.offerTags') !== null) return;
		let tags;
		try {
			tags = await getOfferTags(3, offerId, parameters);
			offerTags[offerId] = tags;
			let tagsDiv;     
      tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
			if (tags !== null) {
				for (let i = 0; i < tags.length; i++) {
					tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}" data-tagid="${tags[i].id}">${tags[i].name}</div>`;
				}	
			}
      tagsDiv += `</div>`;
			const currentlyAssignedTags = offerRow.querySelector('div.offerTags');
			if (currentlyAssignedTags !== null) {
				currentlyAssignedTags.remove();
			}
      offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
			insertedTag = offerRow.firstElementChild.firstElementChild.children[2].lastElementChild;
			if (offerTagsSearchMode === '1' || offerTagsSearchMode === '2') {
				insertedTag.addEventListener('click', otTagClick);
				if (offerTagsSearchMode === '2') {
					insertedTag.addEventListener('longClick', otTagLongClick);
					insertedTag.addEventListener('mousedown', (e) => {
						e.target.dataset.clickTimer = setTimeout(() => {
							delete e.target?.dataset?.clickTimer;
							const longClickEvent = new CustomEvent('longClick');
							insertedTag.dispatchEvent(longClickEvent);
						}, 1000);
					});
					insertedTag.addEventListener('mouseup', (e) => {
						const clickTimer = e.target?.dataset?.clickTimer;
						if (clickTimer) {
							clearTimeout(clickTimer);
							delete e.target?.dataset?.clickTimer;
						}
					});
				}
			}
    } catch (error) {
			toastMessage(`Błąd! Podczas pobierania tagów ofertowych dla aukcji ${offerId} wystąpił błąd. ${getErrorMessage(error)}`);
		}
	}
	return await otProcessOffersList(parameters, offersList, offerTags);
}

async function otTagClick(e) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	const offerTagsSearchMode = document.body.dataset.offerTagsSearchMode;

	if (offerTagsSearchMode === '0') return;
	if (offerTagsSearchMode === '1') {
		let tagsProgress = document.getElementById('tagsProgress');
		if (tagsProgress === null) {
			let insertionPoint;
			try {
				insertionPoint = document.getElementById('portal-container').nextElementSibling.firstElementChild;
				if (!insertionPoint) throw new Error('wait');
			} catch (error) {
				await new Promise(resolve => setTimeout(resolve, 100));
			}
			
			insertionPoint.insertAdjacentHTML('afterend', `<div id="tagsProgressBox" class="row"><div class="col-auto d-flex align-items-center"><span>Szukanie taga</span></div><div class="col-auto d-flex align-items-center"><span id="otCancelProgress" class="material-symbols-outlined fs16">close</span></div><div class="col-auto d-flex flex-grow-1"><progress id="tagsProgress" max="0" value="0">0%</progress></div></div>`);
			tagsProgress = document.getElementById('tagsProgress');
			let cancelProgress = document.getElementById('otCancelProgress');
			cancelProgress.addEventListener('click', (e) => {
				e.target.disabled = true;
				const progress = document.getElementById('tagsProgress');
				progress.value = progress.max;
			});
		} else {
			toastMessage('Trwa wyszukiwanie taga, poczekaj na jego zakończenie zanim rozpoczniesz nowe'); 
			return;
		}
		
		let response;
		try {
			response = await sendMessage({ action: 'getAllegroAccessToken' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			return Promise.reject(false);
		}

		let parameters = {
			accessToken: response.result,
			environment: environment,
			tagId: e.target.dataset.tagid,
			tagsProgress: tagsProgress,
			offers: [],
			offerTagsSearchMode: offerTagsSearchMode
		}

		let offersCount = 0;
		try {
			offersCount = await otGetOffersCount(parameters, 5);
			parameters.tagsProgress.max = offersCount;
			await otProcessOffers(parameters);
			
			const searchInput = document.getElementById('search-filter');
			let offersListJoined = parameters.offers.join(' ');
			if (offersListJoined.length <= 3000) {
				searchInput.value = offersListJoined;
				searchInput.dispatchEvent(new Event('input'));
			} else {					
				const resultPages = [];
				let index = 0;
				do {
					if (parameters.offers[index]) {
						if ((offersListJoined + (offersListJoined.length === 0 ? '' : ' ') + parameters.offers[index]).length <= 3000) {
							offersListJoined = offersListJoined + (offersListJoined.length === 0 ? '' : ' ') +  parameters.offers[index];
							index++;
						} else {
							resultPages.push(offersListJoined);
							offersListJoined = '';
						}
					} else {
						if (offersListJoined.length) resultPages.push(offersListJoined);
						break;	
					}
				} while (true);

				let insertionPoint;
				try {
					insertionPoint = document.getElementById('portal-container').nextElementSibling.firstElementChild;
					if (!insertionPoint) throw new Error('wait');
				} catch (error) {
					await new Promise(resolve => setTimeout(resolve, 100));
				}

				outputWindow = document.getElementById('resultPagesWindow');
				if (outputWindow !== null) outputWindow.innerHTML = '';
				else {
					outputWindow = document.createElement('div');
					outputWindow.id = 'resultPagesWindow';
					insertionPoint.insertAdjacentElement('afterend', outputWindow);
				}

				outputWindow.innerHTML = /*html*/ `
					<div class="otRow">
						<span id="otCloseContainer" class="material-symbols-outlined fs28">close</span>
					</div>
					<div class="otRow">
						<table id="offerTagsResultPagesTable">
							<thead>
								<tr>
									<th>Pozycje</th>
									<th></th>
									<th>Lista aukcji</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				`;
				
				const table = document.getElementById('offerTagsResultPagesTable');
				let rows = Array.from(table.rows).slice(1);
				for (let i = rows.length; i > 0; i--) {
					table.deleteRow(-1);
				}

				let itemsCount = 0;
				resultPages.forEach(resultPage => { 
					let newRow = table.insertRow(-1);
					let newCell = newRow.insertCell(0);
					
					const pageItems = resultPage.split(' ').length;
					const startNum = itemsCount + 1;
					const endNum = itemsCount + pageItems;
					itemsCount += pageItems;
					
					let newText = document.createTextNode(`${startNum}-${endNum}`);
					let newNode;
					newCell.appendChild(newText);

					newCell = newRow.insertCell(1);
					newNode = document.createElement('span');
					newNode.innerText = 'wybierz';
					newNode.style.cursor = 'pointer';
					newNode.addEventListener('click', resultPageSelectButtonClick);
					newCell.appendChild(newNode);

					newCell = newRow.insertCell(2);
					newText = document.createTextNode(resultPage);
					newCell.appendChild(newText);
				});

				function updateTableColumnWidth() {
					const resultPagesWindow = document.getElementById('resultPagesWindow');
					const table = document.getElementById('offerTagsResultPagesTable');
					
					if (resultPagesWindow && table) {
						const containerWidth = resultPagesWindow.clientWidth - 32;
						const col1Width = 50;
						const col2Width = 60;
						const availableWidth = Math.max(500, containerWidth - col1Width - col2Width);
						
						const cells = document.querySelectorAll('#offerTagsResultPagesTable td:nth-of-type(3), #offerTagsResultPagesTable th:nth-of-type(3)');
						cells.forEach(cell => {
							cell.style.maxWidth = availableWidth + 'px';
						});
					}
				}

				updateTableColumnWidth();

				const resizeListener = () => updateTableColumnWidth();
				window.addEventListener('resize', resizeListener);

				document.getElementById('otCloseContainer').addEventListener('click', () => {
					window.removeEventListener('resize', resizeListener);
					document.getElementById('resultPagesWindow').remove();
				});						
			}
			document.getElementById('tagsProgressBox').remove();
			
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}
	} else if (offerTagsSearchMode === '2') {
		let response;

		try {
			response = await sendMessage({ action: 'offerTagsSearch', tagId: e.target.dataset.tagid });
			if (response.success && response.result.length) {
				const searchInput = document.getElementById('search-filter');
				let offersListJoined = response.result.join(' ');
				if (offersListJoined.length <= 3000) {
					searchInput.value = offersListJoined;
					searchInput.dispatchEvent(new Event('input'));
				} else {
					const resultPages = [];
					let offersListJoined = '';
					let index = 0;
					do {
						if (response.result[index]) {
							if ((offersListJoined + (offersListJoined.length === 0 ? '' : ' ') + response.result[index]).length <= 3000) {
								offersListJoined = offersListJoined + (offersListJoined.length === 0 ? '' : ' ') +  response.result[index];
								index++;
							} else {
								resultPages.push(offersListJoined);
								offersListJoined = '';
							}
						} else {
							if (offersListJoined.length) resultPages.push(offersListJoined);
							break;	
						}
					} while (true);

					let insertionPoint;
					try {
						insertionPoint = document.getElementById('portal-container').nextElementSibling.firstElementChild;
						if (!insertionPoint) throw new Error('wait');
					} catch (error) {
						await new Promise(resolve => setTimeout(resolve, 100));
					}

					outputWindow = document.getElementById('resultPagesWindow');
  				if (outputWindow !== null) outputWindow.innerHTML = '';
					else {
						outputWindow = document.createElement('div');
						outputWindow.id = 'resultPagesWindow';
						insertionPoint.insertAdjacentElement('afterend', outputWindow);
					}

					outputWindow.innerHTML = /*html*/ `
						<div class="otRow">
							<span id="otCloseContainer" class="material-symbols-outlined fs28">close</span>
						</div>
						<div class="otRow">
							<table id="offerTagsResultPagesTable">
								<thead>
									<tr>
										<th>Pozycje</th>
										<th></th>
										<th>Lista aukcji</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					`;
					
					const table = document.getElementById('offerTagsResultPagesTable');
					let rows = Array.from(table.rows).slice(1);
					for (let i = rows.length; i > 0; i--) {
						table.deleteRow(-1);
					}

					let itemsCount = 0;
					resultPages.forEach(resultPage => { 
						let newRow = table.insertRow(-1);
  					let newCell = newRow.insertCell(0);
						
						const pageItems = resultPage.split(' ').length;
						const startNum = itemsCount + 1;
						const endNum = itemsCount + pageItems;
						itemsCount += pageItems;
						
						let newText = document.createTextNode(`${startNum}-${endNum}`);
						let newNode;
  					newCell.appendChild(newText);

						newCell = newRow.insertCell(1);
						newNode = document.createElement('span');
						newNode.innerText = 'wybierz';
						newNode.style.cursor = 'pointer';
						newNode.addEventListener('click', resultPageSelectButtonClick);
						newCell.appendChild(newNode);

						newCell = newRow.insertCell(2);
						newText = document.createTextNode(resultPage);
						newCell.appendChild(newText);
					});

					function updateTableColumnWidth() {
						const resultPagesWindow = document.getElementById('resultPagesWindow');
						const table = document.getElementById('offerTagsResultPagesTable');
						
						if (resultPagesWindow && table) {
							const containerWidth = resultPagesWindow.clientWidth - 32;
							const col1Width = 50;
							const col2Width = 60;
							const availableWidth = Math.max(500, containerWidth - col1Width - col2Width);
							
							const cells = document.querySelectorAll('#offerTagsResultPagesTable td:nth-of-type(3), #offerTagsResultPagesTable th:nth-of-type(3)');
							cells.forEach(cell => {
								cell.style.maxWidth = availableWidth + 'px';
							});
						}
					}

					updateTableColumnWidth();

					const resizeListener = () => updateTableColumnWidth();
					window.addEventListener('resize', resizeListener);

					document.getElementById('otCloseContainer').addEventListener('click', () => {
						window.removeEventListener('resize', resizeListener);
						document.getElementById('resultPagesWindow').remove();
					});
					
				}
			}
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}
	}
}

function updateTableColumnWidth() {
	const resultPagesWindow = document.getElementById('resultPagesWindow');
	const table = document.getElementById('offerTagsResultPagesTable');
	
	if (resultPagesWindow && table) {
		const containerWidth = resultPagesWindow.clientWidth - 32;
		const col1Width = 50;
		const col2Width = 60;
		const availableWidth = Math.max(500, containerWidth - col1Width - col2Width);
		
		const cells = document.querySelectorAll('#offerTagsResultPagesTable td:nth-of-type(3), #offerTagsResultPagesTable th:nth-of-type(3)');
		cells.forEach(cell => {
			cell.style.maxWidth = availableWidth + 'px';
		});
	}
}

function resultPageSelectButtonClick(e) {
	e.target.style.color = 'purple';
	let textToCopy = e.target.parentElement.nextElementSibling;
	const searchInput = document.getElementById('search-filter');
	searchInput.value = textToCopy.innerText;;
	searchInput.dispatchEvent(new Event('input'));
}

async function otTagLongClick(e) {
	const offerTagsSearchMode = document.body.dataset.offerTagsSearchMode;
	if (offerTagsSearchMode !== '2') return;

	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'offerTagsRemoveBase' });
	} catch (error) {
		toastMessage('Błąd! Podczas usuwania poprzedniej bazy danych wystąpił błąd.');
		return;
	}

	let tagsProgress = document.getElementById('tagsProgress');
	if (tagsProgress === null) {
		let insertionPoint;
		try {
			insertionPoint = document.getElementById('portal-container').nextElementSibling.firstElementChild;
			if (!insertionPoint) throw new Error('wait');
		} catch (error) {
			await new Promise(resolve => setTimeout(resolve, 100));
		}
		insertionPoint.insertAdjacentHTML('afterend', `<div id="tagsProgressBox" class="row"><div class="col-auto d-flex align-items-center"><span>Indeksowanie aukcji</span></div><div class="col-auto d-flex align-items-center"><span id="otCancelProgress" class="material-symbols-outlined fs16">close</span></div><div class="col-auto d-flex flex-grow-1"><progress id="tagsProgress" max="0" value="0">0%</progress></div></div>`);
		tagsProgress = document.getElementById('tagsProgress');
		let cancelProgress = document.getElementById('otCancelProgress');
		cancelProgress.addEventListener('click', (e) => {
			e.target.disabled = true;
			const progress = document.getElementById('tagsProgress');
			progress.value = progress.max;
		});
	} else {
		toastMessage('Trwa indeksowanie aukcji, poczekaj na jego zakończenie zanim rozpoczniesz nowe'); 
		return;
	}

	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	if (response.result === undefined) {
		toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
		return Promise.reject(false);
	}

	let parameters = {
		accessToken: response.result,
		environment: environment,
		tagId: e.target.dataset.tagid,
		offers: [],
		tagsProgress: tagsProgress
	}

	let offersCount = 0;
	try {
		offersCount = await otGetOffersCount(parameters, 5);
		parameters.tagsProgress.max = offersCount;
		await otProcessOffers(parameters);
		toastMessage('Zakończono indeksowanie aukcji.');	
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}

	document.getElementById('tagsProgressBox').remove();

}

async function otGetOffersCount(parameters, count) {
	let result, response, fetchResponse, offersCount;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1&publication.status=ACTIVE&publication.status=ENDED`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await otGetOffersCount(parameters, count);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać liczby aukcji.`);
		}
	}
	if (fetchResponse.status === 200) {
		try {
			result = await fetchResponse.json();
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}
		offersCount = result.totalCount;
		return Promise.resolve(offersCount);
	} else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			if (response.result === undefined) {
				return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			}
			parameters.accessToken = response.result;
			return await otGetOffersCount(parameters, count);  
		} else {
			return Promise.reject('Nie udało się zalogować użytkownika.');
		}		
	} else if (fetchResponse.status === 403) {
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await otGetOffersCount(parameters, count);
		} else {
			return Promise.reject(`Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}											
	}	
}	

async	function otProcessOffers(parameters) {
	try {
		await otGetOffers(parameters);
		parameters.tagsProgress.value = parameters.tagsProgress.max;
		return;
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
}

async function otGetOffers(parameters, offset = 0, count = 5) {
	let fetchResponse, result;
	if (offset > parameters.tagsProgress.max || parameters.tagsProgress.value === parameters.tagsProgress.max) {
		return;
	}
	parameters.tagsProgress.value = offset;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=20&publication.status=ACTIVE&publication.status=ENDED`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await otGetOffers(parameters, offset, count);
		} else {
			return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aukcji.');
		}
	}
	if (fetchResponse.status === 200) {
		try {
			result = await fetchResponse.json();
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}
					
		let offersList = [];
		result.offers.forEach(offer => {
			offersList.push(offer.id);
		});

		if (result.offers.length) {
			do {
				const offerId = offersList.shift();
				if (offerId === undefined) {
					if (result.totalCount > (offset + 20)) {
						await new Promise(resolve => setTimeout(resolve, 0));
						return await otGetOffers(parameters, offset + 20);
					} else {
						return;
					}
				}

				let tags;
				let tagFound;
				try {
					tags = await getOfferTags(5, offerId, parameters);
					if (tags)	{
						if (parameters.offerTagsSearchMode === '1') {
							tagFound = tags.find(tag => tag.id === parameters.tagId);
							if (tagFound) parameters.offers.push(offerId);
						} else {
							await sendMessage({ action: 'offerTagsSave', offer: { id: offerId, tags: [...tags.map(tag => tag.id)]	} });
						}
					}
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
				}
			} while (offersList.length > 0);

			if (result.totalCount > (offset + 20)) {
				await new Promise(resolve => setTimeout(resolve, 0));
				return await otGetOffers(parameters, offset + 20);
			} else {
				return;
			}
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			parameters.accessToken = response.result;
			return await otGetOffers(parameters, offset, count);  
		} else {
			return Promise.reject(`Nie udało się zalogować użytkownika.`);
		}			
	} else if (fetchResponse.status === 403) {
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await otGetOffers(parameters, offset, count);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
		}
	}	else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await otGetOffers(parameters, offset, count);
		} else {
			return Promise.reject(`Błąd serwera w trakcie pobierania aukcji, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await otGetOffers(parameters, offset, count);
		} else {
			return Promise.reject(`Nie udało się pobrać aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}


async function getOfferTags(count, offerId, parameters) {
	let tags = [];
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/tags`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOfferTags(count, offerId, parameters)
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać tagów przypisanych do oferty ${offerId}. ${getErrorMessage(error)}`);
		}
	}

  if (fetchResponse.status === 200) {
    let offerTags;
    try {
      offerTags = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }

    if (offerTags.tags.length === 0) {
      tags = null;
    } else {
      for (const tag of offerTags.tags) {
        tags.push({
          id: tag.id,
          name: tag.name,
          hidden: tag.hidden
        });
      };
    }
    return Promise.resolve(tags);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
      } catch (error) {
        return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getOfferTags(count, offerId, parameters);
    } else {
			return Promise.reject(`Nie udało się odświeżyć tokena dostępowego.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject(`Użytkownik nie posiada abonamentu oferującego funkcjonalność tagów ofertowych.`);
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await getOfferTags(count, offerId, parameters);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania tagów ofertowych. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferTags(count, offerId, parameters);
    } else {
      return Promise.reject('Błąd serwera podczas pobierania tagów ofertowych, spróbuj ponownie później.');
    }
  } else {
		if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferTags(count, offerId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać tagów ofertowych. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}