async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
  return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;

	switch (action) {
    case 'offerTags': {
			if (document.body.dataset.offerTagsChangeInProgress) return Promise.resolve(true);
			toastMessage('Przełączanie widoczności tagów ofertowych...');
			document.body.dataset.offerTagsChangeInProgress = true;
			if (document.body.dataset.offerTagsHidden === 'true') document.body.dataset.offerTagsHidden = 'false'; else document.body.dataset.offerTagsHidden = 'true';
      document.querySelectorAll('div.offerTags').forEach(element => {
        document.body.dataset.offerTagsHidden === 'true' ? element.classList.add('hidden') : element.classList.remove('hidden');
      });
			const offersTable = document.querySelector('table[aria-label="lista ofert"]');
			const spanElement = document.createElement('span');
			spanElement.id = 'offerTagsMutationObserverTriggeerElement';
			offersTable.appendChild(spanElement);
      await new Promise(resolve => setTimeout(resolve, 1000));
      delete document.body.dataset.offerTagsChangeInProgress;
      break;
    }
  }
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt offerTags');
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsDefaultHidden']);
		document.body.dataset.offerTagsHidden = readedValue.offerTagsDefaultHidden;
		await otAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

async function otAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await otAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await otAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await otObserveOffersTable(parameters);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function otObserveOffersTable(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

	let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
	}

	let accessToken = response.result; 
	parameters.accessToken = accessToken;
	parameters.environment = environment;

	let offerTags = [];

	const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

	const observer = new IntersectionObserver(intersectionCallback, options);

	async function intersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.ot = false;
        });

        try {
          await otProcessOffersList(parameters, offersList, offerTags);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
      }
    });
		parameters.offersTable.querySelectorAll('tr[data-cy]').forEach(e => observer.observe(e));
  }

	let offersList;
	do {
		offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
		const offersListLength = offersList.length;
		await new Promise(resolve => setTimeout(resolve, 2000));
		offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(offerRow => offerRow.dataset.ot === undefined);
		if (offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
		else break;
	} while (1);
	
	offersList.forEach(offerRow => {
    offerRow.dataset.ot = false;
    observer.observe(offerRow);
  });

	try {
		await otProcessOffersList(parameters, offersList, offerTags);
	} catch (error) {
		return Promise.reject(getErrorMessage(error));
	}
}

async function otProcessOffersList(parameters, offersList, offerTags) {
	const offerTagsHidden = (document.body.dataset.offerTagsHidden === 'true' ? true : false); 
	let offerRow = offersList.shift();
	if (offerRow === undefined) return;
	if (!offerRow.isConnected) return await otProcessOffersList(parameters, offersList, offerTags);
	offerRow.dataset.ot = true;
	const offerId = offerRow.dataset.cy;
	if (offerTags[offerId]) {	
		if (offerRow.querySelector('div.offerTags') !== null) return;
		const tags = offerTags[offerId];
		let tagsDiv;     
		tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
		for (let i = 0; i < tags.length; i++) {
			tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}">${tags[i].name}</div>`;
		}	
		tagsDiv += `</div>`;
		offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
	} else {
		if (offerRow.querySelector('div.offerTags') !== null) return;
		let tags;
		try {
			tags = await getOfferTags(3, offerId, parameters);
			offerTags[offerId] = tags;
			let tagsDiv;     
      tagsDiv = `<div class="offerTags${offerTagsHidden ? ' hidden' : ''}">`;
			if (tags !== null) {
				for (let i = 0; i < tags.length; i++) {
					tagsDiv += `<div class="offerTag${tags[i].hidden ? ' hidden' : ''}">${tags[i].name}</div>`;
				}	
			}
      tagsDiv += `</div>`;
      offerRow.firstElementChild.firstElementChild.children[2].insertAdjacentHTML('beforeend', tagsDiv);
    } catch (error) {
			toastMessage(`Błąd! Podczas pobierania tagów ofertowych dla aukcji ${offerId} wystąpił błąd. ${getErrorMessage(error)}`);
		}
	}
	return await otProcessOffersList(parameters, offersList, offerTags);
}


async function getOfferTags(count, offerId, parameters) {
	let tags = [];
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/offers/${offerId}/tags`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOfferTags(count, offerId, parameters)
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać tagów przypisanych do oferty ${offerId}. ${getErrorMessage(error)}`);
		}
	}

  if (fetchResponse.status === 200) {
    let offerTags;
    try {
      offerTags = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }

    if (offerTags.tags.length === 0) {
      tags = null;
    } else {
      for (const tag of offerTags.tags) {
        tags.push({
          id: tag.id,
          name: tag.name,
          hidden: tag.hidden
        });
      };
    }
    return Promise.resolve(tags);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken' });
      } catch (error) {
        return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
			if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getOfferTags(count, offerId, parameters);
    } else {
			return Promise.reject(`Nie udało się odświeżyć tokena dostępowego.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject(`Użytkownik nie posiada abonamentu oferującego funkcjonalność tagów ofertowych.`);
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await getOfferTags(count, offerId, parameters);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania tagów ofertowych. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferTags(count, offerId, parameters);
    } else {
      return Promise.reject('Błąd serwera podczas pobierania tagów ofertowych, spróbuj ponownie później.');
    }
  } else {
		if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferTags(count, offerId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać tagów ofertowych. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}