const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const SAMPLE_NOT_SEND = 'Wysyłanie próbki danych do serwera nie powiodło się.';

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

function anonymizeBuyerData(data) {
  const numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  const accentedLetters = ['ą', 'ć', 'ę', 'ł', 'ń', 'ó', 'ś', 'ź', 'ż'];
  const splittedData = data.split('');
  let returnData = '';
  splittedData.forEach(char => {
    if (numbers.includes(char)) {
      returnData += 'N';
    } else if (letters.includes(char.toLowerCase())) {
      returnData += 'L';
    } else if (accentedLetters.includes(char.toLowerCase())) {
      returnData += 'A'
    } else returnData += char;
  });
  return returnData;
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt validateBuyerAddressErrors');

  let orderId;
  let orderDetails;
  let requiredActions = {
    name: '',
    company: '',
    street: '',
    zipcode: '',
    city: '',
    country: '',
    phone: ''
  }
  let readedValue;

  try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}

  const autofillExtension = Object.keys(readedValue.extensions).find(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize'));
  if (autofillExtension) {
    console.log('validateBuyerAddressErrors: oczekiwanie na zakończenie działania modułu autofillPackageSize');
    async function waitForAutofillExtensionComplete(i) {
      const orderShipmentsButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zamów przesyłki');
      if (!orderShipmentsButton) {
        await new Promise(resolve => setTimeout(resolve, 200));
        return await waitForAutofillExtensionComplete(--i);
      }
      if (orderShipmentsButton.dataset.done === undefined) {
        await new Promise(resolve => setTimeout(resolve, 200));
        return await waitForAutofillExtensionComplete(--i);
      }
      if (orderShipmentsButton.dataset.done.search('autofillPackageSize') === -1) {
        await new Promise(resolve => setTimeout(resolve, 200));
        return await waitForAutofillExtensionComplete(--i);
      }
      console.log('validateBuyerAddressErrors: moduł autofillPackageSize zakończył działanie, kontynuuję...');
      return Promise.resolve(true);
    }
    await waitForAutofillExtensionComplete(50);
  }

  try {
    readedValue = await readDataFromLocalStorage(['buyerAddressErrorsFeedback']);
  } catch (error) {
    toastMessage('Błąd! Nie udało się sprawdzić ustawień przesyłania zanonimizowanych próbek podczas wystąpienia błędu.');
  }

  const locationSplitted = window.location.href.split('/');
	orderId = locationSplitted[locationSplitted.length - 1];
  
  try {
    orderDetails = await getOrder(orderId);
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  }

  if (!orderDetails.address.companyName) orderDetails.address.companyName = '';

  if (((orderDetails.address.firstName.length + orderDetails.address.lastName.length) > 30)
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.name += 'Zbyt długie pole nazwa, dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.companyName.length > 30
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.company += 'Zbyt długa nazwa firmy; dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.companyName.length > 35
    && orderDetails.method.search('UPS') !== -1) {
      requiredActions.company += 'Zbyt długa nazwa firmy; dozwolone max. 35 znaków; ';
  }

  if (orderDetails.address.street.length > 35
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.street += 'Zbyt długa nazwa ulicy; dozwolone max. 35 znaków; ';
  }

  if (orderDetails.address.city.length > 30
    && orderDetails.method.search('Allegro One') !== -1) {
      requiredActions.city += 'Zbyt długa nazwa miejscowości; dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.street.search(/ \d/) === -1) {
    requiredActions.street += 'Brak numeru ulicy poprzedzonego spacją; ';
  }

  if (orderDetails.pickupPoint && ((orderDetails.address.phoneNumber.length === 12 && orderDetails.address.phoneNumber[0] === '+' && orderDetails.address.phoneNumber.slice(1,3) !== '48') || (orderDetails.address.phoneNumber.length === 11 && orderDetails.address.phoneNumber.slice(0,2) !== '48'))) {
    requiredActions.phone += 'Numer telefonu nie należy do polskiej sieci; ';
  }

  if (Object.values(requiredActions).find(e => e.length > 0)) {
    toastMessage('Wymagana zmiana danych odbiorcy');
    
    let changeBuyerDataButton;
    let i = 50;
    do {
      changeBuyerDataButton = document.querySelector('button[data-analytics-interaction-label="change.recipient.open"]');
      if (changeBuyerDataButton) break;
      await new Promise(resolve => setTimeout(resolve, 200));
    } while (i--);
    if (i === 0) {
      toastMessage('Błąd! Nie znaleziono przycisku zmiany danych odbiorcy.');
      return;
    }  

    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
    });

    const observer = new MutationObserver(mutations => {
      for (const mutation of mutations) {
        if (document.querySelector('input[name="phone"]') !== null) {
          observer.disconnect();
          showRequiredActions();
        }
      } 
    });
    observer.observe(document.body, { subtree: true, childList: true });
    changeBuyerDataButton.dispatchEvent(clickEvent);   
  }

  if (readedValue?.buyerAddressErrorsFeedback) {
    const errorObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length) {
          errorsList = Array.from(mutation.addedNodes).find(e => e.childNodes.length && e.firstChild.dataset?.testid === "message-container");
          if (errorsList) {
            if (['Wybrany urząd nadania jest niewłaściwy',
                'Punkt odbiorcy nie istnieje',
                'Adres odbiorcy nie może być taki sam, jak adres nadawcy.',
                'Wybierz sposób nadania przesyłki',
                'API przewoźnika jest niedostępne',
                'API przewoźnika jest tymczasowo niedostępne. Ponów próbę później.',
                'API Inpost jest tymczasowo niedostępne. Ponów próbę później.',
                'Problem z zamówieniem przesyłki. try.again',
                'Kwota płatności za pobraniem musi był większa niż zero',
                'Przesyłki nie udało się utworzyć. Spróbuj ponownie później',
                'Wystąpił błąd w systemie zewnętrznego przewoźnika',
                'Błąd zewnętrznego przewoźnika',
                'Pole "Dane odbiorcy" zawiera błędne dane: Punkt odbiorcy nie istnieje'].indexOf(errorsList.innerText) !== -1) return;
            let anonymizedBuyerData = {
              shippingMethod: orderDetails.method,
              firstName: anonymizeBuyerData(orderDetails.address.firstName),
              lastName: anonymizeBuyerData(orderDetails.address.lastName),
              company: (orderDetails.address.companyName ? anonymizeBuyerData(orderDetails.address.companyName) : ''),
              street: anonymizeBuyerData(orderDetails.address.street),
              city: anonymizeBuyerData(orderDetails.address.city),
              zipCode: anonymizeBuyerData(orderDetails.address.zipCode),
              country: orderDetails.address.countryCode,
              phone: anonymizeBuyerData(orderDetails.address.phoneNumber),
              details: errorsList.innerText 
            }
            
            try {
              response = await sendMessage({ action: 'sendAnonymizedSample', sample: anonymizedBuyerData });
              if (!response.success) throw new Error(response.result);
            } catch (error) {
              toastMessage(`Błąd! ${error?.message ? error.message : error}`);
            }
          } 
        }
      } 
    });
    errorObserver.observe(document.body, { subtree: true, childList: true });
  }

  function showRequiredActions() {
    if (requiredActions.name) {
      const element = document.querySelector('input[name="name"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.innerText = requiredActions.name;
      }
    }

    if (requiredActions.company) {
      const element = document.querySelector('input[name="company"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild; 
        information.classList.add('informationWrong'); 
        information.innerText = requiredActions.company;
      }
    }

    if (requiredActions.street) {
      const element = document.querySelector('input[name="addressLine"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild; 
        information.classList.add('informationWrong'); 
        information.innerText = requiredActions.street;
      }
    }

    if (requiredActions.city) {
      const element = document.querySelector('input[name="city"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.innerText = requiredActions.city;
      }
    }

    if (requiredActions.phone) {
      const element = document.querySelector('input[name="phone"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.innerText = requiredActions.phone;
      }
    }
  }

  function clearInformationField(e) {
    if (e.target.dataset.information) {
      delete e.target.dataset.information;
      e.target.parentNode.nextElementSibling.firstChild.innerText = '';
    }
  }
});

async function getOrder(orderId, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOrder(orderId, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. ${error?.message ? error.message : error}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    return Promise.resolve({ method: fetchData.delivery.method.name, address: fetchData.delivery.address, pickupPoint: (fetchData.delivery.pickupPoint === null ? false : true) });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await getOrder(orderId, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOrder(orderId, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}