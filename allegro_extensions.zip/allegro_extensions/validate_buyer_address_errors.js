const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const SAMPLE_NOT_SEND = 'Wysyłanie próbki danych do serwera nie powiodło się.';

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

function anonymizeBuyerData(data) {
  const numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  const accentedLetters = ['ą', 'ć', 'ę', 'ł', 'ń', 'ó', 'ś', 'ź', 'ż'];
  const splittedData = data.split('');
  let returnData = '';
  splittedData.forEach(char => {
    if (numbers.includes(char)) {
      returnData += 'N';
    } else if (letters.includes(char.toLowerCase())) {
      returnData += 'L';
    } else if (accentedLetters.includes(char.toLowerCase())) {
      returnData += 'A'
    } else returnData += char;
  });
  return returnData;
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt validateBuyerAddressErrors');

  let orderId = document.location.href.split('/');
	orderId = orderId[orderId.length - 1].split('?')[0];
	if (orderId.indexOf(',') !== -1) document.body.dataset.multipleOrders = 'true';
	else document.body.dataset.multipleOrders = 'false';

  const observer = new MutationObserver(mutations => {
		mutations.forEach(async (mutation) => {
			if (mutation.type === 'childList') {
				const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.validateBuyerErrorsNew === undefined);
				if (addedHeader) {
          addedHeader.dataset.validateBuyerErrorsNew = 'false';
					try {
            await validateBuyerAddressErrors();
          } catch (error) {
            toastMessage(`Błąd! ${error?.message ? error.message : error}`);
          }
				}	
			}
		});
	});

  observer.observe(document.body, { subtree: true, childList: true });

  const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.validateBuyerErrorsNew === undefined);
  if (addedHeader) {
    addedHeader.dataset.validateBuyerErrorsNew = 'false';
    try {
      await validateBuyerAddressErrors();
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    }
  }
});

async function validateBuyerAddressErrors() {
  const multipleOrders = (document.body.dataset.multipleOrders === 'true');

  let orderId;
  let ordersIds;
  let shipmentContainer;
  let addedHeader;
  let orderDetails;
  let requiredActions = {
    name: '',
    company: '',
    street: '',
    zipcode: '',
    city: '',
    country: '',
    phone: ''
  }
  let readedValue;

  try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}

  if (!multipleOrders) {
    orderId = document.location.href.split('/');
    orderId = orderId[orderId.length - 1].split('?')[0];
    addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:');
    shipmentContainer = addedHeader.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
    shipmentContainer.dataset.orderId = orderId;
  } else {
    ordersIds = document.location.href.split('/');
    ordersIds = ordersIds[ordersIds.length - 1].split('?')[0];
    ordersIds = ordersIds.split(',');
    addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:');
    shipmentContainer = addedHeader.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
    orderId = ordersIds[Number(shipmentContainer.querySelector('H4').textContent.split(' z ')[0]) - 1];
    shipmentContainer.dataset.orderId = orderId;
  }

  const autofillExtension = Object.keys(readedValue.extensions).find(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize'));
  if (autofillExtension) {
    console.log('validateBuyerAddressErrors: oczekiwanie na zakończenie działania modułu autofillPackageSize');
    if (!multipleOrders) {
      async function waitForAutofillExtensionComplete(i) {
        const orderShipmentsButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zamów przesyłki');
        if (!orderShipmentsButton) {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionComplete(--i);
        }
        if (orderShipmentsButton.dataset.done === undefined) {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionComplete(--i);
        }
        if (orderShipmentsButton.dataset.done.search('autofillPackageSize') === -1) {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionComplete(--i);
        }
        console.log('validateBuyerAddressErrors: moduł autofillPackageSize zakończył działanie, kontynuuję...');
        return Promise.resolve(true);
      }
      await waitForAutofillExtensionComplete(50);
    } else {
      async function waitForAutofillExtensionCompleteMultipleOrders(i) {
        const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:');
        if (!addedHeader) {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionCompleteMultipleOrders(--i);
        }
        const shipmentContainer = addedHeader.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]');
        if (!shipmentContainer) {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionCompleteMultipleOrders(--i);
        }
        if (shipmentContainer.dataset.packageSize !== 'ready') {
          await new Promise(resolve => setTimeout(resolve, 200));
          return await waitForAutofillExtensionCompleteMultipleOrders(--i);
        }
        
        console.log('validateBuyerAddressErrors: moduł autofillPackageSize zakończył działanie, kontynuuję...');
        return Promise.resolve(true);
      }
      await waitForAutofillExtensionCompleteMultipleOrders(50);
    }
  }

  try {
    readedValue = await readDataFromLocalStorage(['buyerAddressErrorsFeedback']);
  } catch (error) {
    toastMessage('Błąd! Nie udało się sprawdzić ustawień przesyłania zanonimizowanych próbek podczas wystąpienia błędu.');
  }

  try {
    orderDetails = await getOrder(orderId);
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  }

  if (!orderDetails.address.companyName) orderDetails.address.companyName = '';

  if (((orderDetails.address.firstName.length + orderDetails.address.lastName.length) > 30)
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.name += 'Zbyt długie pole nazwa, dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.companyName.length > 30
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.company += 'Zbyt długa nazwa firmy; dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.companyName.length > 35
    && orderDetails.method.search('UPS') !== -1) {
      requiredActions.company += 'Zbyt długa nazwa firmy; dozwolone max. 35 znaków; ';
  }

  if (orderDetails.address.street.length > 35
    && (orderDetails.method.search('Allegro One') !== -1 || orderDetails.method.search('ORLEN') !== -1)) {
      requiredActions.street += 'Zbyt długa nazwa ulicy; dozwolone max. 35 znaków; ';
  }

  if (orderDetails.address.city.length > 30
    && orderDetails.method.search('Allegro One') !== -1) {
      requiredActions.city += 'Zbyt długa nazwa miejscowości; dozwolone max. 30 znaków; ';
  }

  if (orderDetails.address.street.search(/ \d/) === -1) {
    requiredActions.street += 'Brak numeru ulicy poprzedzonego spacją; ';
  }

  if (orderDetails.pickupPoint && ((orderDetails.address.phoneNumber.length === 12 && orderDetails.address.phoneNumber[0] === '+' && orderDetails.address.phoneNumber.slice(1,3) !== '48') || (orderDetails.address.phoneNumber.length === 11 && orderDetails.address.phoneNumber.slice(0,2) !== '48'))) {
    requiredActions.phone += 'Numer telefonu nie należy do polskiej sieci; ';
  }

  if (Object.values(requiredActions).find(e => e.length > 0)) {
    toastMessage('Wymagana zmiana danych odbiorcy');
    
    let changeBuyerDataButton;
    let i = 50;
    do {
      changeBuyerDataButton = document.querySelector('button[data-analytics-interaction-label="change.recipient.open"]');
      if (changeBuyerDataButton) break;
      await new Promise(resolve => setTimeout(resolve, 200));
    } while (i--);
    if (i === 0) {
      toastMessage('Błąd! Nie znaleziono przycisku zmiany danych odbiorcy.');
      return;
    }  

    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
    });

    const observer = new MutationObserver(mutations => {
      for (const mutation of mutations) {
        if (document.querySelector('input[name="phone"]') !== null) {
          observer.disconnect();
          showRequiredActions();
        }
      } 
    });
    observer.observe(document.body, { subtree: true, childList: true });
    changeBuyerDataButton.dispatchEvent(clickEvent);   
  }

  if (readedValue?.buyerAddressErrorsFeedback) {
    const errorObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length) {
          errorsList = Array.from(mutation.addedNodes).find(e => e.childNodes.length && e.firstChild.dataset?.testid === "message-container" && e.firstChild.firstChild.className === 'mgcwm5' && e.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a883q"]').dataset.orderId === orderDetails.orderId);
          if (errorsList) {
            errorsList.querySelectorAll('div[data-testid="message-container"]').forEach(async (errorMessage) => {
              if (['Wybrany urząd nadania jest niewłaściwy',
                  'Punkt odbiorcy nie istnieje',
                  'Adres odbiorcy nie może być taki sam, jak adres nadawcy.',
                  'Wybierz sposób nadania przesyłki',
                  'API przewoźnika jest niedostępne',
                  'API przewoźnika jest tymczasowo niedostępne. Ponów próbę później.',
                  'Jeden z wymaganych serwisów, do poprawnego działania, jest niedostępny. Spróbuj ponownie za moment.',
                  'API Inpost jest tymczasowo niedostępne. Ponów próbę później.',
                  'Problem z zamówieniem przesyłki. try.again',
                  'Kwota płatności za pobraniem musi był większa niż zero',
                  'Przesyłki nie udało się utworzyć. Spróbuj ponownie później',
                  'Wystąpił błąd w systemie zewnętrznego przewoźnika',
                  'Wystąpił nieznany błąd w systemie zewnętrznego przewoźnika',
                  'Błąd zewnętrznego przewoźnika',
                  'Zamawianie przesyłek jest niemożliwe ze względu na brak środków na koncie InPost.',
                  'Pole "Dane odbiorcy" zawiera błędne dane: Punkt odbiorcy nie istnieje'].indexOf(errorMessage.textContent) !== -1) return;
              let anonymizedBuyerData = {
                shippingMethod: orderDetails.method,
                firstName: anonymizeBuyerData(orderDetails.address.firstName),
                lastName: anonymizeBuyerData(orderDetails.address.lastName),
                company: (orderDetails.address.companyName ? anonymizeBuyerData(orderDetails.address.companyName) : ''),
                street: anonymizeBuyerData(orderDetails.address.street),
                city: anonymizeBuyerData(orderDetails.address.city),
                zipCode: anonymizeBuyerData(orderDetails.address.zipCode),
                country: orderDetails.address.countryCode,
                phone: anonymizeBuyerData(orderDetails.address.phoneNumber),
                details: errorMessage.textContent 
              }
              
              try {
                response = await sendMessage({ action: 'sendAnonymizedSample', sample: anonymizedBuyerData });
                if (!response.success) throw new Error(response.result);
              } catch (error) {
                toastMessage(`Błąd! ${error?.message ? error.message : error}`);
              }
            }); 
          }
        }
      } 
    });
    errorObserver.observe(document.body, { subtree: true, childList: true });
  }

  function showRequiredActions() {
    if (requiredActions.name) {
      const element = document.querySelector('input[name="name"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.textContent = requiredActions.name;
      }
    }

    if (requiredActions.company) {
      const element = document.querySelector('input[name="company"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild; 
        information.classList.add('informationWrong'); 
        information.textContent = requiredActions.company;
      }
    }

    if (requiredActions.street) {
      const element = document.querySelector('input[name="addressLine"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild; 
        information.classList.add('informationWrong'); 
        information.textContent = requiredActions.street;
      }
    }

    if (requiredActions.city) {
      const element = document.querySelector('input[name="city"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.textContent = requiredActions.city;
      }
    }

    if (requiredActions.phone) {
      const element = document.querySelector('input[name="phone"]');
      if (element) {
        element.addEventListener('click', clearInformationField);
        element.dataset.information = true;
        let information = element.parentNode.nextElementSibling.firstChild;  
        information.classList.add('informationWrong');
        information.textContent = requiredActions.phone;
      }
    }
  }

  function clearInformationField(e) {
    if (e.target.dataset.information) {
      delete e.target.dataset.information;
      e.target.parentNode.nextElementSibling.firstChild.textContent = '';
    }
  }
}

async function getOrder(orderId, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;
  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOrder(orderId, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. ${error?.message ? error.message : error}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    return Promise.resolve({orderId: fetchData.id, method: fetchData.delivery.method.name, address: fetchData.delivery.address, pickupPoint: (fetchData.delivery.pickupPoint === null ? false : true) });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await getOrder(orderId, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOrder(orderId, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać szczegółów zamówienia. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}