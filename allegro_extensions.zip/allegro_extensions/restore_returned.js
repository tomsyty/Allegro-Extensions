async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt restoreReturned');	

  let sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  let environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

  if (window.location.href.startsWith(`https://salescenter.allegro.com${environment}/payment-refund-form`)) {
    fillRefundForm();
    return;
  }

  let readedValue;
  try { 
    readedValue = await readDataFromLocalStorage(['returnsDoneList']);
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
  } 
  
	(function addStylesheet() {	
		const link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0&display=block';
		document.head.appendChild(link);
	})();	
	
	restoreReturnedAwaitOrdersTable();
});

async function fillRefundForm() {
  console.log('Znaleziono stronę zwracania środków.');
  let readedValue;
  try {
    readedValue = await readDataFromSessionStorage(['itemsToRestore']);
    if (readedValue.itemsToRestore) {
      console.log(readedValue.itemsToRestore);
      let checkAllCheckBox;
      let checkAllRetriesLeft = 5;
      let breakLoop = false;
      do {
        checkAllRetriesLeft--;
        await new Promise(resolve => setTimeout(resolve, 1000));
        checkAllCheckBox = document.querySelector('div[data-testid="select-all"] input[type="checkbox"]');
        if (checkAllCheckBox) {
          checkAllCheckBox.click();
          break;
        } else if (!checkAllRetriesLeft) {
          toastMessage('Błąd! Nie znaleziono pola do zaznaczenia wszystkich przedmiotów. Wypełnij formularz zwrotu ręcznie.');
          break;
        }
      } while (checkAllRetriesLeft);
      await new Promise(resolve => setTimeout(resolve, 2000));
      const inputEvent = new InputEvent('input', { bubbles: true });
      let itemRetriesLeft = 5;
      let inputRetriesLeft = 5;
      let nextItem;
      for (const item of readedValue.itemsToRestore) {
        let itemCheckBox;
        nextItem = false;
        do {
          itemRetriesLeft--;
          await new Promise(resolve => setTimeout(resolve, 200));
          itemCheckBox = document.querySelector(`div[data-testid="select-${item.offerId}"]`);
          if (itemCheckBox !== null) {
            itemCheckBox.firstElementChild.click();
            inputRetriesLeft = 5;
            do {
              inputRetriesLeft--;
              await new Promise(resolve => setTimeout(resolve, 200));
              const inputElement = document.querySelector(`div[data-testid="${item.offerId}"] input[aria-label="liczba sztuk"]`);
              if (inputElement) {
                if (inputElement.value != item.quantity) {
                  inputElement.value = item.quantity;
                  inputElement.dispatchEvent(inputEvent);
                }
                nextItem = true;
              } else if (!inputRetriesLeft) {
                toastMessage('Błąd! Nie znaleziono pola do wpisania ilości sztuk. Wypełnij formularz zwrotu ręcznie.');
                breakLoop = true;
                break;
              }
            } while (inputRetriesLeft && !nextItem);
            if (breakLoop) break;
          } else if (!itemRetriesLeft) {
            toastMessage('Błąd! Nie znaleziono przedmiotu z listy zwrotów do zaznaczenia. Wypełnij formularz zwrotu ręcznie.');
            breakLoop = true;
            break;
          }
        } while (itemRetriesLeft && !nextItem);
        if (breakLoop) break;
      }
      if (!breakLoop) {
        toastMessage('Zaznaczono wszystkie przedmioty z listy zwrotów. Sprawdź kwotę, koszt wysyłki i wybierz powód zwrotu.');
      }
    } else {
      console.log('Nie znaleziono danych w pamięci tymczasowej');
    }
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
  }

  try {
    readedValue = await readDataFromLocalStorage(['iFirmaReturns']);
  } catch (error) {
    toastMessage(`Błąd! Nie udało się odczytać ustawień dotyczących serwisu iFirma. Opcja uzupełniania protokołu anulowania sprzedaży będzie niedostępna. ${error?.message ? error.message : error}`);
  }
  if (readedValue.iFirmaReturns) {
    let sourceButton;
    let retriesLeft = 10;
    do {
      sourceButton = document.querySelector('button[data-testid="submit-refund"]');
      if (sourceButton === null) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } while (sourceButton === null || retriesLeft--);
    
    if (!retriesLeft) {
      toastMessage('Błąd! Nie znaleziono przycisku "Zwróć wpłatę". Odśwież stronę i spróbuj ponownie.');
      return;
    }

    const fillFormButton = document.createElement('button');
    fillFormButton.innerText = 'PROTOKÓŁ ANULOWANIA';
    fillFormButton.id = 'fillFormButton';
    fillFormButton.className = sourceButton.className;
    sourceButton.parentElement.insertAdjacentElement('afterbegin', fillFormButton);
    fillFormButton.addEventListener('click', async (e) => {
      let restoreList = [];
      let itemName, quantity, price;
      let parentRow, parentName;
      
      const itemsToRestore = document.querySelectorAll('input[name="offer-checkboxes"]:checked');
      for (const item of itemsToRestore) {
        parentName = item.parentElement.dataset?.testid;
        if (parentName) {
          parentName = parentName.split('-')[1];
          parentRow = document.querySelector(`div[data-testid="${parentName}"]`);
          itemName = parentRow.querySelector('a[data-testid="offer-url"]').innerText;
          quantity = parentRow.querySelector('input[aria-label="liczba sztuk"]').value;
          price = parentRow.querySelector('span[data-testid="unit-price"]').textContent.split(' ')[0];
          restoreList.push({ itemName: itemName, quantity: quantity, price: price });
        }
      }

      try {
        response = await sendMessage({ action: 'fillRefundForm', restoreList: restoreList });
        if (!response.success) throw new Error(response.result);
        e.target.disabled = true;
        toastMessage('Skopiowano listę zwróconych przedmiotów na stronę z protokołem anulowania sprzedaży. Uzupełnij w nim pozostałe dane.');
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      }
    });
  }
  return;
}

async function restoreReturnedAwaitOrdersTable() {
  const returnsTable = document.querySelector('div[data-box-name="allegro.returns.listing_condition"]');
  let previousUrl = '';
  if (returnsTable === null) {
    const returnsTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.returns.listing_condition')) {
            returnsTableObserver.disconnect();
						return await restoreReturnedAwaitOrdersTable();
          }
        }
      }
    });
    returnsTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
    const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
        urlObserver.disconnect();
        return await restoreReturnedAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      urlObserver.observe(document, {	subtree: true, childList: true });
      try {
        restoreReturnedObserve(returnsTable);
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      }
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
  }
}

async function restoreReturnedObserve(returnsTable) {
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}
  if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
    const iconCheckCircleOutline = document.createElement('span');
    iconCheckCircleOutline.className = 'material-symbols-outlined';
    iconCheckCircleOutline.dataset.icon = 'check_circle';
    preloadIconsContainer.appendChild(iconCheckCircleOutline);
  }
  if (!preloadIconsContainer.querySelector('span[data-icon="highlight_off"]')) {
	const iconHighlightOff = document.createElement('span');
    iconHighlightOff.className = 'material-symbols-outlined';
    iconHighlightOff.dataset.icon = 'highlight_off'
    preloadIconsContainer.appendChild(iconHighlightOff);
  }
  const params = new URLSearchParams(document.location.search);
	const status = params.get('status');
  //if (!status === null) return;

  if (document.getElementById('restoreItemsDialog') === null) {
		returnsTable.insertAdjacentHTML('beforeend', /*html*/ `
		<dialog id="restoreItemsDialog">
			<form method="dialog">
        <div class="row">
          <span id="closeContainer" class="material-symbols-outlined fs28">close</span>
        </div>
				<div class="dialogHead">
					<span>Przedmioty do przywrócenia</span>
				</div>
				<div class="row">
					<table id="itemsToRestoreTable">
						<thead>
							<tr>
								<th></th>
                <th></th>
								<th>Przedmiot</th>
								<th>nr aukcji</th>
								<th>szt.</th>
							</tr>	
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
				<div class="row">
					<button id="restoreItemsDialogCancel" class="actionButton"><span class="material-symbols-outlined fs28">cancel</span>Anuluj</button>
					<button id="restoreItemsDialogConfirm" class="actionButton"><span class="material-symbols-outlined fs28">replay</span>Przywróć</button>
				</div>
			</form>
		</dialog>`);
	}

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let readedValue;
  let returnsList;
  let returnsDoneList;
  let returnRows;
  let searchAfterDate, searchAfterDateISO;
  let response;
  const currentTimestamp = Date.now();
  searchAfterDate = new Date(currentTimestamp - (100 * 24 * 60 * 60 * 1000));
  searchAfterDateISO = searchAfterDate.toISOString().replace(/:/g, '%3A');
  try {
    readedValue = await readDataFromLocalStorage(['returnsDoneList']);
    if (readedValue.returnsDoneList === undefined) {
      throw new Error('Nie znaleziono listy zwrotów. Zainstaluj aplikację na nowo.');
    }
    returnsDoneList = await filterAndSaveReturnsDoneList(readedValue.returnsDoneList, searchAfterDate);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  }

  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  }

  const parameters = {
    accessToken: response.result,
    environment: environment,
    searchAfterDateISO: searchAfterDateISO
  }
  
  try {
    returnsList = await getReturns(parameters);
    returnRows = await getReturnRows(returnsList, returnsDoneList);
  } catch (error) {
    return Promise.reject(error?.message ? error.message : error);
  }

  if (returnRows?.length) {
    for (const returnRow of returnRows) {
      const returnRowButtons = returnRow.querySelectorAll('button');
      if (returnRowButtons.length) {
        const sourceButtonStyle = returnRowButtons[returnRowButtons.length - 1].className;
        const restoreButton = document.createElement('button');
        restoreButton.innerText = 'PRZYWRÓĆ STAN';
        restoreButton.className = sourceButtonStyle;
        restoreButton.classList.remove('m7er_k4');
        let goToOrder = returnRow.querySelector('a[data-analytics-click-label="goToOrder"]');
        if (goToOrder !== null) {
          goToOrder.previousElementSibling.insertAdjacentElement('afterend', restoreButton);
          restoreButton.addEventListener('click', (e) => {
            e.target.disabled = true;
            const returnRow = e.target.closest('div[class~="_992f8_KF-cc"]');
            if (returnRow !== null) {
              let returnReferenceNumber = Array.from(returnRow.querySelectorAll('div')).filter(element => element.innerText === 'Numer zwrotu')?.[0].nextElementSibling;
              if (returnReferenceNumber !== null) {
                returnReferenceNumber = returnReferenceNumber.innerText;
                const itemsList = returnRow.querySelectorAll('div[class="mpof_ki mp4t_16"]');
                if (itemsList.length) {
                  const itemsToRestore = [];
                  for (item of itemsList) {
                    const itemName = item.children[1].firstChild.firstChild.firstChild.innerText;
                    const offerId = item.children[1].firstChild.firstChild.children[1].innerText.replace(/[\(\)]/g, '');
                    const quantity = Number(item.children[1].children[1].firstChild.innerText.split(' ')[0]);
                    itemsToRestore.push({ itemName: itemName, offerId: offerId, quantity: quantity });
                  }

                  const restoreItemsDialog = document.getElementById('restoreItemsDialog');
                  if (restoreItemsDialog) {
                    restoreItemsDialog.dataset.returnReferenceNumber = returnReferenceNumber;
                    document.getElementById('restoreItemsDialogCancel').disabled = false;
                    document.getElementById('restoreItemsDialogConfirm').disabled = false;

                    const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
                    if (itemsToRestoreTable === null) {
                      toastMessage('Błąd! Nie znaleziono tabeli z listą przedmiotów do przywrócenia.');
                      return;
                    }
                    const bodySection = itemsToRestoreTable.tBodies[0];
                    bodySection.innerHTML = '';
                    let itemName;
                    let offerId;
                    let quantity;
                    for (const item of itemsToRestore) {
                      itemName = item['itemName'];
                      offerId = item['offerId'];
                      quantity = item['quantity'];

                      let newRow = document.createElement('tr');
                      newRow.innerHTML = /*html*/ `
                        <td></td>
                        <td><input type="checkbox" checked></td>
                        <td>${itemName}</td>
                        <td>${offerId}</td>
                        <td><input type="number" step="1" min="0" max="9999" value="${quantity}" required /></td>
                      `;
                      let insertedRow = bodySection.insertRow();
                      insertedRow.innerHTML = newRow.innerHTML;
                    }

                    itemsToRestoreTable.querySelectorAll('input[type="number"]').forEach(input => input.addEventListener('blur', numericInputBlur));
                    restoreItemsDialog.showModal();
                    document.getElementById('restoreItemsDialogCancel').focus();
                    document.getElementById('restoreItemsDialogCancel').blur();
                  } else {
                    toastMessage('Błąd! Nie znaleziono okna z listą przedmiotów do przywrócenia.');
                  }
                  //processOffer(offersList, returnReferenceNumber);
                }
              }
            }
          });

          let refundLink = Array.from(returnRow.querySelectorAll('button')).find(element => element.innerText === 'DECYZJA ZWROTOWA');
          if (refundLink !== undefined) {
            const itemsList = returnRow.querySelectorAll('div[class="mpof_ki mp4t_16"]');
            if (itemsList.length) {
              const itemsToRestore = [];
              for (item of itemsList) {
                const itemName = item.children[1].firstChild.firstChild.firstChild.innerText;
                const offerId = item.children[1].firstChild.firstChild.children[1].innerText.replace(/[\(\)]/g, '');
                const quantity = Number(item.children[1].children[1].firstChild.innerText.split(' ')[0]);
                itemsToRestore.push({ itemName: itemName, offerId: offerId, quantity: quantity });
              }
              refundLink.addEventListener('click', async (e) => {
                try {
                  await saveDataToSessionStorage({ 'itemsToRestore': itemsToRestore });
                  console.log('Zapisano listę przedmiotów do przywrócenia w pamięci tymczasowej.');
                } catch (error) {
                  toastMessage(`Błąd! Nie zapisano listy przedmiotów do przywrócenia. ${error?.message ? error.message : error}`);
                }
              });
            }
          }
        }
      }
    }
  }

  function numericInputBlur(e) {
    if (!e.target.reportValidity()) e.target.focus();
  }

  document.getElementById('restoreItemsDialogCancel').addEventListener('click', () => {
    document.getElementById('restoreItemsDialog').close();
  });

  document.getElementById('closeContainer').addEventListener('click', () => {
    document.getElementById('restoreItemsDialog').close();
  });

  document.getElementById('restoreItemsDialog').addEventListener('close', () => {
		const element = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
		if (element) element.disabled = false;
	});

  document.getElementById('restoreItemsDialogConfirm').addEventListener('click', async (e) => {
    const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
    const numericInputs = itemsToRestoreTable.querySelectorAll('input[type="number"]');
    let numericInputsInvalid = false;
    numericInputs.forEach(input => {
			if (!input.reportValidity()) numericInputsInvalid = true;
		});

		if (numericInputsInvalid) return;

    (e.target.nodeName === 'SPAN' ? e.target.parentElement.disabled = true : e.target.disabled = true);
    
    Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN')?.remove();
    document.getElementById('restoreItemsDialogCancel').disabled = true;
    
    const checkboxes = itemsToRestoreTable.querySelectorAll('input[type="checkbox"]');
		checkboxes.forEach(checkbox => checkbox.disabled = true);
    
    numericInputs.forEach(input => input.disabled = true);
    const itemsToRestore = Array.from(itemsToRestoreTable.tBodies[0].rows);
    const environment = (new URL(document.URL).hostname.indexOf('allegrosandbox.pl') !== -1 ? '.allegrosandbox.pl' : '');
    let response;
    try {
      response = await sendMessage({ action: 'getAllegroAccessToken' });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      return Promise.reject(false);
    }

    const restoreItemsDialog = document.getElementById('restoreItemsDialog');
    const referenceNumber = restoreItemsDialog.dataset.returnReferenceNumber;
    const createdAt = returnsList.find(element => element.referenceNumber === referenceNumber).createdAt;

    returnsDoneList.push({
      createdAt: createdAt,
      referenceNumber: referenceNumber
    });

    try {
      await saveDataToLocalStorage({ returnsDoneList: returnsDoneList });
    } catch (error) {
      toastMessage(`Błąd! Nie zapisano informacji o zwrocie - przycisk pozwalający na zwrot będzie widoczny na liście dopóki status zwrotu na Allegro nie ulegnie zmianie. ${error?.message ? error.message : error}`);
    }
    
    const accessToken = response.result;
    let restoreStatus;
    try {
      restoreStatus = await restoreItems(itemsToRestore, environment, accessToken);
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      return Promise.reject(false);
    }

    document.getElementById('restoreItemsDialogCancel').disabled = true;
    let restoreStatusText = '';
    if (restoreStatus.cancelled) restoreStatusText += 'Anulowano przywracanie stanu magazynowego, część aukcji została już zmieniona; ';
    if (restoreStatus.errorOccured) restoreStatusText += 'Podczas przywracania wystąpiły błędy, sprawdź aukcje; ';
    if (restoreStatusText === '') toastMessage('Zakończono przywracanie stanów magazynowych.');
    else toastMessage(restoreStatusText);
  });
}

async function filterAndSaveReturnsDoneList(returnsDoneList, searchAfterDate) {
  const searchAfterDateTimestamp = searchAfterDate.valueOf();
  const filteredReturnsDoneList = Array.from(returnsDoneList).filter(element => Date.parse(element.createdAt) > searchAfterDateTimestamp);
  try {
    await saveDataToLocalStorage({ returnsDoneList: filteredReturnsDoneList });
  } catch (error) {
    return Promise.reject(`Nie udało się zaktualizować listy wykonanych zwrotów. ${error?.message ? error.message : error}`);
  }
  return Promise.resolve(filteredReturnsDoneList);
}

async function getReturns(parameters, returnsListArray = [], offset = 0, count = 5) {
  let returnsList = returnsListArray;
  let response;
  try {
    response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/customer-returns?offset=${offset}&createdAt.gte=${parameters.searchAfterDateISO}`, {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.beta.v1+json',
        'Accept': 'application/vnd.allegro.beta.v1+json'
      }
    });
  } catch (error) {
    return Promise.reject(`Podczas wysyłania żądania nastąpił błąd. ${error?.message ? error.message : error}`);
  }  
  if (response.status === 200) {
    let result;
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    if (result.customerReturns !== undefined && result.customerReturns.length) {
      result.customerReturns.forEach(customerReturn => {
        returnsList.push({
          createdAt: customerReturn.createdAt,
          referenceNumber: customerReturn.referenceNumber
        });
      });
      if (result.count > (offset + 100)) {
        return await getReturns(parameters, returnsList, offset + 100);
      }
    } 
    return Promise.resolve(returnsList);  
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
       return Promise.reject(error?.message ? error.message : error);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getReturns(parameters, returnsList, offset, count);									       
    } else {
      return Promise.reject(`Nie udało się pobrać listy zwrotów. Nie udało się zalogować użytkownika.`);
    }
  } else if (response.status === 403) {                       
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getReturns(parameters, returnsList, offset, count);
    } else {
      return Promise.reject('Nie udało się pobrać listy zwrotów.');
    }
  }
}

async function getReturnRows(returnsList, returnsDoneList) {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.type === 'childList') {
        let returnRows = Array.from(mutation.addedNodes).filter(element => {
          if (element.nodeName === 'DIV' && element.classList.contains('_992f8_KF-cc') && (!element.querySelector('button[innerText="PRZYWRÓĆ STAN"]')) && (element.querySelector('strong').innerText === 'Doręczony' || element.querySelector('strong').innerText === 'W drodze')) {
            let returnReferenceNumber = Array.from(element.querySelectorAll('div')).filter(elem => elem.innerText === 'Numer zwrotu')[0].nextElementSibling.innerText;
            if ((returnsList.find(element => element.referenceNumber === returnReferenceNumber)) && (returnsDoneList.find(element => element.referenceNumber === returnReferenceNumber) === undefined)) return true;
          }
          return false;
        });
        return Promise.resolve(returnRows);
      }
    });
  });

  let returnRows = Array.from(document.querySelectorAll('div[class~="_992f8_KF-cc"]')).filter(element => {
    if (element.nodeName === 'DIV' && element.classList.contains('_992f8_KF-cc') && (!element.querySelector('button[innerText="PRZYWRÓĆ STAN"]')) && (element.querySelector('strong').innerText === 'Doręczony' || element.querySelector('strong').innerText === 'W drodze')) {
      let returnReferenceNumber = Array.from(element.querySelectorAll('div')).filter(elem => elem.innerText === 'Numer zwrotu')[0].nextElementSibling.innerText;
      if ((returnsList.find(element => element.referenceNumber === returnReferenceNumber)) && (returnsDoneList.find(element => element.referenceNumber === returnReferenceNumber) === undefined)) return true;
    } 
    return false;
  });
  if (returnRows.length) return Promise.resolve(returnRows);
  observer.observe(document.querySelector('div[data-box-name="allegro.returns.listing_condition"]'), { subtree: true, childList: true });
}


async function restoreItems(itemsToRestore, environment, accessToken, count = 5, i = 0) {
	if (document.getElementById('restoreItemsDialog').open === false) {
		const errorOccured = false;
		return Promise.resolve({ cancelled: true, errorOccured: (errorOccured ? true : false) });
	}
	let response;
	let fetchResponse;
	let fetchData;
	const row = itemsToRestore[i];
  if (!row.cells[1].childNodes[0].checked) {
		if (i !== (itemsToRestore.length - 1)) return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
		else {
			const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
			const errorOccured = Array.from(itemsToRestoreTable.querySelectorAll('span')).find(e => e.innerText === 'highlight_off');
			return Promise.resolve({ cancelled: false, errorOccured: (errorOccured ? true : false) });
		}
	}

	const offerId = row.cells[3].innerText;
	const quantityToRestore = Number(row.cells[4].firstChild.value);
	if (row.cells[0].childElementCount === 0) {
		const spinner = document.createElement('progress');
		spinner.className = 'pure-material-progress-circular';
		row.cells[0].appendChild(spinner);
	}

	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await restoreItems(itemsToRestore, environment, accessToken, count, i);
		} else {
			setIconInCell('highlight_off', row.cells[0], true);
			if (i === (itemsToRestore.length - 1)) return Promise.reject(`Podczas wysyłania żądania nastąpił błąd. ${error?.message ? error.message : error}`);
			else return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
		}
	}

	if (fetchResponse.status === 200) {
		try {
			fetchData = await fetchResponse.json();
		} catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }

		if (fetchData.stock.available !== undefined) {
			const stock = {
				'stock': {
					'available': Number(fetchData.stock.available + quantityToRestore),
					'unit': fetchData.stock.unit
				}
			}
			if (fetchData.publication.status === 'ENDED') {
				if (fetchData.stock.available === 0) {
					stock.publication = {
						'status': 'ACTIVE'
					}
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					toastMessage(`Błąd! Aukcja ${fetchData.id} (${fetchData.name}) została zakończona z niezerowym stanem magazynowym. Tą aukcję wznów ręcznie.`);
					const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
					const errorOccured = Array.from(itemsToRestoreTable.querySelectorAll('span')).find(e => e.innerText === 'highlight_off');
					if (i === (itemsToRestore.length - 1)) return Promise.resolve({ cancelled: false, errorOccured: (errorOccured ? true : false) });
					else return await restoreItems(itemsToRestore, environment, accessToken, 5, ++i);
				}
			}

			try {
				await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
					'method': 'PATCH',
					'headers': {
						'Authorization': `Bearer ${accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					},
					body: JSON.stringify(stock)
				});
			}	catch (error) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await restoreItems(itemsToRestore, environment, accessToken, count, i);
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					if (i === (itemsToRestore.length - 1)) return Promise.reject(`Podczas wysyłania żądania nastąpił błąd. ${error?.message ? error.message : error}`);
					else return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
				}
			}
			if (fetchResponse.status === 200 || fetchResponse.status === 202) {
				setIconInCell('check_circle', row.cells[0], true);
				if (i === (itemsToRestore.length - 1)) {
					const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
					const errorOccured = Array.from(itemsToRestoreTable.querySelectorAll('span')).find(e => e.innerText === 'highlight_off');
					return Promise.resolve({ cancelled: false, errorOccured: (errorOccured ? true : false) });
				}	else return await restoreItems(itemsToRestore, environment, accessToken, 5, ++i);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
            if (!response.success) throw new Error(response.result);
					} catch (error) {
						setIconInCell('highlight_off', row.cells[0], true);
						return Promise.reject(error?.message ? error.message : error);
					}  
					if (response.result === undefined) {
						setIconInCell('highlight_off', row.cells[0], true);
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					return await restoreItems(itemsToRestore, environment, response.result, count, i);
				} else {
					return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. Nie udało się zalogować użytkownika.`);
				}
			} else if (fetchResponse.status === 403) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await restoreItems(itemsToRestore, environment, accessToken, count, i);   
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					if (i === (itemsToRestore.length - 1)) return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. ${error?.message ? error.message : error}`);
					else return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
				}												
			}
		} else {
			if (--count) {
				toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await restoreItems(itemsToRestore, environment, accessToken, count, i);   
			} else {
				setIconInCell('highlight_off', row.cells[0], true);
				if (i === (itemsToRestore.length - 1)) return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. ${error?.message ? error.message : error}`);
				else return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
			}												
		}
	}	else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
			} catch (error) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject(error?.message ? error.message : error);
			}  
			if (response.result === undefined) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			}
			return await restoreItems(itemsToRestore, environment, response.result, count, i);  
		} else {
			return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. Nie udało się zalogować użytkownika.`);
		}
	} else if (fetchResponse.status === 403) {
		setIconInCell('highlight_off', row.cells[0], true);
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await restoreItems(itemsToRestore, environment, accessToken, count, i);   
		} else {
			setIconInCell('highlight_off', row.cells[0], true);
			if (i === (itemsToRestore.length - 1)) return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. ${error?.message ? error.message : error}`);
			else return await restoreItems(itemsToRestore, environment, accessToken, count, ++i);
		}												
	}
}

function setIconInCell(iconName, place, replace = false) {
	const icon = document.createElement('span');
	icon.className = 'material-symbols-outlined';
	icon.innerText = iconName;
	if (!replace) place.appendChild(icon);
	else place.firstElementChild.replaceWith(icon);
}