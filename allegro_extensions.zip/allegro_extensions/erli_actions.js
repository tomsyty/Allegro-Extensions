async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function saveDataToSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromSessionStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.session.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}


window.addEventListener('load', async () => {
	console.log('Załadowano skrypt erliActions');
	try {
		await erliActionsAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}

  (function addStylesheet() {	
		const link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0&display=block';
		document.head.appendChild(link);
	})();

  await new Promise(resolve => setTimeout(resolve, 1000));
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="highlight_off"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'highlight_off';
		preloadIconsContainer.appendChild(iconHighlightOff);
	}
});

async function erliActionsAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await erliActionsAwaitOffersTable();
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await erliActionsAwaitOffersTable();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await erliActionsAwaitGroupOperationsBar();
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function erliActionsAwaitGroupOperationsBar() {
  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	if (offersTable.closest('div[data-box-name="allegro.myAssortment.list"]').querySelector('div#group-operations-bar') === null) {
    const groupOperationsBarObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.id === 'group-operations-bar')) {
            groupOperationsBarObserver.disconnect();
            try {
              await erliActionsAwaitGroupOperationsBar();
            } catch (error) {
              return Promise.reject(error?.message ? error.message : error);
            }
            break;
          }
        }
      }
    });
    groupOperationsBarObserver.observe(document, { subtree: true, childList: true });
  } else {
    const groupOperationsBar = offersTable.closest('div[data-box-name="allegro.myAssortment.list"]').querySelector('div#group-operations-bar');
    if (groupOperationsBar.querySelector('div[id="erliActions"]') !== null) {
      return Promise.resolve(true);
    }
    const erliActionsContainer = groupOperationsBar.querySelector('div[class="mp7g_oh"]').cloneNode(true);
    erliActionsContainer.id = 'erliActions';
    const erliActionsButton = erliActionsContainer.firstElementChild;
    erliActionsButton.childNodes[0].textContent = 'ERLI';

    erliActionsButton.addEventListener('click', erliActionsToggleSubmenu);
    erliActionsButton.addEventListener('blur', erliActionsButtonBlur);
    
    const erliActionsSubmenu = erliActionsContainer.lastElementChild;
    erliActionsSubmenu.setAttribute('aria-hidden', true);
    erliActionsSubmenu.style.display = 'none';
    erliActionsSubmenu.className = 'mjyo_6x msts_pt mp7g_f6 mg9e_0 mvrt_0 mj7a_0 mh36_0 mx7m_1 m911_co mefy_co mnyp_co mdwl_co mlkp_6x msbw_2 mldj_2 mtag_2 mm2b_2 eynyt myre_6m e1bhe mpof_ki mjb5_zq _b4f97_KawpV';
    const copyToErliButton = document.createElement('button');
    copyToErliButton.setAttribute('nonvisited', 'true');
    copyToErliButton.className = `mgn2_14 mp0t_0a mgmw_wo mqu1_21 mli8_k4 mqen_m6 l1o8h m911_5r mefy_5r mdwl_5r m0qj_5r msts_n7 ld19g mj9z_5r l5s4b mzmg_7i msa3_z4 mg9e_8 mj7a_8 mh36_16 mvrt_16 mjsg_q9 mgqx_91 mx7m_1 mnyp_co mlkp_ag mse2_40 m7er_k4 mjyo_6x _b4f97_oHYW7 mpof_z0`;
    copyToErliButton.id = 'copyToErliButton';
    copyToErliButton.textContent = 'kopiuj do Erli';
    copyToErliButton.addEventListener('click', performErliAction.bind(null, 'copy'));
    copyToErliButton.addEventListener('mouseenter', submenuItemMouseEnter);
    copyToErliButton.addEventListener('mouseleave', submenuItemMouseLeave);

    const synchronizeStockOnErliButton = copyToErliButton.cloneNode(false);
    synchronizeStockOnErliButton.id = 'synchronizeStockOnErliButton';
    synchronizeStockOnErliButton.textContent = 'uaktualnij stan magazynowy / cenę / stan aukcji w Erli';
    synchronizeStockOnErliButton.addEventListener('click', performErliAction.bind(null, 'stock'));
    synchronizeStockOnErliButton.addEventListener('mouseenter', submenuItemMouseEnter);
    synchronizeStockOnErliButton.addEventListener('mouseleave', submenuItemMouseLeave);

    const updateAuctionOnErliButton = copyToErliButton.cloneNode(false);
    updateAuctionOnErliButton.id = 'updateAuctionOnErliButton';
    updateAuctionOnErliButton.textContent = 'uaktualnij całą aukcję w Erli';
    updateAuctionOnErliButton.addEventListener('click', performErliAction.bind(null, 'update'));
    updateAuctionOnErliButton.addEventListener('mouseenter', submenuItemMouseEnter);
    updateAuctionOnErliButton.addEventListener('mouseleave', submenuItemMouseLeave);

    erliActionsSubmenu.appendChild(copyToErliButton);
    erliActionsSubmenu.appendChild(synchronizeStockOnErliButton);
    erliActionsSubmenu.appendChild(updateAuctionOnErliButton);
    groupOperationsBar.children[1].insertAdjacentElement('afterbegin', erliActionsContainer);
    const groupOperationsBarObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.id === 'group-operations-bar')) {
            groupOperationsBarObserver.disconnect();
            try {
              await erliActionsAwaitGroupOperationsBar();
            } catch (error) {
              return Promise.reject(error?.message ? error.message : error);
            }
            break;
          }
        }
      }
    });
    groupOperationsBarObserver.observe(document, { subtree: true, childList: true });
  }
}

function submenuItemMouseEnter(e) {
  e.target.closest('div[id="erliActions"]').dataset.hovered = 'true';
}

function submenuItemMouseLeave(e) {
  delete e.target.closest('div[id="erliActions"]').dataset.hovered;
}

function erliActionsButtonBlur(e) {
  const erliActionsContainer =  e.target.closest('div[id="erliActions"]');
  if (!erliActionsContainer.dataset?.hovered) {
    const erliActionsSubmenu = erliActionsContainer.querySelector('div[aria-hidden="false"]');
    if (erliActionsSubmenu) {
      erliActionsSubmenu.setAttribute('aria-hidden', 'true');
      erliActionsSubmenu.style.display = 'none';
      e.target.nodeName === 'SPAN' ? e.target.style.transform = 'rotate(-90deg)' : e.target.firstElementChild.style.transform = 'rotate(-90deg)';
    }
  }
}

function erliActionsToggleSubmenu(e) {
  const erliActionsSubmenu = (e.target.nodeName === 'SPAN' ? e.target.parentElement.nextElementSibling : e.target.nextElementSibling);
  const clickedElement = (e.target.nodeName === 'SPAN' ? e.target : e.target.firstElementChild);

  const currentValue = erliActionsSubmenu.getAttribute('aria-hidden');
  erliActionsSubmenu.setAttribute('aria-hidden', currentValue === 'true' ? 'false' : 'true');
  if (erliActionsSubmenu.getAttribute('aria-hidden') === 'true') {
    erliActionsSubmenu.style.display = 'none';
    clickedElement.style.transform = 'rotate(-90deg)';
  } else {
    erliActionsSubmenu.style.display = 'flex';
    clickedElement.style.transform = 'rotate(90deg)';
  }
}

async function performErliAction(action) {
  document.activeElement.blur();

  const erliActionsSubmenu = document.querySelector('div[id="erliActions"] div[aria-hidden="false"]');
  if (erliActionsSubmenu) {
    erliActionsSubmenu.style.display = 'none';
    erliActionsSubmenu.setAttribute('aria-hidden', 'true');
    erliActionsSubmenu.previousElementSibling.querySelector('span').style.transform = 'rotate(-90deg)';
  }

  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
  const frozenFieldsNames = {
    'name': 'tytuł',
    'description': 'opis',
    'ean': 'EAN',
    'externalAttributes': 'atrybuty',
    'externalCategories': 'kategoria',
    'images': 'zdjęcia',
    'price': 'cena',
    'stock': 'stan magazynowy',
    'status': 'status',
    'dispatchTime': 'czas realizacji',
    'invoiceType': 'typ faktury',
    'taxRate': 'stawka VAT'
  };

  const selectedOffers = Array.from(offersTable.querySelectorAll('input[type="checkbox"]:checked')).map(checkbox => checkbox.closest('tr').dataset.cy);
  if (selectedOffers.length === 0) {
    toastMessage('Nie zaznaczono żadnej oferty!');
    return;
  }

  let readedValue;

  try {
    readedValue = await readDataFromLocalStorage(['erliToken', 'erliTokenSandbox', 'erliAlwaysSyncToSandbox', 'erliPriceListName', 'erliObligatoryName', 'erliVoluntaryName', 'erliReturnsName', 'erliPriceApplyDiscountCheckbox']);
    if (readedValue['erliToken'] === undefined) {
      toastMessage('Nie znaleziono tokena Erli.');
      return;
    }
    if (readedValue['erliTokenSandbox'] === undefined) {
      toastMessage('Nie znaleziono tokena Erli (Sandbox).');
      return;
    }
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  }

  const sandbox =  (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const allegroEnvironment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let erliToken;
  let erliEnvironment;
  if (readedValue['erliAlwaysSyncToSandbox'] === true) {
    erliEnvironment = 'sandbox.erli.dev';
    erliToken = readedValue['erliTokenSandbox'];
  } else { 
    if (sandbox === 'Sandbox') {
      erliEnvironment = 'sandbox.erli.dev';
      erliToken = readedValue['erliTokenSandbox'];
    } else {
      erliEnvironment = 'erli.pl';
      erliToken = readedValue['erliToken'];
    }
  }
  
  const erliPriceListName = readedValue[`erliPriceListName`];
  const erliObligatoryName = readedValue[`erliObligatoryName`];
  const erliVoluntaryName = readedValue[`erliVoluntaryName`];
  const erliReturnsName = readedValue[`erliReturnsName`];

  let erliPriceAmountRadio, erliPricePercentRadio, erliPriceStepsRadio, erliPriceAmountValue, erliPricePercentValue, erliPriceSteps;

  const applyDiscount = readedValue['erliPriceApplyDiscountCheckbox'] === true;
  if (applyDiscount) {
    try {
      readedValue = await readDataFromLocalStorage(['erliPriceAmountRadio', 'erliPricePercentRadio', 'erliPriceStepsRadio', 'erliPriceAmountValue', 'erliPricePercentValue', 'erliPriceSteps']);
    } catch (error) {
      toastMessage(`Błąd! Wybrano zastosowanie rabatu, ale nie znaleziono danych o rabacie. ${error?.message ? error.message : error}`);
      return;
    }
    erliPriceAmountRadio = readedValue['erliPriceAmountRadio'];
    erliPricePercentRadio = readedValue['erliPricePercentRadio'];
    erliPriceStepsRadio = readedValue['erliPriceStepsRadio'];
    erliPriceAmountValue = readedValue['erliPriceAmountValue'];
    erliPricePercentValue = readedValue['erliPricePercentValue'];
    erliPriceSteps = readedValue['erliPriceSteps'];
  }
  
  if (applyDiscount && (erliPriceAmountRadio === undefined || erliPricePercentRadio === undefined || erliPriceStepsRadio === undefined || erliPriceAmountValue === undefined || erliPricePercentValue === undefined || erliPriceSteps === undefined)) {
    toastMessage('Wybrano zastosowanie rabatu, ale nie znaleziono danych o rabacie. Proszę sprawdzić ustawienia rozszerzenia.');
    return;
  }

  let erliActionsProgress = document.getElementById('erliActionsProgress');
  if (erliActionsProgress === null) {
    let insertionPoint;
    try {
      insertionPoint = offersTable.closest('div[class="msts_pt"]')?.nextElementSibling;
      if (!insertionPoint) throw new Error('Nie znaleziono odpowiedniego miejsca na stronie.');
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      return;
    }
    insertionPoint.insertAdjacentHTML('afterbegin', `<div id="erliActionsProgressBox"><label for="erliActionsProgress">${action === 'copy' ? 'Kopiowanie aukcji do' : 'Aktualizowanie aukcji w'} Erli</label><progress id="erliActionsProgress" value="0">0%</progress><span id="erliActionsCloseContainer" class="material-symbols-outlined fs28">close</span></div>`);
    const erliActionsCloseContainer = document.getElementById('erliActionsCloseContainer');
    erliActionsCloseContainer.addEventListener('click', () => {
      erliActionsCloseContainer.closest('div#erliActionsProgressBox').remove();
    });
  }
  erliActionsProgress = document.getElementById('erliActionsProgress');
  erliActionsProgress.value = 0;
  erliActionsProgress.max = selectedOffers.length;

  let response, erliResponse;
  let allegroAccessToken;
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) { 
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  }
  allegroAccessToken = response.result;

  let erliOfferData, allegroOfferData;

  const invoiceTypes = {
    'VAT': 'vatInvoice',
    'VAT_MARGIN': 'vatInvoiceWithMarginScheme',
    'WITHOUT_VAT': 'invoiceWithoutVat',
    'NO_INVOICE': 'withoutInvoice'
  }

  const taxRates = {
    '23.00': 'TAX_23',
    '8.00': 'TAX_8',
    '5.00': 'TAX_5',
    '0.00': 'TAX_0'
  }

  if (action === 'copy' || action === 'update') {
    do {
      const offerId = selectedOffers.shift();
      let images = [];
      try {
        response = await getAuctionFromAllegro(allegroEnvironment, allegroAccessToken, offerId, 5); 
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        break;
      }

      if (response.newToken) {
        allegroAccessToken = response.newToken;
      }

      allegroOfferData = response.result;
      let categoryTree;

      try {
        response = await getAllegroCategory(allegroEnvironment, allegroAccessToken, allegroOfferData.category.id, undefined, 5);
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        break;
      }
      categoryTree = response.result;
      categoryTree.reverse();
        
      if (response.newToken) {
        allegroAccessToken = response.newToken;
      }

      erliOfferData = {};
      erliOfferData.name = allegroOfferData.name;
      erliOfferData.ean = allegroOfferData.productSet[0].product.parameters.find(parameter => parameter.name === 'EAN (GTIN)')?.values[0];
      erliOfferData.description = allegroOfferData.description;
      allegroOfferData.images.forEach(image => { 
        images.push({ url: image });
      });
      erliOfferData['images'] = images;
      erliOfferData.cataloguePrice = erliOfferData.price = Number(allegroOfferData.sellingMode.price.amount.replace('.', ''));
      erliOfferData.referencePriceType = 'cataloguePrice';
      if (applyDiscount) {
        const price = Number(allegroOfferData.sellingMode.price.amount);
        let lowerPrice;
        if (erliPriceAmountRadio === true) {
          lowerPrice = price - erliPriceAmountValue;
        } else if (erliPricePercentRadio === true) {
          lowerPrice = price - (price * (erliPricePercentValue / 100));
        } else if (erliPriceStepsRadio === true) {
          lowerPrice = price;
          const maxIndex = erliPriceSteps.length - 1;
          const discount = erliPriceSteps.find((step, index) => { return (price >= step.amount) && (index < maxIndex) && (price < erliPriceSteps[index + 1].amount) });
          if (discount !== undefined) lowerPrice = price - discount.value;
        }
        erliOfferData.price = Number(lowerPrice.toFixed(2).replace('.', ''));
      } else {
        erliOfferData.price = Number(allegroOfferData.sellingMode.price.amount.replace('.', ''));
      }
      erliOfferData.stock = allegroOfferData.stock.available;
      erliOfferData.status = (allegroOfferData.publication.status === 'ACTIVE' ? 'active' : 'inactive');
      period = extractDurationNumber(allegroOfferData.delivery.handlingTime);
      erliOfferData.dispatchTime = {
        period: (period === 0 || period === 24 ? 1 : period)
      }
      erliOfferData.invoiceType = invoiceTypes[allegroOfferData.payments.invoice];
      if (allegroOfferData.taxSettings?.rates && allegroOfferData.taxSettings.rates.find(rate => rate.countryCode === 'PL') !== undefined) {
        const taxRate = allegroOfferData.taxSettings.rates.find(rate => rate.countryCode === 'PL');
        erliOfferData.taxRate = taxRates[taxRate.rate];
      }
      
      if (action === 'copy') {
        erliOfferData.obligatoryIdentifier = erliObligatoryName;
        erliOfferData.voluntaryIdentifier = erliVoluntaryName;
        erliOfferData.returnIdentifier = erliReturnsName; ;
        erliOfferData.deliveryPriceList = erliPriceListName;
      }
      erliOfferData.externalReferences = [{
        id: allegroOfferData.id,
        kind: 'allegro'
      }];
      erliOfferData.externalCategories = [{
        source: 'allegro',
        breadcrumb: categoryTree
      }]; 
      erliOfferData.externalAttributes = (allegroOfferData.productSet[0].product.parameters.concat(allegroOfferData.parameters)).map(attribute => { 
        if (attribute.rangeValue !== null) {
          return {
            source: 'allegro',
            id: attribute.id,
            name: attribute.name,
            type: 'range',
            values: {
              from: Number(attribute.rangeValue.from),
              to: Number(attribute.rangeValue.to)
            }
          }
        } 

        if (attribute.valuesIds !== null) {
          let values = [];
          attribute.values.forEach((value, index) => {
            values.push({
              id: attribute.valuesIds[index],
              name: value
            })
          });
          return {
            source: 'allegro',
            id: attribute.id,
            name: attribute.name,
            type: 'dictionary',
            values: values
          }
        }

        return {
          source: 'allegro',
          id: attribute.id,
          name: attribute.name,
          type: 'string',
          values: attribute.values
        }
      });

      let readedValue;
      let erliResponsibleProducers = [];
      if (allegroOfferData.productSet[0].responsibleProducer === null) {
        erliOfferData.externalResponsibleProducer = [];
      } else {        
        try {
          readedValue = await readDataFromLocalStorage(['responsibleProducers']);
        } catch (error) {
          toastMessage(`Błąd! ${error?.message ? error.message : error}`);
          break;
        }
        if (readedValue['responsibleProducers']?.length > 0) {
          erliResponsibleProducers = readedValue['responsibleProducers'];
        } 
        if (erliResponsibleProducers.find(id => id === allegroOfferData.productSet[0].responsibleProducer.id) === undefined) {
          let retriesLeft = 5;
          do {
            try {
              response = await backgroundFetch(`https://api.allegro.pl${allegroEnvironment}/sale/responsible-producers/${allegroOfferData.productSet[0].responsibleProducer.id}`, {
                'method': 'GET',
                'headers': {
                  'Authorization': `Bearer ${allegroAccessToken}`,
                  'Accept': 'application/vnd.allegro.public.v1+json',
                  'Content-Type': 'application/vnd.allegro.public.v1+json'
                }
              });
            } catch (error) {
              toastMessage(`Błąd! ${error?.message ? error.message : error}`);
              break;
            }
            if (response.status === 200) {
              let result;
              try {
                result = await response.json();
              } catch (error) {
                toastMessage(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
                break;
              }

              const producerDataId = result.id;
              let retriesLeft = 5;
              do {
                retriesLeft--;
                try {
                  erliResponse = await backgroundFetch(`https://${erliEnvironment}/svc/shop-api/dictionaries/responsibleProducers`, {
                    'method': 'POST',
                    'headers': {
                      'Authorization': `Bearer ${erliToken}`,
                      'Content-Type': 'application/json',
                      'Accept': 'application/json'
                    },
                    'body': JSON.stringify({
                      name: result.name,
                      idempotenceKey: result.id,
                      properName: result.producerData.tradeName,
                      country: result.producerData.address.countryCode,
                      address: result.producerData.address.street,
                      postalCode: result.producerData.address.postalCode,
                      city: result.producerData.address.city,
                      phone: result.producerData.contact.phoneNumber,
                      email: result.producerData.contact.email,
                      source: 'allegro'
                    })
                  })
                } catch (error) {
                  toastMessage(`Błąd! ${error?.message ? error.message : error}`);
                  break;
                }

                if (erliResponse.status === 200) {
                  toastMessage(`Dodano nowego producenta odpowiedzialnego (${result.name}) do Erli.`);
                  erliResponsibleProducers.push(producerDataId);
                  await new Promise(resolve => setTimeout(resolve, 1000));
                  break;
                } else if (erliResponse.status === 409) {
                  erliResponsibleProducers.push(producerDataId);
                  break;
                } else {
                  toastMessage(`Ponawianie próby wysyłania żądania (${5 - retriesLeft} z 5), proszę czekać...`);
                  await new Promise(resolve => setTimeout(resolve, 5000));
                }
              } while (retriesLeft);
              if (!retriesLeft) {
                toastMessage(`Błąd! Nie udało się dodać producenta odpowiedzialnego do Erli. Kod odpowiedzi HTTP: ${response.status}`);
                break;
              }

              try {
                await saveDataToLocalStorage({ responsibleProducers: erliResponsibleProducers });
              } catch (error) {
                toastMessage(`Błąd! ${error?.message ? error.message : error}`); 
              }
              break;
            } else if (response.status === 401) {
              if (--retriesLeft) {
                try {
                  response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                  if (!response.success) throw new Error(response.result);
                } catch (error) {
                  toastMessage(`Błąd! ${error?.message ? error.message : error}`);
                  break;
                }
                if (response.result === undefined) {
                  toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
                  break;
                }
                allegroAccessToken = response.result;
              } else {
                toastMessage('Błąd! Nie udało się pobrać producenta odpowiedzialnego z Allegro. Nie udało się zalogować użytkownika.');
                break;
              }
            } else if (response.status === 403) {
              toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
              break;
            } else {
              if (--retriesLeft) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - retriesLeft} z 5), proszę czekać...`);
                await new Promise(resolve => setTimeout(resolve, 5000));
              } else {
                const responseJSON = await response.json();
                toastMessage(`Błąd! Nie udało się pobrać producenta odpowiedzialnego z Allegro. Kod odpowiedzi HTTP: ${response.status}, ${responseJSON?.errors[0]?.userMessage}`);
                break;
              }
            }
          } while (retriesLeft);
          if (!retriesLeft) {
            const responseJSON = await response.json();
            toastMessage(`Błąd! Nie udało się pobrać producenta odpowiedzialnego z Allegro. Kod odpowiedzi HTTP: ${response.status}, ${responseJSON?.errors[0]?.userMessage}`);
            break;
          }
        }
      }

      if (allegroOfferData.productSet[0].responsibleProducer) {
        if (erliResponsibleProducers.find(id => id === allegroOfferData.productSet[0].responsibleProducer.id) === undefined) {
          toastMessage(`Uwaga! Nie znaleziono producenta odpowiedzialnego (${allegroOfferData.productSet[0].responsibleProducer.name}) w Erli, aukcja zostanie dodana bez producenta.`);
          erliOfferData.externalResponsibleProducer = [];
        } else {
          erliOfferData.externalResponsibleProducer = [{
            externalId: allegroOfferData.productSet[0].responsibleProducer.id,
            source: 'allegro'
          }];
        }
      }

      let erliResponsiblePersons = [];
      if (allegroOfferData.productSet[0].responsiblePerson === null) {
        erliOfferData.externalResponsiblePerson = [];
      } else {
        try {
          readedValue = await readDataFromLocalStorage(['responsiblePersons']);
        } catch (error) {
          toastMessage(`Błąd! ${error?.message ? error.message : error}`);
          break;
        }
        if (readedValue['responsiblePersons']?.length > 0) {
          erliResponsiblePersons = readedValue['responsiblePersons'];
        } else {
          toastMessage('Pobieranie listy osób odpowiedzialnych z Erli...');
          retriesLeft = 5;
          do {
            try {
              erliResponse = await backgroundFetch(`https://${erliEnvironment}/svc/shop-api/dictionaries/responsiblePersons`, {
                'method': 'GET',
                'headers': {
                  'Authorization': `Bearer ${erliToken}`,
                  'Content-Type': 'application/json',
                  'Accept': 'application/json'
                }
              });
            } catch (error) {
              toastMessage(`Błąd! ${error?.message ? error.message : error}`);
              break;
            }
            if (erliResponse.status === 200) {
              let responsiblePersons;
              try {
                responsiblePersons = await erliResponse.json();
              } catch (error) {
                toastMessage(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
                break;
              }
              erliResponsiblePersons = responsiblePersons.map(person => { return person.idempotenceKey });  
              break;
            } else {
              if (--retriesLeft) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - retriesLeft} z 5), proszę czekać...`);
                await new Promise(resolve => setTimeout(resolve, 5000));
              } else {
                toastMessage(`Błąd! Nie udało się pobrać lsity osób odpowiedzialnych z Erli. Kod odpowiedzi HTTP: ${erliResponse.status}`);
                break;
              }
            }  
          } while (retriesLeft);
        } 

        if (erliResponsiblePersons.find(id => id === allegroOfferData.productSet[0].responsiblePerson.id) === undefined) {
          toastMessage('Aktualizowanie listy osób odpowiedzialnych z Allegro...');
          let retriesLeft = 5;
          do {
            try {
              response = await backgroundFetch(`https://api.allegro.pl${allegroEnvironment}/sale/responsible-persons`, {
                'method': 'GET',
                'headers': {
                  'Authorization': `Bearer ${allegroAccessToken}`,
                  'Accept': 'application/vnd.allegro.public.v1+json',
                  'Content-Type': 'application/vnd.allegro.public.v1+json'
                }
              });
            } catch (error) {
              toastMessage(`Błąd! ${error?.message ? error.message : error}`);
              break;
            }
            if (response.status === 200) {
              let result;
              try {
                result = await response.json();
              } catch (error) {
                toastMessage(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
                break;
              }

              let retriesLeft = 5;
              let person;
              do {
                person = result.responsiblePersons.shift();
                if (erliResponsiblePersons.find(id => id === person.id) === undefined) {
                  try {
                    erliResponse = await backgroundFetch(`https://${erliEnvironment}/svc/shop-api/dictionaries/responsiblePersons`, {
                      'method': 'POST',
                      'headers': {
                        'Authorization': `Bearer ${erliToken}`,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                      },
                      'body': JSON.stringify({
                        name: person.name,
                        idempotenceKey: person.id,
                        properName: person.personalData.name,
                        country: person.personalData.address.countryCode,
                        address: person.personalData.address.street,
                        postalCode: person.personalData.address.postalCode,
                        city: person.personalData.address.city,
                        phone: person.personalData.contact.phoneNumber,
                        email: person.personalData.contact.email,
                        source: 'allegro'
                      })
                    })
                  } catch (error) {
                    toastMessage(`Błąd! Nie udało się dodać osoby odpowiedzialnej do Erli. ${error?.message ? error.message : error}`);
                  }
    
                  if (erliResponse.status === 200) {
                    toastMessage(`Dodano nową osobę odpowiedzialną (${person.name}) do Erli.`);
                    erliResponsiblePersons.push(person.id);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                  } else if (erliResponse.status === 409) {
                    erliResponsiblePersons.push(person.id);
                  } else {
                    retriesLeft--;
                    toastMessage(`Ponawianie próby wysyłania żądania (${5 - retriesLeft} z 5), proszę czekać...`);
                    await new Promise(resolve => setTimeout(resolve, 5000));
                  }
                }
              } while (retriesLeft && result.responsiblePersons.length > 0);

              await saveDataToLocalStorage({ responsiblePersons: erliResponsiblePersons });

              if (!retriesLeft) {
                toastMessage(`Błąd! Nie udało się dodać wszystkich osób odpowiedzialnych do Erli. Kod odpowiedzi HTTP: ${erliResponse.status}`);
              }
              break;
            } else if (response.status === 401) {
              if (--retriesLeft) {
                try {
                  response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                  if (!response.success) throw new Error(response.result);
                } catch (error) {
                  toastMessage(`Błąd! ${error?.message ? error.message : error}`);
                  break;
                }
                if (response.result === undefined) {
                  toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
                  break;
                }
                allegroAccessToken = response.result;
              } else {
                toastMessage('Błąd! Nie udało się pobrać listy osób odpowiedzialnych z Allegro. Nie udało się zalogować użytkownika.');
                break;
              }
            } else if (response.status === 403) {
              toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
              break;
            } else {
              if (--retriesLeft) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - retriesLeft} z 5), proszę czekać...`);
                await new Promise(resolve => setTimeout(resolve, 5000));
              } else {
                const responseJSON = await response.json();
                toastMessage(`Błąd! Nie udało się pobrać listy osób odpowiedzialnych z Allegro. Kod odpowiedzi HTTP: ${response.status}`);
                break;
              }
            }
          } while (retriesLeft);
          if (!retriesLeft) {
            const responseJSON = await response.json();
            toastMessage(`Błąd! Nie udało się pobrać listy osób odpowiedzialnych z Allegro. Kod odpowiedzi HTTP: ${response.status}`);
            break;
          }

          try {
            readedValue = await readDataFromLocalStorage(['responsiblePersons']);
            erliResponsiblePersons = readedValue['responsiblePersons'];
          } catch (error) {
            toastMessage(`Błąd! ${error?.message ? error.message : error}`);
            break;
          }

          if (erliResponsiblePersons.find(id => id === allegroOfferData.productSet[0].responsiblePerson.id) === undefined) {
            toastMessage(`Uwaga! Nie znaleziono osoby odpowiedzialnej (${allegroOfferData.productSet[0]}) w Erli, aukcja zostanie dodana bez osoby odpowiedzialnej.`);
            erliOfferData.externalResponsiblePerson = [];
          } else {
            erliOfferData.externalResponsiblePerson = [{
              externalId: allegroOfferData.productSet[0].responsiblePerson.id,
              source: 'allegro'
            }];
          }
        } else {
          erliOfferData.externalResponsiblePerson = [{
            externalId: allegroOfferData.productSet[0].responsiblePerson.id,
            source: 'allegro'
          }];
        }
      }

      try {
        if (action === 'copy') response = await copyToErli(erliEnvironment, erliToken, offerId, erliOfferData);
        else response = await updateOnErli(erliEnvironment, erliToken, offerId, erliOfferData);
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        break;
      }

      erliActionsProgress.value++;
      const checkbox = offersTable.querySelector(`input[id="${offerId}"]`);
      if (checkbox !== null) {
        checkbox.setAttribute('aria-checked', 'false');
        checkbox.setAttribute('value', 'false');
        checkbox.checked = false;
        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
      }

      if (action === 'copy') {
        if (response.copied === false) {
          toastMessage(`Aukcja ${offerId} już istnieje w Erli, pominięto.`);
        } 
        if (response?.responsibleProducer === false) {
          toastMessage(`Uwaga! Aukcja ${offerId} została skopiowana do Erli bez producenta odpowiedzialnego.`);
        }
      }

      if (response.frozen) {
        toastMessage(`Uwaga! Aukcja ${offerId} w Erli ma zablokowane do edycji pola: ` + response.frozen.map((field => frozenFieldsNames[field])).join(', '));
      }

    } while (selectedOffers.length > 0);
  } else {
    do {
      const offerId = selectedOffers.shift();
      
      try {
        response = await getAuctionFromAllegro(allegroEnvironment, allegroAccessToken, offerId, 5); 
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        break;
      }

      if (response.newToken) {
        allegroAccessToken = response.newToken;
      }

      allegroOfferData = response.result;

      erliOfferData = {};
      erliOfferData.cataloguePrice = erliOfferData.price = Number(allegroOfferData.sellingMode.price.amount.replace('.', ''));
      erliOfferData.referencePriceType = 'cataloguePrice';
      if (applyDiscount) {
        const price = Number(allegroOfferData.sellingMode.price.amount);
        let lowerPrice;
        if (erliPriceAmountRadio === true) {
          lowerPrice = price - erliPriceAmountValue;
        } else if (erliPricePercentRadio === true) {
          lowerPrice = price - (price * (erliPricePercentValue / 100));
        } else if (erliPriceStepsRadio === true) {
          lowerPrice = price;
          const maxIndex = erliPriceSteps.length - 1;
          const discount = erliPriceSteps.find((step, index) => { return (price >= step.amount) && (index < maxIndex) && (price < erliPriceSteps[index + 1].amount) });
          if (discount !== undefined) lowerPrice = price - discount.value;
        }
        erliOfferData.price = Number(lowerPrice.toFixed(2).replace('.', ''));
      } else {
        erliOfferData.price = Number(allegroOfferData.sellingMode.price.amount.replace('.', ''));
      }
      erliOfferData.stock = allegroOfferData.stock.available;
      erliOfferData.status = (allegroOfferData.publication.status === 'ACTIVE' ? 'active' : 'inactive');

      try {
        response = await updateStockOnErli(erliEnvironment, erliToken, offerId, erliOfferData);
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        break;
      }

      if (response.frozen) {
        toastMessage(`Uwaga! Aukcja ${offerId} w Erli ma zablokowane do edycji pola: ` + response.frozen.map((field => frozenFieldsNames[field])).join(', '));
      }

      erliActionsProgress.value++;
      const checkbox = offersTable.querySelector(`input[id="${offerId}"]`);
      if (checkbox !== null) {
        checkbox.setAttribute('aria-checked', 'false');
        checkbox.setAttribute('value', 'false');
        checkbox.checked = false;
        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
      }
    } while (selectedOffers.length > 0);
  }
}

function extractDurationNumber(duration) {
  const match = duration.match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

async function getAllegroCategory(environment, allegroAccessToken, categoryId, categoryTree, count, tokenRefreshed) {
  if (categoryTree === undefined) {
    categoryTree = [];
  }

  let response;

  try {
    response = await backgroundFetch(`https://api.allegro.pl${environment}/sale/categories/${categoryId}`, {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${allegroAccessToken}`,
        'Accept': 'application/vnd.allegro.public.v1+json',
        'Content-Type': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getAllegroCategory(environment, allegroAccessToken, categoryId, categoryTree, count, tokenRefreshed);      
    } else {
      return Promise.reject(`Nie udało się pobrać kategorii ${categoryId} z Allegro. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200) {
    let result;
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }

    categoryTree.push({
      id: result.id,
      name: result.name
    });

    if (result.parent !== null) {
      return await getAllegroCategory(environment, allegroAccessToken, result.parent.id, categoryTree, 5, tokenRefreshed);
    } else {
      return Promise.resolve({ result: categoryTree, newToken: (tokenRefreshed ? allegroAccessToken : undefined) });
    }
  } else if (response.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      allegroAccessToken = response.result;
      return await getAllegroCategory(environment, allegroAccessToken, categoryId, categoryTree, count, true);
    } else {
      return Promise.reject('Nie udało się pobrać kategorii z Allegro. Nie udało się zalogować użytkownika.');
    }
  } 
}

async function getAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed) {
  let response;
  try {
    response = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/vnd.allegro.public.v1+json',
        'Content-Type': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);      
    } else {
      return Promise.reject(`Nie udało się pobrać aukcji ${offerId} z Allegro. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200) {
    let result;
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    return Promise.resolve({ result: result, newToken: (tokenRefreshed ? accessToken : undefined) });
  } else if (response.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(error?.message ? error.message : error);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      accessToken = response.result;
      return await getAuctionFromAllegro(environment, accessToken, offerId, count, true);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getAuctionFromAllegro(environment, accessToken, offerId, count, tokenRefreshed);    
    } else {
      return Promise.reject(`Nie udało się pobrać aukcji ${offerId} z Allegro. Kod odpowiedzi HTTP: ${response.status}`);
    }	
  }
}

async function copyToErli(environment, accessToken, offerId, offerData, count = 5) {
  let response;
  try {
    response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'POST',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await copyToErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się skopiować aukcji ${offerId} do Erli. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200 || response.status === 202) {
    try {
      response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
        'method': 'PATCH',
        'headers': {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        'body': JSON.stringify({externalResponsibleProducer: offerData.externalResponsibleProducer})
      });
    } catch (error) {
      return Promise.resolve({ result: offerId, copied: true, responsibleProducer: false });
    }
    if (response.status === 202) {
      return Promise.resolve({ result: offerId, copied: true });
    } else if (response.status === 429) {
      if (--count) {
        toastMessage(`Przekroczono limit zapytań, ponawianie próby wysyłania żądania po chwili przerwy (${5 - count} z 5), proszę czekać...`);
        await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
        return await copyToErli(environment, accessToken, offerId, offerData, count);
      } else {
        return Promise.reject(`Nie udało się skopiować aukcji ${offerId} do Erli. Przekroczono limit zapytań. ${error?.message ? error.message : error}`);
      }
    } else {
      return Promise.resolve({ result: offerId, copied: true, responsibleProducer: false });
    }
  } else if (response.status === 409) {
    return Promise.resolve({ result: offerId, copied: false });
  } else if (response.status === 429) {
    if (--count) {
      toastMessage(`Przekroczono limit zapytań, ponawianie próby wysyłania żądania po chwili przerwy (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await copyToErli(environment, accessToken, offerId, offerData, count);
    } else {
      return Promise.reject(`Nie udało się skopiować aukcji ${offerId} do Erli. Przekroczono limit zapytań. ${error?.message ? error.message : error}`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await copyToErli(environment, accessToken, offerId, offerData, count);
    } else {
      let result;
      try {
        result = await response.json();
      } catch (error) {
        return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      if (result === undefined) result = { message: 'Brak szczegółów błędu.' };
      return Promise.reject(`Nie udało się skopiować aukcji ${offerId} do Erli. Kod odpowiedzi HTTP: ${response.status}. ${result.message}`);
    }
  }
}

async function updateOnErli(environment, accessToken, offerId, offerData, count = 5) {
  let response;
  let frozenFields = [];
  let result;
  try {
    response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać danych aukcji ${offerId} w Erli. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200) {
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    frozenFields = Object.entries(result.frozen).filter(field => field[1] === true && ['name', 'description', 'ean', 'externalAttributes', 'externalCategories', 'images', 'price', 'stock', 'status', 'dispatchTime', 'invoiceType', 'taxRate'].indexOf(field[0]) !== -1).map(element => element[0]);
  } else if (response.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else if (response.status === 429) {
    if (--count) {
      toastMessage(`Przekroczono limit zapytań, ponawianie próby wysyłania żądania po chwili przerwy (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      return Promise.reject(`Nie udało się pobrać danych aukcji ${offerId} w Erli. Przekroczono limit zapytań. ${error?.message ? error.message : error}`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      let result;
      try {
        result = await response.json();
      } catch (error) {
        return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      if (result === undefined) result = { message: 'Brak szczegółów błędu.' };
      return Promise.reject(`Nie udało się zmienić aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${response.status}. ${result.message}`);
    }
  }

  try {
    response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'PATCH',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się zmienić aukcji ${offerId} w Erli. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200 || response.status === 202) {
    if (frozenFields?.length) return Promise.resolve({ result: offerId, copied: true, frozen: frozenFields });
    else return Promise.resolve({ result: offerId, copied: true });
  } else if (response.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else if (response.status === 409) {
    return Promise.resolve({ result: offerId, copied: false });
  } else if (response.status === 429) {
    if (--count) {
      toastMessage(`Przekroczono limit zapytań, ponawianie próby wysyłania żądania po chwili przerwy (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      return Promise.reject(`Nie udało się zmienić aukcji ${offerId} w Erli. Przekroczono limit zapytań. ${error?.message ? error.message : error}`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      let result;
      try {
        result = await response.json();
      } catch (error) {
        return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      if (result === undefined) result = { message: 'Brak szczegółów błędu.' };
      return Promise.reject(`Nie udało się zmienić aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${response.status}. ${result.message}`);
    }
  }
}

async function updateStockOnErli(environment, accessToken, offerId, offerData, count = 5) {
  let response;
  let frozenFields = [];
  let result;

  try {
    response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać danych aukcji ${offerId} w Erli. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200) {
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
    }
    frozenFields = Object.entries(result.frozen).filter(field => field[1] === true && ['price', 'stock', 'status'].indexOf(field[0]) !== -1).map(element => element[0]);
  } else if (response.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateStockOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      result = await response.json();
      return Promise.reject(`Nie udało się pobrać danych aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${response.status}. ${result.message}`);
    }
  }

  try {
    response = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'PATCH',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się zmienić stanu magazynowego / ceny / statusu aukcji ${offerId} w Erli. ${error?.message ? error.message : error}`);
    }
  }

  if (response.status === 200 || response.status === 202) {
    if (frozenFields?.length) return Promise.resolve({ result: offerId, frozen: frozenFields });
    else return Promise.resolve({ result: offerId });
  } else if (response.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await updateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      result = await response.json();
      return Promise.reject(`Nie udało się zmienić stanu magazynowego / ceny / statusu aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${response.status}. ${result.message}`);
    }
  }
}
