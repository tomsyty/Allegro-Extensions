async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt autofillPackageSize');
	const observer = new MutationObserver(mutations => {
		mutations.forEach(async (mutation) => {
			if (mutation.type === 'childList') {
				const addedHeader = Array.from(document.querySelectorAll('H5'))?.find(headerElement => headerElement.textContent === 'Lista przesyłek do nadania:' && headerElement.dataset.autofillNew === undefined);
				if (addedHeader) {
					addedHeader.dataset.autofillNew = 'false';
					let deliveryMethod;
					do {
						deliveryMethod = Array.from(addedHeader.parentElement.querySelectorAll('span'))?.find(span => span.innerText === 'METODA DOSTAWY')?.nextElementSibling?.innerText;
						if (!deliveryMethod) await new Promise(resolve => setTimeout(resolve, 200));
					} while (!deliveryMethod);
					autofillPackageSize(deliveryMethod);
				}
			}
		});
	});

	observer.observe(document.body, { subtree: true, childList: true });

	let orderId = document.location.href.split('/');
	orderId = orderId[orderId.length - 1].split('?')[0];
	if (orderId.indexOf(',') !== -1) document.body.dataset.multipleOrders = 'true';
	else document.body.dataset.multipleOrders = 'false';

	const deliveryMethod = Array.from(document.querySelectorAll('span'))?.find(span => span.innerText === 'METODA DOSTAWY')?.nextElementSibling?.innerText;
	if (deliveryMethod) {
		autofillPackageSize(deliveryMethod);
	}
});

async function autofillPackageSize(deliveryMethod) {
	console.log('autofillPackageSize: metoda dostawy to ' + deliveryMethod);
	const multipleOrders = (document.body.dataset.multipleOrders === 'true');

	let buttonNodes = Array.from(document.querySelectorAll('button'));
	let orderShipmentsButton;
	let saveButton;
	if (buttonNodes.length) {
		orderShipmentsButton = buttonNodes.find(element => element.textContent === 'Zamów przesyłki');
		saveButton = buttonNodes.find(element => element.textContent === 'Zapisz');
	}

	if (orderShipmentsButton !== undefined && saveButton !== undefined) {
		console.log('autofillPackageSize: znaleziono przyciski "Zapisz" i "Zamów przesyłki"');
		
		saveButton.disabled = true;
		if (multipleOrders) {
			autofillPackageSizePrepareShipmentContainers();
		}

		const shipmentContainer = saveButton.closest('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a1b65"]');

		try {
			await awaitInPostSendModeReady(shipmentContainer);
			await autofillPackageSizeObserveOrderShipmentsButton(orderShipmentsButton, multipleOrders);
			await fillDimensions(deliveryMethod);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}

		saveButton.disabled = false;

		if (!multipleOrders) {
			orderShipmentsButton.dataset.lock = orderShipmentsButton.dataset.lock.replace('autofillPackageSize,', '');
			if (orderShipmentsButton.dataset.done !== undefined) {
				if (orderShipmentsButton.dataset.done.search('autofillPackageSize') === -1) orderShipmentsButton.dataset.done += 'autofillPackageSize,';
			}	else orderShipmentsButton.dataset.done = 'autofillPackageSize,';	
		} else {
			if (shipmentContainer.dataset?.packageSize === 'not-processed') shipmentContainer.dataset.packageSize = 'ready';
			let notReadyAutofillPackageSizeShipments = Array.from(document.querySelectorAll('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a1b65"]'))?.filter(div => div.querySelector('H4') !== null && div.dataset?.packageSize === 'not-processed');
			if (notReadyAutofillPackageSizeShipments.length === 0) {
				orderShipmentsButton.dataset.lock = orderShipmentsButton.dataset.lock.replace('autofillPackageSize,', '');
				if (orderShipmentsButton.dataset.done !== undefined) {
					if (orderShipmentsButton.dataset.done.search('autofillPackageSize') === -1) orderShipmentsButton.dataset.done += 'autofillPackageSize,';
				}	else orderShipmentsButton.dataset.done = 'autofillPackageSize,';	
			}
		}
		return Promise.resolve(true);
	} else {
		console.log('autofillPackageSize: oczekiwanie na przyciski "Zapisz" i "Zamów przesyłki"');
		const observer = new MutationObserver(mutations => {
			mutations.forEach(async (mutation) => {
				if (mutation.type === 'childList' && mutation.addedNodes.length) {
					const addedButton = Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && (Array.from(element.querySelectorAll('button')).find(button => button.textContent === 'Zamów przesyłki')));
					if (addedButton !== undefined) {
						buttonNodes = Array.from(document.querySelectorAll('button'));
						const bothButtons = buttonNodes.filter(element => element.textContent === 'Zamów przesyłki' || element.textContent === 'Zapisz');
						if (bothButtons.length === 2) {
							observer.disconnect();
							console.log('autofillPackageSize: przyciski "Zapisz" i "Zamów przesyłki" pojawiły się już na stronie');
							return await autofillPackageSize(deliveryMethod);
						}
					}	
				}
			});
		});
		observer.observe(document.body, { subtree: true, childList: true });
	}
}

async function awaitInPostSendModeReady(shipmentContainer) {
	if (shipmentContainer.dataset?.inPost && shipmentContainer.dataset.inPost !== 'ready') {
		await new Promise(resolve => setTimeout(resolve, 200));
		return await awaitInPostSendModeReady(shipmentContainer);
	}
	return Promise.resolve(true);
}


function autofillPackageSizePrepareShipmentContainers() {
	let shipmentContainers = Array.from(document.querySelectorAll('div[class="msts_pt mg9e_16 mg9e_24_l mvrt_16 mvrt_24_l mj7a_16 mj7a_24_l mh36_16 mh36_24_l a1b65"]'))?.filter(div => div.querySelector('H4') !== null && div.dataset?.packageSize === undefined);
	for (const shipmentContainer of shipmentContainers) {
		shipmentContainer.dataset.packageSize = 'not-processed';
	}
}

async function autofillPackageSizeObserveOrderShipmentsButton(orderShipmentsButton, multipleOrders) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject('Nie udało się wczytać listy aktywnych rozszerzeń.');
	}
	const activeLockingExtensions = Object.keys(readedValue.extensions).filter(extensionName => readedValue.extensions[extensionName] === true && (extensionName === 'autofillPackageSize' || extensionName === 'inPostSendMode'));
	
	if (orderShipmentsButton.dataset.lock !== undefined || orderShipmentsButton.dataset.done !== undefined) return Promise.resolve(true);
	orderShipmentsButton.dataset.lock = `${activeLockingExtensions.join(',')},`;

	const orderShipmentsButtonObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.attributeName === 'data-lock') {
				const saveButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zapisz');
				if (!multipleOrders) {
					if (orderShipmentsButton.dataset.lock === '') {
						saveButton.disabled = false;
					} else {
						saveButton.disabled = true;
					}
				}
			}
		});
	});
	orderShipmentsButtonObserver.observe(orderShipmentsButton, { attributes: true, attributeFilter: ['data-lock'] });		
}

async function fillDimensions(deliveryMethod) {
	const otherPackageRadioButton = [...document.querySelectorAll('label')].find(label => label.textContent === 'InneWybierz, aby wpisać własne wymiary')?.previousElementSibling;

	if (!otherPackageRadioButton) {
		console.log('autofillPackageSize: oczekiwanie na przycisk wyboru opakowania innej wielkości...');
		await new Promise(resolve => setTimeout(resolve, 500));
		return await fillDimensions(deliveryMethod);
	}

	if (otherPackageRadioButton.checked === false) {
		console.log('autofillPackageSize: wybór innego opakowania');
		const clickEvent = new MouseEvent('click', {
			view: window,
			bubbles: true,
			cancelable: false,
		});
		otherPackageRadioButton.dispatchEvent(clickEvent);

		await new Promise(resolve => setTimeout(resolve, 500));
		return await fillDimensions(deliveryMethod);
	} 

	const weightInput = document.querySelector('input[name="weight"]');
	const lengthInput = document.querySelector('input[name="length"]');
	const widthInput = document.querySelector('input[name="width"]');
	const heightInput = document.querySelector('input[name="height"]');

	if (weightInput && lengthInput && widthInput && heightInput) {	
		let response;
		try {
			response = await sendMessage({ action: 'getPackageTemplates', shippingMethod: deliveryMethod });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			return Promise.reject(error.message);
		}
		const autofillPackageSizeDelayBefore = parseInt(response.result.delayBefore * 1000);
		const autofillPackageSizeDelayBetween = parseInt((response.result.delayBetween * 1000) - 100);
		if (response.result.template !== undefined) {		
			const inputsBox = document.querySelector('div[class="mp4t_8 mryx_8"]')?.previousElementSibling;
			if (inputsBox) {
				let templateButtonsContainer = document.createElement('div');
				templateButtonsContainer.className = 'templateButtonsContainer hidden';
				let i = 1;
				while (response.result.template[`weight${i}`] !== undefined) {
					if (i > 9) break;
					let templateButton = document.createElement('button');
					templateButton.className = 'templateButton';
					if (i == response.result.template.default) templateButton.classList.add('defaultTemplate');
					templateButton.id = `templateButton${i}`;
					templateButton.dataset.length = response.result.template[`length${i}`];
					templateButton.dataset.width = response.result.template[`width${i}`];
					templateButton.dataset.height = response.result.template[`height${i}`];
					templateButton.dataset.weight = response.result.template[`weight${i}`];
					templateButton.innerText = `${templateButton.dataset.length}x${templateButton.dataset.width}x${templateButton.dataset.height}cm, ${templateButton.dataset.weight}kg`;
					templateButton.addEventListener('click', templateButtonClick);
					templateButton.addEventListener('mousedown', templateButtonMouseDown);
					templateButton.addEventListener('mouseup', templateButtonMouseUp);
					templateButtonsContainer.insertAdjacentElement('beforeend', templateButton);
					i++;
				}

				inputsBox.insertAdjacentHTML('beforeend', '<div style="flex-basis: 100%; height: 0;"></div>');
				inputsBox.insertAdjacentElement('beforeend', templateButtonsContainer);
				/*if (document.getElementById('templateButton1').offsetTop === document.getElementById(`templateButton${i-1}`).offsetTop) {
					[...document.querySelectorAll('.templateButton')].forEach(button => button.classList.add('templateButtonSingle'));
				}*/

				templateButtonsContainer.classList.remove('hidden');

				const packageSizeContainer = [...document.querySelectorAll('span')].find(e => e.innerText === 'WIELKOŚĆ PACZKI')?.parentElement?.parentElement;
				if (packageSizeContainer) packageSizeContainer.style.marginTop = '32px';
				const weightSizeContainer = [...document.querySelectorAll('span')].find(e => e.innerText === 'WAGA GABARYTOWA')?.parentElement?.parentElement;
				if (weightSizeContainer) weightSizeContainer.style.marginTop = '32px';
			}


			const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
			const event = new Event('input', { bubbles: true });

			const delay = t => new Promise(resolve => setTimeout(resolve, t));
			await delay(autofillPackageSizeDelayBefore);

			if (response.result.template[`weight${response.result.template.default}`] && response.result.template[`weight${response.result.template.default}`] !== '0') {
				weightInput.focus({ preventScroll: true, focusVisible: false });
				await delay(autofillPackageSizeDelayBetween);
				const weightInputValue = response.result.template[`weight${response.result.template.default}`];
				nativeInputValueSetter.call(weightInput, weightInputValue);
				weightInput.dispatchEvent(event);
			}

			lengthInput.focus({ preventScroll: true, focusVisible: false });
			await delay(autofillPackageSizeDelayBetween);
			const lengthInputValue = response.result.template[`length${response.result.template.default}`];
			nativeInputValueSetter.call(lengthInput, lengthInputValue);
			lengthInput.dispatchEvent(event);

			widthInput.focus({ preventScroll: true, focusVisible: false });
			await delay(autofillPackageSizeDelayBetween);
			const widthInputValue = response.result.template[`width${response.result.template.default}`];
			nativeInputValueSetter.call(widthInput, widthInputValue);
			widthInput.dispatchEvent(event);

			heightInput.focus({ preventScroll: true, focusVisible: false });	
			await delay(autofillPackageSizeDelayBetween);	
			const heightInputValue = response.result.template[`height${response.result.template.default}`];
			nativeInputValueSetter.call(heightInput, heightInputValue);
			heightInput.dispatchEvent(event);				
			
			await delay(autofillPackageSizeDelayBetween);
			
			heightInput.blur();			

			return Promise.resolve(true);	
		} else {
			return Promise.reject('Dla wybranej formy dostawy nie ustawiono wartości domyślnych.');
		}
	} else {
		console.log('autofillPackageSize: oczekiwanie na pola do wypełnienia...');
		await new Promise(resolve => setTimeout(resolve, 500));
		return await fillDimensions(deliveryMethod);
	}
}

async function templateButtonClick(e) {
	const weightInput = document.querySelector('input[name="weight"]');
	const lengthInput = document.querySelector('input[name="length"]');
	const widthInput = document.querySelector('input[name="width"]');
	const heightInput = document.querySelector('input[name="height"]');

	let response;
	try {
		response = await sendMessage({ action: 'getPackageDelay' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(error.message);
	}

	const autofillPackageSizeDelayBetween =  parseInt((response.result.delayBetween * 1000) - 100) || 200;

	if (weightInput && lengthInput && widthInput && heightInput) {
		const event = new Event('input');
		const delay = t => new Promise(resolve => setTimeout(resolve, t));

		if (e.target.dataset.weight && e.target.dataset.weight !== '0') {
			weightInput.focus({ preventScroll: true, focusVisible: false });
			await delay(autofillPackageSizeDelayBetween);
			weightInput.value = e.target.dataset.weight;
			await delay(100);
			weightInput.dispatchEvent(event);
		}
		
		lengthInput.focus({ preventScroll: true, focusVisible: false });
		await delay(autofillPackageSizeDelayBetween);
		lengthInput.value = e.target.dataset.length;
		await delay(100);
		lengthInput.dispatchEvent(event);

		widthInput.focus({ preventScroll: true, focusVisible: false });
		await delay(autofillPackageSizeDelayBetween);
		widthInput.value = e.target.dataset.width;
		await delay(100);
		widthInput.dispatchEvent(event);

		heightInput.focus({ preventScroll: true, focusVisible: false });	
		await delay(autofillPackageSizeDelayBetween);	
		heightInput.value = e.target.dataset.height;
		await delay(100);
		heightInput.dispatchEvent(event);
		
		await delay(autofillPackageSizeDelayBetween);
		heightInput.blur();		
	}
}

function templateButtonMouseDown(e) {
	e.target.dataset.clickTimer = setTimeout(async () => {
		delete e.target.dataset?.clickTimer;
		document.querySelector('button[class~="defaultTemplate"]')?.classList.remove('defaultTemplate');
		e.target.classList.add('defaultTemplate');
		const deliveryMethod = Array.from(document.querySelectorAll('span')).find(element => element.innerText === 'METODA DOSTAWY')?.nextElementSibling?.innerText;
		if (!deliveryMethod) {
			toastMessage('Błąd! Nie znaleziono nazwy metody dostawy na stronie.');
			return;
		}
		const defaultTemplate = (e.target.id.charAt(e.target.id.length - 1));
		let readedValue;

		try {
			readedValue = await readDataFromLocalStorage(['shippingMethods']);
			if (!readedValue.shippingMethods) throw new Error('Nie udało się odczytać z pamięci listy metod dostawy.');
			let changed = false;
			for (const method of readedValue.shippingMethods) {
				if (method.name === deliveryMethod) {
					method.default = defaultTemplate;
					changed = true;
					break;
				}
			}
			if (!changed) {
				throw new Error('W pamięci nie znaleziono metody dostawy o podanej nazwie.');
			}
			await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });
			toastMessage('Zmieniono domyślny szablon.');
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić domyślnego szablonu. ${getErrorMessage(error)}`);
		}
	}, 1000);
}

function templateButtonMouseUp(e) {
	const clickTimer = e.target?.dataset?.clickTimer;
	clearTimeout(clickTimer);
	delete e.target.dataset?.clickTimer;
}

function sizeRadioMouseDown(e) {
	if (e.target.nodeName === 'DIV') return;
	e.target.dataset.clickTimer = setTimeout(async () => {
		delete e.target.dataset?.clickTimer;
		document.querySelector('div[class~="selected"]')?.classList.remove('selected');
		if (e.target.nodeName === 'LABEL') {
			e.target.firstChild.classList.add('selected');
		} else if (e.target.nodeName === 'SPAN') {
			e.target.closest('label').firstChild.classList.add('selected');
		}
		const deliveryMethod = Array.from(document.querySelectorAll('span')).find(element => element.innerText === 'METODA DOSTAWY')?.nextElementSibling?.innerText;
		const predefinedSizeOptions = Array.from(document.querySelectorAll('input[id^="P0"]')).filter(element => element?.nextElementSibling?.innerText.indexOf('Gabaryt') === 0);
		
		let defaultSize = 1;
		let found = false;
		for (const option of predefinedSizeOptions) {
			if (option?.nextElementSibling?.firstChild.classList.contains('selected')) {
				found = true;
				break;
			}
			defaultSize++;
		}

		if (!found) {
			toastMessage('Błąd! Nie udało się ustalić która predefiniowana wielkość przesyłki ma być ustawiona jako domyślna.');
			return;
		}

		let readedValue;

		try {
			readedValue = await readDataFromLocalStorage(['shippingMethods']);
			if (!readedValue.shippingMethods) throw new Error('Nie udało się odczytać z pamięci listy metod dostawy.');
			let changed = false;
			for (const method of readedValue.shippingMethods) {
				if (method.name === deliveryMethod) {
					if (!method[`size${defaultSize}`]) {
						let i = 1;
						while (method[`size${i}`] !== undefined) i++;
						throw new Error(`W ustawieniach szablonu dla formy dostawy ${deliveryMethod} znaleziono ${i-1} opcji. Brak opcji o indeksie ${defaultSize}. Dodaj nowe wybieralne opcje.`);
					}
					method.default = defaultSize;
					changed = true;
					break;
				}
			}
			if (!changed) {
				throw new Error('W pamięci nie znaleziono metody dostawy o podanej nazwie.');
			}
			await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });
			toastMessage('Zmieniono domyślny szablon.');
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić domyślnego szablonu. ${getErrorMessage(error)}`);
		}
	}, 1000);
}

function sizeRadioMouseUp(e) {
	if (e.target.nodeName === 'DIV') return;
	const clickTimer = e.target?.dataset?.clickTimer;
	clearTimeout(clickTimer);
	delete e.target.dataset?.clickTimer;
}
