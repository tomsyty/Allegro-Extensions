const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt sendMessageFromOrdersPage');

  (function addStylesheetMaterialSymbols() {	
		var link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0&display=block';
    document.head.appendChild(link);
	})();

  try {
   await sendMessageFromOrdersPageAwaitOrdersTable();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }

});

async function sendMessageFromOrdersPageAwaitOrdersTable() {
	const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	let previousUrl = '';
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
						return await sendMessageFromOrdersPageAwaitOrdersTable();
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				return await sendMessageFromOrdersPageAwaitOrdersTable();
			}
		});	

    if (document.getElementById('sendMessageFromOrdersPageDialog') === null) {
      ordersTable.insertAdjacentHTML('beforeend', /*html*/ `
      <dialog id="sendMessageFromOrdersPageDialog">
        <form method="dialog">
          <div class="row">
            <span id="sendMessageFromOrdersPageCloseContainer" class="material-symbols-outlined fs28">close</span>
          </div>
          <div class="dialogHead">
            <span>Zamówienie nr <span id="sendMessageFromOrdersPageOrderIdSpan"></span></span>
            <span>Użytkownik <span id="sendMessageFromOrdersPageBuyerLoginSpan"></span></span>
            <span>Wiadomość</span>
          </div>
          <div class="row">
            <textarea id="sendMessageFromOrdersPageTextarea" rows="10" cols="100" maxlength="2000"></textarea>
          </div>
          <div class="row">
            <button id="sendMessageFromOrdersPageCancel" class="actionButton"><span class="material-symbols-outlined fs28">cancel</span>Anuluj</button>
            <button id="sendMessageFromOrdersPageSend" class="actionButton"><span class="material-symbols-outlined fs28">send</span>Wyślij</button>
          </div>
        </form>
      </dialog>`);

      document.getElementById('sendMessageFromOrdersPageCancel').addEventListener('click', (e) => {
        document.getElementById('sendMessageFromOrdersPageDialog').close();
      });

      document.getElementById('sendMessageFromOrdersPageSend').addEventListener('click', (e) => {
        sendMessageFromOrdersPageSendButtonClick.call(e.target, e);
      });

      document.getElementById('sendMessageFromOrdersPageCloseContainer').addEventListener('click', () => {
        document.getElementById('sendMessageFromOrdersPageDialog').close();
      });

      document.getElementById('sendMessageFromOrdersPageDialog').addEventListener('close', () => {
        const element = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'Wyślij wiadomość');
        if (element) element.disabled = false;
      });
    }

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      urlObserver.observe(document, {	subtree: true, childList: true });
			await new Promise(resolve => setTimeout(resolve, 5000));
			try {
      	await sendMessageFromOrdersPageAwaitOrders();
			} catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
      }
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function sendMessageFromOrdersPageAwaitOrders() {
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}
	if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
		const iconCheckCircleOutline = document.createElement('span');
		iconCheckCircleOutline.className = 'material-symbols-outlined';
		iconCheckCircleOutline.dataset.icon = 'check_circle';
		preloadIconsContainer.appendChild(iconCheckCircleOutline);
	}
	if (!preloadIconsContainer.querySelector('span[data-icon="highlight_off"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'highlight_off';
		preloadIconsContainer.appendChild(iconHighlightOff);
	}
  if (!preloadIconsContainer.querySelector('span[data-icon="send"]')) {
		const iconSend = document.createElement('span');
		iconSend.className = 'material-symbols-outlined';
		iconSend.dataset.icon = 'send';
		preloadIconsContainer.appendChild(iconSend);
	}

  let ordersRows, ordersRowsFound;

  do {
    ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
    ordersRowsFound = ordersRows.length;
    if (ordersRowsFound) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
      if (ordersRowsFound !== ordersRows.length) {
        ordersRowsFound = ordersRows.length;
        continue;
      }
    }
    break;
  } while (1);

  ordersRows.forEach(element => {
    element = element.nextElementSibling;
    if (!element.querySelector('button[class~="sendMessageFromOrdersPage"]')) {
      const sellerNoteButton = element.querySelector('button[data-test-id="sellerNoteButton"]');
      const sendMessageButton = document.createElement('button');
      sendMessageButton.className = sellerNoteButton.className;
      sendMessageButton.classList.add('sendMessageFromOrdersPage');
      sendMessageButton.textContent = 'Wyślij wiadomość';
      sendMessageButton.addEventListener('click', sendMessageFromOrdersPageShowModal);
      sellerNoteButton.insertAdjacentElement('afterend', sendMessageButton);
    }
  });

  return Promise.resolve(true);
}

async function sendMessageFromOrdersPageShowModal(e) {
  e.target.disabled = true;

  const sendMessageFromOrdersPageDialog = document.getElementById('sendMessageFromOrdersPageDialog');
  if (!sendMessageFromOrdersPageDialog) {
    toastMessage('Błąd! Nie znaleziono okna wysyłania wiadomości.');
    e.target.disabled = false;
    return;
  }

  const orderParentElement = this.closest('div[class^="order"]');
  const buyerLogin = orderParentElement.querySelector('span[class="buyer-details"] a').textContent;
  const orderId = orderParentElement.querySelector('a[aria-label="Szczegóły zamówienia"]').getAttribute('orderid');
  console.log(buyerLogin + ': ' + orderId);

  document.getElementById('sendMessageFromOrdersPageBuyerLoginSpan').textContent = buyerLogin;
  document.getElementById('sendMessageFromOrdersPageOrderIdSpan').textContent = orderId;
  document.getElementById('sendMessageFromOrdersPageTextarea').value = '';

  sendMessageFromOrdersPageDialog.showModal();
  e.target.disabled = false;
}

async function sendMessageFromOrdersPageSendButtonClick(e) {
  e.target.disabled = true;
  const buyerLogin = document.getElementById('sendMessageFromOrdersPageBuyerLoginSpan').innerText;
  const orderId = document.getElementById('sendMessageFromOrdersPageOrderIdSpan').innerText;
  console.log(buyerLogin + ': ' + orderId);
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

  let response;

  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    e.target.disabled = false;
    return;
  } 

  if (response.result === undefined) {
    toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
    e.target.disabled = false;
    return;
  }

  const accessToken = response.result;
  const text = document.getElementById('sendMessageFromOrdersPageTextarea').value;
  if (text.length === 0) {
    toastMessage('Błąd! Wiadomość nie może być pusta.');
    e.target.disabled = false;
    return;
  }

  let messageStatus, messageId;

  try {
    response = await composeAndSendMessage(buyerLogin, orderId, text, accessToken, environment);
    messageStatus = response.status;
    messageId = response.id;
    toastMessage(`Status wysłanej wiadomości: ${messageStatus}, numer wiadomości: ${messageId}`);
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    e.target.disabled = false;
    return;
  }
  e.target.disabled = false;
}

async function composeAndSendMessage(recipient, orderId, text, accessToken, environment) {
  const data = {
    recipient: {
      login: recipient
    },
    text: text,
    order: {
      id: orderId
    },
    attachments: []
  }

  let response;
  let fetchResponse;
  let fetchData;

  async function composeAndSendMessageRetry(count = 5) {
    try {
      fetchResponse = await fetch(`https://api.allegro.pl${environment}/messaging/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/vnd.allegro.public.v1+json',
          'Content-Type': 'application/vnd.allegro.public.v1+json'
        },
        body: JSON.stringify(data)
      });		
    } catch (error) {
      return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
    } 

    if (fetchResponse.status === 201) {
      try {
        fetchData = await fetchResponse.json();
        return Promise.resolve(fetchData);
      } catch(error) {
        return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}.`);
      }
    } else if (fetchResponse.status === 401) {
      if (--count) {	
        toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);
        try {
          response = chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken' });
        } catch (error) {
          return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error.message}`);
        } 
        if (response.result === undefined) {
          return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
        }          
        accessToken = response.result; 
        return await composeAndSendMessageRetry(count);            
      } else {
        return Promise.reject(`Nie udało się wysłać wiadomości. Nie udało się odświeżyć tokena dostępowego.`);
      }
    } else if (fetchResponse.status === 403) {
      return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
    } else {
      if (--count) {	
        toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        await delay(5000);
        return await composeAndSendMessageRetry(count);
      } else {
        return Promise.reject(`Nie udało się wysłać wiadomości. ${HTTP_RESPONSE_CODE} ${response.status}`);
      }
    }  
  }

  try {
    const message = await composeAndSendMessageRetry();
    return Promise.resolve(message);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  }
}