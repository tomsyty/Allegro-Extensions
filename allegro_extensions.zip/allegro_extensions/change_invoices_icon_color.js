async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt changeInvoicesIconColor');

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;
   
  let response;
  try {
    response = await sendMessage({ action: 'getFilter' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! Podczas odczytu informacji o kolorze ikony faktury wystąpił błąd. ${getErrorMessage(error)}`);
    return;
  }
  const css = '<style>.aeFv {' + response.result + '}</style>';
  document.head.insertAdjacentHTML('beforeend', css);
  document.querySelectorAll('button[aria-label="Dodaj fakturę."]:not(.aeFv)').forEach(btn => { btn.firstElementChild.classList.add('aeFv'); });
  try {
    await changeInvoicesIconColor();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }
});

async function changeInvoicesIconColor() {
  let observedElement;

	async function waitForOrdersTable(count = 50) {
		observedElement = document.querySelectorAll('div[data-box-name="allegro.orders.listing"]');
		if (!observedElement.length) {
			if (--count) {
        await new Promise(resolve => setTimeout(resolve, 500));
				await waitForOrdersTable(count);	
			} else return Promise.reject(false);		
		} else return Promise.resolve(true);
  }

  try {
    await waitForOrdersTable();
  } catch (error) {
    return Promise.reject('Nie znaleziono tabeli z ofertami. Kolor ikon faktur nie ulegnie zmianie.');
  } 
  changeInvoicesIconColorObserve(observedElement[0]);
  return Promise.resolve(true);
}

function changeInvoicesIconColorObserve(observedElement) {
	const observer = new MutationObserver(() => {
		observer.disconnect();			
		document.querySelectorAll('button[aria-label="Dodaj fakturę."]:not(.aeFv)').forEach(btn =>{ btn.firstElementChild.classList.add('aeFv'); });
		changeInvoicesIconColorObserve(observedElement);
	});	
	
	observer.observe(observedElement, { subtree: true, childList: true });
}