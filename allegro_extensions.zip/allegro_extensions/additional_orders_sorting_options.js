window.addEventListener('load', async () => {
	console.log('Załadowano skrypt additionalOrdersSortingOptions');
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;

  try {
    await waitForSortingSelectElement();
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  } 

  const selectElement = document.getElementById('sort-options');
  const options = selectElement.options;
  const newOption = document.createElement('option');
  newOption.className = options[0].className;
  newOption.value = 'items';
  newOption.textContent = 'ilość pozycji: rosnąco';
  newOption.label = 'ilość pozycji: rosnąco';
  selectElement.appendChild(newOption);
  selectElement.addEventListener('change', async (event) => {
    if (event.target.value === 'items') {
      event.stopImmediatePropagation();
      
      toastMessage('Sortowanie wg ilości pozycji: rosnąco');
      const container = document.querySelector('div[class~="order-group-operation"]').parentElement.parentElement;
      const children = Array.from(container.children); 
      const sortableDivs = children.slice(3).filter(div => div.querySelector('div[class~="order-group-operation"]'));
      const sortedDivs = sortableDivs.slice().sort((a, b) => {
        const aItems = a.querySelectorAll('div[data-test-id="item-offer"]').length;
        const bItems = b.querySelectorAll('div[data-test-id="item-offer"]').length;
        return aItems - bItems;
      });
      const firstAfterSortable = children[3 + sortableDivs.length] || null;
      sortedDivs.forEach(div => container.insertBefore(div, firstAfterSortable));
      event.preventDefault();
    }
  });
  
});

async function waitForSortingSelectElement(retriesLeft = 10) {
  let selectElement;
  do {
    retriesLeft--;
    selectElement = document.getElementById('sort-options');
    if (!selectElement) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      continue;
    }
    break;
  } while (retriesLeft);
  if (!selectElement) {
    return Promise.reject('Nie znaleziono listy z wyborem opcji sortowania.');
  }
  return Promise.resolve(true);
}