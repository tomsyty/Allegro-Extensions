console.log('Załadowano współdzielony skrypt');
if (document.getElementById('aeToast') === null) { 
  let toast = document.createElement('div');
  toast.id = 'aeToast';
  toast.dataset.timer = '';
  toast.classList.add('aeToastHidden');
  document.body.appendChild(toast);
}