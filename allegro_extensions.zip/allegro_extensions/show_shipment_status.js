async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt showShipmentStatus');

	let previousUrl = '';

  const urlObserver = new MutationObserver(async () => {
    if (window.location.href !== previousUrl && new URL(window.location.href).searchParams.get('shipmentId') === null) {
      previousUrl = window.location.href;
      return await showShipmentStatusGetStatuses();
    }
  });	
  urlObserver.observe(document, {	subtree: true, childList: true });

  if (window.location.href !== previousUrl) {
    previousUrl = window.location.href;
    try {
      await showShipmentStatusGetStatuses();
    } catch (error) {
      toastMessage(`Błąd! ${getErrorMessage(error)}`);
    }
  }
});

async function showShipmentStatusGetStatuses() {
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	
  let services;

  try {
    services = await getCarrierIds(environment);
    services = services.services;
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
    return;
  }

  let shippingsTable;
  do {
    shippingsTable = document.querySelector('table[class="mgn2_14 mp0t_0a mqu1_21 mgmw_wo mli8_k4 q1srg m7er_k4"]');
    if (!shippingsTable || shippingsTable.tBodies[0].rows.length === 0) {
      console.log('showShipmentStatus: oczekiwanie na tabelę z listą przesyłek');
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  } while(!shippingsTable || shippingsTable.tBodies[0].rows.length === 0);
  console.log('showShipmentStatus: znaleziono tabelę z listą przesyłek');
  await new Promise(resolve => setTimeout(resolve, 1000));

  for (const row of Array.from(shippingsTable.tBodies[0].rows).filter(r => r.firstElementChild?.colSpan === 1)) {
    const shippingNumber = row.cells[1].innerText;
    const deliveryMethod = row.cells[3].innerText;
    //.replace(/ \(.*/, '')
    const service = services.filter(service => service.name.replace(/ \(.*/, '') === deliveryMethod.replace(/ \(.*/, ''));
    if (service.length) {
      let waybill;
      let serviceIndex = 0;
      try {
        do {
          waybill = await checkShipmentsStatus(environment, service[serviceIndex].carrierId, shippingNumber);
          toastMessage('');
          waybill = waybill.waybill;
          serviceIndex++;
        } while (waybill.trackingDetails === null && serviceIndex < service.length);
  
        if (shippingNumber === waybill.waybill) {
          let lastStatus = waybill.trackingDetails?.statuses.find(status => status.code === 'RETURNED');
          if (!lastStatus) lastStatus = waybill.trackingDetails?.statuses.reduce((latest, status) =>
            new Date(status.occurredAt) > new Date(latest.occurredAt) ? status : latest
          );
          console.log(`Numer przesyłki: ${shippingNumber}, metoda dostawy: ${deliveryMethod}, status: ${lastStatus?.code ?? 'brak statusu'}`);
          if (lastStatus?.code) {
            let progressBarContainer;
            if (progressBarContainer = row.cells[1].querySelector('div[class~="statusProgressContainer"]')) {
              progressBarContainer.remove();
            }
            progressBarContainer = document.createElement('div');
            progressBarContainer.className = 'statusProgressContainer';
            let progressBar = document.createElement('div');
            progressBar.className = 'statusProgress';
            progressBar.dataset.state = lastStatus.code;
            progressBarContainer.appendChild(progressBar);
            row.cells[1].appendChild(progressBarContainer);
            row.cells[1].offsetHeight;
          }
        }
      } catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
      }   
    }
  }
  console.log('showShipmentStatus: pobrano statusy przesyłek');
}

async function checkShipmentsStatus(environment, carrierId, waybill, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;

  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;

  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/carriers/${carrierId}/tracking?waybill=${waybill}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkShipmentsStatus(environment, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić statusu przesyłki ${waybill}. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    return Promise.resolve({ waybill: fetchData.waybills[0] });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await checkShipmentsStatus(environment, count);  
    } else {
      return Promise.reject(`Nie udało się sprawdzić statusu przesyłki. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await checkShipmentsStatus(environment, count);
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania statusu przeasyłki ${waybill}. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkShipmentsStatus(environment, count);
    } else {
      return Promise.reject(`Błąd serwera podczas sprawdzania statusu przesyłki ${waybill}, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await checkShipmentsStatus(environment, count);      
    } else {
      return Promise.reject(`Nie udało się sprawdzić statusu przesyłki ${waybill}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}

async function getCarrierIds(environment, count = 5) {
  let response;
  let fetchResponse;
  let fetchData;

  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }

  let accessToken = response.result;

  try {
    fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/shipment-management/delivery-services` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getCarrierIds(environment, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać listy przewoźników. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    return Promise.resolve({ services: fetchData.services });
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await getCarrierIds(environment, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy przewoźników. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await getCarrierIds(environment, count);
    } else {
      return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania listy przewoźników. Spróbuj ponownie później.');
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getCarrierIds(environment, count);
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania listy przewoźników, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getCarrierIds(environment, count);      
    } else {
      return Promise.reject(`Nie udało się pobrać listy przewoźników. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}