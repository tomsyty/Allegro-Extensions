async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt actions_popup.js');
  let readedValue;

  readedValue = await readDataFromLocalStorage(['extensions']);
  if (readedValue.extensions) {
    if (readedValue.extensions?.parametersWatcher) document.getElementById('pwForm').classList.remove('hidden');
    if (readedValue.extensions?.showShipmentStatus) document.getElementById('csForm').classList.remove('hidden');
  }


	document.getElementById('pwRunNowButton').addEventListener('click', pwRunNowButtonClick);
  document.getElementById('pwPostponeButton').addEventListener('click', pwPostponeButtonClick);
  document.getElementById('pwStopButton').addEventListener('click', pwStopButtonClick);

  document.getElementById('csRunNowButton').addEventListener('click', csRunNowButtonClick);
  document.getElementById('csPostponeButton').addEventListener('click', csPostponeButtonClick);
  document.getElementById('csStopButton').addEventListener('click', csStopButtonClick);

  readedValue = await readDataFromSessionStorage(['auctionsWithChangesInProducts']);
  if (readedValue['auctionsWithChangesInProducts'] !== undefined) {
    let pwChangesList = document.getElementById('pwChangesList');
    readedValue['auctionsWithChangesInProducts'].forEach(auction => {
      pwChangesList.innerHTML += `<div><a href="https://salescenter.allegro.com/my-assortment?phrase=${auction.number}" target="_blank"${auction.visited ? ' class="visited"' : ""}>${auction.number}</a></div>`;
    });
    document.querySelectorAll('a').forEach(linkElement => linkElement.addEventListener('click', pwLinkSetVisited));
  }

  let shipmentsResult = document.getElementById('csShipmentsResults');

  chrome.storage.onChanged.addListener((storageObject, storageArea) => {
    if (storageArea === 'session') {
      if ('auctionsWithChangesInProducts' in storageObject && 'newValue' in storageObject['auctionsWithChangesInProducts'] && storageObject['auctionsWithChangesInProducts'].newValue[0]?.visited === false) {
        pwChangesList.innerHTML = storageObject['auctionsWithChangesInProducts'].newValue.map(auction => `<div><a href="https://salescenter.allegro.com/my-assortment?phrase=${auction.number}" target="_blank"${auction.visited ? ' class="visited"' : ""}>${auction.number}</a></div>`).join('');
      }
      if ('checkShipmentsUpdate' in storageObject && 'newValue' in storageObject['checkShipmentsUpdate']) {
        storageObject['checkShipmentsUpdate'].newValue.forEach(async (newValue) => {
          if ([...shipmentsResult.querySelectorAll('span')].find(span => span.textContent === newValue.waybill)) return;
          if (newValue.returned) return;

          let item = document.createElement('div');
          let cssShipmentStatus;
          let shipmentStatus;
          switch (newValue.status) {
            case 'RETURNED': {
              cssShipmentStatus = 'returned';
              shipmentStatus = 'ZWRÓCONA';
              break;
            }

            case 'ISSUE': {
              cssShipmentStatus = 'issue';
              shipmentStatus = 'PROBLEM';
              break;
            }

            case 'NOTICE_LEFT': {
              cssShipmentStatus = 'noticeLeft';
              shipmentStatus = 'AWIZO';
              break;
            }

            case 'TIME_RUNNING_OUT': {
              cssShipmentStatus = 'timeRunningOut';
              shipmentStatus = 'MAŁO CZASU';
              break;
            }
          }
          
          item.classList = `csShipments ${cssShipmentStatus}`;
          readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
          if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
          if (readedValue.checkShipmentsPageOpened.find(waybill => waybill === newValue.waybill)) item.classList.add('visited');
          item.innerHTML =  `<span>${newValue.waybill}</span><span>${newValue.carrier}</span><span class="status">${shipmentStatus}</span>`;
          item.addEventListener('click', checkShipmentsShowPage);
          item.addEventListener('longClick', checkShipmentsMarkAsRead);
          item.addEventListener('transitionend', (e) => { e.target.remove() });
          item.addEventListener('mousedown', (e) => {
            e.target.dataset.clickTimer = setTimeout(() => {
              delete e.target?.dataset?.clickTimer;
              const longClickEvent = new CustomEvent('longClick', { detail: e.target });
              item.dispatchEvent(longClickEvent);
            }, 1000);
          });
          item.addEventListener('mouseup', (e) => {
            const clickTimer = e.target?.dataset?.clickTimer;
            if (clickTimer) {
              clearTimeout(clickTimer);
              delete e.target?.dataset?.clickTimer;
            }
          });
          shipmentsResult.insertAdjacentElement('beforeend', item);
        });
      }

      if ('checkShipmentsStatusDone' in storageObject && 'newValue' in storageObject['checkShipmentsStatusDone'] ) {
        chrome.storage.session.remove('checkShipmentsStatusDone');
        document.getElementById('csRunNowButton').disabled = false;
        document.getElementById('csPostponeButton').disabled = false;
        document.getElementById('csStopButton').disabled = true;
        document.getElementById('csInfo').textContent = 'Zakończono sprawdzanie statusów przesyłek.';
      }
    }

    document.querySelectorAll('a').forEach(linkElement => linkElement.addEventListener('click', pwLinkSetVisited));
  });

  let response;
  try {
    response = await sendMessage({ action: 'checkShipmentsGetByStatus', status: 'RETURNED' });
    if (!response.success) throw new Error(response.result);
    let shipmentsResult = document.getElementById('csShipmentsResults');
    shipmentsResult.innerHTML = '';
    readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
    if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
    response.result.forEach(shipment => {
      if (shipment.readed) return;
      let item = document.createElement('div');
      item.classList = 'csShipments returned';
      if (readedValue.checkShipmentsPageOpened.find(waybill => waybill === shipment.waybill)) item.classList.add('visited');
      item.innerHTML =  `<span>${shipment.waybill}</span><span>${shipment.carrier}</span><span class="status">ZWRÓCONA</span>`;
      item.addEventListener('click', checkShipmentsShowPage);
      item.addEventListener('longClick', checkShipmentsMarkAsRead);
      item.addEventListener('transitionend', (e) => { e.target.remove() });
      item.addEventListener('mousedown', (e) => {
        e.target.dataset.clickTimer = setTimeout(() => {
          delete e.target?.dataset?.clickTimer;
          const longClickEvent = new CustomEvent('longClick', { detail: e.target });
          item.dispatchEvent(longClickEvent);
        }, 1000);
      });
      item.addEventListener('mouseup', (e) => {
        const clickTimer = e.target?.dataset?.clickTimer;
        if (clickTimer) {
          clearTimeout(clickTimer);
          delete e.target?.dataset?.clickTimer;
        }
      });
        shipmentsResult.insertAdjacentElement('beforeend', item);
    });

    response = await sendMessage({ action: 'checkShipmentsGetByStatus', status: 'ISSUE' });
    if (!response.success) throw new Error(response.result);
    shipmentsResult = document.getElementById('csShipmentsResults');
    readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
    if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
    response.result.forEach(shipment => {
      if (shipment.readed) return;
      let item = document.createElement('div');
      item.classList = 'csShipments issue';
      if (readedValue.checkShipmentsPageOpened.find(waybill => waybill === shipment.waybill)) item.classList.add('visited');
      item.innerHTML = `<span>${shipment.waybill}</span><span>${shipment.carrier}</span><span class="status">PROBLEM</span>`;
      item.addEventListener('click', checkShipmentsShowPage);
      item.addEventListener('longClick', checkShipmentsMarkAsRead);
      item.addEventListener('transitionend', (e) => { e.target.remove() });
      item.addEventListener('mousedown', (e) => {
        e.target.dataset.clickTimer = setTimeout(() => {
          delete e.target?.dataset?.clickTimer;
          const longClickEvent = new CustomEvent('longClick', { detail: e.target });
          item.dispatchEvent(longClickEvent);
        }, 1000);
      });
      item.addEventListener('mouseup', (e) => {
        const clickTimer = e.target?.dataset?.clickTimer;
        if (clickTimer) {
          clearTimeout(clickTimer);
          delete e.target?.dataset?.clickTimer;
        }
      });
      shipmentsResult.insertAdjacentElement('beforeend', item);
    });

    response = await sendMessage({ action: 'checkShipmentsGetByStatus', status: 'NOTICE_LEFT' });
    if (!response.success) throw new Error(response.result);
    shipmentsResult = document.getElementById('csShipmentsResults');
    readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
    if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
    response.result.forEach(shipment => {
      if (shipment.readed) return;
      let item = document.createElement('div');
      item.classList = 'csShipments noticeLeft';
      if (readedValue.checkShipmentsPageOpened.find(waybill => waybill === shipment.waybill)) item.classList.add('visited');
      item.innerHTML = `<span>${shipment.waybill}</span><span>${shipment.carrier}</span><span class="status">AWIZO</span>`;
      item.addEventListener('click', checkShipmentsShowPage);
      item.addEventListener('longClick', checkShipmentsMarkAsRead);
      item.addEventListener('transitionend', (e) => { e.target.remove() });
      item.addEventListener('mousedown', (e) => {
        e.target.dataset.clickTimer = setTimeout(() => {
          delete e.target?.dataset?.clickTimer;
          const longClickEvent = new CustomEvent('longClick', { detail: e.target });
          item.dispatchEvent(longClickEvent);
        }, 1000);
      });
      item.addEventListener('mouseup', (e) => {
        const clickTimer = e.target?.dataset?.clickTimer;
        if (clickTimer) {
          clearTimeout(clickTimer);
          delete e.target?.dataset?.clickTimer;
        }
      });
      shipmentsResult.insertAdjacentElement('beforeend', item);
    });

    response = await sendMessage({ action: 'checkShipmentsGetByStatus', status: 'TIME_RUNNING_OUT' });
    if (!response.success) throw new Error(response.result);
    shipmentsResult = document.getElementById('csShipmentsResults');
    readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
    if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
    response.result.forEach(shipment => {
      if (shipment.readed) return;
      let item = document.createElement('div');
      item.classList = 'csShipments timeRunningOut';
      if (readedValue.checkShipmentsPageOpened.find(waybill => waybill === shipment.waybill)) item.classList.add('visited');
      item.innerHTML = `<span>${shipment.waybill}</span><span>${shipment.carrier}</span><span class="status">MAŁO CZASU</span>`;
      item.addEventListener('click', checkShipmentsShowPage);
      item.addEventListener('longClick', checkShipmentsMarkAsRead);
      item.addEventListener('transitionend', (e) => { e.target.remove() });
      item.addEventListener('mousedown', (e) => {
        e.target.dataset.clickTimer = setTimeout(() => {
          delete e.target?.dataset?.clickTimer;
          const longClickEvent = new CustomEvent('longClick', { detail: e.target });
          item.dispatchEvent(longClickEvent);
        }, 1000);
      });
      item.addEventListener('mouseup', (e) => {
        const clickTimer = e.target?.dataset?.clickTimer;
        if (clickTimer) {
          clearTimeout(clickTimer);
          delete e.target?.dataset?.clickTimer;
        }
      });
      shipmentsResult.insertAdjacentElement('beforeend', item);
    });
  } catch (error) {
    document.getElementById('csInfo').textContent = 'Nie udało się wczytać listy przesyłek';
    console.log(response.result);
  }

  let currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
  if (currentBadgeColor[0] === 1) {
    document.getElementById('pwRunNowButton').disabled = true;
    document.getElementById('pwPostponeButton').disabled = true;
    document.getElementById('pwStopButton').disabled = false;
    document.getElementById('pwInfo').textContent = 'Sprawdzanie parametrów jest w toku.';
  }

  if (currentBadgeColor[1] === 1) {
    document.getElementById('csRunNowButton').disabled = true;
    document.getElementById('csPostponeButton').disabled = true;
    document.getElementById('csStopButton').disabled = false;
    document.getElementById('csInfo').textContent = 'Sprawdzanie statusów przesyłek jest w toku.';
  }

});

async function checkShipmentsMarkAsRead(e) {
  const waybillSpan = (e.target.nodeName === 'SPAN' ? e.target.parentElement.querySelector('span') : e.target.querySelector('span'));
  const waybillNumber = waybillSpan.innerText;
  let response;
  try {
    response =  await sendMessage({ action: 'checkShipmentsMarkAsRead', waybill: waybillNumber });
    if (!response.success) throw new Error(response.result);
   } catch (error) {
    console.log(error?.message);
  }
    
  let readedValue;
  try {
    readedValue = await readDataFromSessionStorage(['shipmentsMarkedAsReaded']);
    if (!readedValue.shipmentsMarkedAsReaded) readedValue.shipmentsMarkedAsReaded = [];
    if (!readedValue.shipmentsMarkedAsReaded.find(waybill => waybill === waybillNumber)) {
      readedValue.shipmentsMarkedAsReaded.push(waybillNumber);
      await saveDataToSessionStorage({ shipmentsMarkedAsReaded: readedValue.shipmentsMarkedAsReaded });
    }
    waybillSpan.closest('div.csShipments').style.opacity = 0;
  } catch (error) {
    console.log(error?.message);
  }
}

async function checkShipmentsShowPage(e) {
  const waybillSpan = (e.target.nodeName === 'SPAN' ? e.target.parentElement.querySelector('span') : e.target.querySelector('span'));
  const waybillNumber = waybillSpan.innerText;
  const hrefLink = document.createElement('a');
  hrefLink.href = `https://salescenter.allegro.com/ship-with-allegro/shipments?waybill=${waybillNumber}`;
  hrefLink.target = '_blank';
  hrefLink.click();
  hrefLink.remove();
  waybillSpan.classList.add('visited');
  try {
    let readedValue = await readDataFromSessionStorage(['checkShipmentsPageOpened']);
    if (!readedValue.checkShipmentsPageOpened) readedValue.checkShipmentsPageOpened = [];
    if (!readedValue.checkShipmentsPageOpened.find(waybill => waybill === waybillNumber)) {
      readedValue.checkShipmentsPageOpened.push(waybillNumber);
      await saveDataToSessionStorage({ checkShipmentsPageOpened: readedValue.checkShipmentsPageOpened });
    }
  } catch (error) {

  }
}


async function pwLinkSetVisited(e) {
  e.target.classList.add('visited');
  let readedValue = await readDataFromSessionStorage(['auctionsWithChangesInProducts']);
  if (readedValue['auctionsWithChangesInProducts'] !== undefined) {
    Array.from(readedValue['auctionsWithChangesInProducts']).forEach(auction => {
      if (auction.number === e.target.innerText) {
        auction.visited = true;
      }
    })
  }
  await saveDataToSessionStorage({ auctionsWithChangesInProducts: readedValue['auctionsWithChangesInProducts'] });
}



async function pwRunNowButtonClick(e) {
  e.target.disabled = true;
  document.getElementById('pwPostponeButton').disabled = true;
  document.getElementById('pwStopButton').disabled = false;
  document.getElementById('pwInfo').textContent = 'Sprawdzanie parametrów jest w toku.';
  let response;
  try {
    await chrome.storage.session.remove('auctionsWithChangesInProducts');
    document.getElementById('pwChangesList').textContent = '';
    document.getElementById('pwInfo').textContent = 'Sprawdzanie parametrów jest w toku.';
    response = await sendMessage({ action: 'parametersWatcherRun' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    e.target.disabled = false;
    document.getElementById('pwPostponeButton').disabled = false;
    document.getElementById('pwStopButton').disabled = true;
    document.getElementById('pwInfo') = '';
  }
}

async function pwPostponeButtonClick() {
  let response;
  try {
    response = await sendMessage({ action: 'parametersWatcherPostpone' });
    if (!response.success) throw new Error(response.result);
    document.getElementById('pwInfo').textContent = `Przełożono sprawdzanie parametrów na ${response.result}`;

    let actionTitle = await chrome.action.getTitle({});
    actionTitle = actionTitle.split('\n');
    actionTitle[0] = 'Usprawnienia serwisu Allegro';
    actionTitle = actionTitle.map(title => {
      if (title.indexOf('sprawdzanie parametrów') !== -1) {
        return `Następne sprawdzanie parametrów o ${response.result}`;
      } else {
        return title;
      }
    })
    await chrome.action.setTitle({ title: actionTitle.join('\n') });

  } catch (error) {
    document.getElementById('pwInfo').textContent = 'Nie udało się przełożyć sprawdzania parametrów';
  }
}

async function pwStopButtonClick(e) {
  e.target.disabled = true;
  try {
    await sendMessage({ action: 'parametersWatcherStop' });
    document.getElementById('pwRunNowButton').disabled = false;
    document.getElementById('pwPostponeButton').disabled = false; 
    document.getElementById('pwInfo').textContent = 'Zatrzymano';  
  } catch (error) {
    document.getElementById('pwInfo').textContent = 'Nie udało się zatrzymać sprawdzania parametrów. Wyłącz rozszerzenie aby zatrzymać.';
    e.target.disabled = false;
  }
}

async function csRunNowButtonClick(e) {
  e.target.disabled = true;
  document.getElementById('csPostponeButton').disabled = true;
  document.getElementById('csStopButton').disabled = false;
  document.getElementById('csInfo').textContent = 'Sprawdzanie statusów przesyłek jest w toku.';
  let response;
  try {
    document.getElementById('csShipmentsResults').textContent = '';
    document.getElementById('csInfo').textContent = 'Sprawdzanie statusów przesyłek jest w toku.';
    response = await sendMessage({ action: 'checkShipmentsRun' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    e.target.disabled = false;
    document.getElementById('csPostponeButton').disabled = false;
    document.getElementById('csStopButton').disabled = true;
    document.getElementById('csInfo').textContent = '';
  }
}

async function csPostponeButtonClick() {
  let response;
  try {
    response = await sendMessage({ action: 'checkShipmentsPostpone' });
    if (!response.success) throw new Error(response.result);
    document.getElementById('csInfo').textContent = `Przełożono sprawdzanie statusów przesyłek na ${response.result}`;

    let actionTitle = await chrome.action.getTitle({});
    actionTitle = actionTitle.split('\n');
    actionTitle[0] = 'Usprawnienia serwisu Allegro';
    actionTitle = actionTitle.map(title => {
      if (title.indexOf('sprawdzanie statusów') !== -1) {
        return `Następne sprawdzanie statusów przesyłek o ${response.result}`;
      } else {
        return title;
      }
    })
    await chrome.action.setTitle({ title: actionTitle.join('\n') });

  } catch (error) {
    document.getElementById('csInfo').textContent = 'Nie udało się przełożyć sprawdzania statusów przesyłek';
  }
}

async function csStopButtonClick(e) {
  e.target.disabled = true;
  try {
    await sendMessage({ action: 'checkShipmentsStop' });
    document.getElementById('csRunNowButton').disabled = false;
    document.getElementById('csPostponeButton').disabled = false; 
    document.getElementById('csInfo').textContent = 'Zatrzymano';  
  } catch (error) {
    document.getElementById('csInfo').textContent = 'Nie udało się zatrzymać sprawdzania statusów przesyłek. Wyłącz rozszerzenie aby zatrzymać.';
    e.target.disabled = false;
  }
}