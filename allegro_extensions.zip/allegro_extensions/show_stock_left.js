async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

window.addEventListener('load', () => {
	console.log('Załadowano skrypt showStockLeft');	

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;
  
	showStockLeftAwaitOrdersTable();
});

async function showStockLeftAwaitOrdersTable() {
  let previousUrl = '';
  const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
            return await showStockLeftAwaitOrdersTable(previousUrl);
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
        previousUrl = window.location.href; 
        urlObserver.disconnect();
				return await showStockLeftAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      //urlObserver.observe(document, {	subtree: true, childList: true });
      const params = new URLSearchParams(document.location.search);
	    const status = params.get('status');
      if (status === null || status === 'NEW' || status === 'PROCESSING') {
        let stockProgress = document.getElementById('stockProgress');
        if (stockProgress === null) {
          let insertionPoint;
          try {
            insertionPoint = ordersTable.children[1].firstElementChild.children[1];
            if (!insertionPoint) throw new Error('wait');
          } catch (error) {
            await new Promise(resolve => setTimeout(resolve, 100));
            return await showStockLeftAwaitOrdersTable();
          }
          insertionPoint.insertAdjacentHTML('afterend', `<div id="stockProgressBox"><label for="stockProgress">Pobieranie stanów magazynowych</label><progress id="stockProgress" max="100" value="0">0%</progress></div>`);
          stockProgress = document.getElementById('stockProgress');
        }
        try {
          await getOrders(stockProgress);
        } catch (error) {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
        }
      }
      urlObserver.observe(document, {	subtree: true, childList: true });
      return;
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function getOrders(stockProgress) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let response;
  try {
    response = await sendMessage({ action: 'getAllegroAccessToken' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  } 

  if (response.result === undefined) {
    return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
  }
  const accessToken = response.result;
  let parameters = {
    accessToken: accessToken,
    environment: environment,
    offersSoldTable: {},
    products: {},
    offset: 0
  }
  try {
    await fetchOrders(5, parameters, stockProgress);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  }
}

async function fetchOrders(count, parameters, stockProgress) {
  let response;
  try {
    response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms?offset=${parameters.offset}&fulfillment.status=NEW&status=READY_FOR_PROCESSING` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fetchOrders(count, parameters, stockProgress);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać listy zamówień. ${getErrorMessage(error)}`);
    }
  }
  if (response.status === 200) {
    let result;
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    
    parameters['totalCount'] = result.totalCount;
    parameters['checkoutForms'] = result.checkoutForms;

    if (stockProgress) stockProgress.max = parameters['totalCount'];
    try {
      await getOrder(0, parameters, stockProgress);
    } catch (error) {
      return Promise.reject(getErrorMessage(error));
    } 
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await fetchOrders(count, parameters, stockProgress);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
    }
  } else if (response.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (response.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await fetchOrders(count, parameters, stockProgress); 
    } else {
      return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania listy zamówień. Spróbuj ponownie później.');
    }
  } else if (response.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fetchOrders(count, parameters, stockProgress); 
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania listy zamówień, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await fetchOrders(count, parameters, stockProgress);      
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Kod odpowiedzi HTTP: ${response.status}`);
    }											
  }	
}

async function getOrder(i, parameters, stockProgress) {
  if (parameters.checkoutForms[i] === undefined) {
    if ((parameters.offset + 100) <= parameters.totalCount) {
      parameters.offset += 100;
      return await fetchOrders(5, parameters, stockProgress); 
    } else {
      stockProgress.value = '100';
      showStockLeftUpdate(parameters.offersSoldTable, parameters.products);
      return Promise.resolve(true);
    }
  }
  let order = parameters.checkoutForms[i];
  stockProgress.value = i;
  return await getLineItems(0, order, i, parameters, stockProgress);
}

async function getLineItems(line, order, i, parameters, stockProgress) {
  let item = order.lineItems[line];

  if (item === undefined) {
    return await getOrder(++i, parameters, stockProgress);
  }
  if (parameters.offersSoldTable[item.offer.id] !== undefined) {
    parameters.offersSoldTable[item.offer.id].sold += item.quantity;  
    return await getLineItems(++line, order, i, parameters, stockProgress);
  } else {
    parameters.offersSoldTable[item.offer.id] = {
      stock: 0,
      sold: item.quantity
    };
    return await getOfferStock(item.offer.id, 5, line, order, i, parameters, stockProgress);
  }
}

async function getOfferStock(offerId, count, line, order, i, parameters, stockProgress) {
  let response;
  try {
    response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać stanu magazynowego oferty ${offerId}. ${getErrorMessage(error)}`);
  }
  
  if (response.status === 200) {
    let result;
    try {
      result = await response.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }

    if (result.stock.available !== undefined) {
      parameters.offersSoldTable[offerId].stock = result.stock.available;
      const productId = result.productSet[0].product.id;
      if (parameters.products[offerId] === undefined) {
        let productName;
        try {
          productName = await getProductName(3, parameters, productId);
        } catch (error) {
          return Promise.reject(`Podczas pobierania nazwy produktu wystąpił błąd. ${getErrorMessage(error)}`);
        }
        parameters.products[offerId] = productName;
      }
      
      return await getLineItems(++line, order, i, parameters, stockProgress);
    }
  } else if (response.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getOfferStock(offerId, count, line, order, i, parameters);  
    } else {
      return Promise.reject(`Nie udało się pobrać stanu magazynowego oferty ${offerId}. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 429) {
    if (--count) {
      toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await getOfferStock(offerId, count, line, order, i, parameters);
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania stanu magazynowego oferty ${offerId}. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferStock(offerId, count, line, order, i, parameters);
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania stanu magazynowego oferty ${offerId}, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await getOfferStock(offerId, count, line, order, i, parameters);
    } else {
      return Promise.reject(`Nie udało się pobrać stanu magazynowego oferty ${offerId}. Kod odpowiedzi HTTP: ${response.status}`);
    }
  }
}

async function getProductName(count = 5, parameters, productId) {
	let response, fetchResponse;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getProductName(count, parameters, productId);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać nazwy produktu ${productId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let result;
		try {
			result = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (result.name !== undefined) {
			return Promise.resolve(result.name);
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await getProductName(count, parameters, productId);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await getProductName(count, parameters, productId);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania nazwy produktu ${productId}. Spróbuj ponownie później.`);
		}
	} else {
		return Promise.reject(`Nie udało się pobrać nazwy produktu ${productId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
	}
}

function showStockLeftUpdate(offersSoldTable, products) {
  document.getElementById('stockProgressBox')?.remove();
  let soldItems = document.querySelectorAll('span[data-test-id="item-offer-id"]');
  if (soldItems.length) {
    soldItems.forEach(soldItem => {
      const offerId = Number.parseInt(soldItem.innerText.slice(soldItem.innerText.lastIndexOf(' ')));
      let tableItem = offersSoldTable[offerId];
      if (tableItem !== undefined && tableItem.stock !== undefined && tableItem.sold !== undefined && soldItem.parentElement.lastElementChild.className !== 'stockLeft') {
        const insertionPoint = soldItem.parentElement;
        insertionPoint.insertAdjacentHTML('beforeend', `<span class="stockLeft">produkt: ${products[offerId]}</span><span class="stockLeft">pozostało:${(tableItem.stock === 0 ? '<span class="stockLeftValue stockLeftRed">0</span>' : '<span class="stockLeftValue">' + tableItem.stock + '</span>')}(sprzedano: ${tableItem.sold})</span>`);  
        const stockLeftValueSpan = insertionPoint.querySelector('span.stockLeftValue');
        stockLeftValueSpan.addEventListener('click', stockLeftValueClick);
        stockLeftValueSpan.addEventListener('blur', stockLeftValueBlur);
        stockLeftValueSpan.addEventListener('wheel', stockLeftValueWheel);
        stockLeftValueSpan.addEventListener('keydown', stockLeftValueKeyDown);
        stockLeftValueSpan.addEventListener('keyup', stockLeftValueKeyUp);
      }
    });
  }
}

function stockLeftValueClick(e) {
  e.target.contentEditable = "plaintext-only";
  e.target.dataset.default = e.target.innerText;
  e.target.focus();
  //e.target.classList.add('stockLeftEditable');
  
}

function stockLeftValueBlur(e) {
  e.target.contentEditable = false;
  e.target.innerText = e.target.dataset.default;
  if (e.target.innerText === '0') e.target.classList.add('stockLeftRed');
  else e.target.classList.remove('stockLeftRed');
  //e.target.classList.remove('stockLeftEditable');
}

function stockLeftValueWheel(e) {
  if (!e.target.isContentEditable) return;
  e.preventDefault();
  const direction = e.deltaY;
  const stockLeft = e.target;
  const stockLeftValue = stockLeft.innerText;
	if (direction < 0) {
		if (Number(stockLeftValue) < 9999) stockLeft.innerText = Number(stockLeftValue) + 1;
	} else {
		if (Number(stockLeftValue) > 0) stockLeft.innerText = Number(stockLeftValue) - 1;
	}

  if (stockLeft.innerText === '0') stockLeft.classList.add('stockLeftRed');
  else stockLeft.classList.remove('stockLeftRed');
}

async function sslUpdateStockOnErli(environment, accessToken, offerId, offerData, count = 5) {
  let response, fetchResponse;
  let frozenFields = [];
  let result;

  try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await sslUpdateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200) {
    try {
      result = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    frozenFields = Object.entries(result.frozen).filter(field => field[1] === true && ['stock', 'status'].indexOf(field[0]) !== -1).map(element => element[0]);
    if (frozenFields.indexOf('stock') !== -1) {
      return Promise.reject(`Uwaga! Aukcja ${offerId} jest zablokowana w Erli, nie można zmienić stanu magazynowego. Zablokowane pola: ${frozenFields.join(', ')}.`);
    }
    if (frozenFields.indexOf('status') !== -1 && offerData.status !== result.status) {
      return Promise.reject(`Uwaga! Aukcja ${offerId} jest zablokowana w Erli, nie można zmienić statusu aukcji. Zablokowane pola: ${frozenFields.join(', ')}.`);
    }
  } else if (fetchResponse.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await sslUpdateStockOnErli(environment, accessToken, offerId, offerData, count);
    } else {
      return Promise.reject(`Nie udało się pobrać danych aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
  }

  try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'PATCH',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await sslUpdateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
    }
  }

  if (fetchResponse.status === 200 || fetchResponse.status === 202) {
    return Promise.resolve({ result: offerId });
  } else if (fetchResponse.status === 404) {
    return Promise.reject(`Nie znaleziono aukcji ${offerId} w Erli.`);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await sslUpdateStockOnErli(environment, accessToken, offerId, offerData, count);      
    } else {
      return Promise.reject(`Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
  }
}

async function stockLeftValueKeyDown(e) {
  const char = e.which || e.keyCode;
  if (char == 27) {
    e.target.blur();
  } else if (char == 13) {
    if (e.target.innerText === e.target.dataset.default) {
      toastMessage('Nie ma nic do zmiany');
      e.target.blur();
    } else {
      e.preventDefault();
      const offerId = e.target.parentNode.parentNode.firstElementChild.innerText.split(' ')[1];
      if (!Number.isInteger(parseInt(offerId))) {
        toastMessage('Błąd! Nie znaleziono numeru aukcji.');
        e.target.blur();
      }

      /*sslUpdateStockOnErli*/
      let readedValue;
      try {
        readedValue = await readDataFromLocalStorage(['extensions', 'erliShowStockLeftCheckbox', 'erliToken', 'erliTokenSandbox', 'erliAlwaysSyncToSandbox']);
      } catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
        return;
      }
      const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
      const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
    
      const erliActions = readedValue.extensions['erliActions'];
      const erliShowStockLeft = readedValue.erliShowStockLeftCheckbox;
      let erliToken, erliEnvironment;

      if (erliActions && erliShowStockLeft) {
        if (readedValue.erliAlwaysSyncToSandbox) {
          erliToken = readedValue.erliTokenSandbox;
          erliEnvironment = 'sandbox.erli.dev';
        } else {
          if (sandbox === 'Sandbox') {
            erliToken = readedValue.erliTokenSandbox;
            erliEnvironment = 'sandbox.erli.dev';
          } else {
            erliToken = readedValue.erliToken;
            erliEnvironment = 'erli.pl';
          }
        }
      }

      const relativeChangeValue = (Number(e.target.dataset.default) - Number(e.target.innerText)) * -1;
      e.target.removeEventListener('blur', stockLeftValueBlur);
      e.target.contentEditable = false;
      if (e.target.innerText === '0') toastMessage(`Kończenie aukcji ${offerId}`);
      else if (e.target.dataset.default === '0') toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt. i wznawianie aukcji${erliActions && erliShowStockLeft ? ' na Allegro i w Erli' : ''}`);
      else toastMessage(`${relativeChangeValue > 0 ? '▲ Zwiększanie' : '▼ Zmniejszanie'} stanu magazynowego o ${Math.abs(relativeChangeValue)} szt.${erliActions && erliShowStockLeft ? ' na Allegro i w Erli' : ''}`);

      

      const parameters = {
        environment: environment,
        accessToken: '',
        erliEnvironment: erliEnvironment,
        erliToken: erliToken
      }

      let response;
      try {
        response = await sendMessage({ action: 'getAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
        e.target.innerText = e.target.dataset.default;
        if (e.target.innerText === '0') e.target.classList.add('stockLeftRed');
        else e.target.classList.remove('stockLeftRed');
        return;
      }
      parameters.accessToken = response.result;

      async function confirmStockChange(parameters, offerId, relativeChangeValue, count = 5) {
        let fetchResponse, response, result;
        try {
          fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
            'method': 'GET',
            'headers': {
              'Authorization': `Bearer ${parameters.accessToken}`,
              'Content-Type': 'application/vnd.allegro.public.v1+json',
              'Accept': 'application/vnd.allegro.public.v1+json'
            }
          });
        } catch (error) {
          return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić stanu magazynowego w ofercie ${offerId}. ${getErrorMessage(error)}`);
        }

        if (fetchResponse.status === 200) {
          try {
            result = await fetchResponse.json();
          } catch (error) {
            return Promise.reject(`Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
          }

          if (result.stock.available !== undefined) {
            const stock = {
              'stock': {
                'available': (e.target.innerText === '0' ? 0 : Number(result.stock.available) + relativeChangeValue)
              }
            }
            if (stock.stock.available < 0) stock.stock.available = 0;
            else if (result.publication.status === 'ENDED') {
              stock.publication = {
                'status': 'ACTIVE'
              }
            }
            try {
              fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}` , {
                'method': 'PATCH',
                'headers': {
                  'Authorization': `Bearer ${parameters.accessToken}`,
                  'Content-Type': 'application/vnd.allegro.public.v1+json',
                  'Accept': 'application/vnd.allegro.public.v1+json'
                },
                body: JSON.stringify(stock)
              });
            } catch (error) {
              return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić stanu magazynowego w ofercie ${offerId}. ${getErrorMessage(error)}`);
            }
            
            if (fetchResponse.status === 200) {
              if (stock.stock.available === 0) {
                try {
                  await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: 0, status: 'inactive' });
                } catch (error) {

                }
                return Promise.resolve({ message: 'Zakończono!', stock: 0 });
              }
              else if (stock?.publication?.status === 'ACTIVE') {
                try {
                  await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: stock.stock.available, status: 'active' });
                } catch (error) {

                }
                return Promise.resolve({ message: 'Zmieniono i wznowono zakończoną aukcję!', stock: stock.stock.available });
              }
              else {
                try {
                  await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: stock.stock.available });
                } catch (error) {

                }
                return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
              }
            } else if (fetchResponse.status === 202) {
              toastMessage('Trwa wprowadzanie zmian...');
              let responseStatusLocation = fetchResponse.headers.get('Location');
              if (responseStatusLocation) {
                try {
                  response = await checkChangeStatus(parameters, offerId, responseStatusLocation);
                  if (stock.stock.available === 0) {
                    try {
                      await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: 0, status: 'inactive' });
                    } catch (error) {

                    }
                    return Promise.resolve({ message: `Zakończono aukcję ${offerId}`, stock: 0 });
                  }
                  else if (stock?.publication?.status === 'ACTIVE') {
                    try {
                      await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: stock.stock.available, status: 'active' });
                    } catch (error) {

                    }
                    return Promise.resolve({ message: `Zmieniono i wznowono zakończoną aukcję ${offerId}`, stock: stock.stock.available });
                  }
                  else {
                    try {
                      await sslUpdateStockOnErli(parameters.erliEnvironment, parameters.erliToken, offerId, { stock: stock.stock.available });
                    } catch (error) {

                    }
                    return Promise.resolve({ message: 'Zmieniono!', stock: stock.stock.available });
                  }
                } catch (error) {
                  return Promise.reject(getErrorMessage(error));
                }	
              } else {
                return Promise.reject(`Nie udało się potwierdzić wprowadzenia zmiany w ofercie ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`);
              }
            } else if (fetchResponse.status === 401) {
              if (--count) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, 5000));
                try {
                  response = await sendMessage({ action: 'refreshAllegroAccessToken' });
                  if (!response.success) throw new Error(response.result);
                } catch (error) {	
                  return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
                }
                if (response.result === undefined) {
                  return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
                }								
                parameters.accessToken = response.result;
                return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
              } else {
                return Promise.reject(`Nie udało się zmienić liczby przedmiotów w ofercie ${offerId}. Nie udało się zalogować użytkownika.`);
              }
            } else if (fetchResponse.status === 403) {
              return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
            } else if (fetchResponse.status === 429) {
              if (--count) {
                toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
                return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
              } else {
                return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas zmiany liczby przedmiotów w ofercie ${offerId}. Spróbuj ponownie później.`);
              }
            } else if (fetchResponse.status === 500) {
              if (--count) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, 5000));
                return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
              } else {
                return Promise.reject(`Błąd serwera podczas zmiany liczby przedmiotów w ofercie ${offerId}, spróbuj ponownie później.`);
              }
            } else {
              if (--count) {
                toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
                await new Promise(resolve => setTimeout(resolve, 5000));
                return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
              } else {
                return Promise.reject(`Nie udało się zmienić liczby przedmiotów w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
              }
            }
          }
        } else if (fetchResponse.status === 401) {
          if (--count) {
            try {
              response = await sendMessage({ action: 'refreshAllegroAccessToken' });
              if (!response.success) throw new Error(response.result);
            } catch (error) {
              return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
            }
            if (response.result === undefined) {
              return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
            }
            parameters.accessToken = response.result;
            return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
          } else {
            return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
          }
        } else if (fetchResponse.status === 403) {
          return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
        } else if (fetchResponse.status === 429) {
          if (--count) {
            toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
            await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
            return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
          } else {
            return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania stanu magazynowego w ofercie ${offerId}. Spróbuj ponownie później.`);
          }
        } else if (fetchResponse.status === 500) {
          if (--count) {
            toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
            await new Promise(resolve => setTimeout(resolve, 5000));
            return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
          } else {
            return Promise.reject(`Błąd serwera podczas pobierania stanu magazynowego w ofercie ${offerId}, spróbuj ponownie później.`);
          }
        } else {
          if (--count) {
            toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
            await new Promise(resolve => setTimeout(resolve, 5000));
            return await confirmStockChange(parameters, offerId, relativeChangeValue, count);
          } else {
            return Promise.reject(`Nie udało się pobrać stanu magazynowego w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
          }
        }
      }

      try {
        response = await confirmStockChange(parameters, offerId, relativeChangeValue);
        e.target.dataset.default = response.stock;
        e.target.innerText = response.stock;
        if (e.target.innerText === '0') e.target.classList.add('stockLeftRed');
        toastMessage(response.message);
      } catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
        e.target.innerText = e.target.dataset.default;
        if (e.target.innerText === '0') e.target.classList.add('stockLeftRed');
        else e.target.classList.remove('stockLeftRed');
      } finally {
        e.target.addEventListener('blur', stockLeftValueBlur);
      }
    }
  } else {
    e.preventDefault();
  }
}

async function checkChangeStatus(parameters, offerId, responseStatusLocation, count = 10) {
	let fetchResponse;
	try {
		fetchResponse = await backgroundFetch(responseStatusLocation , {
		'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się potwierdzić wprowadzenia zmiany w ofercie ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`);
	}
	if (fetchResponse.status === 202) {
		if (--count) {
			toastMessage(`Sprawdzanie statusu wykonanej zmiany (${10 - count} z 10), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (10 - count) * (10 - count) * 3000));
			return await checkChangeStatus(parameters, offerId, responseStatusLocation, count);
		} else {
			return Promise.reject(`Nie udało się potwierdzić wprowadzenia zmiany w ofercie ${offerId}. Zweryfikuj czy została wykonana poprawnie sprawdzając aukcję ręcznie.`);
		}
	}	else if (fetchResponse.status === 200) {
		return Promise.resolve('Zmieniono!');
	}
}

function stockLeftValueKeyUp(e) {
  const char = e.which || e.keyCode;
  const stockLeft = e.target;
  const stockLeftValue = stockLeft.innerText;
  if (char == 38) {
    if (Number(stockLeftValue) < 9999) {
      stockLeft.innerText = Number(stockLeftValue) + 1;
    }
  } else {
    if (char == 40) {
      if (Number(stockLeftValue) > 0) {
        stockLeft.innerText = Number(stockLeftValue) - 1;
      }
    }
  }
  if (stockLeft.innerText === '0') stockLeft.classList.add('stockLeftRed');
  else stockLeft.classList.remove('stockLeftRed');
}



