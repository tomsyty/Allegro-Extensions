const NO_PERMISSION_GRANTED = 'Brak uprawnień.'

chrome.storage.onChanged.addListener((storageObject, storageArea) => {
	if (storageArea === 'session') {
		if ('message' in storageObject && 'newValue' in storageObject.message) {
			toastMessage(storageObject.message.newValue);
			chrome.storage.session.remove('message');
		}

		if ('shipmentsMarkedAsReaded' in storageObject && 'newValue' in storageObject.shipmentsMarkedAsReaded) {
			const checkShipmentsStatusDetails = document.getElementById('checkShipmentsStatusDetails');
			if (checkShipmentsStatusDetails && checkShipmentsStatusDetails.hasAttribute('open')) {
				checkShipmentsStatusDetails.dispatchEvent(new Event('toggle'));
			}
		}
	}
});

async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt optionsPage');
	let readedValue;
	try {
		readedValue = await readDataFromSessionStorage('message');
		if (readedValue.message !== undefined) {
			toastMessage(readedValue.message);
			await chrome.storage.session.remove('message');
		}
	} catch (error) {
		toastMessage(`Błąd! Nie udało się sprawdzić czy istnieje wiadomość którą należy wyświetlić albo nie udało się jej usunąć po jej wyświetleniu. ${getErrorMessage(error)}`);
	}

	const navigatorPermissions = await navigator.permissions.query({ name: 'clipboard-write' });
	if (navigatorPermissions.state !== undefined) {
		if (navigatorPermissions.state === 'granted') {
			const colorCodeCopyButton = document.getElementById('colorCodeCopyButton');
			colorCodeCopyButton.addEventListener('click', colorCodeCopyButtonClick);
			colorCodeCopyButton.parentNode.classList.remove('disabled');
		} else {
			console.log('Stan zezwolenia na zapis do schowka: ' + navigatorPermissions.state);
		}
	}
});

async function checkAllegroAPIPermission(e) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject(`Podczas pobierania listy rozszerzeń wystąpił błąd. ${getErrorMessage(error)}`);
	}

	if (e.target.checked) {
		if (!readedValue.extensions['allegroAPI']) {
			if (window.confirm('To rozszerzenie wymaga aktywowania najpierw rozszerzenia API Allegro. Czy chcesz włączyć je teraz?')) {
				return Promise.resolve(false);
			} else {
				e.target.checked = false;
				return Promise.reject('Aby aktywować rozszerzenie, wymagane jest aktywowanie rozszerzenia API Allegro.');
			}
		}
	}
	return Promise.resolve(true);
}

window.addEventListener('DOMContentLoaded', async () => {
	console.log('Options page DOMContentLoaded event');
	let readedValue;

	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		toastMessage(`Błąd! W trakcie próby odczytu danych wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}

	document.getElementById('changeInvoicesIconColor').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('highlightMessageFromBuyer').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('autoprintLabel').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['nativeMessaging', 'downloads', 'tabs']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* oraz uprawnień do zarządzania pobranymi plikami, komunikowania się ze współpracującymi aplikacjami natywnymi i dostępu do historii przeglądania.');
		}
	});

	document.getElementById('autofillPackageSize').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('inPostSendMode').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('additionalOrdersSortingOptions').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('validateBuyerAddressErrors').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('changeAuctionsTitle').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* i dostępu do historii przeglądania');
		}
	});

	document.getElementById('fastStockManager').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('restoreCancelled').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('restoreReturned').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* i dostępu do historii przeglądania');
		}
	});

	document.getElementById('iFirmaReturnsCheckbox').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://www.ifirma.pl/*']
		});
		if (granted) {
			
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do strony https://www.ifirma.pl/*');
		}
	});

	document.getElementById('showProductName').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('offerTags').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('showStockLeft').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('shipmentExistsWarning').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('showShipmentStatus').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('parametersWatcher').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('buyerStats').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('erliActions').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*', 'https://erli.pl/*', 'https://sandbox.erli.dev/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*, https://erli.pl/*, https://sandbox.erli.dev/*');
		}
	});

	document.getElementById('additionalActions').addEventListener('change', async (e) => {
		let apiON;
		try {
			apiON = await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			await extensionSetState(e.target);
			if (!apiON) {
				const apiSwitch = document.getElementById('allegroAPI');
				apiSwitch.dispatchEvent(new CustomEvent('change', { detail: apiSwitch }));
			}
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('changeAdditionalInfo').addEventListener('change', (e) => {
		e.target.parentNode.parentNode.parentNode.disabled = !e.target.checked;
		if (!e.target.checked) {
			document.getElementById('additionalInfoProgress').style = 'width: 0%';
		}

		if (e.target.checked) {
			let allegroTokenScopes = document.getElementById('allegroTokenScopes').textContent.split(', ');
			if (!allegroTokenScopes.includes('allegro:api:profile:read')) allegroTokenScopes.push('allegro:api:profile:read');
			let allegroTokenScopesSandbox = document.getElementById('allegroTokenScopesSandbox').textContent.split(', ');
			if (!allegroTokenScopesSandbox.includes('allegro:api:profile:read')) allegroTokenScopesSandbox.push('allegro:api:profile:read');
			let missingScopes = [];
			let missingScopesSandbox = [];

			const requiredScopes = ['allegro:api:sale:offers:read', 'allegro:api:sale:offers:write'];
			requiredScopes.forEach(scope => {
				if (allegroTokenScopes.includes(scope) === false) {
					missingScopes.push(scope);
				}
				if (allegroTokenScopesSandbox.includes(scope) === false) {
					missingScopesSandbox.push(scope);
				}
			});
					
			if (readedValue.extensions['allegroAPI'] === true) {
				if (missingScopes.length) {
					toastMessage(`Uwaga! Aktualnie nie masz przyznanych następujących uprawnień: ${missingScopes.join(', ')}. Edytuj uprawnienia na <a href="https://apps.developer.allegro.pl" target="_blank">stronie rejestracji aplikacji</a> a następnie kliknij przycisk Zaloguj aby uzyskać przyznane uprawnienia.`);
				}
				if (missingScopesSandbox.length && document.getElementById('allegroAPIClientIdTextSandbox').value !== '' && document.getElementById('allegroAPIClientSecretTextSandbox').value !== '') {
					toastMessage(`Uwaga! Aktualnie nie masz przyznanych następujących uprawnień: ${missingScopesSandbox.join(', ')} dla serwisu testowego Sandbox. Edytuj uprawnienia na <a href="https://apps.developer.allegro.pl.allegrosandbox.pl" target="_blank">stronie rejestracji aplikacji</a> serwisu testowego Sandbox a następnie kliknij przycisk Zaloguj aby uzyskać przyznane uprawnienia.`);
				}
			}
		}
	});

	document.getElementById('additionalInfoChangeButton').addEventListener('click', async (e) => {
		e.target.disabled = true;
		document.getElementById('additionalInfoMode').disabled = true;
		const environment = (document.getElementById('additionalInfoModeNormal').checked ? '' : '.allegrosandbox.pl');
		const mode = (environment === '' ? 'allegro' : 'sandbox');
		let progressBar = document.getElementById('additionalInfoProgress');
		progressBar.class = 'progress-bar';
		progressBar.ariaValueNow = '0';
		progressBar.ariaValueMax = '0';
		progressBar.style = 'width: 0%';
		document.getElementById('additionalInfoFailures').classList.add('hidden');
		document.getElementById('additionalInfoErrorsList').innerText = '';
		let response;
		try {
			response = await sendMessage({ action: 'getAllegroAccessToken', mode: mode });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
			return Promise.reject(false);
		}
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
			return Promise.reject(false);
		}

		let parameters = {
			accessToken: response.result,
			environment: environment
		}
		
		let offersCount = 0;
		try {
			response = await getOffersCount(parameters, 5);
			response = await processOffers(parameters, response);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
		}
		
		async function getOffersCount(parameters, count) {
			let result, fetchResponse;
			try {
				fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1&publication.status=ACTIVE&publication.status=ENDED`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać liczby aukcji.');
				}
			}
			if (fetchResponse.status === 200) {
				try {
					result = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}
				offersCount = result.totalCount;
				return Promise.resolve(offersCount);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					parameters.accessToken = response.result;  
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject('Nie udało się zalogować użytkownika.');
				}		
			} else if (fetchResponse.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject(`Błąd serwera podczas pobierania liczby ofert, spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));;
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject(`Nie udało się pobrać liczby aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}							
			}	
		}

		async	function processOffers(parameters, offersCount) {
			progressBar.ariaValueMax = offersCount;

			const text = document.getElementById('additionalInfoText').value;
			try {
				response = await getOffers();
			} catch (error) {
				toastMessage(`Błąd! ${getErrorMessage(error)}`);
			}

			async function getOffers(offset = 0, count = 5) {
				let fetchResponse, result;
				if (offset > offersCount) {
					progressBar.ariaValueNow = progressBar.ariaValueMax;
					progressBar.style = 'width: 100%';
					progressBar.className = 'progress-bar bg-success';
					toastMessage('Zakończono zmianę ofert.');
					e.target.disabled = false;
					document.getElementById('additionalInfoMode').disabled = false;
					return;
				}
				try {
					fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=10&publication.status=ACTIVE&publication.status=ENDED`, {
						'method': 'GET',
						'headers': {
							'Authorization': `Bearer ${parameters.accessToken}`,
							'Content-Type': 'application/vnd.allegro.public.v1+json',
							'Accept': 'application/vnd.allegro.public.v1+json'
						}
					});
				} catch (error) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aukcji.');
					}
				}
				if (fetchResponse.status === 200) {
					try {
						result = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
					}
								
					let offersList = [];
					result.offers.forEach(offer => {
						offersList.push(offer.id);
					});

					if (offersList.length) {
						async function changeOffers(offersList) {
							const offerId = offersList.shift();
							if (offerId === undefined) {
								if (result.totalCount > (offset + 10)) {
									await new Promise(resolve => setTimeout(resolve, 0));
									return await getOffers(offset + 10);
								} else {
									progressBar.ariaValueNow = progressBar.ariaValueMax;
									progressBar.style = 'width: 100%';
									progressBar.className = 'progress-bar bg-success';
									toastMessage('Zakończono zmianę ofert.');
									e.target.disabled = false;
									document.getElementById('additionalInfoMode').disabled = false;
									return Promise.resolve(true);
								}
							}

							async function changeOffer(count = 5) {
								console.log(`Zmiana oferty ${offerId}`);
								try {
									fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
										'method': 'PATCH',
										'headers': {
											'Authorization': `Bearer ${parameters.accessToken}`,
											'Content-Type': 'application/vnd.allegro.public.v1+json',
											'Accept': 'application/vnd.allegro.public.v1+json'
										},
										body: JSON.stringify({
											'delivery': {
												'additionalInfo': text
											}
										})
									});
								} catch (error) {
									if (--count) {
										toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await changeOffer(count);
									} else {
										return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aukcji ${offerId}.`);
									}
								}
									
								if (fetchResponse.status === 200) {
									progressBar.ariaValueNow = Number(progressBar.ariaValueNow) + 1;
									progressBar.style = `width: ${Math.floor(100 / (result.totalCount / Number(progressBar.ariaValueNow)))}%`;
									return await changeOffers(offersList);
								} else if (fetchResponse.status === 401) {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: mode });
											if (!response.success) throw new Error(response.result);
										} catch (error) {
											return Promise.reject(getErrorMessage(error));
										}
										if (response.result === undefined) {
											return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
										}
										parameters.accessToken = response.result;  
										return await changeOffer(count);												
									} else {
										e.target.disabled = false;
										document.getElementById('additionalInfoMode').disabled = false;
										return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
									}
								} else if (fetchResponse.status === 403) {
									e.target.disabled = false;
									document.getElementById('additionalInfoMode').disabled = false;
									return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								} else {
									if (--count) {
										toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await changeOffer(count);
									} else {
										document.getElementById('additionalInfoErrorsList').innerText += `${offerId} `;
										progressBar.ariaValueNow = Number(progressBar.ariaValueNow) + 1;
										progressBar.style = `width: ${Math.floor(100 / (result.totalCount / Number(progressBar.ariaValueNow)))}%`;
										document.getElementById('additionalInfoFailures').classList.remove('hidden');
										return await changeOffers(offersList);
									}
								}
							}
							await changeOffer();
						}
						await changeOffers(offersList);
					}
				} else if (fetchResponse.status === 401) {
					if (--count) {
						try {
							response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: mode });
							if (!response.success) throw new Error(response.result);
						} catch (error) {
							e.target.disabled = false;
							document.getElementById('additionalInfoMode').disabled = false;
							return Promise.reject(getErrorMessage(error));
						}
						if (response.result === undefined) {
							return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
						}
						parameters.accessToken = response.result;  
						return await getOffers(offset, count);
					} else {
						e.target.disabled = false;
						document.getElementById('additionalInfoMode').disabled = false;
						return Promise.reject('Nie udało się pobrać aukcji. Nie udało się zalogować użytkownika.');
					}
				} else if (fetchResponse.status === 403) {
					e.target.disabled = false;
					document.getElementById('additionalInfoMode').disabled = false;
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				} else if (fetchResponse.status === 429) {
					if (--count) {
						toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
						return await getOffers(offset, count);
					}
				} else if (fetchResponse.status === 500) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject(`Błąd serwera podczas próby zmiany oferty, spróbuj ponownie później.`);
					}
				} else {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						e.target.disabled = false;
						document.getElementById('additionalInfoMode').disabled = false;
						return Promise.reject(`Nie udało się pobrać aukcji. Kod HTTP odpowiedzi : ${fetchResponse.code}`);
					}
				}	
			}
		} 
	});

	document.getElementById('allegroAPI').addEventListener('change', async (e) => {
		if (e.target.checked === false && e.isTrusted) {
			let apiDependentModules = [];
			let checkboxesTurnedOff = [];
			const event = new Event('change');
			[...document.querySelectorAll('input[role="switch"]:checked')].forEach(e => {
				if (e.dataset.scopes) {
					checkboxesTurnedOff.push(e);
					apiDependentModules.push(document.querySelector(`label[for="${e.id}"]`).innerText);
					e.checked = false;
				}
			});
			try {
				await extensionSetState(...checkboxesTurnedOff);

			} catch (error) {
				toastMessage('Uwaga! Podczas dekatywacji niektórych modułów wystąpił błąd i nie udało się ich deaktywować. Jeśli masz otwarte strony Allegro, odśwież je aby deaktywować załadowane w nich moduły.');
			}
			
			if (apiDependentModules.length) toastMessage(`Uwaga! Następujące aktywne moduły zależne od API zostały wyłączone: ${apiDependentModules.join(', ')}`);
		}
		const granted = await chrome.permissions.request({
			permissions: ['identity'],
			origins: ['https://api.allegro.pl/*', 'https://salescenter.allegro.com/*', 'https://api.allegro.pl.allegrosandbox.pl/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			if (!e.isTrusted) {
				document.getElementById('allegroAPI').checked = true;
				await extensionSetState(e.target, e.detail);
			} else await extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować rozszerzenie, wymagane jest przyznanie uprawnień dostępu do strony https://api.allegro.pl/*, https://salescenter.allegro.com/*, https://api.allegro.pl.allegrosandbox.pl/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.querySelectorAll('.keyboardShortcutChangeLink').forEach(element => element.addEventListener('click', (e) => {
		e.preventDefault();
		chrome.tabs.create({url: 'chrome://extensions/shortcuts'});
	}));

	document.getElementById('numericValuesRadio').addEventListener('change', (e) => {
		const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
		shipmentMethodAdditionalInfoText.innerText = 'Dla ręcznie dodawanej formy dostawy nie są znane ograniczenia dotyczące wagi i wymiarów. Wprowadź wartość która nie generuje błędu w formularzu nadawczym.';
		const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
		shipmentMethodNameText.disabled = false;
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues');
		if (!shipmentMethodPredefinedValues.classList.contains('hidden')) {
			const predefinedValuesBox = document.getElementById('predefinedValuesBox');
			predefinedValuesBox.innerHTML = '';
			shipmentMethodPredefinedValues.classList.add('hidden');
		}
		shipmentMethodNumericValues.querySelectorAll('input[type="number"]').forEach(element => element.value = '');
		shipmentMethodNumericValues.classList.remove('hidden');

		const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
		numericValuesTemplatesBox.innerHTML = '';
		shipmentMethodAddTemplateClick();
	});

	document.getElementById('predefinedValuesRadio').addEventListener('change', () => {
		const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
		shipmentMethodAdditionalInfoText.innerText = 'Rozwiń dodatkowe menu koło przycisku "Zapisz" aby dodać nową pozycję.';
		const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
		shipmentMethodNameText.disabled = false;
		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		if (!shipmentMethodNumericValues.classList.contains('hidden')) {
			const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
			numericValuesTemplatesBox.innerHTML = '';
			shipmentMethodNumericValues.classList.add('hidden');
			shipmentMethodNumericValues.querySelectorAll('input[type="number"]').forEach(element => element.value = '');
		}
	});

	document.getElementById('hmfbHighlightModeTextColor').addEventListener('change', () => {
		const colorPickerHmfb = document.getElementById('colorPickerHmfb');
		const el2 = document.querySelector('label[for="hmfbHighlightModeTextBackground"]');
		el2.style.backgroundColor = 'initial';
		const el3 = document.querySelector('label[for="hmfbHighlightModeTextBorder"]');
		el3.style.border = 'none';
		const el1 = document.querySelector('label[for="hmfbHighlightModeTextColor"]');
		el1.style.color = colorPickerHmfb.value;
	});

	document.getElementById('hmfbHighlightModeTextBackground').addEventListener('change', () => {
		const colorPickerHmfb = document.getElementById('colorPickerHmfb');
		const el1 = document.querySelector('label[for="hmfbHighlightModeTextColor"]');
		el1.style.color = 'initial';
		const el3 = document.querySelector('label[for="hmfbHighlightModeTextBorder"]');
		el3.style.border = 'none';
		const el2 = document.querySelector('label[for="hmfbHighlightModeTextBackground"]');
		el2.style.backgroundColor = colorPickerHmfb.value;	
	});

	document.getElementById('hmfbHighlightModeTextBorder').addEventListener('change', () => {
		const colorPickerHmfb = document.getElementById('colorPickerHmfb');
		const el1 = document.querySelector('label[for="hmfbHighlightModeTextColor"]');
		el1.style.color = 'initial';
		const el2 = document.querySelector('label[for="hmfbHighlightModeTextBackground"]');
		el2.style.backgroundColor = 'initial';	
		const el3 = document.querySelector('label[for="hmfbHighlightModeTextBorder"]');
		Object.assign(el3.style, {
			borderWidth: '3px',
			borderStyle: 'solid',
			borderColor: `${colorPickerHmfb.value}`
		});
	});

	document.getElementById('saveCssHmfbButton').addEventListener('click', saveCssHmfbButtonClick);

	const commands = await chrome.commands.getAll();
	let shortcut = commands.find(command => command.name === 'changeAuctionsTitle').shortcut;
	let shortcutKeys = [];
	for (const key of shortcut.split('+')) {
		shortcutKeys.push(`<kbd>${key}</kbd>`); 
	}
	let shortcutHTML = shortcutKeys.join(' + ');
	document.getElementById('keyboardShortcutChangeAuctionsTitleSpan').innerHTML = shortcutHTML;

	shortcut = commands.find(command => command.name === 'offerTags').shortcut;
	shortcutKeys = [];
	for (const key of shortcut.split('+')) {
		shortcutKeys.push(`<kbd>${key}</kbd>`); 
	}
	shortcutHTML = shortcutKeys.join(' + ');
	document.getElementById('keyboardShortcutOfferTagsSpan').innerHTML = shortcutHTML;

	let toggleSwitches = Array.from(document.querySelectorAll('legend .form-check-input'));
	toggleSwitches.unshift(toggleSwitches.pop());
	toggleSwitches.forEach(toggleSwitch => {
		const extensionId = toggleSwitch.id;
		toggleSwitch.checked = readedValue.extensions[extensionId];
		toggleSwitch.parentNode.parentNode.parentNode.disabled = !toggleSwitch.checked;
		if (toggleSwitch.checked) window[extensionId]();
	});
});

async function extensionSetState(...targets) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		toastMessage(`Błąd! Podczas pobierania listy rozszerzeń wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}

	for (const target of targets) {
		const extensionId = target.id;
		readedValue.extensions[extensionId] = target.checked;
		target.parentNode.parentNode.parentNode.disabled = !target.checked;
	}
	try {
		await saveDataToLocalStorage({ extensions: readedValue.extensions });
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisywania stanu rozszerzenia wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}
	
	for (const target of targets) {
		const extensionId = target.id;
		if (target.checked) window[extensionId]();
		else {
			const contentScripts = await chrome.scripting.getRegisteredContentScripts();
			if (contentScripts.find(registeredScript => { return registeredScript.id === extensionId }) !== undefined) {
				try {
					await chrome.scripting.unregisterContentScripts({ ids: [extensionId] });
					console.log(`${extensionId} Skrypt został wyrejestrowany`);
					if (extensionId === 'showShipmentStatus') {
						let alarms = await chrome.alarms.get('checkShipmentsStatusAlarm');
						if (alarms) {
							await sendMessage({ action: 'checkShipmentsStatusDisableSchedule'});
						}
						if (Array.from(await chrome.alarms.getAll()).find(alarm => alarm.name === 'parametersWatcherAlarm' || alarm.name === 'checkShipmentsStatusAlarm')) await chrome.action.setIcon({ path: 'icon-48-timer.png' });
						else await chrome.action.setIcon({ path: 'icon-48.png' });
					}

					if (extensionId === 'parametersWatcher') {
						let alarms = await chrome.alarms.get('parametersWatcherAlarm');
						if (alarms) {
							await sendMessage({ action: 'parametersWatcherDisableSchedule'});
						}
						if (Array.from(await chrome.alarms.getAll()).find(alarm => alarm.name === 'parametersWatcherAlarm' || alarm.name === 'checkShipmentsStatusAlarm')) await chrome.action.setIcon({ path: 'icon-48-timer.png' });
						else await chrome.action.setIcon({ path: 'icon-48.png' });
					}
				} catch (error) {
					toastMessage(`Wystąpił błąd podczas wyrejestrowywania skryptu ${extensionId}. ${getErrorMessage(error)}`);
				}
			}
		}
	}

	let allegroTokenScopes = document.getElementById('allegroTokenScopes').textContent.split(', ');
	if (!allegroTokenScopes.includes('allegro:api:profile:read')) allegroTokenScopes.push('allegro:api:profile:read');
	let allegroTokenScopesSandbox = document.getElementById('allegroTokenScopesSandbox').textContent.split(', ');
	if (!allegroTokenScopesSandbox.includes('allegro:api:profile:read')) allegroTokenScopesSandbox.push('allegro:api:profile:read');
	let missingScopes = [];
	let missingScopesSandbox = [];

	for (const target of targets) {
		const extensionId = target.id;
		if (extensionId === 'allegroAPI') continue;
		if (target.checked) {
			const requiredScopes = document.getElementById(extensionId).dataset.scopes;
			if (requiredScopes) {
				requiredScopes.split(', ').forEach(scope => {
					if (allegroTokenScopes.includes(scope) === false) {
						missingScopes.push(scope);
						document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(element => {
							element.classList.remove('scopeGrantedYes');
							element.classList.add('scopeGrantedNo');
						});
					} else {
						document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(element => {
							element.classList.remove('scopeGrantedNo');
							element.classList.add('scopeGrantedYes');
						});
					}
					if (allegroTokenScopesSandbox.includes(scope) === false) {
						missingScopesSandbox.push(scope);
						document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(element => {
							element.classList.remove('scopeGrantedYesSandbox');
							element.classList.add('scopeGrantedNoSandbox');
						});
					} else {
						document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(element => {
							element.classList.remove('scopeGrantedNoSandbox');
							element.classList.add('scopeGrantedYesSandbox');
						});
					}
				});
			}
		}
	}

	if (readedValue.extensions['allegroAPI'] === true) {
		if (missingScopes.length) {
			toastMessage(`Uwaga! Aktualnie nie masz przyznanych następujących uprawnień: ${missingScopes.join(', ')}. Edytuj uprawnienia na <a href="https://apps.developer.allegro.pl" target="_blank">stronie rejestracji aplikacji</a> a następnie kliknij przycisk Zaloguj aby uzyskać przyznane uprawnienia.`);
		}
		if (missingScopesSandbox.length && document.getElementById('allegroAPIClientIdTextSandbox').value !== '' && document.getElementById('allegroAPIClientSecretTextSandbox').value !== '') {
			toastMessage(`Uwaga! Aktualnie nie masz przyznanych następujących uprawnień: ${missingScopesSandbox.join(', ')} dla serwisu testowego Sandbox. Edytuj uprawnienia na <a href="https://apps.developer.allegro.pl.allegrosandbox.pl" target="_blank">stronie rejestracji aplikacji</a> serwisu testowego Sandbox a następnie kliknij przycisk Zaloguj aby uzyskać przyznane uprawnienia.`);
		}
	}

	if (readedValue.extensions['parametersWatcher'] === false && readedValue.extensions['showShipmentStatus'] === false) chrome.action.setPopup({ popup: '' });
}

async function allegroAPILoginButtonClick(sandboxParam = false) {
	const environment = (sandboxParam === false ? '' : '.allegrosandbox.pl');
	const mode = (environment === '' ? 'allegro' : 'sandbox');
	const sandbox = (environment === '' ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	let loginData;
	try {
		loginData = await readDataFromLocalStorage([`allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu danych logowania wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}

	if (loginData[`allegroAPIClientId${sandbox}`] === undefined || loginData[`allegroAPIClientSecret${sandbox}`] === undefined) {
		toastMessage('Błąd! Nie znaleziono danych wymaganych do logowania.');
		return;
	}

	async function login(count = 5) {
		if (!count) {
			return Promise.reject('Nie udało się zalogować użytkownika.');
		}

		let params = {
			scopes: ['allegro:api:profile:read']
		}

		document.querySelectorAll('legend .form-check-input:checked').forEach(toggleSwitch => {
			if (toggleSwitch.dataset.scopes !== undefined) {
				toggleSwitch.dataset.scopes.split(', ').forEach(scope => {
					if (!params.scopes.includes(scope)) params.scopes.push(scope);
				});
			}
		});

		let fetchResponse;
		let fetchData;
		let response;

		const redirectUri = document.getElementById('chromeExtensionRedirectURL').innerText;
		let redirectUrl;
		try {
			redirectUrl = await chrome.identity.launchWebAuthFlow({ 'url': `https://allegro.pl${environment}/auth/oauth/authorize?response_type=code&client_id=${document.getElementById(`allegroAPIClientIdText${sandbox}`).value}&redirect_uri=${redirectUri}&scope=${params.scopes.join(' ')}&prompt=confirm`, 'interactive': true, 'abortOnLoadForNonInteractive': false, timeoutMsForNonInteractive: 10000 });
		} catch (error) {
			if (error.message === 'The user did not approve access.') return Promise.reject('Proces logowania nie został zakończony.');
		}

		if (redirectUrl !== undefined) {
			if (redirectUrl.indexOf('error') !== -1) {
				if (redirectUrl.indexOf('error=invalid_scope') !== -1) {
					return Promise.reject('Nie przyznano wymaganych uprawnień. Edytuj uprawnienia na stronie rejestracji aplikacji a następnie kliknij przycisk Zaloguj aby uzyskać przyznane uprawnienia.');
				} else {
					return Promise.reject(`Podczas pobierania kodu wystąpił błąd. ${decodeURIComponent(redirectUrl.split('?')[1])}`);
				}
			}
			const code = redirectUrl.substring(redirectUrl.indexOf('code=') + 5);
			try {
				fetchResponse = await fetch(`https://allegro.pl${environment}/auth/oauth/token`, {
					method: 'POST',
					headers: {
						'Authorization': `Basic ${btoa(loginData[`allegroAPIClientId${sandbox}`] + ':' + loginData[`allegroAPIClientSecret${sandbox}`])}`,
						'Content-Type': 'application/x-www-form-urlencoded'
					},
					body: encodeURI(`grant_type=authorization_code&code=${code}&redirect_uri=${redirectUri}`)
				});
			} catch (error) {
				return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać tokenów dostępowych.`);
			}
			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}

				if (fetchData.access_token !== undefined && fetchData.refresh_token !== undefined && fetchData.scope !== undefined) {
					try {
						await saveDataToLocalStorage({ [`allegroAccessToken${sandbox}`]: fetchData.access_token, [`allegroRefreshToken${sandbox}`]: fetchData.refresh_token, [`allegroTokenScopes${sandbox}`]: fetchData.scope.split(' ').join(', ') });
					} catch (error) {
						return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${getErrorMessage(error)}`);
					}
					document.getElementById(`allegroTokenScopes${sandbox}`).textContent = fetchData.scope.split(' ').join(', ');
					fetchData.scope.split(' ').forEach(scope => {
						document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(span => {
							span.classList.add(`scopeGrantedYes${sandbox}`);
							span.classList.remove(`scopeGrantedNo${sandbox}`);
						})
					});

					async function getLoggedUsername(count = 5) {
						try {
							fetchResponse = await fetch(`https://api.allegro.pl${environment}/me`, {
								method: 'GET',
								headers: {
									'Authorization': `Bearer ${fetchData.access_token}`,
									'Content-Type': 'application/vnd.allegro.public.v1+json',
									'Accept': 'application/vnd.allegro.public.v1+json'
								}
							});
						} catch (error) {
							if (--count) {
								toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
								await new Promise(resolve => setTimeout(resolve, 5000));
								return await getLoggedUsername(count);
							} else {
								return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić nazwy zalogowanego użytkownika.`);
							}
						}

						if (fetchResponse.status === 200) {
							try {
								fetchData = await fetchResponse.json();
							} catch (error) {
								return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
							}
							if (fetchData.login !== undefined) return Promise.resolve(fetchData.login);
							else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
						} else if (fetchResponse === 401) {
							if (--count) {
								try {
									response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: mode });
									if (!response.success) throw new Error(response.result);
								} catch (error) {
									return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
								}
								if (response.result === undefined) {
									return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
								}
								fetchData.access_token = response.result;
								return await getLoggedUsername(count);
							} else {
								return Promise.reject('Nie udało się odświeżyć tokena dostępowego.');
							}
						} else if (fetchResponse.status === 403) {
							return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
						} else if (fetchResponse.status === 429) {
							if (--count) {
								toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
								await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
								return await getLoggedUsername(count);
							} else {
								return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania nazwy użytkownika. Spróbuj ponownie później.');
							}		
						} else if (fetchResponse.status === 500) {
							if (--count) {
								toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
								await new Promise(resolve => setTimeout(resolve, 5000));
								return await getLoggedUsername(count);
							} else {
								return Promise.reject(`Błąd serwera podczas pobierania nazwy użytkownika, spróbuj ponownie później.`);
							}
						} else {
							if (--count) {
								toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
								await new Promise(resolve => setTimeout(resolve, 5000));
								return await getLoggedUsername(count);
							} else {
								return Promise.reject(`Nie udało się pobrać nazwy użytkownika. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
							}
						}
					}

					try {
						const username = await getLoggedUsername();
						return Promise.resolve(`Zalogowano jako użytkownik ${username}`);
					} catch (error) {
						return Promise.reject(`${error}`);
					}
				}
			} else if (fetchResponse.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do Allegro. Spróbuj ponownie później.`);
					await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await checkOrderStatus(count);
				} else {
					return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane. Spróbuj ponownie później.`);
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await checkOrderStatus(count);
				} else {
					return Promise.reject(`Błąd serwera podczas sprawdzania czy zamówienie ${orderId} nie jest anulowane, spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await login(count);
				} else {
					return Promise.reject(`Nie udało się pobrać tokenów dostępowych. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}
			}
		}
		
	}
	try {
		const result = await login();
		toastMessage(result);
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
}

async function allegroAPISaveButtonClick(sandboxParam = false) {
	const sandbox = (sandboxParam === false ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	try {
		const response = await sendMessage({ action: 'allegroAPISave', clientId: document.getElementById(`allegroAPIClientIdText${sandbox}`).value, clientSecret: document.getElementById(`allegroAPIClientSecretText${sandbox}`).value, sandbox: sandboxParam });
		document.getElementById(`allegroAPISaveButton${sandbox}`).disabled = true;
		document.getElementById(`allegroAPILoginButton${sandbox}`).disabled = !response.result;
		if (!response.success) throw new Error(response.result);
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu parametrów Client ID i Cilent Secret wystąpił błąd. ${getErrorMessage(error)}`);
	};
}


async function changeInvoicesIconColor() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	
		
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'changeInvoicesIconColor')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'changeInvoicesIconColor',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['change_invoices_icon_color.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'changeInvoicesIconColor',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['change_invoices_icon_color.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['color', 'filter']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania stylu ikony faktury wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (readedValue.color !== undefined && readedValue.filter !== undefined) {
		const colorPickerValue = document.getElementById('colorPickerValue');
		const colorFilterText = document.getElementById('colorFilterText');
		const colorPicker = document.getElementById('colorPicker');
		colorPickerValue.value = readedValue.color;
		colorFilterText.value = readedValue.filter;
		colorPicker.value = readedValue.color;
		colorPicker.addEventListener('input', colorPickerChange);
		const event = new Event('input');
		colorPicker.dispatchEvent(event);
		colorFilterText.addEventListener('input', colorFilterTextInput);
		const saveFilterButton = document.getElementById('saveFilterButton');
		saveFilterButton.addEventListener('click', saveFilterButtonClick);
	}

}

async function highlightMessageFromBuyer() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	
		
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'highlightMessageFromBuyer')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'highlightMessageFromBuyer',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['highlight_message_from_buyer.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'highlightMessageFromBuyer',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['highlight_message_from_buyer.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['cssHmfb']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania informacji o sposobie wyróżniania wiadomości od kupującego wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (readedValue.cssHmfb !== undefined ) {
		if (readedValue.cssHmfb.indexOf('border') !== -1) {
			document.getElementById('hmfbHighlightModeTextBorder').checked = true;
		} else if (readedValue.cssHmfb.indexOf('background-color') !== -1) {
			document.getElementById('hmfbHighlightModeTextBackground').checked = true;
		}

		const colorPicker = document.getElementById('colorPickerHmfb');
		colorPicker.value = readedValue.cssHmfb.slice(readedValue.cssHmfb.indexOf('#')).replace(';', '');
		colorPicker.addEventListener('input', colorPickerHmfbChange);
		const event = new Event('input');
		colorPicker.dispatchEvent(event);
	}
}

function colorPickerHmfbChange() {
	const selectedRadio = [...document.querySelectorAll('input[name="hmfbHighlightMode"]')].find(e => e.checked).id;
	const event = new Event('change');
	document.getElementById(selectedRadio).dispatchEvent(event);
}

async function saveCssHmfbButtonClick() {
	let cssStyle;
	const colorPicker = document.getElementById('colorPickerHmfb');

	if (document.getElementById('hmfbHighlightModeTextColor').checked) {
		cssStyle = `color: ${colorPicker.value};`;
	} else if (document.getElementById('hmfbHighlightModeTextBackground').checked) {
		cssStyle = `background-color: ${colorPicker.value};`;
	} else if (document.getElementById('hmfbHighlightModeTextBorder').checked) {
		cssStyle = `border: 3px solid ${colorPicker.value};`;
	} else {
		toastMessage('Błąd! Nie udało się zapisać ustawień dotyczących wyróżniania wiadomości od kupującego.');
		return;
	}
	try {
		await saveDataToLocalStorage({ cssHmfb: cssStyle });
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisywania informacji o sposobie wyróżniania wiadomości wystąpił błąd. ${getErrorMessage(error)}`);
	}
}


async function autoprintLabel() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	let response;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['nativeMessaging', 'downloads', 'tabs']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'autoprintLabel')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autoprintLabel',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
					css: ['autoprint_label.css', 'toast.css'],
					js: ['autoprint_label.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autoprintLabel',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*',  'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
					css: ['autoprint_label.css', 'toast.css'],
					js: ['autoprint_label.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}

		if (!contentScripts.some(registeredScript => registeredScript.id === 'autoprintLabelOrders')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autoprintLabelOrders',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['autoprint_label_orders.css'],
					js: ['autoprint_label_orders.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autoprintLabelOrders',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['autoprint_label_orders.css'],
					js: ['autoprint_label_orders.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['defaultPrinter']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania zapisanej domyślnej drukarki wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		response = await sendMessage({ action: 'getPrinters' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	let options = '<option>Wybierz drukarkę</option>';
	
	response.result.forEach(printer => {
		options += `<option${(readedValue.defaultPrinter === printer ? ' selected' : '')}>${printer}</option>`;
	});	
	const printerSelect = document.getElementById('printerSelect');
	printerSelect.innerHTML = options;

	printerSelect.addEventListener('change', async (e) => {
		const options = e.target.options;
		const selectedIndex = e.target.selectedIndex;
		if (selectedIndex) {
			try {
				await saveDataToLocalStorage({ defaultPrinter: options[selectedIndex].text });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać zmiany drukarki. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			toastMessage('Zapisano wybór wskazanej drukarki.');
		} else {
			try {
				await saveDataToLocalStorage({ defaultPrinter: '' });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać zmiany drukarki. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			toastMessage('Usunięto wybór wskazanej drukarki. Wybierz nową.');
		}
	});

	try {
		readedValue = await readDataFromLocalStorage(['sumatraPath']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania zapisanej ścieżki programu SumatraPDF wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	if (readedValue.sumatraPath !== undefined && readedValue.sumatraPath) {
		const sumatraPathInput = document.getElementById('sumatraPathInput');
		sumatraPathInput.value = readedValue.sumatraPath;
		sumatraPathInput.addEventListener('paste', (e) => {
			document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
		});
		sumatraPathInput.addEventListener('input', (e) => {
			document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
		});
		const event = new Event('input');
		sumatraPathInput.dispatchEvent(event);
	} else {
		try {
			response = await sendMessage({ action: 'getSumatraPath' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! Podczas pobierania ścieżki programu SumatraPDF wystąpił błąd. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}

		if (response.result) {
			try {
				await saveDataToLocalStorage({ sumatraPath: response.result })
			} catch (error) {
				toastMessage(`Błąd! Podczas zapisywania domyślnej ścieżki programu SumatraPDF wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			const sumatraPathInput = document.getElementById('sumatraPathInput');
			sumatraPathInput.value = response.result;
			sumatraPathInput.addEventListener('paste', (e) => {
				document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
			});
			sumatraPathInput.addEventListener('input', (e) => {
				document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
			});
			const event = new Event('input');
			sumatraPathInput.dispatchEvent(event);
		}
	}

	const sumatraPathSaveButton = document.getElementById('sumatraPathSaveButton');
	sumatraPathSaveButton.addEventListener('click', async (e) => {
		const sumatraPath = document.getElementById('sumatraPathInput').value;
		if (sumatraPath) {
			try {
				await saveDataToLocalStorage({ sumatraPath: sumatraPath });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać ścieżki programu SumatraPDF. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			e.target.disabled = true;
			toastMessage('Zapisano ścieżkę programu SumatraPDF.');
		} else {
			try {
				await saveDataToLocalStorage({ sumatraPath: '' });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się usunąć zapisanej ścieżki programu SumatraPDF. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			e.target.disabled = true;
			toastMessage('Usunięto zapisaną ścieżkę do programu SumatraPDF. Wskaż nową.');
		}
	});
}

async function autofillPackageSize() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'autofillPackageSize')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autofillPackageSize',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['autofill_package_size.css', 'toast.css'],
					js: ['autofill_package_size.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autofillPackageSize',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['autofill_package_size.css', 'toast.css'],
					js: ['autofill_package_size.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['shippingMethods']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania listy metod dostawy wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	let options = '<option>Wybierz metodę dostawy</option>';
	for (let option of readedValue.shippingMethods) {
		if (option.weight1 !== undefined) {
			let optionTemplate = '<option';
			let i = 1;
			while (option[`weight${i}`] !== undefined) {
				optionTemplate += ` data-weight${i}="${option[`weight${i}`]}" data-length${i}="${option[`length${i}`]}" data-width${i}="${option[`width${i}`]}" data-height${i}="${option[`height${i++}`]}"`;
			}
			optionTemplate += ` data-max-weight="${option.maxWeight}" data-min-length="${option.minLength}" data-max-length="${option.maxLength}" data-min-width="${option.minWidth}" data-max-width="${option.maxWidth}" data-min-height="${option.minHeight}" data-max-height="${option.maxHeight}" data-default="${option.default}" ${(option.defaultName !== undefined ? ' data-default-name="' + option.defaultName + '"' : '')}>${option.name}</option>`;
			options += optionTemplate;
		} else if (option.size1 !== undefined) {
			let optionSize = '<option';
			let i = 1;
			while (option[`size${i}`] !== undefined) {
				optionSize += ` data-size${i}="${option[`size${i++}`]}"`;
			}
			optionSize += ` data-weight="${option.weight}" data-default="${option.default}"${(option.defaultName !== undefined ? ' data-default-name="' + option.defaultName + '"' : '')}>${option.name}</option>`;
			options += optionSize;
		}
	}
	options += '<option>Dodaj nową</option>';

	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.innerHTML = options;
	const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
	const shipmentMethodNameInvalidFeedback = document.getElementById('shipmentMethodNameInvalidFeedback');

	shipmentMethodSelect.addEventListener('change', async (e) => {
		const shipmentMethodAdditionalInfo = document.getElementById('shipmentMethodAdditionalInfo');
		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues');
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		const numericValuesRadio = document.getElementById('numericValuesRadio');
		const shipmentMethodCommonElements = document.getElementById('shipmentMethodCommonElements');
		
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		shipmentMethodDropdown.disabled = false;

		const shipmentMethodRemove = document.getElementById('shipmentMethodRemove');
		shipmentMethodRemove.classList.add('disabled');
		
		const shipmentMethodAddTemplate = document.getElementById('shipmentMethodAddTemplate');
		shipmentMethodAddTemplate.classList.add('disabled');
		const shipmentMethodRemoveTemplate = document.getElementById('shipmentMethodRemoveTemplate');
		shipmentMethodRemoveTemplate.classList.add('disabled');
		
		const shipmentMethodAddPredefinedValue = document.getElementById('shipmentMethodAddPredefinedValue');
		shipmentMethodAddPredefinedValue.classList.add('disabled');
		const shipmentMethodRemovePredefinedValue = document.getElementById('shipmentMethodRemovePredefinedValue');
		shipmentMethodRemovePredefinedValue.classList.add('disabled');
		
		let type;
		const options = e.target.options;
		const selectedIndex = e.target.selectedIndex;
		let selectedOption = options[selectedIndex];

		if (selectedOption.text !== 'Dodaj nową') {
			shipmentMethodNumericValues.classList.add('hidden');
			shipmentMethodPredefinedValues.classList.add('hidden');
		}

		if (e.isTrusted) {
			shipmentMethodSelectType.classList.add('hidden');
			shipmentMethodAdditionalInfo.classList.add('hidden');
		}

		if (selectedIndex === 0) {
			shipmentMethodCommonElements.classList.add('hidden');
			return Promise.resolve(true);
		}
		shipmentMethodCommonElements.classList.remove('hidden');
		

		if (selectedOption.dataset.weight1 !== undefined || (selectedOption.text === 'Dodaj nową' && numericValuesRadio.checked)) {
			type = 'numeric';
			shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodAddTemplate.classList.remove('disabled');
			shipmentMethodRemoveTemplate.classList.remove('disabled');
		}	else if (selectedOption.dataset.size1 !== undefined || (selectedOption.text === 'Dodaj nową' && numericValuesRadio.checked)) {
			type = 'predefined';
			if (e.isTrusted) shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodAddPredefinedValue.classList.remove('disabled');
			shipmentMethodRemovePredefinedValue.classList.remove('disabled');
		}	else {
			if (e.isTrusted) {
				type = 'new';
				shipmentMethodNameText.disabled = true;
				shipmentMethodNumericValues.classList.remove('hidden');
				numericValuesRadio.click();
			} else {
				const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
				if (numericValuesRadio.checked) {
					type = 'numeric';
					shipmentMethodNameText.disabled = false;
					shipmentMethodAdditionalInfoText.innerText = 'Dla ręcznie dodawanej formy dostawy nie są znane ograniczenia dotyczące wagi i wymiarów. Wprowadź wartość która nie generuje błędu w formularzu nadawczym.';
				} else {
					type = 'predefined';
					shipmentMethodNameText.disabled = false;
					shipmentMethodAdditionalInfoText.innerText = 'Dodaj wybieralne wartości rozwijając dodatkowe menu koło przycisku "Zapisz".';
					shipmentMethodAddPredefinedValue.classList.remove('disabled');
					shipmentMethodRemovePredefinedValue.classList.remove('disabled');
					shipmentMethodAddPredefinedValue.disabled = false;
					shipmentMethodRemovePredefinedValue.disabled = false;
					shipmentMethodDropdown.disabled = false;
				}
			}
			shipmentMethodAdditionalInfo.classList.remove('hidden');
			shipmentMethodSelectType.classList.remove('hidden');
		}
		
		let unmodified = (selectedOption.text === selectedOption.dataset?.defaultName);
	
		if (type === 'numeric') {
			const weightText = document.getElementById('weightText');
			const lengthText = document.getElementById('lengthText');
			const widthText = document.getElementById('widthText');
			const heightText = document.getElementById('heightText');
			const weightInvalidFeedback = document.getElementById('weightInvalidFeedback');
			const lengthInvalidFeedback = document.getElementById('lengthInvalidFeedback');
			const widthInvalidFeedback = document.getElementById('widthInvalidFeedback');
			const heightInvalidFeedback = document.getElementById('heightInvalidFeedback');

			if (e.isTrusted) {
				shipmentMethodNameText.classList.remove('is-invalid');
				shipmentMethodNameText.value = selectedOption.text;
			} else {
				shipmentMethodNameText.value = '';
			}

			document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podaj nazwę metody dostawy';
			const defaultTemplate = selectedOption.dataset.default;

			if (defaultTemplate !== undefined) {
				weightText.value = selectedOption.dataset[`weight${defaultTemplate}`];
				lengthText.value = selectedOption.dataset[`length${defaultTemplate}`];
				widthText.value = selectedOption.dataset[`width${defaultTemplate}`];
				heightText.value = selectedOption.dataset[`height${defaultTemplate}`];
			}
			
			weightText.min = '0';
			weightText.max = (unmodified ? selectedOption.dataset.maxWeight : '999');
			

			lengthText.min = (unmodified ? selectedOption.dataset.minLength : '1');
			lengthText.max = (unmodified ? selectedOption.dataset.maxLength : '999'); 
			

			widthText.min = (unmodified ? selectedOption.dataset.minWidth : '1');
			widthText.max = (unmodified ? selectedOption.dataset.maxWidth : '999');
			

			heightText.min = (unmodified ? selectedOption.dataset.minHeight : '1');
			heightText.max = (unmodified ? selectedOption.dataset.maxHeight : '999');
			

			weightInvalidFeedback.innerText = `0-${(unmodified ? selectedOption.dataset.maxWeight : '999')}kg`;
			lengthInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minLength + '-' + selectedOption.dataset.maxLength : '1-999')}cm`;
			widthInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minWidth + '-' + selectedOption.dataset.maxWidth : '1-999')}cm`;
			heightInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minHeight + '-' + selectedOption.dataset.maxHeight : '1-999')}cm`;

			if (defaultTemplate !== undefined) {
				const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
				numericValuesTemplatesBox.querySelectorAll('*').forEach(node => node.remove() );
			}
			
			let i = 1;

			while (selectedOption.dataset[`weight${i}`] !== undefined) {
				if (i > 9) break;
				const numericValuesTemplate = document.createElement('div');
				numericValuesTemplate.className = 'form-check form-check-inline';
				numericValuesTemplate.innerHTML = `<input class="form-check-input" data-weight="${selectedOption.dataset[`weight${i}`]}" data-length="${selectedOption.dataset[`length${i}`]}" data-width="${selectedOption.dataset[`width${i}`]}" data-height="${selectedOption.dataset[`height${i}`]}" type="radio" name="numericValuesTemplate" id="numericValuesTemplate${i}" value="${i}"${selectedOption.dataset.default == i ? ' checked' : ''}><label class="form-check-label" for="numericValuesTemplate${i}">${selectedOption.dataset[`length${i}`] ? selectedOption.dataset[`length${i}`] : '-'}x${selectedOption.dataset[`width${i}`] ? selectedOption.dataset[`width${i}`] : '-'}x${selectedOption.dataset[`height${i}`] ? selectedOption.dataset[`height${i}`] : '-'}cm, ${selectedOption.dataset[`weight${i}`] ? selectedOption.dataset[`weight${i}`] : '-'}kg</label>`;
				numericValuesTemplatesBox.insertAdjacentElement('beforeend', numericValuesTemplate);
				numericValuesTemplate.firstChild.addEventListener('change', numericValuesTemplateChecked);
				i++;
			}

			if (selectedIndex < (options.length - 1)) shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodNumericValues.classList.remove('hidden');
		} else if (type === 'predefined') {
			if (e.isTrusted) {
				shipmentMethodNameText.classList.remove('is-invalid');
				shipmentMethodNameText.value = selectedOption.text;
			} else {
				shipmentMethodNameText.value = '';
			}

			const predefinedValuesDefaultWeightInput = document.getElementById('predefinedValuesDefaultWeightInput');
			predefinedValuesDefaultWeightInput.value = selectedOption.dataset.weight || 0;
			predefinedValuesDefaultWeightInput.addEventListener('blur', (e) => {
				if (e.target.value === '') {
					e.target.value = 0;
				}
			});
			predefinedValuesDefaultWeightInput.addEventListener('change', saveButtonSetState);
			
			const predefinedValuesBox = document.getElementById('predefinedValuesBox');
			predefinedValuesBox.querySelectorAll('*').forEach(node => node.remove() );
			let i = 1;

			while (selectedOption.dataset[`size${i}`] !== undefined) {
				if (i > 9) break;
				const predefinedSize = document.createElement('div');
				predefinedSize.className = 'form-check form-check-inline';
				predefinedSize.innerHTML = `<input class="form-check-input" type="radio" name="shipmentMethodPredefinedSize" id="shipmentMethodPredefinedSize${i}" value="${i}"${i == selectedOption.dataset.default ? ' checked' : ''}><label class="form-check-label" for="shipmentMethodPredefinedSize${i}">${selectedOption.dataset[`size${i}`]}</label>`;
				predefinedValuesBox.insertAdjacentElement('beforeend', predefinedSize);
				predefinedSize.firstChild.addEventListener('change', (e) => {
					saveButtonSetState();
				});
				i++;
			}

			shipmentMethodPredefinedValues.classList.remove('hidden');
		} else {
			shipmentMethodNameText.value = '';
			shipmentMethodNameInvalidFeedback.innerText = 'Podaj nazwę metody dostawy';
			shipmentMethodNameText.classList.remove('is-invalid');		
			shipmentMethodSelectType.classList.remove('hidden');
		}
	});

	const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
	shipmentMethodSelectType.querySelectorAll('input[type="radio"]').forEach(element => element.addEventListener('change', (e) => {
		document.getElementById('shipmentMethodSelect').dispatchEvent(new Event('change'));
	}));

	const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
	for (let element of numericValues) {
		element.addEventListener('input', () => {
			const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
			const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
			const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
			const shipmentMethodNameText = document.getElementById('shipmentMethodNameText');		
			if (!shipmentMethodNameText.classList.contains('is-invalid') && shipmentMethodNameText.checkValidity() && [...numericValues].every(element => element.checkValidity())) {
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}
			else {
				shipmentMethodSaveButton.disabled = true;
				//shipmentMethodDropdown.disabled = true;
			}
		});
	};

	shipmentMethodNameText.addEventListener('change', (e) => {
		e.target.classList.remove('is-invalid');
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const options = shipmentMethodSelect.options;
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		const shipmentMethodSelectText = options[shipmentMethodSelect.selectedIndex].text;
		for (let option of options) {
			if (option.text === e.target.value) {
				if ((shipmentMethodSelect.selectedIndex === (options.length - 1)) || (shipmentMethodSelectText !== e.target.value)) {
					document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podana nazwa już istnieje';
					e.target.classList.add('is-invalid');
					shipmentMethodSaveButton.disabled = true;
					//shipmentMethodDropdown.disabled = true;
					return;
				}
			}
		}
		
		//document.getElementById('shipmentMethodNameInvalidFeedback').innerText = '';	
		saveButtonSetState();
	});

	shipmentMethodNameText.addEventListener('keyup', (e) => {
		e.target.classList.remove('is-invalid');
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const options = shipmentMethodSelect.options;
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		const shipmentMethodSelectText = options[shipmentMethodSelect.selectedIndex].text;
		
		for (let option of options) {
			if (option.text === e.target.value) {
				if ((shipmentMethodSelect.selectedIndex === (options.length - 1)) || (shipmentMethodSelectText !== e.target.value)) {
					document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podana nazwa już istnieje';
					e.target.classList.add('is-invalid');
					shipmentMethodSaveButton.disabled = true;
					//shipmentMethodDropdown.disabled = true;
					return;
				}
			}
		}
		
		//document.getElementById('shipmentMethodNameInvalidFeedback').innerText = '';
		saveButtonSetState();
	});

	const shipmentMethodAddPredefinedValue = document.getElementById('shipmentMethodAddPredefinedValue');
	shipmentMethodAddPredefinedValue.addEventListener('click', () => {
		const predefinedValuesBox = document.getElementById('predefinedValuesBox');
		if (Array.from(predefinedValuesBox.querySelectorAll('input[type="radio"]')).find(predefinedSize => predefinedSize.nextElementSibling.innerText === 'Kliknij tutaj aby wkleić ze schowka skopiowany tekst')) {
			toastMessage('Uzupełnij poprzednio dodaną opcję zanim dodasz kolejną.');
			return;
		}
		const predefinedValuesRadioButtons = predefinedValuesBox.querySelectorAll('input[type="radio"]');
		if (predefinedValuesRadioButtons.length >= 9) {
			toastMessage('Dla wybranej metody dostawy osiągnięto maksymalną liczbę szablonów.');
			return;
		}
		const i = predefinedValuesRadioButtons.length + 1;
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		shipmentMethodSelectType.classList.add('hidden');
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;

		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		shipmentMethodSelect.disabled = true;

		const predefinedSize = document.createElement('div');
		predefinedSize.className = 'form-check form-check-inline';
		predefinedSize.innerHTML = `<input class="form-check-input" type="radio" name="shipmentMethodPredefinedSize" id="shipmentMethodPredefinedSize${i}" value="${i}"><label class="form-check-label" for="shipmentMethodPredefinedSize${i}">Kliknij tutaj aby wkleić ze schowka skopiowany tekst</label>`;
		predefinedValuesBox.insertAdjacentElement('beforeend', predefinedSize);		
		
		const predefinedSizeLabel = predefinedSize.querySelector('label');
		predefinedSizeLabel.addEventListener('click', predefinedSizeLabelClick);
		const predefinedSizeRadioButton = predefinedSize.firstChild;
		predefinedSizeRadioButton.checked = true;
		predefinedSizeRadioButton.addEventListener('change', saveButtonSetState);
	});

	const shipmentMethodRemovePredefinedValue = document.getElementById('shipmentMethodRemovePredefinedValue');

	shipmentMethodRemovePredefinedValue.addEventListener('click', async (e) => {
		const predefinedValuesBox = document.getElementById('predefinedValuesBox');
		const predefinedValuesRadioButtons = predefinedValuesBox.querySelectorAll('input[type="radio"]');
		if (predefinedValuesRadioButtons.length < 2) {
			toastMessage('Musi pozostać co najmniej jeden szablon.');
			return;
		}

		let selectedPredefinedValue = document.querySelector('input[name="shipmentMethodPredefinedSize"]:checked');
		if (selectedPredefinedValue === null) {
			toastMessage('Zaznacz opcję do usunięcia');
			return;
		}
		e.target.disabled = true;
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		shipmentMethodSelectType.classList.add('hidden');
	
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		shipmentMethodSelect.disabled = true;
		const indexToRemove = parseInt(selectedPredefinedValue.id.charAt(selectedPredefinedValue.id.length - 1));
		selectedPredefinedValue.parentElement.remove();	
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;

		for (let i = indexToRemove + 1; i <= 9; i++) {
			const currentOption = document.getElementById(`shipmentMethodPredefinedSize${i}`);
			if (currentOption !== null) {
				currentOption.id = `shipmentMethodPredefinedSize${i-1}`;
				currentOption.value = i-1;
				currentOption.nextElementSibling.setAttribute('for', `shipmentMethodPredefinedSize${i-1}`);
			} else break;
		}

		predefinedValuesBox.querySelector('input[type="radio"]').click();
		
		e.target.disabled = false;
	});

	document.getElementById('shipmentMethodSaveButton').addEventListener('click', async (e) => {
		e.target.disabled = true;
		let readedValue;
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const shipmentMethodName = document.getElementById('shipmentMethodNameText').value;

		try {
			readedValue = await readDataFromLocalStorage(['shippingMethods']);
		}	catch (error) {
			toastMessage(`Błąd! Nie udało się wczytać opcji dostawy. ${getErrorMessage(error)}`);
			shipmentMethodSelect.disabled = false;
			return;
		}

		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues'); 
		let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
		const existingValue = (shipmentMethodSelect.selectedIndex !== shipmentMethodSelect.options.length - 1);
		const unmodified = (shipmentMethodName === selectedOption.dataset?.defaultName);

		if (!shipmentMethodNumericValues.classList.contains('hidden')) {
			const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');

			function hasDuplicates(arr) {
				return new Set(arr).size !== arr.length;
			}

			const numericValuesTemplates = numericValuesTemplatesBox.querySelectorAll('input[type="radio"]');
			const templateNames = [];
			numericValuesTemplates.forEach(template => templateNames.push(template.nextElementSibling.innerText));
			if (hasDuplicates(templateNames)) {
				e.target.disabled = false;
				toastMessage('Błąd! Nie zapisano - usuń duplikaty szablonów.');
				return;
			}

			let i = 1;
			let optionObject = {
				name: shipmentMethodName
			}

			let defaultTemplate = 1;

			numericValuesTemplates.forEach(input => {
				if (input.checked) {
					optionObject.default = input.value;
					defaultTemplate = i;
				}
				optionObject[`weight${i}`] = input.dataset.weight;
				optionObject[`length${i}`] = input.dataset.length;
				optionObject[`width${i}`] = input.dataset.width;
				optionObject[`height${i}`] = input.dataset.height;
				i++;
			});

			if (existingValue && unmodified) {
				if (selectedOption.dataset.maxWeight) {
					optionObject['minWidth'] = selectedOption.dataset.minWidth;
					optionObject['minLength'] = selectedOption.dataset.minLength;
					optionObject['minHeight'] = selectedOption.dataset.minHeight;
					optionObject['maxWeight'] = selectedOption.dataset.maxWeight;
					optionObject['maxWidth'] = selectedOption.dataset.maxWidth;
					optionObject['maxLength'] = selectedOption.dataset.maxLength;
					optionObject['maxHeight'] = selectedOption.dataset.maxHeight;
					optionObject['defaultName'] = selectedOption.dataset.defaultName
				}
			}

			if (!existingValue) {
				readedValue.shippingMethods.push(optionObject);
			} else {
				for (let [index, value] of readedValue.shippingMethods.entries()) {
					if (value.name === selectedOption.text) {
						readedValue.shippingMethods[index] = optionObject;
						break;
					}
				}
			}

			try {
				await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });
			} catch (error) {
				shipmentMethodSelect.disabled = false;
				toastMessage(`Błąd! Nie udało się zapisać zmian w opcjach dostawy. ${getErrorMessage(error)}`);
				return;
			}
			toastMessage('Zapisano opcję dostawy.');

			selectedOption.text = shipmentMethodName;
			selectedOption.dataset.name = shipmentMethodName;
			selectedOption.dataset.default = defaultTemplate.toString();

			i = 1;
			numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').forEach(input => {
				selectedOption.dataset[`weight${i}`] = input.dataset.weight;
				selectedOption.dataset[`length${i}`] = input.dataset.length;
				selectedOption.dataset[`width${i}`] = input.dataset.width;
				selectedOption.dataset[`height${i}`] = input.dataset.height;
				i++;
			});

			if (existingValue && selectedOption.dataset.maxWeight && !unmodified) {
				delete selectedOption.dataset.minWidth;
				delete selectedOption.dataset.minLength;
			 	delete selectedOption.dataset.minHeight;
				delete selectedOption.dataset.maxWeight;
				delete selectedOption.dataset.maxWidth;
				delete selectedOption.dataset.maxLength;
				delete selectedOption.dataset.maxHeight;
				delete selectedOption.dataset.defaultName;
			}

			const weightText = document.getElementById('weightText');
			const lengthText = document.getElementById('lengthText');
			const widthText = document.getElementById('widthText');
			const heightText = document.getElementById('heightText');
			const weightInvalidFeedback = document.getElementById('weightInvalidFeedback');
			const lengthInvalidFeedback = document.getElementById('lengthInvalidFeedback');
			const widthInvalidFeedback = document.getElementById('widthInvalidFeedback');
			const heightInvalidFeedback = document.getElementById('heightInvalidFeedback');

			weightText.max = (optionObject?.maxWeight ?? '999');
			lengthText.min = (optionObject?.minLength ?? '1');
			lengthText.max = (optionObject?.maxLength ?? '999'); 
			widthText.min = (optionObject?.minWidth ?? '1');
			widthText.max = (optionObject?.maxWidth ?? '999');
			heightText.min = (optionObject?.minHeight ?? '1');
			heightText.max = (optionObject?.maxHeight ?? '999');
			
			weightInvalidFeedback.innerText = `0-${(unmodified ? optionObject.maxWeight : '999')}kg`;
			lengthInvalidFeedback.innerText = `${(unmodified ? optionObject.minLength + '-' + optionObject.maxLength : '1-999')}cm`;
			widthInvalidFeedback.innerText = `${(unmodified ? optionObject.minWidth + '-' + optionObject.maxWidth : '1-999')}cm`;
			heightInvalidFeedback.innerText = `${(unmodified ? optionObject.minHeight + '-' + optionObject.maxHeight : '1-999')}cm`;

			if (!existingValue) {
				const addNewOption = document.createElement('option');
				addNewOption.textContent = 'Dodaj nową';
				shipmentMethodSelect.appendChild(addNewOption);
			}

			numericValuesTemplatesBox.querySelectorAll('div[class~="red"]').forEach(template => template.classList.remove('red'));
		} else if (!shipmentMethodPredefinedValues.classList.contains('hidden')) {
			let optionObject = {
				name: shipmentMethodName,
				weight: document.getElementById('predefinedValuesDefaultWeightInput').value || 0
			}
			let i = 1;
			let element;
			do {
				element = document.getElementById(`shipmentMethodPredefinedSize${i}`);
				if (element === null) break;
				optionObject[`size${i}`] = element.nextElementSibling.innerText;
				if (element.checked) optionObject.default = i.toString();
				i++;
			} while (element !== null);

			if (!existingValue) {
				readedValue.shippingMethods.push(optionObject);
			} else {
				for (let [index, value] of readedValue.shippingMethods.entries()) {
					if (value.name === selectedOption.text) {
						readedValue.shippingMethods[index] = optionObject;
						break;
					}
				}
			}
			try {
				await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });	
			} catch (error) {
				shipmentMethodSelect.disabled = false;
				toastMessage(`Błąd! Nie udało się zapisać zmian w opcjach dostawy. ${getErrorMessage(error)}`);
				return;
			}
			toastMessage('Zapisano opcje dostawy.');
			selectedOption.text = shipmentMethodName;
			selectedOption.dataset.name = shipmentMethodName;

			i = 1;
			while (selectedOption.dataset[`size${i}`] !== undefined) {
				delete selectedOption.dataset[`size${i}`];
				i++;
			}
			i = 1;
			while (optionObject[`size${i}`] !== undefined) {
				selectedOption.dataset[`size${i}`] = optionObject[`size${i}`];
				i++;
			}
			selectedOption.dataset.weight = optionObject.weight;
			selectedOption.dataset.default = optionObject.default;
			if (!existingValue) {
				const addNewOption = document.createElement('option');
				addNewOption.textContent = 'Dodaj nową';
				shipmentMethodSelect.appendChild(addNewOption);
			}
		}

		shipmentMethodSelect.disabled = false;
	});


	document.getElementById('shipmentMethodRemove').addEventListener('click', shipmentMethodRemoveClick);
	document.getElementById('shipmentMethodAddTemplate').addEventListener('click', shipmentMethodAddTemplateClick);
	document.getElementById('shipmentMethodRemoveTemplate').addEventListener('click', shipmentMethodRemoveTemplateClick);

	document.getElementById('weightText').addEventListener('change', numericValuesChange);
	document.getElementById('lengthText').addEventListener('change', numericValuesChange);
	document.getElementById('widthText').addEventListener('change', numericValuesChange);
	document.getElementById('heightText').addEventListener('change', numericValuesChange);
}

function numericValuesTemplateChecked(e) {
	const weightText = document.getElementById('weightText');
	const lengthText = document.getElementById('lengthText');
	const widthText = document.getElementById('widthText');
	const heightText = document.getElementById('heightText');

	weightText.value = e.target.dataset.weight;
	lengthText.value = e.target.dataset.length;
	widthText.value = e.target.dataset.width;
	heightText.value = e.target.dataset.height;

	saveButtonSetState();
}


async function predefinedSizeLabelClick(e) {
	let paste;
	try {
		paste = await navigator.clipboard.readText();
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać tekstu ze schowka.');
		return;
	}	

	if (!paste) {
		toastMessage('Nie znaleziono tekstu w schowku.');
		return;
	}

	if (paste.length > 40) {
		toastMessage('Tekst znaleziony w schowku jest znacznie dłuższy niż oczekiwano. Upewnij się że skopiowałeś właściwy tekst.');
		return;
	}
	paste = paste.replace('\r\n', ' ');

	const labelInput = e.target.previousElementSibling;
	//const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	//let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
	const i = (labelInput.id.charAt(labelInput.id.length - 1));

	const options = document.getElementsByName('shipmentMethodPredefinedSize');
	let duplicateFound;
	for (const option of options) {
		duplicateFound = false;
		if (option.nextElementSibling !== e.target) {
			if (option.nextElementSibling.innerText === paste) {
				toastMessage(`Podana wartość ${paste} już istnieje.`);
				duplicateFound = true;
				break;
			}
		}
	}
	if (!duplicateFound) {
		//selectedOption.dataset[`size${i}`] = paste;
		e.target.innerText = paste;
		saveButtonSetState();
		e.target.removeEventListener('click', predefinedSizeLabelClick);
	}
}

function saveButtonSetState() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	const predefinedValuesBox = document.getElementById('predefinedValuesBox');
	const shipmentMethodNameText = document.getElementById('shipmentMethodNameText');
	const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
	const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
	if (!(shipmentMethodNameText.classList.contains('is-invalid') || shipmentMethodNameText.validity.valueMissing)) {
		if (!(document.getElementById('shipmentMethodPredefinedValues').classList.contains('hidden'))) {
			if ((Array.from(predefinedValuesBox.querySelectorAll('label')).filter(element => element.innerText === '' || element.innerText === 'Kliknij tutaj aby wkleić ze schowka skopiowany tekst').length === 0) && (predefinedValuesBox.querySelector('input[type="radio"]:checked'))) { 
				shipmentMethodSelect.disabled = true;
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}	else if (predefinedValuesBox.querySelector('input[type="radio"]') === null) {
				shipmentMethodDropdown.disabled = false;
			}
		} else {
			const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
			if ([...numericValues].every(element => element.checkValidity())) {
				shipmentMethodSelect.disabled = true;
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}	else {
				shipmentMethodSaveButton.disabled = true;
				//shipmentMethodDropdown.disabled = true;
			}
		}	
	} else {
		shipmentMethodSaveButton.disabled = true;
		//shipmentMethodDropdown.disabled = true;
	}
}

async function shipmentMethodRemoveClick() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	if (!window.confirm(`Usunąć metodę dostawy ${shipmentMethodSelect.value}?`)) return;
	shipmentMethodSelect.disabled = true;
	document.getElementById('shipmentMethodRemove').disabled = true;
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['shippingMethods']);
	} catch (error) {
		toastMessage(`Błąd! Nie udało się wczytać opcji dostawy. ${getErrorMessage(error)}`);
		shipmentMethodSelect.disabled = false;
		return;
	}
	
	const options = shipmentMethodSelect.options;
	const selectedIndex = shipmentMethodSelect.selectedIndex;
	if (selectedIndex > 0 && selectedIndex < (options.length - 1)) {
		let modifiedShippingMethods = [];
		const selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
		readedValue.shippingMethods.forEach(shippingMethod => {
			if (shippingMethod.name !== selectedOption.text) modifiedShippingMethods.push(shippingMethod);
		});

		try {
			await saveDataToLocalStorage({ shippingMethods: modifiedShippingMethods });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się usunąć opcji dostawy. ${getErrorMessage(error)}`);
			shipmentMethodSelect.disabled = false;
			return;
		}	
		shipmentMethodSelect.selectedIndex = 0;
		shipmentMethodSelect.remove(selectedIndex);
		shipmentMethodNumericValues.classList.add('hidden');
		shipmentMethodPredefinedValues.classList.add('hidden');
		toastMessage('Usunięto opcję dostawy.');
	}
	shipmentMethodSelect.disabled = false;
	shipmentMethodSelect.dispatchEvent(new Event('change'));
}

async function shipmentMethodAddTemplateClick() {
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const numericValuesTemplatesCount =  numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').length;
	if (numericValuesTemplatesCount >= 9) {
		toastMessage('Błąd! Dla wybranej metody dostawy osiągnięto maksymalną liczbę szablonów.');
		return;
	}
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.disabled = true;

	document.getElementById('shipmentMethodAddTemplate').disabled = true;
	//let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];

	let i = numericValuesTemplatesCount + 1;

	let inputsValidity = false;
	const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
	if ([...numericValues].every(element => element.checkValidity())) inputsValidity = true;

	if (!inputsValidity && i > 1) {
		toastMessage('Błąd! Wprowadzone wartości dla danej formy dostawy są spoza dopuszczalnego zakresu.');
		shipmentMethodSelect.disabled = false;
		return;
	}

	const weight = document.getElementById('weightText').value;
	const length = document.getElementById('lengthText').value;
	const width = document.getElementById('widthText').value;
	const height = document.getElementById('heightText').value;

	const numericValuesTemplate = document.createElement('div');
	numericValuesTemplate.className = 'form-check form-check-inline red';
	numericValuesTemplate.innerHTML = `<input class="form-check-input" data-weight="${weight}" data-length="${length}" data-width="${width}" data-height="${height}" type="radio" name="numericValuesTemplate" id="numericValuesTemplate${i}" value="${i}" checked><label class="form-check-label" for="numericValuesTemplate${i}">${length}x${width}x${height}cm, ${weight}kg</label>`;
	numericValuesTemplatesBox.insertAdjacentElement('beforeend', numericValuesTemplate);
	numericValuesTemplate.firstChild.addEventListener('change', numericValuesTemplateChecked);

	saveButtonSetState();
}

async function shipmentMethodRemoveTemplateClick() {
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const numericValuesTemplatesCount = numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').length;
	if (numericValuesTemplatesCount < 2) {
		toastMessage('Błąd! Musi pozostać co najmniej jeden szablon.');
		return;
	}
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	const options = shipmentMethodSelect.options;
	const selectedIndex = shipmentMethodSelect.selectedIndex;
	const selectedOption = options[selectedIndex];
	const selectedTemplate = numericValuesTemplatesBox.querySelector('input[type="radio"]:checked');
	const selectedTemplateIndex = Number(selectedTemplate.value);
	if (!window.confirm(`Usunąć szablon ${selectedTemplate.nextElementSibling.innerText} z metody dostawy ${shipmentMethodSelect.value}?`)) return;
	shipmentMethodSelect.disabled = true;
	document.getElementById('shipmentMethodRemoveTemplate').disabled = true;
	selectedTemplate.parentNode.remove();
	let i;
	let nextTemplate;
	for (i = selectedTemplateIndex; i < numericValuesTemplatesCount; i++) {
		nextTemplate = document.getElementById(`numericValuesTemplate${i+1}`);
		selectedOption.dataset[`weight${selectedTemplateIndex}`] = selectedOption.dataset[`weight${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`length${selectedTemplateIndex}`] = selectedOption.dataset[`length${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`width${selectedTemplateIndex}`] = selectedOption.dataset[`width${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`height${selectedTemplateIndex}`] = selectedOption.dataset[`height${selectedTemplateIndex + 1}`];
		nextTemplate.nextElementSibling.htmlFor = `numericValuesTemplate${i}`;
		nextTemplate.value = i;
		nextTemplate.id = `numericValuesTemplate${i}`;
	}
	delete selectedOption.dataset[`weight${i}`];
	delete selectedOption.dataset[`length${i}`];
	delete selectedOption.dataset[`width${i}`];
	delete selectedOption.dataset[`height${i}`];
	
	document.getElementById('numericValuesTemplate1').click();
}

function numericValuesChange() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.disabled = true;
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const selectedTemplate = numericValuesTemplatesBox.querySelector('input[type="radio"]:checked');
	const weight = document.getElementById('weightText').value;
	const length = document.getElementById('lengthText').value;
	const width = document.getElementById('widthText').value;
	const height = document.getElementById('heightText').value;
	selectedTemplate.nextElementSibling.innerText = `${length !== '' ? length : '-'}x${width !== '' ? width : '-'}x${height !== '' ? height : '-'}cm, ${weight !== '' ? weight : '-'}kg`;
	selectedTemplate.dataset.weight = weight;
	selectedTemplate.dataset.length = length;
	selectedTemplate.dataset.width = width;
	selectedTemplate.dataset.height = height;
	selectedTemplate.parentElement.classList.add('red');
}


async function inPostSendMode() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
		
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'inPostSendMode')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'inPostSendMode',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['inpost_send_mode.css', 'toast.css'],
					js: ['inpost_send_mode.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'inPostSendMode',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['inpost_send_mode.css', 'toast.css'],
					js: ['inpost_send_mode.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
	
	try {
		readedValue = await readDataFromLocalStorage(['inPostSendMode']);
		if (!(readedValue.inPostSendMode >= 1 && readedValue.inPostSendMode <= 2)) throw new Error('Opcja ma nieprawidłową wartość.');
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu domyślnego sposobu nadawania przesyłek InPost wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	document.getElementById(`inPostSendMode${readedValue.inPostSendMode}`).checked = true;
	
	document.getElementById('saveInPostSendModeButtonBox').addEventListener('click', async () => {
		const defaultInPostSendMode = parseInt(document.getElementById('inPostSendModeInputs').querySelector('input:checked')?.value);
		if (defaultInPostSendMode) {
			try {
				await saveDataToLocalStorage({ inPostSendMode: defaultInPostSendMode });
				toastMessage('Zapisano domyślną formę dostawy przesyłek InPost');
			} catch (error) {
				toastMessage(`Błąd! Podczas zapisu domyślnej formy dostawy przesyłek InPost wystąpił błąd. ${getErrorMessage(error)}`);
			}
		}
	});
}

async function changeAuctionsTitle() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (!contentScripts.length || !contentScripts.some(registeredScript => registeredScript.id === 'changeAuctionsTitle')) {
		try {
			await chrome.scripting.registerContentScripts([{
				id: 'changeAuctionsTitle',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['change_auctions_title.css', 'toast.css'],
				js: ['change_auctions_title.js', 'toast.js']
			}]);
		} catch (error) {
			toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
		}
	} else {
		try {
			await chrome.scripting.updateContentScripts([{
				id: 'changeAuctionsTitle',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['change_auctions_title.css', 'toast.css'],
				js: ['change_auctions_title.js', 'toast.js']
			}]);
		} catch (error) {
			toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
		}
	}
	
	try {
		await sendMessage({ action: 'getShortcutChangeAuctionsTitle' });
	} catch (error) {
		console.log(getErrorMessage(error));
	}
	
}

async function validateBuyerAddressErrors() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'validateBuyerAddressErrors')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'validateBuyerAddressErrors',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['validate_buyer_address_errors.css', 'toast.css'],
					js: ['validate_buyer_address_errors.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'validateBuyerAddressErrors',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['validate_buyer_address_errors.css', 'toast.css'],
					js: ['validate_buyer_address_errors.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['buyerAddressErrorsFeedback']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień opcjonalnego wysyłania błędnych wzorców danych adresowych wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const validateBuyerAddressErrorsSendSamplesCheckbox = document.getElementById('validateBuyerAddressErrorsSendSamplesCheckbox');
	validateBuyerAddressErrorsSendSamplesCheckbox.checked = readedValue.buyerAddressErrorsFeedback;
	validateBuyerAddressErrorsSendSamplesCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ buyerAddressErrorsFeedback: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień opcjonalnego wysyłania błędnych wzorców danych adresowych. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});
}

async function fastStockManager() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
			
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();	
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {	
		if (!contentScripts.some(registeredScript => registeredScript.id === 'fastStockManager')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'fastStockManager',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['fast_stock_manager.css', 'toast.css'],
					js: ['fast_stock_manager.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'fastStockManager',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['fast_stock_manager.css', 'toast.css'],
					js: ['fast_stock_manager.js', 'toast.js']
				}]);	
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
	
}

async function restoreCancelled() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();	
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'restoreCancelled')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'restoreCancelled',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['restore_cancelled.css', 'toast.css'],
					js: ['restore_cancelled.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'restoreCancelled',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['restore_cancelled.css', 'toast.css'],
					js: ['restore_cancelled.js', 'toast.js']
				}]);
			}	catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
}

async function restoreReturned() {
	let permissionGranted;
	let contentScripts;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['iFirmaReturns']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const iFirmaReturnsCheckbox = document.getElementById('iFirmaReturnsCheckbox');
	iFirmaReturnsCheckbox.checked = readedValue.iFirmaReturns;
	iFirmaReturnsCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ iFirmaReturns: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	let originsSites = ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'];
	if (iFirmaReturnsCheckbox.checked && originsSites.indexOf('https://www.ifirma.pl/*') === -1) originsSites.push('https://www.ifirma.pl/*');

	try {
		permissionGranted = await chrome.permissions.contains({
			origins: originsSites
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage(`Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*${ iFirmaReturnsCheckbox.checked ? ', https://www.ifirma.pl/*' : ''}`);
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (iFirmaReturnsCheckbox.checked) {
				if (!contentScripts.some(registeredScript => registeredScript.id === 'iFirmaReturns')) {
					try {
						await chrome.scripting.registerContentScripts([{
							id: 'iFirmaReturns',
							matches: ['https://www.ifirma.pl/*'],
							css: ['ifirma_returns.css', 'toast.css'],
							js: ['ifirma_returns.js', 'toast.js']
						}]);
					} catch (error) {
						toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
						return Promise.reject(false);
					}
				}	else {
					try {
						await chrome.scripting.updateContentScripts([{
							id: 'iFirmaReturns',
							matches: ['https://www.ifirma.pl/*'],
							css: ['ifirma_returns.css', 'toast.css'],
							js: ['ifirma_returns.js', 'toast.js']
						}]);
					} catch (error) {
						toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
						return Promise.reject(false);
					}
				}
			}
			if (!contentScripts.some(registeredScript => registeredScript.id === 'restoreReturned')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'restoreReturned',
						matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
						css: ['restore_returned.css', 'toast.css'],
						js: ['restore_returned.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}	else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'restoreReturned',
						matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
						css: ['restore_returned.css', 'toast.css'],
						js: ['restore_returned.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		}
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
}

async function showProductName() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'showProductName')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'showProductName',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['show_product_name.css', 'toast.css'],
					js: ['show_product_name.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'showProductName',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['show_product_name.css', 'toast.css'],
					js: ['show_product_name.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
	
}

async function offerTags() {
	let permissionGranted;
	let contentScripts;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsDefaultHidden', 'offerTagsSearchMode']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień dotyczących widoczności tagów ofertowych wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const offerTagsHideCheckbox = document.getElementById('offerTagsHideCheckbox');
	offerTagsHideCheckbox.checked = readedValue.offerTagsDefaultHidden;
	offerTagsHideCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ offerTagsDefaultHidden: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących widoczności tagów ofertowych. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});


	const offerTagsSearchModeRadioButtons = document.getElementsByName('offerTagsSearchMode');
	offerTagsSearchModeRadioButtons[readedValue.offerTagsSearchMode].checked = true;

	[...offerTagsSearchModeRadioButtons].forEach(offerTagsSearchModeRadio => {
		offerTagsSearchModeRadio.addEventListener('change', async (e) => {
			try {
				await saveDataToLocalStorage({ offerTagsSearchMode: parseInt(document.getElementById('offerTagsSearchMode').querySelector('input:checked')?.value) });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących sposobu wyszukiwania tagów. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
			toastMessage('Zapisano');
		});
	});


	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'offerTags')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'offerTags',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['offer_tags.css', 'toast.css'],
					js: ['offer_tags.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'offerTags',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['offer_tags.css', 'toast.css'],
					js: ['offer_tags.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
	try {
		await sendMessage({ action: 'getShortcutOfferTags' });
	} catch (error) {
		console.log(getErrorMessage(error));
	}
}

async function showStockLeft() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'showStockLeft')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'showStockLeft',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['show_stock_left.css', 'toast.css'],
						js: ['show_stock_left.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'showStockLeft',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['show_stock_left.css', 'toast.css'],
						js: ['show_stock_left.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
}

async function shipmentExistsWarning() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'shipmentExistsWarning')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'shipmentExistsWarning',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
						css: ['shipment_exists_warning.css', 'toast.css'],
						js: ['shipment_exists_warning.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'shipmentExistsWarning',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
						css: ['shipment_exists_warning.css', 'toast.css'],
						js: ['shipment_exists_warning.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
}

async function showShipmentStatus() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	let response;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		readedValue = await readDataFromLocalStorage(['checkShipmentsStatusTimerCheckbox', 'checkShipmentsStatusPeriodInput']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień dotyczących automatycznego sprawdzania statusów przesyłek w tle wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	const checkShipmentsStatusTimerCheckbox = document.getElementById('checkShipmentsStatusTimerCheckbox');
	checkShipmentsStatusTimerCheckbox.checked = readedValue['checkShipmentsStatusTimerCheckbox'];

	const checkShipmentsStatusPeriodInput = document.getElementById('checkShipmentsStatusPeriodInput');
	checkShipmentsStatusPeriodInput.value = readedValue['checkShipmentsStatusPeriodInput'];
	checkShipmentsStatusPeriodInput.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ checkShipmentsStatusPeriodInput: e.target.value });
			if (checkShipmentsStatusTimerCheckbox.checked) {
				const changeEvent = new Event('change');
				checkShipmentsStatusTimerCheckbox.dispatchEvent(changeEvent);
			} else {
				toastMessage('Zapisano');
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących trybu działania automatycznego sprawdzania st atusów przesyłek w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
	});
	checkShipmentsStatusPeriodInput.addEventListener('keydown', (e) => { e.preventDefault() });

	
	checkShipmentsStatusTimerCheckbox.addEventListener('change', async (e) => {
		try {
			const permissionApproved = await chrome.permissions.contains({ permissions: ['alarms'] });
			if (!permissionApproved) {
				const permissionRequest = await chrome.permissions.request({ permissions: ['alarms'] });
				if (!permissionRequest) throw new Error ('Nie przyznano uprawnień do alarmów');
			}
			await saveDataToLocalStorage({ checkShipmentsStatusTimerCheckbox: e.target.checked });
			if (e.target.checked) {
				try {
					response = await sendMessage({ action: 'checkShipmentsStatusEnableSchedule', period: checkShipmentsStatusPeriodInput.value });
					if (!response.success) throw new Error(response.result);
					toastMessage(`Włączono automatyczne sprawdzanie statusów przesyłek w tle co ${response.result} godzin${response.result === 1 ? 'ę' : ((response.result >= 2 && response.result <= 4) || (response.result >= 20 && response.result <= 24) ? 'y' : '')}`);
					
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
					return;
				} 
			} else {
				try {
					response = await sendMessage({ action: 'checkShipmentsStatusDisableSchedule' });
					if (!response.success) throw new Error(response.result);
					toastMessage('Sprawdzanie statusów przesyłek w tle zostało wyłączone');
				} catch (error) {
					return;
				}
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących automatycznego sprawdzania statusów przesyłek w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'showShipmentStatus')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'showShipmentStatus',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/shipments*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/shipments*'],
						css: ['show_shipment_status.css', 'toast.css'],
						js: ['show_shipment_status.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'showShipmentStatus',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/shipments*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/shipments*'],
						css: ['show_shipment_status.css', 'toast.css'],
						js: ['show_shipment_status.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	if (checkShipmentsStatusTimerCheckbox.checked) {
		let alarm
		try {
			alarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
			if (!alarm) {
				try {
					response = await sendMessage({ action: 'checkShipmentsStatusEnableSchedule', period: checkShipmentsStatusPeriodInput.value });
					if (!response.success) throw new Error(response.result);
					toastMessage(`Włączono automatyczne sprawdzanie statusów przesyłek w tle co ${response.result} godzin${response.result === 1 ? 'ę' : ((response.result >= 2 && response.result <= 4) || (response.result >= 20 && response.result <= 24) ? 'y' : '')}`);
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
					return;
				} 
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się sprawdzić czy automatyczne sprawdzanie statusów przesyłek w tle oczekuje na uruchomienie o określonej godzinie. ${getErrorMessage(error)}`);
		}
	}

	let checkShipmentsStatusDetails = document.getElementById('checkShipmentsStatusDetails');
	checkShipmentsStatusDetails.addEventListener('toggle', async (e) => {
		if (e.target.open) {
			let response;
			let cssShipmentStatus;
			let shipmentStatus;

			try {
    		response = await sendMessage({ action: 'checkShipmentsGetMarkedAsRead' });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				toastMessage(`Błąd! ${getErrorMessage(error)}`);
				return;
			}

			let shipmentsResult = document.getElementById('checkShipmentsStatusMarkedAsRead');
			if (!response.result.length) {
				shipmentsResult.innerHTML = '<span>Brak przesyłek oznaczonych jako przeczytane</span>';
				return;
			}

			shipmentsResult.innerHTML = '';
			
			response.result.forEach(shipment => {
				let item = document.createElement('div');
				switch (shipment.status) {
					case 'RETURNED': {
						cssShipmentStatus = 'returned';
						shipmentStatus = 'ZWRÓCONA';
						break;
					}

					case 'ISSUE': {
						cssShipmentStatus = 'issue';
						shipmentStatus = 'PROBLEM';
						break;
					}

					case 'NOTICE_LEFT': {
						cssShipmentStatus = 'noticeLeft';
						shipmentStatus = 'AWIZO';
						break;
					}

					case 'TIME_RUNNING_OUT': {
						cssShipmentStatus = 'timeRunningOut';
						shipmentStatus = 'MAŁO CZASU';
						break;
					}
				}
				item.classList = `csShipments ${cssShipmentStatus}`;
				item.innerHTML =  `<span>${shipment.waybill}</span><span>${shipment.carrier}</span><span class="status">${shipmentStatus}</span>`;
				item.addEventListener('click', checkShipmentsShowPage);
				item.addEventListener('longClick', checkShipmentsMarkAsUnread);
				item.addEventListener('transitionend', async (e) => {
					const waybillNumber = e.target.firstElementChild.textContent;
					let readedValue;
					try {
						readedValue = await readDataFromSessionStorage(['shipmentsMarkedAsReaded']);
						readedValue.shipmentsMarkedAsReaded = readedValue.shipmentsMarkedAsReaded.filter(item => item !== waybillNumber);
						await saveDataToSessionStorage({ 'shipmentsMarkedAsReaded': readedValue.shipmentsMarkedAsReaded });
					} catch (error) {

					}
					e.target.remove(); 
				});
				item.addEventListener('mousedown', (e) => {
					e.target.dataset.clickTimer = setTimeout(() => {
						delete e.target?.dataset?.clickTimer;
						const longClickEvent = new CustomEvent('longClick', { detail: e.target });
						item.dispatchEvent(longClickEvent);
					}, 1000);
				});
				item.addEventListener('mouseup', (e) => {
					const clickTimer = e.target?.dataset?.clickTimer;
					if (clickTimer) {
						clearTimeout(clickTimer);
						delete e.target?.dataset?.clickTimer;
					}
				});
				shipmentsResult.insertAdjacentElement('beforeend', item);
			});
		}
	});
	chrome.action.setPopup({ popup: 'actions_popup.html' });
}

async function checkShipmentsMarkAsUnread(e) {
	const waybillSpan = (e.target.nodeName === 'SPAN' ? e.target.parentElement.querySelector('span') : e.target.querySelector('span'));
  const waybillNumber = waybillSpan.innerText;
  let response;
  try {
    response =  await sendMessage({ action: 'checkShipmentsMarkAsUnread', waybill: waybillNumber });
		if (!response.success) throw new Error(response.result);
		waybillSpan.closest('div.csShipments').style.opacity = 0;
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }
}

async function checkShipmentsShowPage(e) {
  const waybillSpan = (e.target.nodeName === 'SPAN' ? e.target.parentElement.querySelector('span') : e.target.querySelector('span'));
  const waybillNumber = waybillSpan.innerText;
  const hrefLink = document.createElement('a');
  hrefLink.href = `https://salescenter.allegro.com/ship-with-allegro/shipments?waybill=${waybillNumber}`;
  hrefLink.target = '_blank';
  hrefLink.click();
  hrefLink.remove();
  waybillSpan.classList.add('visited');
}

async function parametersWatcher() {
	let permissionGranted;

	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	let contentScripts;
	let response;
	let readedValue;

	try {
		readedValue = await readDataFromLocalStorage(['parametersWatcherTimerCheckbox', 'parametersWatcherSandbox', 'parametersWatcherPeriodInput']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień dotyczących automatycznego sprawdzania parametrów w tle wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	const parametersWatcherTimerCheckbox = document.getElementById('parametersWatcherTimerCheckbox');
	parametersWatcherTimerCheckbox.checked = readedValue['parametersWatcherTimerCheckbox'];

	const parametersWatcherPeriodInput = document.getElementById('parametersWatcherPeriodInput');
	parametersWatcherPeriodInput.value = readedValue['parametersWatcherPeriodInput'];
	parametersWatcherPeriodInput.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ parametersWatcherPeriodInput: e.target.value });
			if (parametersWatcherTimerCheckbox.checked) {
				const changeEvent = new Event('change');
				parametersWatcherTimerCheckbox.dispatchEvent(changeEvent);
			} else {
				toastMessage('Zapisano');
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących trybu działania automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
	});
	parametersWatcherPeriodInput.addEventListener('keydown', (e) => { e.preventDefault() });

	
	parametersWatcherTimerCheckbox.addEventListener('change', async (e) => {
		try {
			const permissionApproved = await chrome.permissions.contains({ permissions: ['alarms'] });
			if (!permissionApproved) {
				const permissionRequest = await chrome.permissions.request({ permissions: ['alarms'] });
				if (!permissionRequest) throw new Error ('Nie przyznano uprawnień do alarmów');
			}
			await saveDataToLocalStorage({ parametersWatcherTimerCheckbox: e.target.checked });
			if (e.target.checked) {
				try {
					response = await sendMessage({ action: 'parametersWatcherEnableSchedule', period: parametersWatcherPeriodInput.value });
					if (!response.success) throw new Error(response.result);
					toastMessage(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${response.result} godzin${response.result === 1 ? 'ę' : ((response.result >= 2 && response.result <= 4) || (response.result >= 20 && response.result <= 24) ? 'y' : '')}`);
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
					return;
				} 
			} else {
				try {
					response = await sendMessage({ action: 'parametersWatcherDisableSchedule' });
					if (!response.success) throw new Error(response.result);
					toastMessage('Sprawdzanie parametrów w tle zostało wyłączone');
				} catch (error) {
					return;
				} 
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const pwNormalRadio = document.getElementById('pwNormalRadio');
	const pwSandboxRadio = document.getElementById('pwSandboxRadio');

	if (readedValue['parametersWatcherSandbox']) pwSandboxRadio.checked = true;
	else pwNormalRadio.checked = true;

	pwNormalRadio.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ parametersWatcherSandbox: !e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących trybu działania automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	pwSandboxRadio.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ parametersWatcherSandbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących trybu działania automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'parametersWatcher')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'parametersWatcher',
						matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
						css: ['parameters_watcher.css', 'toast.css'],
						js: ['parameters_watcher.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'parametersWatcher',
						matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
						css: ['parameters_watcher.css', 'toast.css'],
						js: ['parameters_watcher.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const parametersWatcherBuildBaseButton = document.getElementById('parametersWatcherBuildBaseButton');
	const parametersWatcherRemoveBaseButton = document.getElementById('parametersWatcherRemoveBaseButton');
	parametersWatcherBuildBaseButton.addEventListener('click', parametersWatcherBuildBaseButtonClick);
	parametersWatcherRemoveBaseButton.addEventListener('click', parametersWatcherRemoveBaseButtonClick);

	if (parametersWatcherTimerCheckbox.checked) {
		let alarm
		try {
			alarm = await chrome.alarms.get('parametersWatcherAlarm');
			if (!alarm) {
				try {
					response = await sendMessage({ action: 'parametersWatcherEnableSchedule', period: parametersWatcherPeriodInput.value });
					if (!response.success) throw new Error(response.result);
					toastMessage(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${response.result} godzin${response.result === 1 ? 'ę' : ((response.result >= 2 && response.result <= 4) || (response.result >= 20 && response.result <= 24) ? 'y' : '')}`);
				} catch (error) {
					toastMessage(`Błąd! ${getErrorMessage(error)}`);
					return;
				} 
			}
		} catch (error) {
			toastMessage(`Błąd! Nie udało się sprawdzić czy automatyczne pobieranie parametrów w tle oczekuje na uruchomienie o określonej godzinie. ${getErrorMessage(error)}`);
		}
	}

	chrome.action.setPopup({ popup: 'actions_popup.html' });
}

async function parametersWatcherBuildBaseButtonClick(e) {
	document.getElementById('pwAdditionalInfoMode').disabled = true;
	const parametersWatcherBuildBaseButton = document.getElementById('parametersWatcherBuildBaseButton');
	const parametersWatcherRemoveBaseButton = document.getElementById('parametersWatcherRemoveBaseButton');
	const pwNormalRadio = document.getElementById('pwNormalRadio');
	pwNormalRadio.disabled = true;
	const pwSandboxRadio = document.getElementById('pwSandboxRadio');
	pwSandboxRadio.disabled = true;
	parametersWatcherRemoveBaseButton.disabled = true;
	const parametersWatcherProgress = document.getElementById('parametersWatcherProgress');

	const sandbox = (pwSandboxRadio.checked ? 'Sandbox' : '');
	const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	const mode = (environment === '' ? 'allegro' : 'sandbox');

	if (e.target.textContent === 'Zbuduj bazę') {
		e.target.textContent = 'Anuluj';
		parametersWatcherProgress.ariaValueNow = 0;
		parametersWatcherProgress.class = 'progress-bar';
		parametersWatcherProgress.style = 'width: 0%';

		let response;

		try {
			response = await sendMessage({ action: 'getAllegroAccessToken', mode: mode });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		} 
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			return;
		}

		const accessToken = response.result;
		let parameters = {
			accessToken: accessToken,
			environment: environment,
			sandbox: sandbox,
			offset: 0,
			mode: mode
		}

		let offersCount = 0;
		let offerProducts = [];
		try {
			offersCount = await getOffersCount(parameters, 5);
			response = await processOffers(parameters, offersCount);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			e.target.disabled = false;
			document.getElementById('pwAdditionalInfoMode').disabled = false;
			return;
		}

		async	function processOffers(parameters, offersCount) {
			parametersWatcherProgress.ariaValueMax = offersCount;

			try {
				response = await getOffers();
			} catch (error) {
				toastMessage(`Błąd! ${getErrorMessage(error)}`);
			}

			async function getOffers(offset = 0, count = 5) {
				if (document.getElementById('parametersWatcherBuildBaseButton').textContent !== 'Anuluj') {
					parametersWatcherProgress.ariaValueNow = 0;
					parametersWatcherProgress.class = 'progress-bar';
					parametersWatcherProgress.style = `width: 0%`;
					parametersWatcherBuildBaseButton.textContent = 'Zbuduj bazę';
					parametersWatcherRemoveBaseButton.disabled = false;
					pwNormalRadio.disabled = false;
					pwSandboxRadio.disabled = false;
					toastMessage('Anulowano tworzenie bazy danych. Dotychczas pobrane dane zostały zapisane, aby je usunąć kliknij przycisk "Usuń bazę".');
					return;
				}
				if (offset > offersCount) {
					parametersWatcherProgress.ariaValueNow = progressBar.ariaValueMax;
					parametersWatcherProgress.style = 'width: 100%';
					parametersWatcherProgress.className = 'progress-bar bg-success';
					toastMessage('Zakończono pobieranie parametrów ofert.');
					e.target.disabled = false;
					document.getElementById('pwAdditionalInfoMode').disabled = false;
					return;
				}
				try {
					fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=10&publication.status=ACTIVE&publication.status=ENDED`, {
						'method': 'GET',
						'headers': {
							'Authorization': `Bearer ${parameters.accessToken}`,
							'Content-Type': 'application/vnd.allegro.public.v1+json',
							'Accept': 'application/vnd.allegro.public.v1+json'
						}
					});
				} catch (error) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aukcji.');
					}
				}
				if (fetchResponse.status === 200) {
					try {
						result = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
					}
								
					let offersList = [];
					result.offers.forEach(offer => {
						offersList.push(offer.id);
					});

					if (offersList.length) {
						do {
							const offerId = offersList.shift();
							if (offerId === undefined) {
								if (result.totalCount > (offset + 10)) {
									await new Promise(resolve => setTimeout(resolve, 0));
									return await getOffers(offset + 10);
								} else {
									parametersWatcherProgress.ariaValueNow = parametersWatcherProgress.ariaValueMax;
									parametersWatcherProgress.style = 'width: 100%';
									parametersWatcherProgress.className = 'progress-bar bg-success';
									parametersWatcherBuildBaseButton.textContent = 'Zbuduj bazę';
									parametersWatcherRemoveBaseButton.disabled = false;
									pwNormalRadio.disabled = false;
									pwSandboxRadio.disabled = false;

									toastMessage('Zakończono pobieranie parametrów ofert.');
									e.target.disabled = false;
									document.getElementById('pwAdditionalInfoMode').disabled = false;
									return Promise.resolve(true);
								}
							}

							let offer;
							try {
								offer = await pwGetOfferProductData(5, offerId, parameters, offerProducts);
								await sendMessage({ action: 'offerParametersSave', offer: offer });
								console.log('Aktualne dane aukcji:' + offer);
							} catch (error) {
								toastMessage(`Błąd! ${getErrorMessage(error)}`);
							}

							parametersWatcherProgress.ariaValueNow = Number(parametersWatcherProgress.ariaValueNow) + 1;
							parametersWatcherProgress.style = `width: ${Math.floor(100 / (result.totalCount / Number(parametersWatcherProgress.ariaValueNow)))}%`;
							
						} while (offersList.length > 0);

						if (result.totalCount > (offset + 10)) {
							await new Promise(resolve => setTimeout(resolve, 0));
							return await getOffers(offset + 10);
						} else {
							parametersWatcherProgress.ariaValueNow = parametersWatcherProgress.ariaValueMax;
							parametersWatcherProgress.style = 'width: 100%';
							parametersWatcherProgress.className = 'progress-bar bg-success';
							parametersWatcherBuildBaseButton.textContent = 'Zbuduj bazę';
							parametersWatcherRemoveBaseButton.disabled = false;
							pwNormalRadio.disabled = false;
							pwSandboxRadio.disabled = false;

							toastMessage('Zakończono pobieranie parametrów ofert.');
							e.target.disabled = false;
							document.getElementById('pwAdditionalInfoMode').disabled = false;
							return Promise.resolve(true);
						}
					}
				}  else if (fetchResponse.status === 401) {
					if (--count) {
						try {
							response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
							if (!response.success) throw new Error(response.result);
						} catch (error) {
							return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
						}
						parameters.accessToken = response.result;
						return await getOffers(offset, count);  
					} else {
						return Promise.reject(`Nie udało się zalogować użytkownika.`);
					}			
				} else if (fetchResponse.status === 403) {
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				} else if (fetchResponse.status === 429) {
					if (--count) {
						toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
					}
				}	else if (fetchResponse.status === 500) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject(`Błąd serwera w trakcie pobierania aukcji, spróbuj ponownie później.`);
					}
				} else {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject(`Nie udało się pobrać aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
					}
				}
			}
		}
	}	else {
		parametersWatcherProgress.ariaValueNow = 0;
		parametersWatcherProgress.class = 'progress-bar';
		parametersWatcherProgress.style = `width: 0%`;
		parametersWatcherBuildBaseButton.textContent = 'Zbuduj bazę';
		parametersWatcherRemoveBaseButton.disabled = false;
		pwNormalRadio.disabled = false;
		pwSandboxRadio.disabled = false;
		toastMessage('Anulowano tworzenie bazy danych. Dotychczas pobrane dane zostały zapisane, aby je usunąć kliknij przycisk "Usuń bazę".');
	}
}

async function pwGetOfferProductData(count, offerId, parameters, offerProducts) {
	let fetchResponse, response;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać oferty ${offerId}`);
		}
	}

	if (fetchResponse.status === 200) {
		let offerData;
		try {
			offerData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (offerData.productSet !== undefined) {
      offerProducts[offerId] = [];
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
				if (productId === null) continue;
        let product;
        try {
          product = await pwGetProductData(5, productId, parameters);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        offerProducts[offerId].push(product);
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts[offerId] });
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response.result;
      return await pwGetOfferProductData(count, offerId, parameters, offerProducts);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Błąd serwera w trakcie pobierania oferty ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Nie udało się pobrać oferty ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}

async function pwGetProductData(count, productId, parameters) {
	let fetchResponse, response;
  const product = {
    id: productId,
    name: '',
    parameters: [],
    images: []
  }
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych produktu ${productId}`);
		}
	}

	if (fetchResponse.status === 200) {
		let productData;
		try {
			productData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (productData.name !== undefined) {
      product.name = productData.name;
      productData.parameters.forEach(parameter => product.parameters.push({ name: parameter.name, values: parameter.valuesLabels }));
      productData.images.forEach(image => product.images.push(image.url));
			return Promise.resolve(product);
		} else return Promise.reject(`W pobranych danych produktu nie znaleziono wymaganych parametrów.`);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response.result;
      return await pwGetProductData(count, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów produktu ${productId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać parametrów produktu ${productId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}

async function getOffersCount(parameters, count) {
	let result, response, fetchResponse, offersCount;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1&publication.status=ACTIVE&publication.status=ENDED`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać liczby aukcji.`);
		}
	}
	if (fetchResponse.status === 200) {
		try {
			result = await fetchResponse.json();
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}
		offersCount = result.totalCount;
		return Promise.resolve(offersCount);
	} else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
				if (!response.success) throw new Error(response.result);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			if (response.result === undefined) {
				return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			}
			parameters.accessToken = response.result;  
		} else {
			return Promise.reject('Nie udało się zalogować użytkownika.');
		}		
	} else if (fetchResponse.status === 403) {
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject(`Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}											
	}	
}

async function parametersWatcherRemoveBaseButtonClick() {
	if (window.confirm('Czy na pewno chcesz usunąć bazę danych z parametrami aukcji?')) {
		let response;
		try {
			response = await sendMessage({ action: 'parametersWatcherRemoveBase' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		toastMessage('Usunięto bazę danych.');
	}
}

async function erliActions() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*', 'https://erli.pl/*', 'https://sandbox.erli.dev/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*, https://erli.pl/*, https://sandbox.erli.dev/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'erliActions')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'erliActions',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['erli_actions.css', 'toast.css'],
					js: ['erli_actions.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'erliActions',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['erli_actions.css', 'toast.css'],
					js: ['erli_actions.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['erliToken', 'erliTokenSandbox', 'erliAlwaysSyncToSandbox', 'erliShowStockLeftCheckbox', 'erliFastStockManagerCheckbox', 'erliRestoreCancelledCheckbox', 'erliRestoreReturnedCheckbox', 'erliPriceListName', 'erliObligatoryName', 'erliVoluntaryName', 'erliReturnsName', 'erliPriceApplyDiscountCheckbox', 'erliPriceAmountRadio', 'erliPricePercentRadio', 'erliPriceStepsRadio', 'erliPriceAmountValue', 'erliPricePercentValue', 'erliPriceSteps']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania tokenów dostępowych do Erli wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const erliTokenText = document.getElementById('erliTokenText');
	erliTokenText.value = readedValue.erliToken;
	const erliTokenTextSandbox = document.getElementById('erliTokenTextSandbox');
	erliTokenTextSandbox.value = readedValue.erliTokenSandbox;

	const erliTokenSaveButton = document.getElementById('erliTokenSaveButton');
	erliTokenSaveButton.addEventListener('click', erliTokenSaveButtonClick.bind(null, false));
	const erliTokenSaveButtonSandbox = document.getElementById('erliTokenSaveButtonSandbox');
	erliTokenSaveButtonSandbox.addEventListener('click', erliTokenSaveButtonClick.bind(null, true));

	const erliAlwaysSyncToSandboxCheckbox = document.getElementById('erliAlwaysSyncToSandboxCheckbox');
	erliAlwaysSyncToSandboxCheckbox.checked = readedValue.erliAlwaysSyncToSandbox;
	erliAlwaysSyncToSandboxCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliAlwaysSyncToSandbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących sposobu kopiowania aukcji do Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const erliShowStockLeftCheckbox = document.getElementById('erliShowStockLeftCheckbox');
	erliShowStockLeftCheckbox.checked = readedValue.erliShowStockLeftCheckbox;
	erliShowStockLeftCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliShowStockLeftCheckbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących synchronizacji stanów przy zmianie stanu na Allegro i w Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const erliFastStockManagerCheckbox = document.getElementById('erliFastStockManagerCheckbox');
	erliFastStockManagerCheckbox.checked = readedValue.erliFastStockManagerCheckbox;
	erliFastStockManagerCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliFastStockManagerCheckbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących synchronizacji stanów przy zmianie stanu na Allegro i w Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const erliRestoreCancelledCheckbox = document.getElementById('erliRestoreCancelledCheckbox');
	erliRestoreCancelledCheckbox.checked = readedValue.erliRestoreCancelledCheckbox;
	erliRestoreCancelledCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliRestoreCancelledCheckbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących synchronizacji stanów przy przywracaniu przedmiotów z anulowanego zamówienia na Allegro. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const erliRestoreReturnedCheckbox = document.getElementById('erliRestoreReturnedCheckbox');
	erliRestoreReturnedCheckbox.checked = readedValue.erliRestoreReturnedCheckbox;
	erliRestoreReturnedCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliRestoreReturnedCheckbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących synchronizacji stanów przy przywracaniu przedmiotów z listy zwrotów na Allegro. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	const erliPriceListNameText = document.getElementById('erliPriceListNameText');
	erliPriceListNameText.value = readedValue.erliPriceListName;
	const erliReturnsNameText = document.getElementById('erliReturnsNameText');
	erliReturnsNameText.value = readedValue.erliReturnsName;
	const erliObligatoryNameText = document.getElementById('erliObligatoryNameText');
	erliObligatoryNameText.value = readedValue.erliObligatoryName;
	const erliVoluntaryNameText = document.getElementById('erliVoluntaryNameText');
	erliVoluntaryNameText.value = readedValue.erliVoluntaryName;

	const erliPriceApplyDiscountCheckbox = document.getElementById('erliPriceApplyDiscountCheckbox');
	erliPriceApplyDiscountCheckbox.checked = readedValue.erliPriceApplyDiscountCheckbox;
	document.getElementById('erliPriceOptionsContainer').style.display = (readedValue.erliPriceApplyDiscountCheckbox ? 'block' : 'none');
	erliPriceApplyDiscountCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ erliPriceApplyDiscountCheckbox: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących obniżania cen w Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		document.getElementById('erliPriceOptionsContainer').style.display = (e.target.checked ? 'block' : 'none');
		toastMessage('Zapisano');
	});

	const erliPriceAmountRadio = document.getElementById('erliPriceAmountRadio');
	erliPriceAmountRadio.checked = readedValue.erliPriceAmountRadio;
	const erliPricePercentRadio = document.getElementById('erliPricePercentRadio');
	erliPricePercentRadio.checked = readedValue.erliPricePercentRadio;
	const erliPriceStepsRadio = document.getElementById('erliPriceStepsRadio');
	erliPriceStepsRadio.checked = readedValue.erliPriceStepsRadio;

	const erliPriceAmountInput = document.getElementById('erliPriceAmountInput');
	const erliPriceAmountValue = readedValue['erliPriceAmountValue'] || 0.00;
	erliPriceAmountInput.value = erliPriceAmountValue;
	erliPriceAmountInput.addEventListener('focus', (e) => {
		document.getElementById('erliPriceAmountRadio').checked = true;
		document.getElementById('erliPriceStepsContainer').style.display = 'none';
	});

	const erliPricePercentInput = document.getElementById('erliPricePercentInput');
	const erliPricePercentValue = readedValue['erliPricePercentValue'] || 0;
	erliPricePercentInput.value = erliPricePercentValue;
	erliPricePercentInput.addEventListener('focus', (e) => {
		document.getElementById('erliPricePercentRadio').checked = true;
		document.getElementById('erliPriceStepsContainer').style.display = 'none';
	});

	const erliPriceStepsContainer = document.getElementById('erliPriceStepsContainer');
	erliPriceStepsContainer.style.display = (readedValue.erliPriceStepsRadio ? 'inherit' : 'none');
	const erliPriceSteps = document.getElementById('erliPriceSteps');
	const erliPriceStepsList = readedValue.erliPriceSteps.sort((a, b) => a.amount - b.amount) || [];

	erliPriceStepsList.forEach((step) => {
		const erliPriceStep = document.createElement('div');
		erliPriceStep.className = 'row pb-2 ms-2';
		erliPriceStep.innerHTML = /*html*/ `
			<div class="col-auto d-flex gx-2">
				<div class="form-check form-check-inline w-100 priceStep">
					<input class="form-check-input" type="radio" name="erliPriceStepRadio">
					<span>Jeśli wartość towaru jest większa niż</span>
					<div class="input-group input-group-sm" style="width: auto;">
						<input type="number" class="form-control form-control-sm" name="erliPriceStepAmountText" min="1" max="1000" step="1" value="${step.amount}">
						<span class="input-group-text">zł</span>
					</div>
					<span>to obniż o</span>
					<div class="input-group input-group-sm" style="width: auto;">
						<input type="number" class="form-control form-control-sm" name="erliPriceStepValueText" min="0.00" max="1" step="0.00" value="${step.value}">
						<span class="input-group-text">zł</span>
					</div>
				</div>
			</div>`;	
		erliPriceSteps.appendChild(erliPriceStep);
	});


	erliPriceAmountRadio.addEventListener('change', async (e) => {
		erliPriceStepsContainer.style.display = 'none';
	});
	erliPricePercentRadio.addEventListener('change', async (e) => {
		erliPriceStepsContainer.style.display = 'none';
	});
	erliPriceStepsRadio.addEventListener('change', async (e) => {
		erliPriceStepsContainer.style.display = (e.target.checked ? 'inherit' : 'none');
	});

	const erliSettingsSaveButton = document.getElementById('erliSettingsSaveButton');
	erliSettingsSaveButton.addEventListener('click', async () => {
		const erliPriceListName = erliPriceListNameText.value;
		const erliReturnsName = erliReturnsNameText.value;
		const erliObligatoryName = erliObligatoryNameText.value;
		const erliVoluntaryName = erliVoluntaryNameText.value;
		try {
			await saveDataToLocalStorage({ erliPriceListName: erliPriceListName, erliReturnsName: erliReturnsName, erliObligatoryName: erliObligatoryName, erliVoluntaryName: erliVoluntaryName });
			toastMessage('Zapisano');
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zapisać ustawień dotyczących Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
	});

	const erliPriceAddStepButton = document.getElementById('erliPriceAddStepButton');
	erliPriceAddStepButton.addEventListener('click', async () => {
		const erliPriceSteps = document.getElementById('erliPriceSteps');
		const erliPriceStep = document.createElement('div');
		erliPriceStep.className = 'row pb-2 ms-2';
		erliPriceStep.innerHTML = /*html*/ `
			<div class="col-auto d-flex gx-2">
				<div class="form-check form-check-inline w-100 priceStep">
					<input class="form-check-input" type="radio" name="erliPriceStepRadio">
					<span>Jeśli wartość towaru jest większa niż</span>
					<div class="input-group input-group-sm" style="width: auto;">
						<input type="number" class="form-control form-control-sm" name="erliPriceStepAmountText" min="1" max="1000" step="1" value="1">
						<span class="input-group-text">zł</span>
					</div>
					<span>to obniż o</span>
					<div class="input-group input-group-sm" style="width: auto;">
						<input type="number" class="form-control form-control-sm" name="erliPriceStepValueText" min="0.00" max="1" step="0.01" value="0.00">
						<span class="input-group-text">zł</span>
					</div>
				</div>
			</div>`;	
		erliPriceSteps.appendChild(erliPriceStep);
	});

	const erliPriceRemoveStepButton = document.getElementById('erliPriceRemoveStepButton');
	erliPriceRemoveStepButton.addEventListener('click', async () => {
		const erliPriceSteps = document.getElementById('erliPriceSteps');
		const erliPriceStepsList = erliPriceSteps.querySelectorAll('.row.pb-2.ms-2');
		if (erliPriceStepsList.length > 1) {
			erliPriceSteps.querySelector('input[type="radio"]:checked')?.parentElement?.parentElement?.parentElement?.remove();
		}
	});

	const erliPriceSaveButton = document.getElementById('erliPriceSaveButton');
	erliPriceSaveButton.addEventListener('click', async () => {
		const erliPriceAmount = erliPriceAmountRadio.checked;
		const erliPricePercent = erliPricePercentRadio.checked;
		const erliPriceSteps = erliPriceStepsRadio.checked;
		const erliPriceAmountValue = document.getElementById('erliPriceAmountInput').value;
		const erliPricePercentValue = document.getElementById('erliPricePercentInput').value;
		const erliPriceStepsList = document.getElementById('erliPriceSteps').querySelectorAll('.row.pb-2.ms-2');
		const erliPriceStepsValues = [];
		for (const erliPriceStep of erliPriceStepsList) {
			const erliPriceStepAmountText = erliPriceStep.querySelector('input[name="erliPriceStepAmountText"]');
			const erliPriceStepValueText = erliPriceStep.querySelector('input[name="erliPriceStepValueText"]');
			if (erliPriceStepAmountText && erliPriceStepValueText) {
				erliPriceStepsValues.push({
					amount: parseFloat(erliPriceStepAmountText.value),
					value: parseFloat(erliPriceStepValueText.value)
				});
			}
		}
		erliPriceStepsValues.sort((a, b) => a.amount - b.amount);
		if (erliPriceSteps && erliPriceStepsValues.length === 0) {
			toastMessage('Błąd! Aby zapisać ustawienia dotyczące obniżania cen w Erli musisz dodać przynajmniej jeden krok obniżania ceny.');
			return Promise.reject(false);
		}

		try {
			await saveDataToLocalStorage({ erliPriceAmountRadio: erliPriceAmount, erliPricePercentRadio: erliPricePercent, erliPriceStepsRadio: erliPriceSteps, erliPriceAmountValue: erliPriceAmountValue, erliPricePercentValue: erliPricePercentValue, erliPriceSteps: erliPriceStepsValues });
			toastMessage('Zapisano');
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zapisać ustawień dotyczących obniżania cen w Erli. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
	});
}

async function erliTokenSaveButtonClick(sandboxParam = false) {
	const sandbox = (sandboxParam === false ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	try {
		const response = await sendMessage({ action: 'erliTokenSave', token: document.getElementById(`erliTokenText${sandbox}`).value, sandbox: sandboxParam });
		document.getElementById(`erliTokenSaveButton${sandbox}`).disabled = true;
		if (!response.success) throw new Error(response.result);
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu tokena do Erli wystąpił błąd. ${getErrorMessage(error)}`);
	};
}

async function additionalActions() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'additionalActions')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'additionalActions',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['additional_actions.css', 'toast.css'],
					js: ['additional_actions.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'additionalActions',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['additional_actions.css', 'toast.css'],
					js: ['additional_actions.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
				return Promise.reject(false);
			}
		}
	}
}

async function buyerStats() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'buyerStats')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'buyerStats',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['buyer_stats.css', 'toast.css'],
						js: ['buyer_stats.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'buyerStats',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['buyer_stats.css', 'toast.css'],
						js: ['buyer_stats.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}

	const buyerStatsBuildBaseButton = document.getElementById('buyerStatsBuildBaseButton');
	const buyerStatsRemoveBaseButton = document.getElementById('buyerStatsRemoveBaseButton');
	buyerStatsBuildBaseButton.addEventListener('click', buyerStatsBuildBaseButtonClick);
	buyerStatsRemoveBaseButton.addEventListener('click', buyerStatsRemoveBaseButtonClick);
}

async function buyerStatsBuildBaseButtonClick(e) {
	const buyerStatsBuildBaseButton = document.getElementById('buyerStatsBuildBaseButton');
	const buyerStatsRemoveBaseButton = document.getElementById('buyerStatsRemoveBaseButton');
	const bsAdditionalInfoModeNormalRadio = document.getElementById('bsAdditionalInfoModeNormal');
	bsAdditionalInfoModeNormalRadio.disabled = true;
	const bsAdditionalInfoModeSandboxRadio = document.getElementById('bsAdditionalInfoModeSandbox');
	bsAdditionalInfoModeSandboxRadio.disabled = true;
	buyerStatsRemoveBaseButton.disabled = true;
	const buyerStatsProgress = document.getElementById('buyerStatsProgress');

	const sandbox = (bsAdditionalInfoModeSandboxRadio.checked ? 'Sandbox' : '');
	const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	const mode = (environment === '' ? 'allegro' : 'sandbox');

	if (e.target.textContent === 'Zbuduj bazę') {
		e.target.textContent = 'Anuluj';
		buyerStatsProgress.ariaValueNow = 0;
		buyerStatsProgress.class = 'progress-bar';
		buyerStatsProgress.style = 'width: 0%';

		let response;

		try {
			response = await sendMessage({ action: 'getAllegroAccessToken', mode: mode });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		} 
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			return;
		}

		let currentDate = new Date();
		let startDate = new Date();
		startDate -= (365*86400000);
		let dateTo = currentDate;
		let dateFrom = dateTo - 86400000;

		const accessToken = response.result;
		let parameters = {
			accessToken: accessToken,
			environment: environment,
			offset: 0,
			startDate: startDate,
			dateFrom: dateFrom,
			dateTo: dateTo,
			mode: mode
		}

		async function fetchOrders(parameters, count = 5) {
			if (e.target.textContent === 'Zbuduj bazę') return;
			let fetchResponse;
			let fetchData;
			let order;
			let dateFromEncoded = encodeURIComponent(new Date(parameters.dateFrom).toISOString());
			let dateToEncoded = encodeURIComponent(new Date(parameters.dateTo).toISOString());
			try {
				fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms?offset=${parameters.offset}&fulfillment.status=SENT&lineItems.boughtAt.gte=${dateFromEncoded}&lineItems.boughtAt.lte=${dateToEncoded}`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await fetchOrders(parameters, count);      
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać listy zamówień.`);
				}
			}
			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}
				
				if (parameters.dateFrom < parameters.startDate) {
					return;
				}

				do {
					order = fetchData.checkoutForms.shift(); 
					if (order === undefined) break;

					try {
						response = await sendMessage({ action: 'buyerStatsGetBuyer', login: order.buyer.login });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}
					let buyer = response.result;
					if (buyer === undefined) {
						buyer = {
							id: order.buyer.id,
							login: order.buyer.login,
							orders: [{
								orderId: order.id,
								orderDate: order.payment.finishedAt,
								orderValue: order.summary.totalToPay.amount
							}],
							returns: []
						}
					} else {
						if (buyer.orders.some(o => o.orderId === order.id) === false) { // Nie znaleziono tego zamówienia na liście wcześniejszych zamówień
							let newOrder = {
								orderId: order.id,
								orderDate: order.payment.finishedAt,
								orderValue: order.summary.totalToPay.amount
							}
							buyer.orders.push(newOrder);
						}
					}

					let returns;
					try {
						returns = await buyerStatsGetReturns(parameters, order.id);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}

					if (returns !== true) { 
						returns.forEach(singleReturn => { 
							if (buyer.returns.some(r => (r.orderId === singleReturn.orderId) && (r.returnDate === singleReturn.returnDate)) === false) { // Nie znaleziono tego konkretnego zwrotu
								buyer.returns.push(singleReturn);
							}
						});
					}

					try {
						response = await sendMessage({ action: 'buyerStatsSaveBuyer', buyer: buyer });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}
				} while (true);
				
				if (parameters.offset + 100 < fetchData.totalCount) {
					parameters.offset += 100;
				} else {
					parameters.dateTo -= 86400000;
					parameters.dateFrom -= 86400000;
					if (e.target.textContent === 'Zbuduj bazę') return;
					buyerStatsProgress.ariaValueNow++;
					buyerStatsProgress.style = `width: ${(buyerStatsProgress.ariaValueNow / 365) * 100}%`;
				}
				return await fetchOrders(parameters);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(getErrorMessage(error));
					}  
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					parameters.accessToken = response.result;
					return await fetchOrders(parameters, count);  
				} else {
					return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
				}
			} else if (fetchResponse.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else if (fetchResponse.status === 429) {
				if (--count) {
					toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					return await fetchOrders(parameters, count);
				} else {
					return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await fetchOrders(parameters, count); 
				} else {
					return Promise.reject(`Błąd serwera podczas pobierania zamówień, spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await fetchOrders(parameters, count);      
				} else {
					return Promise.reject(`Nie udało się pobrać listy zamówień. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}											
			}	
		}

		try {
			await fetchOrders(parameters);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
		}

		if (e.target.textContent !== 'Zbuduj bazę') {
			buyerStatsProgress.ariaValueNow = 365;
			buyerStatsProgress.className = 'progress-bar bg-success';
			buyerStatsProgress.style = `width: 100%`;
			buyerStatsBuildBaseButton.textContent = 'Zbuduj bazę';
			buyerStatsRemoveBaseButton.disabled = false;
			bsAdditionalInfoModeNormalRadio.disabled = false;
			bsAdditionalInfoModeSandboxRadio.disabled = false;
			toastMessage('Zbudowano bazę danych.');
		}
	} else {
		buyerStatsProgress.ariaValueNow = 0;
		buyerStatsProgress.class = 'progress-bar';
		buyerStatsProgress.style = `width: 0%`;
		buyerStatsBuildBaseButton.textContent = 'Zbuduj bazę';
		buyerStatsRemoveBaseButton.disabled = false;
		bsAdditionalInfoModeNormalRadio.disabled = false;
		bsAdditionalInfoModeSandboxRadio.disabled = false;
		toastMessage('Anulowano tworzenie bazy danych. Dotychczas pobrane dane zostały zapisane, aby je usunąć kliknij przycisk "Usuń bazę".');
	}
}

async function buyerStatsRemoveBaseButtonClick() {
	if (window.confirm('Czy na pewno chcesz usunąć bazę danych ze statystykami użytkowników?')) {
		let response;
		try {
			response = await sendMessage({ action: 'buyerStatsRemoveBase' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}
		toastMessage('Usunięto bazę danych.');
	}
}

async function buyerStatsGetReturns(parameters, orderId, count = 5) {
  let response;
	let fetchResponse;
  try {
    fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/order/customer-returns?orderId=${orderId}`, {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.beta.v1+json',
        'Accept': 'application/vnd.allegro.beta.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się sprawdzić zwrotu dla zamówienia ${orderId}.`);
    }
  }

  if (fetchResponse.status === 200) {
    let fetchData;
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    if (fetchData.customerReturns.length > 0) {
      let returns = [];
      for (const returnOrder of fetchData.customerReturns) {
        let returnOrderValue = 0;
        returnOrder.items.forEach(item => {
          returnOrderValue += parseFloat(item.price.amount * item.quantity);
        });
        returns.push({
          orderId: returnOrder.orderId,
          returnDate: returnOrder.createdAt,
          returnValue: returnOrderValue
        });
      }
      return Promise.resolve(returns);
    }
    return Promise.resolve(true);
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: parameters.mode });
        if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await buyerStatsGetReturns(parameters, orderId, count);
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await buyerStatsGetReturns(parameters, orderId, count);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await buyerStatsGetReturns(parameters, orderId, count);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania zwrotów, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await buyerStatsGetReturns(parameters, orderId, count);  
    } else {
      return Promise.reject(`Nie udało się sprawdzić zwrotu. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }
}

async function additionalOrdersSortingOptions() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'additionalOrdersSortingOptions')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'additionalOrdersSortingOptions',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['toast.css'],
						js: ['additional_orders_sorting_options.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'additionalOrdersSortingOptions',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['toast.css'],
						js: ['additional_orders_sorting_options.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${getErrorMessage(error)}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return Promise.reject(false);
	}
}

function colorCodeCopyButtonClick() {
	let colorPickerValue = document.getElementById('colorPickerValue');
	colorPickerValue.select();
	navigator.clipboard.writeText(colorPickerValue.value);
}

function colorFilterTextInput(event) {
	debug('input event');
	let saveFilterButton = document.getElementById('saveFilterButton');
	saveFilterButton.disabled = (event.target.checkValidity() ? false : true);
}

async function saveFilterButtonClick() {
	try {
		await chrome.runtime.sendMessage({ action: 'saveColor', color: document.getElementById('colorPickerValue').value, filter: document.getElementById('colorFilterText').value });
		this.disabled = true;
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. ${getErrorMessage(error)}`);
	}
}


async function allegroAPI() {
	let response;
	let chromeExtensionAppName = document.getElementById('chromeExtensionAppName');
	let chromeExtensionAppNameSandbox = document.getElementById('chromeExtensionAppNameSandbox');
	try {
		response = await sendMessage({ action: 'getAppName' });
		chromeExtensionAppName.innerText = response.result;
		chromeExtensionAppNameSandbox.innerText = response.result;
	} catch (error) {
		toastMessage('Błąd! Nie udało się znaleźć unikalnego identyfikatora rozszerzenia. Funkcje korzystające z API nie będą działać.');
	}

	let redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');
	document.getElementById('chromeExtensionRedirectURL').innerText = redirectUrl;
	document.getElementById('chromeExtensionRedirectURLSandbox').innerText = redirectUrl;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['allegroAPIClientId', 'allegroAPIClientSecret', 'allegroTokenScopes', 'allegroAPIClientIdSandbox', 'allegroAPIClientSecretSandbox', 'allegroTokenScopesSandbox']);
		if (readedValue.allegroAPIClientId !== undefined && readedValue.allegroAPIClientSecret !== undefined) {
			const allegroAPIClientIdText = document.getElementById('allegroAPIClientIdText');
			allegroAPIClientIdText.value = readedValue.allegroAPIClientId;
			allegroAPIClientIdText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientSecretText').checkValidity();
					document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButton').disabled = true;
				}
			});
			allegroAPIClientIdText.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			});

			const allegroAPIClientSecretText = document.getElementById('allegroAPIClientSecretText');
			allegroAPIClientSecretText.value = readedValue.allegroAPIClientSecret;
			allegroAPIClientSecretText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity();
					document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButton').disabled = true;
				}
			});
			allegroAPIClientSecretText.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			});
	
			const allegroTokenScopesSpan = document.getElementById('allegroTokenScopes');
			allegroTokenScopesSpan.textContent = readedValue.allegroTokenScopes;
			readedValue.allegroTokenScopes.split(', ').forEach(scope => {
				document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(span => {
					span.classList.add('scopeGrantedYes');
					span.classList.remove('scopeGrantedNo');
				})
			});
		}
		const allegroAPISaveButton = document.getElementById('allegroAPISaveButton');
		allegroAPISaveButton.addEventListener('click', allegroAPISaveButtonClick.bind(null, false));
		const allegroAPILoginButton = document.getElementById('allegroAPILoginButton');
		allegroAPILoginButton.addEventListener('click', allegroAPILoginButtonClick.bind(null, false));
		if (allegroAPIClientIdText.checkValidity() && allegroAPIClientIdText.value !== '' && allegroAPIClientSecretText.checkValidity && allegroAPIClientSecretText.value !== '') {
			document.getElementById('allegroAPILoginButton').disabled = false;
		}

		if (readedValue.allegroAPIClientIdSandbox !== undefined && readedValue.allegroAPIClientSecretSandbox !== undefined) {
			const allegroAPIClientIdTextSandbox = document.getElementById('allegroAPIClientIdTextSandbox');
			allegroAPIClientIdTextSandbox.value = readedValue.allegroAPIClientIdSandbox;
			allegroAPIClientIdTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
					document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
				}
			});
			allegroAPIClientIdTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			});

			const allegroAPIClientSecretTextSandbox = document.getElementById('allegroAPIClientSecretTextSandbox');
			allegroAPIClientSecretTextSandbox.value = readedValue.allegroAPIClientSecretSandbox;
			allegroAPIClientSecretTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity();
					document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
				}
			});
			allegroAPIClientSecretTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			});

			const allegroTokenScopesSpanSandbox = document.getElementById('allegroTokenScopesSandbox');
			allegroTokenScopesSpanSandbox.textContent = readedValue.allegroTokenScopesSandbox;
			readedValue.allegroTokenScopesSandbox.split(', ').forEach(scope => {
				document.querySelectorAll(`span[class~="${scope.replaceAll(':', '-')}"]`).forEach(span => {
					span.classList.add('scopeGrantedYesSandbox');
					span.classList.remove('scopeGrantedNoSandbox');
				})
			});

			document.querySelectorAll('span[class="requiredScopes"]').forEach(outerSpan => {
				outerSpan.querySelectorAll('span').forEach(span => {
					if (!span.classList.contains('scopeGrantedYes')) span.classList.add('scopeGrantedNo');
					if (!span.classList.contains('scopeGrantedYesSandbox')) span.classList.add('scopeGrantedNoSandbox');
				});
			});
		}
		const allegroAPISaveButtonSandbox = document.getElementById('allegroAPISaveButtonSandbox');
		allegroAPISaveButtonSandbox.addEventListener('click', allegroAPISaveButtonClick.bind(null, true));
		const allegroAPILoginButtonSandbox = document.getElementById('allegroAPILoginButtonSandbox');
		allegroAPILoginButtonSandbox.addEventListener('click', allegroAPILoginButtonClick.bind(null, true));
		if (allegroAPIClientIdTextSandbox.checkValidity() && allegroAPIClientIdTextSandbox.value !== '' && allegroAPIClientSecretTextSandbox.checkValidity && allegroAPIClientSecretTextSandbox.value !== '') {
			document.getElementById('allegroAPILoginButtonSandbox').disabled = false;
		}
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu z pamięci danych dotyczących logowania wystąpił błąd. ${getErrorMessage(error)}`);
	}
}

function debug(text) {
	chrome.runtime.sendMessage({ action: 'debug', info: text });
}

function colorPickerChange() {
	let customColorElements = document.getElementsByClassName('customColor');
	for (let element of customColorElements) {
		element.classList.add('hidden');
	}
	document.getElementById('colorPickerValue').value = this.value;
	let colorFilterText = document.getElementById('colorFilterText');
	let colorFilter = colorFilterText.value;
	switch (this.value) {
		case '#000000': {
			colorFilter = 'filter: invert(0%) sepia(4%) saturate(0%) hue-rotate(337deg) brightness(93%) contrast(107%);';
			break;
		}
		case '#404040': {
			colorFilter = 'filter: invert(19%) sepia(8%) saturate(10%) hue-rotate(11deg) brightness(93%) contrast(77%);';
			break;
		}
		case '#808080': {
			colorFilter = 'filter: invert(19%) sepia(8%) saturate(10%) hue-rotate(11deg) brightness(93%) contrast(77%);';
			break;
		}
		case '#c0c0c0': {
			colorFilter = 'filter: invert(85%) sepia(0%) saturate(1%) hue-rotate(316deg) brightness(90%) contrast(95%);';
			break;
		}
		case '#980000': {
			colorFilter = 'filter: invert(9%) sepia(65%) saturate(7334%) hue-rotate(11deg) brightness(94%) contrast(117%);';
			break;
		}
		case '#ff0000': {
			colorFilter = 'filter: invert(29%) sepia(80%) saturate(6896%) hue-rotate(353deg) brightness(95%) contrast(127%);';
			break;
		}
		case '#ff9900': {
			colorFilter = 'filter: invert(70%) sepia(53%) saturate(4645%) hue-rotate(1deg) brightness(104%) contrast(104%);';
			break;
		}
		case '#ffff00': {
			colorFilter = 'filter: invert(81%) sepia(90%) saturate(1721%) hue-rotate(359deg) brightness(104%) contrast(105%);';
			break;
		}
		case '#00ff00': {
			colorFilter = 'filter: invert(51%) sepia(71%) saturate(2969%) hue-rotate(89deg) brightness(122%) contrast(123%);';
			break;
		}
		case '#00c202': {
			colorFilter = 'filter: invert(40%) sepia(99%) saturate(1016%) hue-rotate(88deg) brightness(103%) contrast(106%);';
			break;
		}
		case '#00ffff': {
			colorFilter = 'filter: invert(100%) sepia(38%) saturate(7498%) hue-rotate(101deg) brightness(105%) contrast(104%);';
			break;
		}
		case '#4a86e8': {
			colorFilter = 'filter: invert(50%) sepia(27%) saturate(1651%) hue-rotate(184deg) brightness(96%) contrast(90%);';
			break;
		}
		case '#0000ff': {
			colorFilter = 'filter: invert(11%) sepia(100%) saturate(4411%) hue-rotate(242deg) brightness(98%) contrast(151%);';
			break;
		}
		case '#9900ff': {
			colorFilter = 'filter: invert(22%) sepia(99%) saturate(6798%) hue-rotate(275deg) brightness(96%) contrast(128%);';
			break;
		}
		case '#ff00ff': {
			colorFilter = 'filter: invert(34%) sepia(100%) saturate(6821%) hue-rotate(296deg) brightness(116%) contrast(124%);';
			break;
		}
		default: {
			for (let element of customColorElements) {
				element.classList.remove('hidden');
			}
			break;
		}
	}
	colorFilterText.value = colorFilter;
	document.getElementById('saveFilterButton').disabled = !document.getElementById('colorFilterText').checkValidity();

}