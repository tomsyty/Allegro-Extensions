const DETAILED_ERROR_MESSAGE = `Szczegóły (oryginalna treść błędu):`;
const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const REFRESHING_TOKEN_ERROR = 'Nie udało się odświeżyć tokena dostępowego.';
const COULDNT_GET_TOKENS = 'Nie udało się uzyskać tokenów dostępowych.';
const NO_PERMISSION_GRANTED = 'Brak uprawnień.'


chrome.storage.onChanged.addListener((storageObject, storageArea) => {
	if (storageArea === 'session') {
		if ('message' in storageObject && 'newValue' in storageObject.message) {
			toastMessage(storageObject.message.newValue);
			chrome.storage.session.remove('message');
		}
	}
});

async function saveDataToLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.set(data, () => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true);
		});
	});
}

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result);
		});
	});
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt optionsPage');
	chrome.storage.session.get(['message']).then(result => {
		if (result.message !== undefined) {
			toastMessage(result.message);
			chrome.storage.session.remove('message');
		}
	});

	const navigatorPermissions = await navigator.permissions.query({ name: 'clipboard-write' });
	if (navigatorPermissions.state !== undefined) {
		if (navigatorPermissions.state === 'granted') {
			const colorCodeCopyButton = document.getElementById('colorCodeCopyButton');
			colorCodeCopyButton.addEventListener('click', colorCodeCopyButtonClick);
			colorCodeCopyButton.parentNode.classList.remove('disabled');
		} else {
			console.log('Stan zezwolenia na zapis do schowka: ' + navigatorPermissions.state);
		}
	}

});

async function checkAllegroAPIPermission(e) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		return Promise.reject(`Podczas pobierania listy rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
	}

	if (e.target.checked) {
		if (!readedValue.extensions['allegroAPI']) {
			if (window.confirm('To rozszerzenie wymaga aktywowania najpierw rozszerzenia API Allegro. Czy chcesz włączyć je teraz?')) {
				const event = new CustomEvent('change', { detail: e.target });
				document.getElementById('allegroAPI').dispatchEvent(event);
				return Promise.resolve(true);
			} else {
				e.target.checked = false;
				return Promise.reject('Aby aktywować rozszerzenie, wymagane jest aktywowanie rozszerzenia API Allegro.');
			}
		}
	}
	return Promise.resolve(true);
}

window.addEventListener('DOMContentLoaded', async () => {
	console.log('Options page DOMContentLoaded event');
	let readedValue;

	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		toastMessage(`Błąd! W trakcie próby odczytu danych wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}

	document.getElementById('changeInvoicesIconColor').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('autoprintLabel').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['nativeMessaging', 'downloads', 'tabs']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* oraz uprawnień do zarządzania pobranymi plikami, komunikowania się ze współpracującymi aplikacjami natywnymi i dostępu do historii przeglądania.');
		}
	});

	document.getElementById('autofillPackageSize').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('inPostSendMode').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('sendMessageFromOrdersPage').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('additionalOrdersSortingOptions').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('validateBuyerAddressErrors').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('changeAuctionsTitle').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* i dostępu do historii przeglądania');
		}
	});

	document.getElementById('fastStockManager').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('restoreCancelled').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('restoreReturned').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/* i dostępu do historii przeglądania');
		}
	});

	document.getElementById('iFirmaReturnsCheckbox').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://www.ifirma.pl/*']
		});
		if (granted) {
			
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do strony https://www.ifirma.pl/*');
		}
	});

	document.getElementById('showProductName').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('showStockLeft').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('shipmentExistsWarning').addEventListener('change', async (e) => {
		try {
			await checkAllegroAPIPermission(e);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			return;
		}
		const granted = await chrome.permissions.request({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (granted) {
			extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować moduł, wymagane jest przyznanie uprawnień dostępu do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		}
	});

	document.getElementById('changeAdditionalInfo').addEventListener('change', (e) => {
		e.target.parentNode.parentNode.parentNode.disabled = !e.target.checked;
		if (!e.target.checked) {
			document.getElementById('additionalInfoProgress').style = 'width: 0%';
		}
	});

	document.getElementById('additionalInfoChangeButton').addEventListener('click', async (e) => {
		e.target.disabled = true;
		document.getElementById('additionalInfoMode').disabled = true;
		const environment = (document.getElementById('additionalInfoModeNormal').checked ? '' : '.allegrosandbox.pl');
		const mode = (environment !== '' ? 'sandbox' : '');
		let progressBar = document.getElementById('additionalInfoProgress');
		progressBar.class = 'progress-bar';
		progressBar.ariaValueNow = '0';
		progressBar.ariaValueMax = '0';
		progressBar.style = 'width: 0%';
		document.getElementById('additionalInfoFailures').classList.add('hidden');
		document.getElementById('additionalInfoErrorsList').innerText = '';
		let response;
		try {
			response = await sendMessage({ action: 'getAllegroAccessToken', mode: mode });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
			return Promise.reject(false);
		}
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
			return Promise.reject(false);
		}

		let parameters = {
			accessToken: response.result,
			environment: environment
		}
		
		let offersCount = 0;
		try {
			response = await getOffersCount(parameters, 5);
			response = await processOffers(parameters, response);
		} catch (error) {
			toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			e.target.disabled = false;
			document.getElementById('additionalInfoMode').disabled = false;
		}
		
		async function getOffersCount(parameters, count) {
			let result, fetchResponse;
			try {
				fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject('Nie udało się pobrać liczby aukcji.');
				}
			}
			if (fetchResponse.status === 200) {
				try {
					result = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`${JSON_DECODE_ERROR}. ${error?.message ? error.message : error}`);
				}
				offersCount = result.totalCount;
				return Promise.resolve(offersCount);
			} else if (response.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
						if (!response.success) throw new Error(response.result);
					} catch (error) {
						return Promise.reject(error?.message ? error.message : error);
					}
					if (response.result === undefined) {
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					parameters.accessToken = response.result;  
				} else {
					return Promise.reject('Nie udało się zalogować użytkownika.');
				}		
			} else if (response.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
					await new Promise(resolve => setTimeout(resolve, 5000));;
					return await getOffersCount(parameters, count);
				} else {
					return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
				}											
			}	
		}

		async	function processOffers(parameters, offersCount) {
			progressBar.ariaValueMax = offersCount;

			const text = document.getElementById('additionalInfoText').value;
			try {
				response = await getOffers();
			} catch (error) {
				toastMessage(`Błąd! ${error?.message ? error.message : error}`);
			}

			async function getOffers(offset = 0, count = 5) {
				if (offset > offersCount) {
					progressBar.ariaValueNow = progressBar.ariaValueMax;
					progressBar.style = 'width: 100%';
					progressBar.class = 'progress-bar bg-success';
					toastMessage('Zakończono zmianę ofert.');
					e.target.disabled = false;
					document.getElementById('additionalInfoMode').disabled = false;
					return;
				}
				try {
					fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=10`, {
						'method': 'GET',
						'headers': {
							'Authorization': `Bearer ${parameters.accessToken}`,
							'Content-Type': 'application/vnd.allegro.public.v1+json',
							'Accept': 'application/vnd.allegro.public.v1+json'
						}
					});
				} catch (error) {
					if (--count) {
						toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						return Promise.reject('Nie udało się pobrać aukcji.');
					}
				}
				if (fetchResponse.status === 200) {
					try {
						result = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR}. ${error?.message ? error.message : error}`);
					}
								
					let offersList = [];
					result.offers.forEach(offer => {
						offersList.push(offer.id);
					});

					if (offersList.length) {
						async function changeOffers(offersList) {
							const offerId = offersList.shift();
							if (offerId === undefined) {
								if (result.totalCount > (offset + 10)) {
									await new Promise(resolve => setTimeout(resolve, 0));
									return await getOffers(offset + 10);
								} else {
									progressBar.ariaValueNow = progressBar.ariaValueMax;
									progressBar.style = 'width: 100%';
									progressBar.class = 'progress-bar bg-success';
									toastMessage('Zakończono zmianę ofert.');
									e.target.disabled = false;
									document.getElementById('additionalInfoMode').disabled = false;
									return Promise.resolve(true);
								}
							}

							async function changeOffer(count = 5) {
								console.log(`Zmiana oferty ${offerId}`);
								try {
									fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
										'method': 'PATCH',
										'headers': {
											'Authorization': `Bearer ${parameters.accessToken}`,
											'Content-Type': 'application/vnd.allegro.public.v1+json',
											'Accept': 'application/vnd.allegro.public.v1+json'
										},
										body: JSON.stringify({
											'delivery': {
												'additionalInfo': text
											}
										})
									});
								} catch (error) {
									if (--count) {
										toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await changeOffer(count);
									} else {
										return Promise.reject('Nie udało się pobrać aukcji.');
									}
								}
									
								if (fetchResponse.status === 200) {
									progressBar.ariaValueNow = Number(progressBar.ariaValueNow) + 1;
									progressBar.style = `width: ${Math.floor(100 / (result.totalCount / Number(progressBar.ariaValueNow)))}%`;
									return await changeOffers(offersList);
								} else if (fetchResponse.status === 401) {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: mode });
											if (!response.success) throw new Error(response.result);
										} catch (error) {
											return Promise.reject(error?.message ? error.message : error);
										}
										if (response.result === undefined) {
											return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
										}
										parameters.accessToken = response.result;  
										return await changeOffer(count);												
									} else {
										e.target.disabled = false;
										document.getElementById('additionalInfoMode').disabled = false;
										return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
									}
								} else if (fetchResponse.status === 403) {
									e.target.disabled = false;
									document.getElementById('additionalInfoMode').disabled = false;
									return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								} else {
									if (--count) {
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await changeOffer(count);
									} else {
										document.getElementById('additionalInfoErrorsList').innerText += `${offerId} `;
										progressBar.ariaValueNow = Number(progressBar.ariaValueNow) + 1;
										progressBar.style = `width: ${Math.floor(100 / (result.totalCount / Number(progressBar.ariaValueNow)))}%`;
										document.getElementById('additionalInfoFailures').classList.remove('hidden');
										return await changeOffers(offersList);
									}
								}
							}
							await changeOffer();
						}
						await changeOffers(offersList);
					}
				} else if (fetchResponse.status === 401) {
					if (--count) {
						try {
							response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: mode });
							if (!response.success) throw new Error(response.result);
						} catch (error) {
							e.target.disabled = false;
							document.getElementById('additionalInfoMode').disabled = false;
							return Promise.reject(error?.message ? error.message : error);
						}
						if (response.result === undefined) {
							return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
						}
						parameters.accessToken = response.result;  
						return await getOffers(offset, count);
					} else {
						e.target.disabled = false;
						document.getElementById('additionalInfoMode').disabled = false;
						return Promise.reject('Nie udało się pobrać aukcji. Nie udało się zalogować użytkownika.');
					}
				} else if (fetchResponse.status === 403) {
					e.target.disabled = false;
					document.getElementById('additionalInfoMode').disabled = false;
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				} else {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await getOffers(offset, count);
					} else {
						e.target.disabled = false;
						document.getElementById('additionalInfoMode').disabled = false;
						return Promise.reject(`Nie udało się pobrać aukcji. Kod HTTP odpowiedzi : ${fetchResponse.code}`);
					}
				}	
			}
		} 
	});

	document.getElementById('allegroAPI').addEventListener('change', async (e) => {
		const granted = await chrome.permissions.request({
			permissions: ['identity'],
			origins: ['https://api.allegro.pl/*', 'https://salescenter.allegro.com/*', 'https://api.allegro.pl.allegrosandbox.pl/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*', 'https://script.google.com/*', 'https://script.googleusercontent.com/*']
		});
		if (granted) {
			if (!e.isTrusted) {
				document.getElementById('allegroAPI').checked = true;
				extensionSetState(e.target, e.detail);
			} else extensionSetState(e.target);
		} else {
			e.target.checked = false;
			toastMessage('Błąd! Aby aktywować rozszerzenie, wymagane jest przyznanie uprawnień dostępu do strony https://api.allegro.pl/*, https://salescenter.allegro.com/*, https://api.allegro.pl.allegrosandbox.pl/*, https://salescenter.allegro.com.allegrosandbox.pl/*, https://script.google.com/*, https://script.googleusercontent.com/*');
		}
	});

	document.getElementById('keyboardShortcutChangeLink').addEventListener('click', () => {
		chrome.tabs.create({url: 'chrome://extensions/shortcuts'});
	});

	document.getElementById('numericValuesRadio').addEventListener('change', (e) => {
		const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
		shipmentMethodAdditionalInfoText.innerText = 'Dla ręcznie dodawanej formy dostawy nie są znane ograniczenia dotyczące wagi i wymiarów. Wprowadź wartość która nie generuje błędu w formularzu nadawczym.';
		const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
		shipmentMethodNameText.disabled = false;
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues');
		if (!shipmentMethodPredefinedValues.classList.contains('hidden')) {
			const predefinedValuesBox = document.getElementById('predefinedValuesBox');
			predefinedValuesBox.innerHTML = '';
			shipmentMethodPredefinedValues.classList.add('hidden');
		}
		shipmentMethodNumericValues.querySelectorAll('input[type="number"]').forEach(element => element.value = '');
		shipmentMethodNumericValues.classList.remove('hidden');

		const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
		numericValuesTemplatesBox.innerHTML = '';
		shipmentMethodAddTemplateClick();
	});

	document.getElementById('predefinedValuesRadio').addEventListener('change', () => {
		const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
		shipmentMethodAdditionalInfoText.innerText = 'Rozwiń dodatkowe menu koło przycisku "Zapisz" aby dodać nową pozycję.';
		const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
		shipmentMethodNameText.disabled = false;
		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		if (!shipmentMethodNumericValues.classList.contains('hidden')) {
			const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
			numericValuesTemplatesBox.innerHTML = '';
			shipmentMethodNumericValues.classList.add('hidden');
			shipmentMethodNumericValues.querySelectorAll('input[type="number"]').forEach(element => element.value = '');
		}
	});

	const commands = await chrome.commands.getAll();
	const shortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
	const shortcutKeys = [];
	for (const key of shortcut.split('+')) {
		shortcutKeys.push(`<kbd>${key}</kbd>`); 
	}
	const shortcutHTML = shortcutKeys.join(' + ');
	document.getElementById('keyboardShortcutSpan').innerHTML = shortcutHTML;

	document.querySelectorAll('legend .form-check-input').forEach(toggleSwitch => {
		const extensionId = toggleSwitch.id;
		toggleSwitch.checked = readedValue.extensions[extensionId];
		toggleSwitch.parentNode.parentNode.parentNode.disabled = !toggleSwitch.checked;
		if (toggleSwitch.checked) window[extensionId]();
	});
});

async function extensionSetState(...targets) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		toastMessage(`Błąd! Podczas pobierania listy rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}

	for (const target of targets) {
		const extensionId = target.id;
		readedValue.extensions[extensionId] = target.checked;
		target.parentNode.parentNode.parentNode.disabled = !target.checked;
	}
	try {
		await saveDataToLocalStorage({ extensions: readedValue.extensions });
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisywania stanu rozszerzenia wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}
	for (const target of targets) {
		const extensionId = target.id;
		if (target.checked) window[extensionId]();
		else {
			const contentScripts = await chrome.scripting.getRegisteredContentScripts();
			if (contentScripts.find(registeredScript => { return registeredScript.id === extensionId }) !== undefined) {
				try {
					chrome.scripting.unregisterContentScripts({ ids: [extensionId] });
					console.log(`${extensionId} Skrypt został wyrejestrowany`);
				} catch (error) {
					console.log(`Wystąpił błąd podczas wyrejestrowywania skryptu ${extensionId}`);
				}
			}
		}
	}
}

async function allegroAPILoginButtonClick(sandboxParam = false) {
	const environment = (sandboxParam === false ? '' : '.allegrosandbox.pl');
	const mode = (environment !== '' ? 'sandbox' : '');
	const sandbox = (environment === '' ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	let loginData;
	try {
		loginData = await readDataFromLocalStorage([`allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`, 'allegroAPIOAuthConnectorSandbox']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu danych logowania wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}

	if (loginData[`allegroAPIClientId${sandbox}`] === undefined || loginData[`allegroAPIClientSecret${sandbox}`] === undefined || loginData.allegroAPIOAuthConnectorSandbox === undefined) {
		toastMessage('Błąd! Nie znaleziono danych wymaganych do logowania.');
		return;
	}

	async function login(count = 3) {
		if (!count) {
			toastMessage('Błąd! Nie udało się zalogować użytkownika.');
			return;
		}

		let params = {
			scopes: ['allegro:api:profile:read']
		}

		document.querySelectorAll('legend .form-check-input:checked').forEach(toggleSwitch => {
			if (toggleSwitch.dataset.scopes !== undefined) {
				toggleSwitch.dataset.scopes.split(' ').forEach(scope => {
					if (!params.scopes.includes(scope)) params.scopes.push(scope);
				});
			}
		});

		let fetchResponse;
		let fetchData;
		let response;

		if (mode === 'sandbox') {	
			
			try {
				fetchResponse = await fetch(loginData.allegroAPIOAuthConnectorSandbox, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({ action: 'getUserCode', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, scopes: params.scopes })
				});
			} catch (error) {
				return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error?.message ? error.message : error}`);
			}

			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}`);
				}

				if (fetchData.status === 'error') {
					return Promise.reject(fetchData.details);
				}

				try {
					response = await sendMessage({ action: 'openLoginPage', url: fetchData.verificationUri });
					if (!response.success) throw new Error(error?.message ? error.message : error);
				} catch (error) {
					return Promise.reject('Nie udało się otworzyć strony logowania.');
				}

				toastMessage('Przejdź do automatycznie otwartej strony logowania i zatwierdź wymagane zgody');
				try {
					fetchResponse = await fetch(loginData.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'getTokens', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, deviceCode: fetchData.deviceCode, interval: fetchData.interval, expirationDate: fetchData.expirationDate })
					});
				} catch (error) {
					return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error?.message ? error.message : error}`);
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}`);
					}

					if (fetchData?.status === 'success') {
						try {
							await saveDataToLocalStorage({ allegroAccessTokenSandbox: fetchData.accessToken, allegroRefreshTokenSandbox: fetchData.refreshToken });
						} catch (error) {
							return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${error?.message ? error.message : error}`);
						}
						console.log('Zapisano tokeny dostępowe.');
						fetchData.access_token = fetchData.accessToken;

						async function getLoggedUsername(count = 3) {
							try {
								fetchResponse = await fetch('https://api.allegro.pl.allegrosandbox.pl/me', {
									method: 'GET',
									headers: {
										'Authorization': `Bearer ${fetchData.access_token}`,
										'Content-Type': 'application/vnd.allegro.public.v1+json',
										'Accept': 'application/vnd.allegro.public.v1+json'
									}
								});
							} catch (error) {
								if (--count) {
									toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
									await new Promise(resolve => setTimeout(resolve, 5000));
									return await getLoggedUsername(count);
								} else return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error?.message ? error.message : error}`);
							}

							if (fetchResponse.status === 200) {
								try {
									fetchData = await fetchResponse.json();
								} catch (error) {
									return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}`);
								}
								if (fetchData.login !== undefined) return Promise.resolve(`${fetchData.login}`);
								else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
							} else {
								if (fetchResponse.status === 403) return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								else if (fetchResponse.status !== 401) {
									if (--count) {
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await getLoggedUsername(count);
									} else return Promise.reject(`${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
								} else {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: 'sandbox' });
											if (!response.success) throw new Error(response.result);
										} catch (error) {
											return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
										}
										fetchData.access_token = response.result;
										return await getLoggedUsername(count);
									} else {
										return Promise.reject(REFRESHING_TOKEN_ERROR);
									}
								}
							}
						}

						try {
							const username = await getLoggedUsername();
							return Promise.resolve(toastMessage(`Zalogowano jako użytkownik ${username}`));
						} catch (error) {
							return Promise.reject(`Nie udało się pobrać nazwy zalogowanego użytkownika. ${error}`);
						}
					} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
						return Promise.reject(`${COULDNT_GET_TOKENS} ${fetchData.details}`);
					} else return Promise.reject(COULDNT_GET_TOKENS);
				} else {
					return Promise.reject(`Podczas pobierania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
				}
			} else if (fetchResponse.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await login(count);
				} else return Promise.reject(`Spróbuj ponownie później. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
			}
		} else {
			const redirectUri = document.getElementById('chromeExtensionRedirectURL').innerText;
			let redirectUrl;
			try {
				redirectUrl = await chrome.identity.launchWebAuthFlow({ 'url': `https://allegro.pl/auth/oauth/authorize?response_type=code&client_id=${document.getElementById('allegroAPIClientIdText').value}&redirect_uri=${redirectUri}&scope=${params.scopes.join(' ')}&prompt=confirm`, 'interactive': true, 'abortOnLoadForNonInteractive': false, timeoutMsForNonInteractive: 10000 });
			} catch (error) {
				if (error.message === 'The user did not approve access.') return Promise.reject('Proces logowania nie został zakończony.');
			}

			if (redirectUrl !== undefined) {
				const code = redirectUrl.substring(redirectUrl.indexOf('code=') + 5);
				try {
					fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=authorization_code&code=${code}&redirect_uri=${redirectUri}`, {
						method: 'POST',
						headers: {
							'Authorization': `Basic ${btoa(loginData['allegroAPIClientId'] + ':' + loginData['allegroAPIClientSecret'])}`
						},
					});
				} catch (error) {
					return Promise.reject(`Spróbuj ponownie później. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
				}
				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}`);
					}

					if (fetchData.access_token !== undefined && fetchData.refresh_token !== undefined) {
						try {
							await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
						} catch (error) {
							return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${error?.message ? error.message : error}`);
						}

						async function getLoggedUsername(count = 3) {
							try {
								fetchResponse = await fetch('https://api.allegro.pl/me', {
									method: 'GET',
									headers: {
										'Authorization': `Bearer ${fetchData.access_token}`,
										'Content-Type': 'application/vnd.allegro.public.v1+json',
										'Accept': 'application/vnd.allegro.public.v1+json'
									}
								});
							} catch (error) {
								if (--count) {
									toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
									await new Promise(resolve => setTimeout(resolve, 5000));
									return await getLoggedUsername(count);
								} else return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error?.message ? error.message : error}`);
							}

							if (fetchResponse.status === 200) {
								try {
									fetchData = await fetchResponse.json();
								} catch (error) {
									return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}`);
								}
								if (fetchData.login !== undefined) return Promise.resolve(fetchData.login);
								else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
							} else {
								if (fetchResponse.status === 403) return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								else if (fetchResponse.status !== 401) {
									if (--count) {
										await new Promise(resolve => setTimeout(resolve, 5000));
										return await getLoggedUsername(count);
									} else return Promise.reject(`${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
								} else {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: 'allegro' });
											if (!response.success) throw new Error(response.result);
										} catch (error) {
											return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
										}
										fetchData.access_token = response.result;
										return await getLoggedUsername(count);
									} else {
										return Promise.reject(REFRESHING_TOKEN_ERROR);
									}
								}
							}
						}

						try {
							const username = await getLoggedUsername();
							return Promise.resolve(`Zalogowano jako użytkownik ${username}`);
						} catch (error) {
							return Promise.reject(`Nie udało się pobrać nazwy zalogowanego użytkownika. ${error}`);
						}
					}
				} else if (fetchResponse.status === 403) {
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				} else {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await login(count);
					} else return Promise.reject(`Spróbuj ponownie później. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}
			}
		}
	}
	try {
		const result = await login();
		toastMessage(result);
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
}

async function allegroAPISaveButtonClick(sandboxParam = false) {
	const sandbox = (sandboxParam === false ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	try {
		const response = await sendMessage({ action: 'allegroAPISave', clientId: document.getElementById(`allegroAPIClientIdText${sandbox}`).value, clientSecret: document.getElementById(`allegroAPIClientSecretText${sandbox}`).value, oAuthConnector: document.getElementById('allegroAPIOAuthConnectorTextSandbox').value, sandbox: sandboxParam });
		document.getElementById(`allegroAPISaveButton${sandbox}`).disabled = true;
		document.getElementById(`allegroAPILoginButton${sandbox}`).disabled = !response.result;
		if (!response.success) throw new Error(response.result);
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu parametrów Client ID i Cilent Secret wystąpił błąd. ${error?.message ? error.message : error}`);
	};
}


async function changeInvoicesIconColor() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	
		
	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'changeInvoicesIconColor')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'changeInvoicesIconColor',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['change_invoices_icon_color.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'changeInvoicesIconColor',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					js: ['change_invoices_icon_color.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['color', 'filter']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania stylu ikony faktury wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (readedValue.color !== undefined && readedValue.filter !== undefined) {
		const colorPickerValue = document.getElementById('colorPickerValue');
		const colorFilterText = document.getElementById('colorFilterText');
		const colorPicker = document.getElementById('colorPicker');
		colorPickerValue.value = readedValue.color;
		colorFilterText.value = readedValue.filter;
		colorPicker.value = readedValue.color;
		colorPicker.addEventListener('input', colorPickerChange);
		const event = new Event('input');
		colorPicker.dispatchEvent(event);
		colorFilterText.addEventListener('input', colorFilterTextInput);
		const saveFilterButton = document.getElementById('saveFilterButton');
		saveFilterButton.addEventListener('click', saveFilterButtonClick);
	}

}

async function autoprintLabel() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	let response;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['nativeMessaging', 'downloads', 'tabs']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'autoprintLabel')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autoprintLabel',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
					css: ['autoprint_label.css', 'toast.css'],
					js: ['autoprint_label.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autoprintLabel',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*',  'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
					css: ['autoprint_label.css', 'toast.css'],
					js: ['autoprint_label.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}

		if (!contentScripts.some(registeredScript => registeredScript.id === 'autoprintLabelOrders')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autoprintLabelOrders',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['autoprint_label_orders.css'],
					js: ['autoprint_label_orders.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autoprintLabelOrders',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['autoprint_label_orders.css'],
					js: ['autoprint_label_orders.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['defaultPrinter']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania zapisanej domyślnej drukarki wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		response = await sendMessage({ action: 'getPrinters' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	let options = '<option>Wybierz drukarkę</option>';
	
	response.result.forEach(printer => {
		options += `<option${(readedValue.defaultPrinter === printer ? ' selected' : '')}>${printer}</option>`;
	});	
	const printerSelect = document.getElementById('printerSelect');
	printerSelect.innerHTML = options;

	printerSelect.addEventListener('change', async (e) => {
		const options = e.target.options;
		const selectedIndex = e.target.selectedIndex;
		if (selectedIndex) {
			try {
				await saveDataToLocalStorage({ defaultPrinter: options[selectedIndex].text });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać zmiany drukarki. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
			toastMessage('Zapisano wybór wskazanej drukarki.');
		} else {
			try {
				await saveDataToLocalStorage({ defaultPrinter: '' });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać zmiany drukarki. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
			toastMessage('Usunięto wybór wskazanej drukarki. Wybierz nową.');
		}
	});

	try {
		readedValue = await readDataFromLocalStorage(['sumatraPath']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania zapisanej ścieżki programu SumatraPDF wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	if (readedValue.sumatraPath !== undefined && readedValue.sumatraPath) {
		const sumatraPathInput = document.getElementById('sumatraPathInput');
		sumatraPathInput.value = readedValue.sumatraPath;
		sumatraPathInput.addEventListener('paste', (e) => {
			document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
		});
		sumatraPathInput.addEventListener('input', (e) => {
			document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
		});
		const event = new Event('input');
		sumatraPathInput.dispatchEvent(event);
	} else {
		try {
			response = await sendMessage({ action: 'getSumatraPath' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! Podczas pobierania ścieżki programu SumatraPDF wystąpił błąd. ${error?.message ? error.message : error}`);
			return Promise.reject(false);
		}

		if (response.result) {
			try {
				await saveDataToLocalStorage({ sumatraPath: response.result })
			} catch (error) {
				toastMessage(`Błąd! Podczas zapisywania domyślnej ścieżki programu SumatraPDF wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
			const sumatraPathInput = document.getElementById('sumatraPathInput');
			sumatraPathInput.value = response.result;
			sumatraPathInput.addEventListener('paste', (e) => {
				document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
			});
			sumatraPathInput.addEventListener('input', (e) => {
				document.getElementById('sumatraPathSaveButton').disabled = !e.target.checkValidity();
			});
			const event = new Event('input');
			sumatraPathInput.dispatchEvent(event);
		}
	}

	const sumatraPathSaveButton = document.getElementById('sumatraPathSaveButton');
	sumatraPathSaveButton.addEventListener('click', async (e) => {
		const sumatraPath = document.getElementById('sumatraPathInput').value;
		if (sumatraPath) {
			try {
				await saveDataToLocalStorage({ sumatraPath: sumatraPath });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się zapisać ścieżki programu SumatraPDF. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
			e.target.disabled = true;
			toastMessage('Zapisano ścieżkę programu SumatraPDF.');
		} else {
			try {
				await saveDataToLocalStorage({ sumatraPath: '' });
			} catch (error) {
				toastMessage(`Błąd! Nie udało się usunąć zapisanej ścieżki programu SumatraPDF. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
			e.target.disabled = true;
			toastMessage('Usunięto zapisaną ścieżkę do programu SumatraPDF. Wskaż nową.');
		}
	});
}

async function autofillPackageSize() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'autofillPackageSize')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'autofillPackageSize',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['autofill_package_size.css', 'toast.css'],
					js: ['autofill_package_size.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'autofillPackageSize',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['autofill_package_size.css', 'toast.css'],
					js: ['autofill_package_size.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['shippingMethods']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania listy metod dostawy wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	let options = '<option>Wybierz metodę dostawy</option>';
	for (let option of readedValue.shippingMethods) {
		if (option.weight1 !== undefined) {
			let optionTemplate = '<option';
			let i = 1;
			while (option[`weight${i}`] !== undefined) {
				optionTemplate += ` data-weight${i}="${option[`weight${i}`]}" data-length${i}="${option[`length${i}`]}" data-width${i}="${option[`width${i}`]}" data-height${i}="${option[`height${i++}`]}"`;
			}
			optionTemplate += ` data-max-weight="${option.maxWeight}" data-min-length="${option.minLength}" data-max-length="${option.maxLength}" data-min-width="${option.minWidth}" data-max-width="${option.maxWidth}" data-min-height="${option.minHeight}" data-max-height="${option.maxHeight}" data-default="${option.default}" ${(option.defaultName !== undefined ? ' data-default-name="' + option.defaultName + '"' : '')}>${option.name}</option>`;
			options += optionTemplate;
		} else if (option.size1 !== undefined) {
			let optionSize = '<option';
			let i = 1;
			while (option[`size${i}`] !== undefined) {
				optionSize += ` data-size${i}="${option[`size${i++}`]}"`;
			}
			optionSize += ` data-default="${option.default}"${(option.defaultName !== undefined ? ' data-default-name="' + option.defaultName + '"' : '')}>${option.name}</option>`;
			options += optionSize;
		}
	}
	options += '<option>Dodaj nową</option>';

	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.innerHTML = options;
	const shipmentMethodNameText = document.getElementById('shipmentMethodNameText'); 
	const shipmentMethodNameInvalidFeedback = document.getElementById('shipmentMethodNameInvalidFeedback');

	shipmentMethodSelect.addEventListener('change', async (e) => {
		const shipmentMethodAdditionalInfo = document.getElementById('shipmentMethodAdditionalInfo');
		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues');
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		const numericValuesRadio = document.getElementById('numericValuesRadio');
		const shipmentMethodCommonElements = document.getElementById('shipmentMethodCommonElements');
		
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		shipmentMethodDropdown.disabled = false;

		const shipmentMethodRemove = document.getElementById('shipmentMethodRemove');
		shipmentMethodRemove.classList.add('disabled');
		
		const shipmentMethodAddTemplate = document.getElementById('shipmentMethodAddTemplate');
		shipmentMethodAddTemplate.classList.add('disabled');
		const shipmentMethodRemoveTemplate = document.getElementById('shipmentMethodRemoveTemplate');
		shipmentMethodRemoveTemplate.classList.add('disabled');
		
		const shipmentMethodAddPredefinedValue = document.getElementById('shipmentMethodAddPredefinedValue');
		shipmentMethodAddPredefinedValue.classList.add('disabled');
		const shipmentMethodRemovePredefinedValue = document.getElementById('shipmentMethodRemovePredefinedValue');
		shipmentMethodRemovePredefinedValue.classList.add('disabled');
		
		let type;
		const options = e.target.options;
		const selectedIndex = e.target.selectedIndex;
		let selectedOption = options[selectedIndex];

		if (selectedOption.text !== 'Dodaj nową') {
			shipmentMethodNumericValues.classList.add('hidden');
			shipmentMethodPredefinedValues.classList.add('hidden');
		}

		if (e.isTrusted) {
			shipmentMethodSelectType.classList.add('hidden');
			shipmentMethodAdditionalInfo.classList.add('hidden');
		}

		if (selectedIndex === 0) {
			shipmentMethodCommonElements.classList.add('hidden');
			return Promise.resolve(true);
		}
		shipmentMethodCommonElements.classList.remove('hidden');
		

		if (selectedOption.dataset.weight1 !== undefined || (selectedOption.text === 'Dodaj nową' && numericValuesRadio.checked)) {
			type = 'numeric';
			shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodAddTemplate.classList.remove('disabled');
			shipmentMethodRemoveTemplate.classList.remove('disabled');
		}	else if (selectedOption.dataset.size1 !== undefined || (selectedOption.text === 'Dodaj nową' && numericValuesRadio.checked)) {
			type = 'predefined';
			if (e.isTrusted) shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodAddPredefinedValue.classList.remove('disabled');
			shipmentMethodRemovePredefinedValue.classList.remove('disabled');
		}	else {
			if (e.isTrusted) {
				type = 'new';
				shipmentMethodNameText.disabled = true;
				shipmentMethodNumericValues.classList.remove('hidden');
				numericValuesRadio.click();
			} else {
				const shipmentMethodAdditionalInfoText = document.getElementById('shipmentMethodAdditionalInfoText');
				if (numericValuesRadio.checked) {
					type = 'numeric';
					shipmentMethodNameText.disabled = false;
					shipmentMethodAdditionalInfoText.innerText = 'Dla ręcznie dodawanej formy dostawy nie są znane ograniczenia dotyczące wagi i wymiarów. Wprowadź wartość która nie generuje błędu w formularzu nadawczym.';
				} else {
					type = 'predefined';
					shipmentMethodNameText.disabled = false;
					shipmentMethodAdditionalInfoText.innerText = 'Dodaj wybieralne wartości rozwijając dodatkowe menu koło przycisku "Zapisz".';
					shipmentMethodAddPredefinedValue.classList.remove('disabled');
					shipmentMethodRemovePredefinedValue.classList.remove('disabled');
					shipmentMethodAddPredefinedValue.disabled = false;
					shipmentMethodRemovePredefinedValue.disabled = false;
					shipmentMethodDropdown.disabled = false;
				}
			}
			shipmentMethodAdditionalInfo.classList.remove('hidden');
			shipmentMethodSelectType.classList.remove('hidden');
		}
		
		let unmodified = (selectedOption.text === selectedOption.dataset?.defaultName);
	
		if (type === 'numeric') {
			const weightText = document.getElementById('weightText');
			const lengthText = document.getElementById('lengthText');
			const widthText = document.getElementById('widthText');
			const heightText = document.getElementById('heightText');
			const weightInvalidFeedback = document.getElementById('weightInvalidFeedback');
			const lengthInvalidFeedback = document.getElementById('lengthInvalidFeedback');
			const widthInvalidFeedback = document.getElementById('widthInvalidFeedback');
			const heightInvalidFeedback = document.getElementById('heightInvalidFeedback');

			if (e.isTrusted) {
				shipmentMethodNameText.classList.remove('is-invalid');
				shipmentMethodNameText.value = selectedOption.text;
			} else {
				shipmentMethodNameText.value = '';
			}

			document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podaj nazwę metody dostawy';
			const defaultTemplate = selectedOption.dataset.default;

			if (defaultTemplate !== undefined) {
				weightText.value = selectedOption.dataset[`weight${defaultTemplate}`];
				lengthText.value = selectedOption.dataset[`length${defaultTemplate}`];
				widthText.value = selectedOption.dataset[`width${defaultTemplate}`];
				heightText.value = selectedOption.dataset[`height${defaultTemplate}`];
			}
			
			weightText.min = '0.1';
			weightText.max = (unmodified ? selectedOption.dataset.maxWeight : '999');
			

			lengthText.min = (unmodified ? selectedOption.dataset.minLength : '1');
			lengthText.max = (unmodified ? selectedOption.dataset.maxLength : '999'); 
			

			widthText.min = (unmodified ? selectedOption.dataset.minWidth : '1');
			widthText.max = (unmodified ? selectedOption.dataset.maxWidth : '999');
			

			heightText.min = (unmodified ? selectedOption.dataset.minHeight : '1');
			heightText.max = (unmodified ? selectedOption.dataset.maxHeight : '999');
			

			weightInvalidFeedback.innerText = `0,1-${(unmodified ? selectedOption.dataset.maxWeight : '999')}kg`;
			lengthInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minLength + '-' + selectedOption.dataset.maxLength : '1-999')}cm`;
			widthInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minWidth + '-' + selectedOption.dataset.maxWidth : '1-999')}cm`;
			heightInvalidFeedback.innerText = `${(unmodified ? selectedOption.dataset.minHeight + '-' + selectedOption.dataset.maxHeight : '1-999')}cm`;

			if (defaultTemplate !== undefined) {
				const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
				numericValuesTemplatesBox.querySelectorAll('*').forEach(node => node.remove() );
			}
			
			let i = 1;

			while (selectedOption.dataset[`weight${i}`] !== undefined) {
				if (i > 9) break;
				const numericValuesTemplate = document.createElement('div');
				numericValuesTemplate.className = 'form-check form-check-inline';
				numericValuesTemplate.innerHTML = `<input class="form-check-input" data-weight="${selectedOption.dataset[`weight${i}`]}" data-length="${selectedOption.dataset[`length${i}`]}" data-width="${selectedOption.dataset[`width${i}`]}" data-height="${selectedOption.dataset[`height${i}`]}" type="radio" name="numericValuesTemplate" id="numericValuesTemplate${i}" value="${i}"${selectedOption.dataset.default == i ? ' checked' : ''}><label class="form-check-label" for="numericValuesTemplate${i}">${selectedOption.dataset[`length${i}`] ? selectedOption.dataset[`length${i}`] : '-'}x${selectedOption.dataset[`width${i}`] ? selectedOption.dataset[`width${i}`] : '-'}x${selectedOption.dataset[`height${i}`] ? selectedOption.dataset[`height${i}`] : '-'}cm, ${selectedOption.dataset[`weight${i}`] ? selectedOption.dataset[`weight${i}`] : '-'}kg</label>`;
				numericValuesTemplatesBox.insertAdjacentElement('beforeend', numericValuesTemplate);
				numericValuesTemplate.firstChild.addEventListener('change', numericValuesTemplateChecked);
				i++;
			}

			if (selectedIndex < (options.length - 1)) shipmentMethodRemove.classList.remove('disabled');
			shipmentMethodNumericValues.classList.remove('hidden');
		} else if (type === 'predefined') {
			if (e.isTrusted) {
				shipmentMethodNameText.classList.remove('is-invalid');
				shipmentMethodNameText.value = selectedOption.text;
			} else {
				shipmentMethodNameText.value = '';
			}
			
			const predefinedValuesBox = document.getElementById('predefinedValuesBox');
			predefinedValuesBox.querySelectorAll('*').forEach(node => node.remove() );
			let i = 1;

			while (selectedOption.dataset[`size${i}`] !== undefined) {
				if (i > 9) break;
				const predefinedSize = document.createElement('div');
				predefinedSize.className = 'form-check form-check-inline';
				predefinedSize.innerHTML = `<input class="form-check-input" type="radio" name="shipmentMethodPredefinedSize" id="shipmentMethodPredefinedSize${i}" value="${i}"${i == selectedOption.dataset.default ? ' checked' : ''}><label class="form-check-label" for="shipmentMethodPredefinedSize${i}">${selectedOption.dataset[`size${i}`]}</label>`;
				predefinedValuesBox.insertAdjacentElement('beforeend', predefinedSize);
				predefinedSize.firstChild.addEventListener('change', (e) => {
					saveButtonSetState();
				});
				i++;
			}

			shipmentMethodPredefinedValues.classList.remove('hidden');
		} else {
			shipmentMethodNameText.value = '';
			shipmentMethodNameInvalidFeedback.innerText = 'Podaj nazwę metody dostawy';
			shipmentMethodNameText.classList.remove('is-invalid');		
			shipmentMethodSelectType.classList.remove('hidden');
		}
	});

	const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
	shipmentMethodSelectType.querySelectorAll('input[type="radio"]').forEach(element => element.addEventListener('change', (e) => {
		document.getElementById('shipmentMethodSelect').dispatchEvent(new Event('change'));
	}));

	const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
	for (let element of numericValues) {
		element.addEventListener('input', () => {
			const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
			const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
			const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
			const shipmentMethodNameText = document.getElementById('shipmentMethodNameText');		
			if (!shipmentMethodNameText.classList.contains('is-invalid') && shipmentMethodNameText.checkValidity() && [...numericValues].every(element => element.checkValidity())) {
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}
			else {
				shipmentMethodSaveButton.disabled = true;
				//shipmentMethodDropdown.disabled = true;
			}
		});
	};

	shipmentMethodNameText.addEventListener('change', (e) => {
		e.target.classList.remove('is-invalid');
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const options = shipmentMethodSelect.options;
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		const shipmentMethodSelectText = options[shipmentMethodSelect.selectedIndex].text;
		for (let option of options) {
			if (option.text === e.target.value) {
				if ((shipmentMethodSelect.selectedIndex === (options.length - 1)) || (shipmentMethodSelectText !== e.target.value)) {
					document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podana nazwa już istnieje';
					e.target.classList.add('is-invalid');
					shipmentMethodSaveButton.disabled = true;
					//shipmentMethodDropdown.disabled = true;
					return;
				}
			}
		}
		
		//document.getElementById('shipmentMethodNameInvalidFeedback').innerText = '';	
		saveButtonSetState();
	});

	shipmentMethodNameText.addEventListener('keyup', (e) => {
		e.target.classList.remove('is-invalid');
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const options = shipmentMethodSelect.options;
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
		const shipmentMethodSelectText = options[shipmentMethodSelect.selectedIndex].text;
		
		for (let option of options) {
			if (option.text === e.target.value) {
				if ((shipmentMethodSelect.selectedIndex === (options.length - 1)) || (shipmentMethodSelectText !== e.target.value)) {
					document.getElementById('shipmentMethodNameInvalidFeedback').innerText = 'Podana nazwa już istnieje';
					e.target.classList.add('is-invalid');
					shipmentMethodSaveButton.disabled = true;
					//shipmentMethodDropdown.disabled = true;
					return;
				}
			}
		}
		
		//document.getElementById('shipmentMethodNameInvalidFeedback').innerText = '';
		saveButtonSetState();
	});

	const shipmentMethodAddPredefinedValue = document.getElementById('shipmentMethodAddPredefinedValue');
	shipmentMethodAddPredefinedValue.addEventListener('click', () => {
		const predefinedValuesBox = document.getElementById('predefinedValuesBox');
		if (Array.from(predefinedValuesBox.querySelectorAll('input[type="radio"]')).find(predefinedSize => predefinedSize.nextElementSibling.innerText === 'Kliknij tutaj aby wkleić ze schowka skopiowany tekst')) {
			toastMessage('Uzupełnij poprzednio dodaną opcję zanim dodasz kolejną.');
			return;
		}
		const predefinedValuesRadioButtons = predefinedValuesBox.querySelectorAll('input[type="radio"]');
		if (predefinedValuesRadioButtons.length >= 9) {
			toastMessage('Dla wybranej metody dostawy osiągnięto maksymalną liczbę szablonów.');
			return;
		}
		const i = predefinedValuesRadioButtons.length + 1;
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		shipmentMethodSelectType.classList.add('hidden');
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;

		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		shipmentMethodSelect.disabled = true;

		const predefinedSize = document.createElement('div');
		predefinedSize.className = 'form-check form-check-inline';
		predefinedSize.innerHTML = `<input class="form-check-input" type="radio" name="shipmentMethodPredefinedSize" id="shipmentMethodPredefinedSize${i}" value="${i}"><label class="form-check-label" for="shipmentMethodPredefinedSize${i}">Kliknij tutaj aby wkleić ze schowka skopiowany tekst</label>`;
		predefinedValuesBox.insertAdjacentElement('beforeend', predefinedSize);		
		
		const predefinedSizeLabel = predefinedSize.querySelector('label');
		predefinedSizeLabel.addEventListener('click', predefinedSizeLabelClick);
		const predefinedSizeRadioButton = predefinedSize.firstChild;
		predefinedSizeRadioButton.checked = true;
		predefinedSizeRadioButton.addEventListener('change', saveButtonSetState);
	});

	const shipmentMethodRemovePredefinedValue = document.getElementById('shipmentMethodRemovePredefinedValue');

	shipmentMethodRemovePredefinedValue.addEventListener('click', async (e) => {
		const predefinedValuesBox = document.getElementById('predefinedValuesBox');
		const predefinedValuesRadioButtons = predefinedValuesBox.querySelectorAll('input[type="radio"]');
		if (predefinedValuesRadioButtons.length < 2) {
			toastMessage('Musi pozostać co najmniej jeden szablon.');
			return;
		}

		let selectedPredefinedValue = document.querySelector('input[name="shipmentMethodPredefinedSize"]:checked');
		if (selectedPredefinedValue === null) {
			toastMessage('Zaznacz opcję do usunięcia');
			return;
		}
		e.target.disabled = true;
		const shipmentMethodSelectType = document.getElementById('shipmentMethodSelectType');
		shipmentMethodSelectType.classList.add('hidden');
	
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		shipmentMethodSelect.disabled = true;
		const indexToRemove = parseInt(selectedPredefinedValue.id.charAt(selectedPredefinedValue.id.length - 1));
		selectedPredefinedValue.parentElement.remove();	
		const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
		shipmentMethodSaveButton.disabled = true;

		for (let i = indexToRemove + 1; i <= 9; i++) {
			const currentOption = document.getElementById(`shipmentMethodPredefinedSize${i}`);
			if (currentOption !== null) {
				currentOption.id = `shipmentMethodPredefinedSize${i-1}`;
				currentOption.value = i-1;
				currentOption.nextElementSibling.setAttribute('for', `shipmentMethodPredefinedSize${i-1}`);
			} else break;
		}

		predefinedValuesBox.querySelector('input[type="radio"]').click();
		
		e.target.disabled = false;
	});

	document.getElementById('shipmentMethodSaveButton').addEventListener('click', async (e) => {
		e.target.disabled = true;
		let readedValue;
		const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
		const shipmentMethodName = document.getElementById('shipmentMethodNameText').value;

		try {
			readedValue = await readDataFromLocalStorage(['shippingMethods']);
		}	catch (error) {
			toastMessage(`Błąd! Nie udało się wczytać opcji dostawy. ${error?.message ? error.message : error}`);
			shipmentMethodSelect.disabled = false;
			return;
		}

		const shipmentMethodNumericValues = document.getElementById('shipmentMethodNumericValues');
		const shipmentMethodPredefinedValues = document.getElementById('shipmentMethodPredefinedValues'); 
		let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
		const existingValue = (shipmentMethodSelect.selectedIndex !== shipmentMethodSelect.options.length - 1);
		const unmodified = (shipmentMethodName === selectedOption.dataset?.defaultName);

		if (!shipmentMethodNumericValues.classList.contains('hidden')) {
			const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');

			function hasDuplicates(arr) {
				return new Set(arr).size !== arr.length;
			}

			const numericValuesTemplates = numericValuesTemplatesBox.querySelectorAll('input[type="radio"]');
			const templateNames = [];
			numericValuesTemplates.forEach(template => templateNames.push(template.nextElementSibling.innerText));
			if (hasDuplicates(templateNames)) {
				e.target.disabled = false;
				toastMessage('Błąd! Nie zapisano - usuń duplikaty szablonów.');
				return;
			}

			let i = 1;
			let optionObject = {
				name: shipmentMethodName
			}

			let defaultTemplate = 1;

			numericValuesTemplates.forEach(input => {
				if (input.checked) {
					optionObject.default = input.value;
					defaultTemplate = i;
				}
				optionObject[`weight${i}`] = input.dataset.weight;
				optionObject[`length${i}`] = input.dataset.length;
				optionObject[`width${i}`] = input.dataset.width;
				optionObject[`height${i}`] = input.dataset.height;
				i++;
			});

			if (existingValue && unmodified) {
				if (selectedOption.dataset.maxWeight) {
					optionObject['minWidth'] = selectedOption.dataset.minWidth;
					optionObject['minLength'] = selectedOption.dataset.minLength;
					optionObject['minHeight'] = selectedOption.dataset.minHeight;
					optionObject['maxWeight'] = selectedOption.dataset.maxWeight;
					optionObject['maxWidth'] = selectedOption.dataset.maxWidth;
					optionObject['maxLength'] = selectedOption.dataset.maxLength;
					optionObject['maxHeight'] = selectedOption.dataset.maxHeight;
					optionObject['defaultName'] = selectedOption.dataset.defaultName
				}
			}

			if (!existingValue) {
				readedValue.shippingMethods.push(optionObject);
			} else {
				for (let [index, value] of readedValue.shippingMethods.entries()) {
					if (value.name === selectedOption.text) {
						readedValue.shippingMethods[index] = optionObject;
						break;
					}
				}
			}

			try {
				await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });
			} catch (error) {
				shipmentMethodSelect.disabled = false;
				toastMessage(`Błąd! Nie udało się zapisać zmian w opcjach dostawy. ${error?.message ? error.message : error}`);
				return;
			}
			toastMessage('Zapisano opcję dostawy.');

			selectedOption.text = shipmentMethodName;
			selectedOption.dataset.name = shipmentMethodName;
			selectedOption.dataset.default = defaultTemplate.toString();

			i = 1;
			numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').forEach(input => {
				selectedOption.dataset[`weight${i}`] = input.dataset.weight;
				selectedOption.dataset[`length${i}`] = input.dataset.length;
				selectedOption.dataset[`width${i}`] = input.dataset.width;
				selectedOption.dataset[`height${i}`] = input.dataset.height;
				i++;
			});

			if (existingValue && selectedOption.dataset.maxWeight && !unmodified) {
				delete selectedOption.dataset.minWidth;
				delete selectedOption.dataset.minLength;
			 	delete selectedOption.dataset.minHeight;
				delete selectedOption.dataset.maxWeight;
				delete selectedOption.dataset.maxWidth;
				delete selectedOption.dataset.maxLength;
				delete selectedOption.dataset.maxHeight;
				delete selectedOption.dataset.defaultName;
			}

			const weightText = document.getElementById('weightText');
			const lengthText = document.getElementById('lengthText');
			const widthText = document.getElementById('widthText');
			const heightText = document.getElementById('heightText');
			const weightInvalidFeedback = document.getElementById('weightInvalidFeedback');
			const lengthInvalidFeedback = document.getElementById('lengthInvalidFeedback');
			const widthInvalidFeedback = document.getElementById('widthInvalidFeedback');
			const heightInvalidFeedback = document.getElementById('heightInvalidFeedback');

			weightText.max = (optionObject?.maxWeight ?? '999');
			lengthText.min = (optionObject?.minLength ?? '1');
			lengthText.max = (optionObject?.maxLength ?? '999'); 
			widthText.min = (optionObject?.minWidth ?? '1');
			widthText.max = (optionObject?.maxWidth ?? '999');
			heightText.min = (optionObject?.minHeight ?? '1');
			heightText.max = (optionObject?.maxHeight ?? '999');
			
			weightInvalidFeedback.innerText = `0,1-${(unmodified ? optionObject.maxWeight : '999')}kg`;
			lengthInvalidFeedback.innerText = `${(unmodified ? optionObject.minLength + '-' + optionObject.maxLength : '1-999')}cm`;
			widthInvalidFeedback.innerText = `${(unmodified ? optionObject.minWidth + '-' + optionObject.maxWidth : '1-999')}cm`;
			heightInvalidFeedback.innerText = `${(unmodified ? optionObject.minHeight + '-' + optionObject.maxHeight : '1-999')}cm`;

			if (!existingValue) {
				const addNewOption = document.createElement('option');
				addNewOption.textContent = 'Dodaj nową';
				shipmentMethodSelect.appendChild(addNewOption);
			}

			numericValuesTemplatesBox.querySelectorAll('div[class~="red"]').forEach(template => template.classList.remove('red'));
		} else if (!shipmentMethodPredefinedValues.classList.contains('hidden')) {
			let optionObject = {
				name: shipmentMethodName
			}
			let i = 1;
			let element;
			do {
				element = document.getElementById(`shipmentMethodPredefinedSize${i}`);
				if (element === null) break;
				optionObject[`size${i}`] = element.nextElementSibling.innerText;
				if (element.checked) optionObject.default = i.toString();
				i++;
			} while (element !== null);

			if (!existingValue) {
				readedValue.shippingMethods.push(optionObject);
			} else {
				for (let [index, value] of readedValue.shippingMethods.entries()) {
					if (value.name === selectedOption.text) {
						readedValue.shippingMethods[index] = optionObject;
						break;
					}
				}
			}
			try {
				await saveDataToLocalStorage({ shippingMethods: readedValue.shippingMethods });	
			} catch (error) {
				shipmentMethodSelect.disabled = false;
				toastMessage(`Błąd! Nie udało się zapisać zmian w opcjach dostawy. ${error?.message ? error.message : error}`);
				return;
			}
			toastMessage('Zapisano opcje dostawy.');
			selectedOption.text = shipmentMethodName;
			selectedOption.dataset.name = shipmentMethodName;

			i = 1;
			while (selectedOption.dataset[`size${i}`] !== undefined) {
				delete selectedOption.dataset[`size${i}`];
				i++;
			}
			i = 1;
			while (optionObject[`size${i}`] !== undefined) {
				selectedOption.dataset[`size${i}`] = optionObject[`size${i}`];
				i++;
			}
			selectedOption.dataset.default = optionObject.default;
			if (!existingValue) {
				const addNewOption = document.createElement('option');
				addNewOption.textContent = 'Dodaj nową';
				shipmentMethodSelect.appendChild(addNewOption);
			}
		}

		shipmentMethodSelect.disabled = false;
	});


	document.getElementById('shipmentMethodRemove').addEventListener('click', shipmentMethodRemoveClick);
	document.getElementById('shipmentMethodAddTemplate').addEventListener('click', shipmentMethodAddTemplateClick);
	document.getElementById('shipmentMethodRemoveTemplate').addEventListener('click', shipmentMethodRemoveTemplateClick);

	document.getElementById('weightText').addEventListener('change', numericValuesChange);
	document.getElementById('lengthText').addEventListener('change', numericValuesChange);
	document.getElementById('widthText').addEventListener('change', numericValuesChange);
	document.getElementById('heightText').addEventListener('change', numericValuesChange);
}

function numericValuesTemplateChecked(e) {
	const weightText = document.getElementById('weightText');
	const lengthText = document.getElementById('lengthText');
	const widthText = document.getElementById('widthText');
	const heightText = document.getElementById('heightText');

	weightText.value = e.target.dataset.weight;
	lengthText.value = e.target.dataset.length;
	widthText.value = e.target.dataset.width;
	heightText.value = e.target.dataset.height;

	saveButtonSetState();
}


async function predefinedSizeLabelClick(e) {
	let paste;
	try {
		paste = await navigator.clipboard.readText();
	} catch (error) {
		toastMessage('Błąd! Nie udało się odczytać tekstu ze schowka.');
		return;
	}	

	if (!paste) {
		toastMessage('Nie znaleziono tekstu w schowku.');
		return;
	}

	if (paste.length > 40) {
		toastMessage('Tekst znaleziony w schowku jest znacznie dłuższy niż oczekiwano. Upewnij się że skopiowałeś właściwy tekst.');
		return;
	}
	paste = paste.replace('\r\n', ' ');

	const labelInput = e.target.previousElementSibling;
	//const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	//let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
	const i = (labelInput.id.charAt(labelInput.id.length - 1));

	const options = document.getElementsByName('shipmentMethodPredefinedSize');
	let duplicateFound;
	for (const option of options) {
		duplicateFound = false;
		if (option.nextElementSibling !== e.target) {
			if (option.nextElementSibling.innerText === paste) {
				toastMessage(`Podana wartość ${paste} już istnieje.`);
				duplicateFound = true;
				break;
			}
		}
	}
	if (!duplicateFound) {
		//selectedOption.dataset[`size${i}`] = paste;
		e.target.innerText = paste;
		saveButtonSetState();
		e.target.removeEventListener('click', predefinedSizeLabelClick);
	}
}

function saveButtonSetState() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	const predefinedValuesBox = document.getElementById('predefinedValuesBox');
	const shipmentMethodNameText = document.getElementById('shipmentMethodNameText');
	const shipmentMethodSaveButton = document.getElementById('shipmentMethodSaveButton');
	const shipmentMethodDropdown = document.getElementById('shipmentMethodDropdown');
	if (!(shipmentMethodNameText.classList.contains('is-invalid') || shipmentMethodNameText.validity.valueMissing)) {
		if (!(document.getElementById('shipmentMethodPredefinedValues').classList.contains('hidden'))) {
			if ((Array.from(predefinedValuesBox.querySelectorAll('label')).filter(element => element.innerText === '' || element.innerText === 'Kliknij tutaj aby wkleić ze schowka skopiowany tekst').length === 0) && (predefinedValuesBox.querySelector('input[type="radio"]:checked'))) { 
				shipmentMethodSelect.disabled = true;
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}	else if (predefinedValuesBox.querySelector('input[type="radio"]') === null) {
				shipmentMethodDropdown.disabled = false;
			}
		} else {
			const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
			if ([...numericValues].every(element => element.checkValidity())) {
				shipmentMethodSelect.disabled = true;
				shipmentMethodSaveButton.disabled = false;
				shipmentMethodDropdown.disabled = false;
			}	else {
				shipmentMethodSaveButton.disabled = true;
				//shipmentMethodDropdown.disabled = true;
			}
		}	
	} else {
		shipmentMethodSaveButton.disabled = true;
		//shipmentMethodDropdown.disabled = true;
	}
}

async function shipmentMethodRemoveClick() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	if (!window.confirm(`Usunąć metodę dostawy ${shipmentMethodSelect.value}?`)) return;
	shipmentMethodSelect.disabled = true;
	document.getElementById('shipmentMethodRemove').disabled = true;
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['shippingMethods']);
	} catch (error) {
		toastMessage(`Błąd! Nie udało się wczytać opcji dostawy. ${error?.message ? error.message : error}`);
		shipmentMethodSelect.disabled = false;
		return;
	}
	
	const options = shipmentMethodSelect.options;
	const selectedIndex = shipmentMethodSelect.selectedIndex;
	if (selectedIndex > 0 && selectedIndex < (options.length - 1)) {
		let modifiedShippingMethods = [];
		const selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];
		readedValue.shippingMethods.forEach(shippingMethod => {
			if (shippingMethod.name !== selectedOption.text) modifiedShippingMethods.push(shippingMethod);
		});

		try {
			await saveDataToLocalStorage({ shippingMethods: modifiedShippingMethods });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się usunąć opcji dostawy. ${error?.message ? error.message : error}`);
			shipmentMethodSelect.disabled = false;
			return;
		}	
		shipmentMethodSelect.selectedIndex = 0;
		shipmentMethodSelect.remove(selectedIndex);
		shipmentMethodNumericValues.classList.add('hidden');
		shipmentMethodPredefinedValues.classList.add('hidden');
		toastMessage('Usunięto opcję dostawy.');
	}
	shipmentMethodSelect.disabled = false;
	shipmentMethodSelect.dispatchEvent(new Event('change'));
}

async function shipmentMethodAddTemplateClick() {
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const numericValuesTemplatesCount =  numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').length;
	if (numericValuesTemplatesCount >= 9) {
		toastMessage('Błąd! Dla wybranej metody dostawy osiągnięto maksymalną liczbę szablonów.');
		return;
	}
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.disabled = true;

	document.getElementById('shipmentMethodAddTemplate').disabled = true;
	//let selectedOption = shipmentMethodSelect.options[shipmentMethodSelect.selectedIndex];

	let i = numericValuesTemplatesCount + 1;

	let inputsValidity = false;
	const numericValues = document.getElementById('shipmentMethodNumericValues').querySelectorAll('input[type="number"]');
	if ([...numericValues].every(element => element.checkValidity())) inputsValidity = true;

	if (!inputsValidity && i > 1) {
		toastMessage('Błąd! Wprowadzone wartości dla danej formy dostawy są spoza dopuszczalnego zakresu.');
		shipmentMethodSelect.disabled = false;
		return;
	}

	const weight = document.getElementById('weightText').value;
	const length = document.getElementById('lengthText').value;
	const width = document.getElementById('widthText').value;
	const height = document.getElementById('heightText').value;

	const numericValuesTemplate = document.createElement('div');
	numericValuesTemplate.className = 'form-check form-check-inline red';
	numericValuesTemplate.innerHTML = `<input class="form-check-input" data-weight="${weight}" data-length="${length}" data-width="${width}" data-height="${height}" type="radio" name="numericValuesTemplate" id="numericValuesTemplate${i}" value="${i}" checked><label class="form-check-label" for="numericValuesTemplate${i}">${length}x${width}x${height}cm, ${weight}kg</label>`;
	numericValuesTemplatesBox.insertAdjacentElement('beforeend', numericValuesTemplate);
	numericValuesTemplate.firstChild.addEventListener('change', numericValuesTemplateChecked);

	saveButtonSetState();
}

async function shipmentMethodRemoveTemplateClick() {
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const numericValuesTemplatesCount = numericValuesTemplatesBox.querySelectorAll('input[type="radio"]').length;
	if (numericValuesTemplatesCount < 2) {
		toastMessage('Błąd! Musi pozostać co najmniej jeden szablon.');
		return;
	}
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	const options = shipmentMethodSelect.options;
	const selectedIndex = shipmentMethodSelect.selectedIndex;
	const selectedOption = options[selectedIndex];
	const selectedTemplate = numericValuesTemplatesBox.querySelector('input[type="radio"]:checked');
	const selectedTemplateIndex = Number(selectedTemplate.value);
	if (!window.confirm(`Usunąć szablon ${selectedTemplate.nextElementSibling.innerText} z metody dostawy ${shipmentMethodSelect.value}?`)) return;
	shipmentMethodSelect.disabled = true;
	document.getElementById('shipmentMethodRemoveTemplate').disabled = true;
	selectedTemplate.parentNode.remove();
	let i;
	let nextTemplate;
	for (i = selectedTemplateIndex; i < numericValuesTemplatesCount; i++) {
		nextTemplate = document.getElementById(`numericValuesTemplate${i+1}`);
		selectedOption.dataset[`weight${selectedTemplateIndex}`] = selectedOption.dataset[`weight${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`length${selectedTemplateIndex}`] = selectedOption.dataset[`length${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`width${selectedTemplateIndex}`] = selectedOption.dataset[`width${selectedTemplateIndex + 1}`];
		selectedOption.dataset[`height${selectedTemplateIndex}`] = selectedOption.dataset[`height${selectedTemplateIndex + 1}`];
		nextTemplate.nextElementSibling.htmlFor = `numericValuesTemplate${i}`;
		nextTemplate.value = i;
		nextTemplate.id = `numericValuesTemplate${i}`;
	}
	delete selectedOption.dataset[`weight${i}`];
	delete selectedOption.dataset[`length${i}`];
	delete selectedOption.dataset[`width${i}`];
	delete selectedOption.dataset[`height${i}`];
	
	document.getElementById('numericValuesTemplate1').click();
}

function numericValuesChange() {
	const shipmentMethodSelect = document.getElementById('shipmentMethodSelect');
	shipmentMethodSelect.disabled = true;
	const numericValuesTemplatesBox = document.getElementById('numericValuesTemplatesBox');
	const selectedTemplate = numericValuesTemplatesBox.querySelector('input[type="radio"]:checked');
	const weight = document.getElementById('weightText').value;
	const length = document.getElementById('lengthText').value;
	const width = document.getElementById('widthText').value;
	const height = document.getElementById('heightText').value;
	selectedTemplate.nextElementSibling.innerText = `${length !== '' ? length : '-'}x${width !== '' ? width : '-'}x${height !== '' ? height : '-'}cm, ${weight !== '' ? weight : '-'}kg`;
	selectedTemplate.dataset.weight = weight;
	selectedTemplate.dataset.length = length;
	selectedTemplate.dataset.width = width;
	selectedTemplate.dataset.height = height;
	selectedTemplate.parentElement.classList.add('red');
}


async function inPostSendMode() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
		
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'inPostSendMode')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'inPostSendMode',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['inpost_send_mode.css', 'toast.css'],
					js: ['inpost_send_mode.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'inPostSendMode',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['inpost_send_mode.css', 'toast.css'],
					js: ['inpost_send_mode.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}
	
	try {
		readedValue = await readDataFromLocalStorage(['inPostSendMode']);
		if (!(readedValue.inPostSendMode >= 1 && readedValue.inPostSendMode <= 3)) throw new Error('Opcja ma nieprawidłową wartość.');
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu domyślnego sposobu nadawania przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	document.getElementById(`inPostSendMode${readedValue.inPostSendMode}`).checked = true;
	
	document.getElementById('saveInPostSendModeButtonBox').addEventListener('click', () => {
		const defaultInPostSendMode = parseInt(document.getElementById('inPostSendModeInputs').querySelector('input:checked')?.value);
		if (defaultInPostSendMode) {
			chrome.storage.local.set({ inPostSendMode: defaultInPostSendMode }).then(() => {
				toastMessage('Zapisano domyślną formę dostawy przesyłek InPost');
			}).catch(error => {
				toastMessage(`Błąd! Podczas zapisu domyślnej formy dostawy przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
			});
		}
	});
}

async function changeAuctionsTitle() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'],
			permissions: ['tabs']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (!contentScripts.length || !contentScripts.some(registeredScript => registeredScript.id === 'changeAuctionsTitle')) {
		await chrome.scripting.registerContentScripts([{
			id: 'changeAuctionsTitle',
			matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
			css: ['change_auctions_title.css', 'toast.css'],
			js: ['change_auctions_title.js', 'toast.js']
		}]);
	} else {
		await chrome.scripting.updateContentScripts([{
			id: 'changeAuctionsTitle',
			matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
			css: ['change_auctions_title.css', 'toast.css'],
			js: ['change_auctions_title.js', 'toast.js']
		}]);
	}
}

async function validateBuyerAddressErrors() {
	let permissionGranted;
	let contentScripts;
	let readedValue;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj wymagane uprawnienia i dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'validateBuyerAddressErrors')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'validateBuyerAddressErrors',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['validate_buyer_address_errors.css', 'toast.css'],
					js: ['validate_buyer_address_errors.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'validateBuyerAddressErrors',
					matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
					css: ['validate_buyer_address_errors.css', 'toast.css'],
					js: ['validate_buyer_address_errors.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}

	try {
		readedValue = await readDataFromLocalStorage(['buyerAddressErrorsFeedback']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień opcjonalnego wysyłania błędnych wzorców danych adresowych wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	const validateBuyerAddressErrorsSendSamplesCheckbox = document.getElementById('validateBuyerAddressErrorsSendSamplesCheckbox');
	validateBuyerAddressErrorsSendSamplesCheckbox.checked = readedValue.buyerAddressErrorsFeedback;
	validateBuyerAddressErrorsSendSamplesCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ buyerAddressErrorsFeedback: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień opcjonalnego wysyłania błędnych wzorców danych adresowych. ${error?.message ? error.message : error}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});
}

async function fastStockManager() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
			
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();	
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}	

	if (contentScripts.length) {	
		if (!contentScripts.some(registeredScript => registeredScript.id === 'fastStockManager')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'fastStockManager',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['fast_stock_manager.css', 'toast.css'],
					js: ['fast_stock_manager.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'fastStockManager',
					matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
					css: ['fast_stock_manager.css', 'toast.css'],
					js: ['fast_stock_manager.js', 'toast.js']
				}]);	
			} catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}
	
}

async function restoreCancelled() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();	
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	if (contentScripts.length) {
		if (!contentScripts.some(registeredScript => registeredScript.id === 'restoreCancelled')) {
			try {
				await chrome.scripting.registerContentScripts([{
					id: 'restoreCancelled',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['restore_cancelled.css', 'toast.css'],
					js: ['restore_cancelled.js', 'toast.js']
				}]);
			} catch (error) {
				toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		} else {
			try {
				await chrome.scripting.updateContentScripts([{
					id: 'restoreCancelled',
					matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
					css: ['restore_cancelled.css', 'toast.css'],
					js: ['restore_cancelled.js', 'toast.js']
				}]);
			}	catch (error) {
				toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
				return Promise.reject(false);
			}
		}
	}
}

async function restoreReturned() {
	let permissionGranted;
	let contentScripts;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['iFirmaReturns']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytywania ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	const iFirmaReturnsCheckbox = document.getElementById('iFirmaReturnsCheckbox');
	iFirmaReturnsCheckbox.checked = readedValue.iFirmaReturns;
	iFirmaReturnsCheckbox.addEventListener('change', async (e) => {
		try {
			await saveDataToLocalStorage({ iFirmaReturns: e.target.checked });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zmienić ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl. ${error?.message ? error.message : error}`);
			return Promise.reject(false);
		}
		toastMessage('Zapisano');
	});

	let originsSites = ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*'];
	if (iFirmaReturnsCheckbox.checked && originsSites.indexOf('https://www.ifirma.pl/*') === -1) originsSites.push('https://www.ifirma.pl/*');

	try {
		permissionGranted = await chrome.permissions.contains({
			origins: originsSites
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage(`Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*${ iFirmaReturnsCheckbox.checked ? ', https://www.ifirma.pl/*' : ''}`);
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (iFirmaReturnsCheckbox.checked) {
				if (!contentScripts.some(registeredScript => registeredScript.id === 'iFirmaReturns')) {
					try {
						await chrome.scripting.registerContentScripts([{
							id: 'iFirmaReturns',
							matches: ['https://www.ifirma.pl/*'],
							css: ['ifirma_returns.css', 'toast.css'],
							js: ['ifirma_returns.js', 'toast.js']
						}]);
					} catch (error) {
						toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
						return Promise.reject(false);
					}
				}	else {
					try {
						await chrome.scripting.updateContentScripts([{
							id: 'restoreReturned',
							matches: ['https://www.ifirma.pl/*'],
							css: ['ifirma_returns.css', 'toast.css'],
							js: ['ifirma_returns.js', 'toast.js']
						}]);
					} catch (error) {
						toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
						return Promise.reject(false);
					}
				}
			}
			if (!contentScripts.some(registeredScript => registeredScript.id === 'restoreReturned')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'restoreReturned',
						matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
						css: ['restore_returned.css', 'toast.css'],
						js: ['restore_returned.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}	else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'restoreReturned',
						matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
						css: ['restore_returned.css', 'toast.css'],
						js: ['restore_returned.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		}
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

async function showProductName() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}

	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'showProductName')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'showProductName',
						matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
						css: ['show_product_name.css', 'toast.css'],
						js: ['show_product_name.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'showProductName',
						matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
						css: ['show_product_name.css', 'toast.css'],
						js: ['show_product_name.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		}
	} catch (error) {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

async function showStockLeft() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'showStockLeft')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'showStockLeft',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['show_stock_left.css', 'toast.css'],
						js: ['show_stock_left.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'showStockLeft',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['show_stock_left.css', 'toast.css'],
						js: ['show_stock_left.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

async function shipmentExistsWarning() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'shipmentExistsWarning')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'shipmentExistsWarning',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
						css: ['shipment_exists_warning.css', 'toast.css'],
						js: ['shipment_exists_warning.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'shipmentExistsWarning',
						matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
						css: ['shipment_exists_warning.css', 'toast.css'],
						js: ['shipment_exists_warning.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

async function sendMessageFromOrdersPage() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'sendMessageFromOrdersPage')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'sendMessageFromOrdersPage',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*', 'https://salescenter.allegro.com/message-center/messages/new-message*', 'https://salescenter.allegro.com.allegrosandbox.pl/message-center/messages/new-message*', 'https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*'],
						css: ['toast.css'],
						js: ['send_message_from_orders_page.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'sendMessageFromOrdersPage',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*', 'https://salescenter.allegro.com/message-center/messages/new-message*', 'https://salescenter.allegro.com.allegrosandbox.pl/message-center/messages/new-message*', 'https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*'],
						css: ['toast.css'],
						js: ['send_message_from_orders_page.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

async function additionalOrdersSortingOptions() {
	let permissionGranted;
	let contentScripts;
	try {
		permissionGranted = await chrome.permissions.contains({
			origins: ['https://salescenter.allegro.com/*', 'https://salescenter.allegro.com.allegrosandbox.pl/*']
		});
		if (permissionGranted === false) throw new Error(NO_PERMISSION_GRANTED);
	} catch (error) {
		if (error.message === NO_PERMISSION_GRANTED) toastMessage('Błąd! Aby rozszerzenie działało przyznaj dostęp do stron https://salescenter.allegro.com/*, https://salescenter.allegro.com.allegrosandbox.pl/*');
		else toastMessage(`Błąd! Podczas sprawdzania uprawnień dostępu wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
	
	try {
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
		if (contentScripts.length) {
			if (!contentScripts.some(registeredScript => registeredScript.id === 'additionalOrdersSortingOptions')) {
				try {
					await chrome.scripting.registerContentScripts([{
						id: 'additionalOrdersSortingOptions',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['toast.css'],
						js: ['additional_orders_sorting_options.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby rejestracji skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			} else {
				try {
					await chrome.scripting.updateContentScripts([{
						id: 'additionalOrdersSortingOptions',
						matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
						css: ['toast.css'],
						js: ['additional_orders_sorting_options.js', 'toast.js']
					}]);
				} catch (error) {
					toastMessage(`Błąd! Podczas próby przeładowania skryptu wystąpił błąd. ${error?.message ? error.message : error}`);
					return Promise.reject(false);
				}
			}
		} 
	} catch (error)  {
		toastMessage(`Błąd! Podczas próby pobrania listy załadowanych skryptów wystąpił błąd. ${error?.message ? error.message : error}`);
		return Promise.reject(false);
	}
}

function colorCodeCopyButtonClick() {
	let colorPickerValue = document.getElementById('colorPickerValue');
	colorPickerValue.select();
	navigator.clipboard.writeText(colorPickerValue.value);
}

function colorFilterTextInput(event) {
	debug('input event');
	let saveFilterButton = document.getElementById('saveFilterButton');
	saveFilterButton.disabled = (event.target.checkValidity() ? false : true);
}

function saveFilterButtonClick() {
	chrome.runtime.sendMessage({ action: 'saveColor', color: document.getElementById('colorPickerValue').value, filter: document.getElementById('colorFilterText').value }).then(() => {
		this.disabled = true;
		toastMessage('Zapisano');
	}).catch(error => {
		if (error.name === 'customError') {
			toastMessage(error.message);
		} else {
			toastMessage(`Błąd! Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd, szczegóły (oryginalna treść błędu): ${error?.message ? error.message : error}`);
		}
	});
}

function allegroAPI() {
	let redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');
	document.getElementById('chromeExtensionRedirectURL').innerText = redirectUrl;

	chrome.storage.local.get(['allegroAPIClientId', 'allegroAPIClientSecret', 'allegroAPIClientIdSandbox', 'allegroAPIClientSecretSandbox', 'allegroAPIOAuthConnectorSandbox']).then(result => {
		if (result.allegroAPIClientId !== undefined && result.allegroAPIClientSecret !== undefined) {
			const allegroAPIClientIdText = document.getElementById('allegroAPIClientIdText');
			allegroAPIClientIdText.value = result.allegroAPIClientId;
			allegroAPIClientIdText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientSecretText').checkValidity();
					document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButton').disabled = true;
				}
			});
			allegroAPIClientIdText.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			});

			const allegroAPIClientSecretText = document.getElementById('allegroAPIClientSecretText');
			allegroAPIClientSecretText.value = result.allegroAPIClientSecret;
			allegroAPIClientSecretText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity();
					document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButton').disabled = true;
				}
			});
			allegroAPIClientSecretText.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			});
		}
		const allegroAPISaveButton = document.getElementById('allegroAPISaveButton');
		allegroAPISaveButton.addEventListener('click', allegroAPISaveButtonClick.bind(null, false));
		const allegroAPILoginButton = document.getElementById('allegroAPILoginButton');
		allegroAPILoginButton.addEventListener('click', allegroAPILoginButtonClick.bind(null, false));
		if (allegroAPIClientIdText.checkValidity() && allegroAPIClientIdText.value !== '' && allegroAPIClientSecretText.checkValidity && allegroAPIClientSecretText.value !== '') {
			document.getElementById('allegroAPILoginButton').disabled = false;
		}


		if (result.allegroAPIClientIdSandbox !== undefined && result.allegroAPIClientSecretSandbox !== undefined && result.allegroAPIOAuthConnectorSandbox !== undefined) {
			const allegroAPIClientIdTextSandbox = document.getElementById('allegroAPIClientIdTextSandbox');
			allegroAPIClientIdTextSandbox.value = result.allegroAPIClientIdSandbox;
			allegroAPIClientIdTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
					document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
				}
			});
			allegroAPIClientIdTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			});

			const allegroAPIClientSecretTextSandbox = document.getElementById('allegroAPIClientSecretTextSandbox');
			allegroAPIClientSecretTextSandbox.value = result.allegroAPIClientSecretSandbox;
			allegroAPIClientSecretTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity();
					document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
				}
			});
			allegroAPIClientSecretTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			});

			const allegroAPIOAuthConnectorTextSandbox = document.getElementById('allegroAPIOAuthConnectorTextSandbox');
			allegroAPIOAuthConnectorTextSandbox.value = result.allegroAPIOAuthConnectorSandbox;
			allegroAPIOAuthConnectorTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				const patternOAuthConnector = /^$|^https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z-_]{1,}\/exec$/g;
				if (patternOAuthConnector.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
					document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
					document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
				}
			});
			allegroAPIOAuthConnectorTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			});
		}
		const allegroAPISaveButtonSandbox = document.getElementById('allegroAPISaveButtonSandbox');
		allegroAPISaveButtonSandbox.addEventListener('click', allegroAPISaveButtonClick.bind(null, true));
		const allegroAPILoginButtonSandbox = document.getElementById('allegroAPILoginButtonSandbox');
		allegroAPILoginButtonSandbox.addEventListener('click', allegroAPILoginButtonClick.bind(null, true));
		if (allegroAPIClientIdTextSandbox.checkValidity() && allegroAPIClientIdTextSandbox.value !== '' && allegroAPIClientSecretTextSandbox.checkValidity && allegroAPIClientSecretTextSandbox.value !== '') {
			document.getElementById('allegroAPILoginButtonSandbox').disabled = false;
		}
	});
}

function debug(text) {
	chrome.runtime.sendMessage({ action: 'debug', info: text });
}

function colorPickerChange() {
	let customColorElements = document.getElementsByClassName('customColor');
	for (let element of customColorElements) {
		element.classList.add('hidden');
	}
	document.getElementById('colorPickerValue').value = this.value;
	let colorFilterText = document.getElementById('colorFilterText');
	let colorFilter = colorFilterText.value;
	switch (this.value) {
		case '#000000': {
			colorFilter = 'filter: invert(0%) sepia(4%) saturate(0%) hue-rotate(337deg) brightness(93%) contrast(107%);';
			break;
		}
		case '#404040': {
			colorFilter = 'filter: invert(19%) sepia(8%) saturate(10%) hue-rotate(11deg) brightness(93%) contrast(77%);';
			break;
		}
		case '#808080': {
			colorFilter = 'filter: invert(19%) sepia(8%) saturate(10%) hue-rotate(11deg) brightness(93%) contrast(77%);';
			break;
		}
		case '#c0c0c0': {
			colorFilter = 'filter: invert(85%) sepia(0%) saturate(1%) hue-rotate(316deg) brightness(90%) contrast(95%);';
			break;
		}
		case '#980000': {
			colorFilter = 'filter: invert(9%) sepia(65%) saturate(7334%) hue-rotate(11deg) brightness(94%) contrast(117%);';
			break;
		}
		case '#ff0000': {
			colorFilter = 'filter: invert(29%) sepia(80%) saturate(6896%) hue-rotate(353deg) brightness(95%) contrast(127%);';
			break;
		}
		case '#ff9900': {
			colorFilter = 'filter: invert(70%) sepia(53%) saturate(4645%) hue-rotate(1deg) brightness(104%) contrast(104%);';
			break;
		}
		case '#ffff00': {
			colorFilter = 'filter: invert(81%) sepia(90%) saturate(1721%) hue-rotate(359deg) brightness(104%) contrast(105%);';
			break;
		}
		case '#00ff00': {
			colorFilter = 'filter: invert(51%) sepia(71%) saturate(2969%) hue-rotate(89deg) brightness(122%) contrast(123%);';
			break;
		}
		case '#00c202': {
			colorFilter = 'filter: invert(40%) sepia(99%) saturate(1016%) hue-rotate(88deg) brightness(103%) contrast(106%);';
			break;
		}
		case '#00ffff': {
			colorFilter = 'filter: invert(100%) sepia(38%) saturate(7498%) hue-rotate(101deg) brightness(105%) contrast(104%);';
			break;
		}
		case '#4a86e8': {
			colorFilter = 'filter: invert(50%) sepia(27%) saturate(1651%) hue-rotate(184deg) brightness(96%) contrast(90%);';
			break;
		}
		case '#0000ff': {
			colorFilter = 'filter: invert(11%) sepia(100%) saturate(4411%) hue-rotate(242deg) brightness(98%) contrast(151%);';
			break;
		}
		case '#9900ff': {
			colorFilter = 'filter: invert(22%) sepia(99%) saturate(6798%) hue-rotate(275deg) brightness(96%) contrast(128%);';
			break;
		}
		case '#ff00ff': {
			colorFilter = 'filter: invert(34%) sepia(100%) saturate(6821%) hue-rotate(296deg) brightness(116%) contrast(124%);';
			break;
		}
		default: {
			for (let element of customColorElements) {
				element.classList.remove('hidden');
			}
			break;
		}
	}
	colorFilterText.value = colorFilter;
	document.getElementById('saveFilterButton').disabled = !document.getElementById('colorFilterText').checkValidity();

}
