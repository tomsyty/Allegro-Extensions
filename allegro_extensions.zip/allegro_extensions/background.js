const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const SHORTCUT_SAVING_ERROR = 'Podczas zapisu skrótu aktywującego wystąpił błąd.';
const SHORTCUT_READING_ERROR = 'Podczas odczytu skrótu aktywującego wystąpił błąd.';
const UNABLE_TO_REFRESH_TOKENS = 'Nie udało się odświeżyć tokenów dostępowych.';
const REFRESHED_TOKENS_SAVE_ERROR = 'Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów.';

chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(true);
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(result);
    });
  });
}

async function sendMessage(tab, data) {
	return new Promise((resolve, reject) => {
		chrome.tabs.sendMessage(tab, data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(response);
		});
	});
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

function getWindows() {
	return new Promise((resolve, reject) => {
		chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(response);
		});
	});
}

const DETAILED_ERROR_MESSAGE = `Szczegóły (oryginalna treść błędu):`;

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		console.log('Ustawianie domyślnych wartości...');
		chrome.storage.local.set({
			extensions: { changeInvoicesIconColor: false, autofillPackageSize: false, autoprintLabel: false, changeAuctionsTitle: false, validateBuyerAddressErrors: false, inPostSendMode: false, fastStockManager: false, restoreCancelled: false, restoreReturned: false, showProductName: false, showStockLeft: false, shipmentExistsWarning: false, sendMessageFromOrdersPage: false, additionalOrdersSortingOptions: false, allegroAPI: false },
			allegroAPIClientId: '',
			allegroAPIClientSecret: '',
			allegroAccessToken: '',
			allegroRefreshToken: '',
			allegroAPIClientIdSandbox: '',
			allegroAPIClientSecretSandbox: '',
			allegroAPIOAuthConnectorSandbox: '',
			allegroAccessTokenSandbox: '',
			allegroRefreshTokenSandbox: '',
			color: '#4a86e8',
			filter: 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);',
			inPostSendMode: 1,
			iFirmaReturns: false,
			buyerAddressErrorsFeedback: false,
			defaultPrinter: '',
			sumatraPath: '',
			shortcut: '',
			returnsDoneList: [],
			shippingMethods: [
				{	name: 'Allegro Paczkomaty InPost',										size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost' },
				{	name: 'Allegro Paczkomaty InPost pobranie',						size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost pobranie' },
				{	name: 'Allegro miniKurier24 InPost',									weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost'	},
				{	name: 'Allegro miniKurier24 InPost pobranie',					weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost pobranie' },
				{	name: 'Allegro Kurier24 InPost',											weight1: '', maxWeight: '30',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost' },
				{	name: 'Allegro Kurier24 InPost pobranie',							weight1: '', maxWeight: '30', length1: '', minLength: '1',	maxLength: '80', width1: '', minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost pobranie' },
				{	name: 'Allegro Automat ORLEN Paczka',									size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Automat ORLEN Paczka' },
				{	name: 'Allegro Odbiór w Punkcie ORLEN Paczka',				size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Odbiór w Punkcie ORLEN Paczka' },
				{	name: 'Allegro One Box, DPD',													weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Box, DPD' },
				{	name: 'Allegro One Box, UPS',													size1: 'Gabaryt S 64x38x8cm, 1kg', size2: 'Gabaryt S 64x38x8cm, 5kg', size3: 'Gabaryt S 64x38x8cm, 10kg', size4: "Gabaryt M 64x38x19cm, 1kg", size5: "Gabaryt M 64x38x19cm, 5kg", size6: "Gabaryt M 64x38x19cm, 10kg", size7: "Gabaryt L 64x38x41cm, 1kg", size8: "Gabaryt L 64x38x41cm, 5kg", size9: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro One Box, UPS' },
				{	name: 'Allegro One Punkt, DPD',												weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', 	height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Punkt, DPD' },
				{	name: 'Allegro One Punkt, UPS',												size1: 'Gabaryt S 64x38x8cm, 1kg', size2: 'Gabaryt S 64x38x8cm, 5kg', size3: 'Gabaryt S 64x38x8cm, 10kg', size4: "Gabaryt M 64x38x19cm, 1kg", size5: "Gabaryt M 64x38x19cm, 5kg", size6: "Gabaryt M 64x38x19cm, 10kg", size7: "Gabaryt L 64x38x41cm, 1kg", size8: "Gabaryt L 64x38x41cm, 5kg", size9: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro One Punkt, UPS' },
				{	name: 'Allegro One Kurier',														weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '120', width1: '',	minWidth: '1', 	maxWidth: '76', 	height1: '', 	minHeight: '1', maxHeight: '76', 	default: '1',	defaultName: 'Allegro One Kurier' },
				{	name: 'Allegro Kurier UPS',														weight1: '',	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '100', width1: '',	minWidth: '1', 	maxWidth: '76', 	height1: '',	minHeight: '1', maxHeight: '76', 	default: '1', defaultName: 'Allegro Kurier UPS'	},
				{	name: 'Allegro Kurier UPS pobranie', 									weight1: '',	maxWeight: '31.5', 	length1: '',	minLength: '1',		maxLength: '100',	width1: '', minWidth: '1',	maxWidth: '76',		height1: '',	minHeight: '1',	maxHeight: '76', 	default: '1', defaultName: 'Allegro Kurier UPS pobranie' },
				{	name: 'Allegro Odbiór w Punkcie UPS',									weight1: '',	maxWeight: '20',		length1: '',	minLength: '1',		maxLength: '97',	width1: '', minWidth: '1',	maxWidth: '97',		height1: '',	minHeight: '1',	maxHeight: '97', 	default: '1', defaultName: 'Allegro Odbiór w Punkcie UPS'	},
				{	name: 'Allegro Kurier DPD',														weight1: '',	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1', 	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD' },
				{	name: 'Allegro Kurier DPD pobranie', 									weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1',	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD pobranie' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup', 					weight1: '', 	maxWeight: '20',		length1: '',	minLength: '1',		maxLength: '100',	width1: '', minWidth: '1',	maxWidth: '100', 	height1: '', 	minHeight: '1', maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup pobranie',	weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '1', 	maxLength: '100', width1: '', minWidth: '1', 	maxWidth: '100', 	height1: '',	minHeight: '1',	maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup pobranie' },
				{	name: 'Allegro Automat DHL POP BOX',									weight1: '',	maxWeight: '25', 		length1: '', 	minLength: '1', 	maxLength: '64', 	width1: '', minWidth: '1', 	maxWidth: '38', 	height1: '', 	minHeight: '1', maxHeight: '41', 	default: '1',	defaultName: 'Allegro Kurier DPD' },
				{	name: 'Allegro Kurier Pocztex', 											weight1: '', 	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120', width1: '', minWidth: '10', maxWidth: '120', 	height1: '', 	minHeight: '1', maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex' },
				{	name: 'Allegro Kurier Pocztex pobranie',							weight1: '',	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120',	width1: '',	minWidth: '10',	maxWidth: '120',	height1: '',	minHeight: '1',	maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex pobranie' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex', 						weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70', 	width1: '',	minWidth: '10', maxWidth: '60', 	height1: '', 	minHeight: '1', maxHeight: '60', 	default: '1',	defaultName: 'Allegro Odbiór w Punkcie Pocztex' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex pobranie',		weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70',	width1: '',	minWidth: '10',	maxWidth: '60',		height1: '',	minHeight: '1',	maxHeight: '60', 	default: '1', defaultName: 'Allegro Odbiór w Punkcie Pocztex pobranie' },
				{	name: 'Allegro Automat Pocztex', 											weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '65', 	width1: '', minWidth: '10', maxWidth: '42', 	height1: '', 	minHeight: '1', maxHeight: '40', 	default: '1',	defaultName: 'Allegro Automat Pocztex' }
			]
		}).then(() => {
			chrome.runtime.openOptionsPage(() => {
			});
		}).catch(error => {
			console.log(error.message);
		});
	} else if (details.reason === 'update') {
		
	}
});

(async function loadExtensions(retriesLeft) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}
	if (readedValue.extensions === undefined) {
		console.log('Nie znaleziono listy rozszerzeń, ponawianie próby...');
		if (--retriesLeft) {
			await new Promise(resolve => setTimeout(resolve, 1000));
			return await loadExtensions(retriesLeft);
		}
		else return;
	}
	let contentScripts;
	try { 
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy załadowanych skryptów wystąpił błąd. ${ error?.message ? error.message : error }`);
		return;
	}

	if (contentScripts === undefined) return;

	if (readedValue.extensions.changeInvoicesIconColor === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeInvoicesIconColor' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeInvoicesIconColor',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['change_invoices_icon_color.js', 'toast.js'],
			}]).then(() => {
				console.log('Załadowano skrypt changeInvoicesIconColor');
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeInvoicesIconColor');
			});
		}
	}

	if (readedValue.extensions.autofillPackageSize === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autofillPackageSize' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autofillPackageSize',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['autofill_package_size.css', 'toast.css'],
				js: ['autofill_package_size.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt autofillPackageSize');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autofillPackageSize');
			});
		}
	}

	if (readedValue.extensions.autoprintLabel === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autoprintLabel' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autoprintLabel',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
				css: ['autoprint_label.css', 'toast.css'],
				js: ['autoprint_label.js', 'toast.js']
			}, {
				id: 'autoprintLabelOrders',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['autoprint_label_orders.css'],
				js: ['autoprint_label_orders.js']
			}]).then(() => {
				console.log('Załadowano skrypt autoprintLabel');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autoprintLabel');
			});
		}
	}

	if (readedValue.extensions.inPostSendMode === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'inPostSendMode' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'inPostSendMode',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['inpost_send_mode.css', 'toast.css'],
				js: ['inpost_send_mode.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt inPostSendMode');
			}).catch(() => {
				console.log('Błąd ładowania skryptu inPostSendMode');
			});
		}
	}
	
	if (readedValue.extensions.changeAuctionsTitle === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeAuctionsTitle' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeAuctionsTitle',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['change_auctions_title.css', 'toast.css'],
				js: ['change_auctions_title.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt changeAuctionsTitle');
				getShortcut();
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeAuctionsTitle');
			});
		}
	}

	if (readedValue.extensions.validateBuyerAddressErrors === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'validateBuyerAddressErrors' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'validateBuyerAddressErrors',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['validate_buyer_address_errors.css', 'toast.css'],
				js: ['validate_buyer_address_errors.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt validateBuyerAddressErrors');
			}).catch(() => {
				console.log('Błąd ładowania skryptu validateBuyerAddressErrors');
			});
		}
	}

	if (readedValue.extensions.fastStockManager === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'fastStockManager' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'fastStockManager',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['fast_stock_manager.css', 'toast.css'],
				js: ['fast_stock_manager.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt fastStockManager');
			}).catch(() => {
				console.log('Błąd ładowania skryptu fastStockManager');
			});
		}
	}

	if (readedValue.extensions.restoreCancelled === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreCancelled' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreCancelled',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['restore_cancelled.css', 'toast.css'],
				js: ['restore_cancelled.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreCancelled');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreCancelled');
			});
		}
	}

	if (readedValue.extensions.restoreReturned === true) {
		let localReadedValue;
		try {
			localReadedValue = await readDataFromLocalStorage(['iFirmaReturns']);
		} catch (error) {
			console.log(`Błąd! Podczas odczytywania ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl wystąpił błąd. ${error?.message ? error.message : error}`);
			return;
		}

		if (localReadedValue.iFirmaReturns === true) {
			if (contentScripts.find(registeredScript => { return registeredScript.id === 'iFirmaReturns' }) === undefined) {
				chrome.scripting.registerContentScripts([{
					id: 'iFirmaReturns',
					matches: ['https://www.ifirma.pl/*'],
					css: ['ifirma_returns.css', 'toast.css'],
					js: ['ifirma_returns.js', 'toast.js']
				}]).then(() => {
					console.log('Załadowano skrypt iFirmaReturns');
				}).catch(() => {
					console.log('Błąd ładowania skryptu iFirmaReturns');
				});
			}
		}

		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreReturned' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreReturned',
				matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
				css: ['restore_returned.css', 'toast.css'],
				js: ['restore_returned.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreReturned');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreReturned');
			});
		}
	}

	if (readedValue.extensions.showProductName === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showProductName' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showProductName',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['show_product_name.css', 'toast.css'],
				js: ['show_product_name.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showProductName');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showProductName');
			});
		}
	}

	if (readedValue.extensions.showStockLeft === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showStockLeft' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showStockLeft',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['show_stock_left.css', 'toast.css'],
				js: ['show_stock_left.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showStockLeft');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showStockLeft');
			});
		}
	}

	if (readedValue.extensions.shipmentExistsWarning === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'shipmentExistsWarning' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'shipmentExistsWarning',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['shipment_exists_warning.css', 'toast.css'],
				js: ['shipment_exists_warning.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt shipmentExistsWarning');
			}).catch(() => {
				console.log('Błąd ładowania skryptu shipmentExistsWarning');
			});
		}
	}

	if (readedValue.extensions.sendMessageFromOrdersPage === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'sendMessageFromOrdersPage' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'sendMessageFromOrdersPage',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*', 'https://salescenter.allegro.com/message-center/messages/new-message*', 'https://salescenter.allegro.com.allegrosandbox.pl/message-center/messages/new-message*', 'https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*'],
				css: ['toast.css'],
				js: ['send_message_from_orders_page.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt sendMessageFromOrdersPage');
			}).catch(() => {
				console.log('Błąd ładowania skryptu sendMessageFromOrdersPage');
			});
		}
	}
})();

async function sendNativeMessage(application, data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendNativeMessage(application, data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}
/*
(async() => {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['property']);
		console.log(readedValue);
	} catch (error) {
		console.log(error.message);
	}
})();
*/

/*
(async() => {
	try {
		await saveDataToLocalStorage({property: value});
		console.log('Zapisano');
	} catch (error) {
		console.log(error.message);
	}
})();
*/
async function handleBackgroundFetch(request) {
  const response = await fetch(request.url, {
    method: request.options.method || 'GET',
    headers: request.options.headers || {},
    body: request.options.body || null
  });

  const responseBody = await response.text();
  return {
    status: response.status,
    statusText: response.statusText,
    headers: Array.from(response.headers.entries()),
    body: responseBody
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'backgroundFetch': {
			return await handleBackgroundFetch(request);
		}

		case 'backgroundFetchPartially': {
			return await handleBackgroundFetchPartially(request);
		}

		case 'getAllegroAccessToken': {
			let sandbox;
			let readedValue;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			console.log(`Sandbox Mode: ${sandbox}`);
			try {
				readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') return Promise.resolve(readedValue[`allegroAccessToken${sandbox}`]);
			else {
				return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
			}
		}

		case 'refreshAllegroAccessToken': {
			let sandbox;
			let readedValue;
			let fetchResponse;
			let fetchData;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			try {
				readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

			const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
			const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
			const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
			const redirectUrl = chrome.identity.getRedirectURL('change_auctions_title');

			if (sandbox === 'Sandbox') {
				try {
					readedValue = await	readDataFromLocalStorage(['allegroAPIOAuthConnectorSandbox']);
				} catch (error) {
					return Promise.reject(`Podczas odczytu wymaganych parametrów (adres skryptu) wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				if (!readedValue.allegroAPIOAuthConnectorSandbox) {
					return Promise.reject('Brak wymaganych parametrów (adres skryptu).');
				}

				try {
					fetchResponse = await fetch(readedValue.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'refreshTokens', clientId: allegroAPIClientId, clientSecret: allegroAPIClientSecret, refreshToken: allegroRefreshToken })
					});
				} catch (error) {
					return Promise.reject(`Nie udało się uzyskać tokenów dostępowych za pośrednictwem skryptu. ${error?.message ? error.message : error}`);
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
					}

					if (fetchData?.status === 'success') {
						try {
							await saveDataToLocalStorage({
								allegroAccessTokenSandbox: fetchData.accessToken,
								allegroRefreshTokenSandbox: fetchData.refreshToken
							});
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
						}

						return Promise.resolve(fetchData.accessToken);
					} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
						return Promise.reject(`${UNABLE_TO_REFRESH_TOKENS} ${fetchData.details}`);
					} else return Promise.reject(UNABLE_TO_REFRESH_TOKENS);
				} else {
					return Promise.reject(`Podczas odświeżania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}.`);
				}
			} else {
				async function login(count = 3) {
					let fetchResponse;
					let fetchData;
					try {
						fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
							method: 'POST',
							headers: {
								'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
								'Content-Type': 'application/x-www-form-urlencoded'
							}
						});
					} catch (error) {
						if (--count) {
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}
					}

					if (fetchResponse.status === 200) {
						try {
							fetchData = await fetchResponse.json();
						} catch (error) {
							return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
						}

						if (fetchData.access_token === undefined || fetchData.refresh_token === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

						try {
							await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
						}

						return Promise.resolve(fetchData.access_token);
					} else {
						if (--count) {
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}
					}
				}
				try {
					const result = await login();
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(result);
				}
			}
		}

		case 'getExtensions': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['extensions']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
			}

			if (readedValue.extensions !== undefined) return Promise.resolve(readedValue.extensions);
			else return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. Nie znaleziono listy.`);
		}

		case 'loadExtensions': {
			loadExtensions();
			break;
		}

		case 'getFilter': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['filter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania ustawień koloru dla ikony faktury wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue.filter !== undefined) return Promise.resolve(readedValue.filter);
			else {
				readedValue.color = '#4a86e8';
				readedValue.filter = 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);';
				try {
					await saveDataToLocalStorage({ color: readedValue.color, filter: readedValue.filter });
				} catch (error) {
					return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				return Promise.resolve(readedValue.filter);
			}
		}

		case 'saveColor': {
			if (request.color === undefined || request.filter === undefined) {
				return Promise.reject('Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane.');
			}
			try {
				await saveDataToLocalStorage({ color: request.color, filter: request.filter });
			} catch (error) {
				return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'allegroAPISave': {
			if (request.clientId === undefined || request.clientSecret === undefined || request.oAuthConnector === undefined || request.sandbox === undefined) return Promise.reject('Nie podano wartości parametrów Client ID i Cilent Secret.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			let patternClientId = /^|[0-9a-f]{32}/;
			let patternClientSecret = /^|[0-9a-zA-Z]{64}/;
			let patternOAuthConnector = /^|https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z\-_]{1,}\/exec$/;
			if ((!patternClientId.test(request.clientId)) || (!patternClientSecret.test(request.clientSecret)) || (!patternOAuthConnector.test(request.oAuthConnector))) return Promise.reject('Podane wartości parametrów są niepoprawne.');
			try {
				await saveDataToLocalStorage({ [`allegroAPIClientId${sandbox}`]: request.clientId, [`allegroAPIClientSecret${sandbox}`]: request.clientSecret, allegroAPIOAuthConnectorSandbox: request.oAuthConnector });
				if (request.clientId === '' || request.clientSecret === '' || (sandbox === 'Sandbox' && request.oAuthConnector === '')) await saveDataToLocalStorage({ [`allegroAccessToken${sandbox}`]: '', [`allegroRefreshToken${sandbox}`]: '' });
			} catch (error) {
				return Promise.reject(`Podczas zapisu parametrów wystąpił błąd. ${error?.message ? error.message : error}`);
			}

			if (sandbox === 'Sandbox') {
				if (request.clientId !== '' && request.clientSecret !== '' && request.oAuthConnector !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			} else {
				if (request.clientId !== '' && request.clientSecret !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			}
		}

		case 'openLoginPage': {
			if (request.url !== undefined) {
				try {
					await chrome.tabs.create({ active: true, url: request.url });
				} catch (error) {
					return Promise.reject(`Podczas otwierania strony logowania wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				return Promise.resolve(true);
			}
			return Promise.reject('Brak wymaganego adresu strony do otwarcia.');
		}

		case 'getPackageTemplates': {
			if (request.shippingMethod !== undefined) {
				let result;
				try {
					result = await readDataFromLocalStorage(['shippingMethods']);
				} catch (error) {
					return Promise.reject(`Podczas wczytywania metod dostawy wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				if (result.shippingMethods !== undefined) {
					let found = false;
					let option;
					for (option of result.shippingMethods) {
						if (option.name === request.shippingMethod) {
							found = true;
							break;
						}
					}
					if (!found) return Promise.reject('Nie znaleziono metody dostawy o takiej nazwie. Dodaj ją ręcznie do listy.');
					if (option.weight1 !== undefined) {
						const template = {};
						let i = 1;
						while (option[`weight${i}`] !== undefined) {
							if (i > 9) break;
							template[`weight${i}`] = option[`weight${i}`];
							template[`length${i}`] = option[`length${i}`];
							template[`width${i}`] = option[`width${i}`];
							template[`height${i}`] = option[`height${i}`];
							i++;
						}
						template.default = option.default;
						
						return Promise.resolve({ template: template });
					}
					else return Promise.resolve({ defaultSize: option['default'] });
				} else return Promise.reject('Nie znaleziono metod dostawy których wartości domyślne mają zostać odczytane.');	
			} else return Promise.reject('Nie określono metody dostawy której wartości domyślne mają zostać odczytane.');
		}

		case 'closeCurrentTab': {
			async function getCurrentTab() {
				let queryOptions = { active: true, lastFocusedWindow: true };
				try {
					let [tab] = await chrome.tabs.query(queryOptions);
					return Promise.resolve(tab);
				} catch(error) {
					return Promise.reject('Nie udało się pobrać aktywnej karty.');
				}
			}
			let tab;
			try {
				tab = await getCurrentTab();
				await chrome.tabs.remove(tab.id);
			} catch (error) {
				return Promise.reject(error);
			}
			
			return Promise.resolve(true);
		}

		case 'closeCallerTab': {
			try {
				await chrome.tabs.remove(sender.tab.id);
			} catch (error) {
				console.log(`Błąd! Podczas zamykania karty wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'drawAttention': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { drawAttention: true });
			} catch (error) {
				return Promise.reject('Nie udało się wyróżnić okna.');
			}
			return Promise.resolve(true);
		}

		case 'bringWindowToFront': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true });
			} catch (error) {
				return Promise.reject('Nie udało się ustawić okna na pierwszym planie.');
			}
			return Promise.resolve(true);
		}

		case 'getPrinters': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getPrinters' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy drukarek wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(response.result);
		}

		case 'getSumatraPath': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getSumatraPath' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania ścieżki programu SumatraPDF wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(response.result);
		}

		case 'moveTabToNewWindow': {
			try {
				await chrome.windows.create({ type: 'popup', focused: false, height: 30, width: 150, state: 'normal', left: (request.screenx - 150), top: (request.screeny - 30), tabId: sender.tab.id });
			} catch (error) {
				return Promise.reject('Nie udało się przenieść karty do nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'maximizeNewWindow': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true, state: 'maximized' });
			} catch (error) {
				return Promise.reject('Nie udało się zmaksymalizować nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'downloadLabel': {
			async function waitForDownloadFinished() {
				return new Promise((resolve, reject) => {
					let downloadItemId = 0;
					let downloadBackupTimer;
					function downloadEvent(downloadItem) {
						if (downloadItemId === 0) {
						
							downloadBackupTimer = setTimeout(downloadBackupHandler, 20000);
							chrome.downloads.search({
								state: 'in_progress',
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								orderBy: ["-startTime"],
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
										if (chrome.runtime.lastError) return;
										const windowFound = windows.some(window => window.id === sender.tab.windowId);
										if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
										try {
											chrome.windows.update(sender.tab.windowId, { state: 'minimized' }).catch(error => { console.log(`Błąd podczas minimalizowania okna. ${error.message}`) });
										} catch (error) {
											console.log(`Błąd podczas minimalizowania okna. ${error.message}`);
										}
									});
									downloadItemId = downloadSearchResult[0].id;
									console.log(`Trwa pobieranie, id: ${downloadItemId}`);
								} else {
									console.log('Nie wykryto rozpoczęcia pobierania pliku.');
								}
							}).catch(error => {
								console.log(`Błąd! Podczas pobierania wystąpił błąd. ${error?.message ? error.message : error}`);
								reject(`Podczas pobierania wystąpił błąd. ${error?.message ? error.message : error}`);
							});
						} else if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
							clearTimeout(downloadBackupTimer);
							console.log(`Pobrano, id: ${downloadItemId}`);
							chrome.downloads.onChanged.removeListener(downloadEvent);
							chrome.downloads.search({
								state: 'complete',
								exists: true,
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								id: downloadItemId
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
									resolve({ filename: downloadSearchResult[0].filename, backup: false });
								}
							}).catch(error => {
								console.log(`Błąd! Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${error?.message ? error.message : error}`);
								reject(`Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${error?.message ? error.message : error}`);
							});
						}
					}
					chrome.downloads.onChanged.addListener(downloadEvent);
					chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
						if (chrome.runtime.lastError) return;
						const windowFound = windows.some(window => window.id === sender.tab.windowId);
						if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
						try {
							chrome.windows.update(sender.tab.windowId, { drawAttention: false }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
						} catch (error) {
							console.log(`Błąd podczas wyróżniania okna. ${error.message}`);
						}
					});
				
					function downloadBackupHandler() {
						chrome.downloads.search({
							state: 'complete',
							exists: true,
							mime: 'application/pdf',
							finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
							limit: 1,
							orderBy: ["-startTime"]
						}).then(downloadSearchResult => {
							if (downloadSearchResult.length) {
								console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
								chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
									if (chrome.runtime.lastError) return;
									const windowFound = windows.some(window => window.id === sender.tab.windowId);
									if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
									try {
										chrome.windows.update(sender.tab.windowId, { focused: true }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
									} catch (error) {
										console.log(`Błąd podczas ustawiania focusa na oknie. ${error.message}`);
									}
								});
								resolve({ filename: downloadSearchResult[0].filename, backup: true });
							}
						});
					}
				});
			}
			return await waitForDownloadFinished();
		}

		case 'printLabel': {
			let readedValue;
			let response;
			if (request.filename === '') return Promise.reject('Nie określono nazwy pliku do wydruku.');
			try {
				readedValue = await readDataFromLocalStorage(['sumatraPath', 'defaultPrinter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania zapisanych wartości ścieżki do programu SumatraPDF i drukarki do wydruku wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			console.log(`sumatraPath: ${readedValue.sumatraPath}, defaultPrinter: ${readedValue.defaultPrinter}, filename: ${request.filename}`);
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: "printLabel", sumatraPath: readedValue.sumatraPath, defaultPrinter: readedValue.defaultPrinter, filename: request.filename.replace('\\\\', '\\') });
			} catch (error) {
				return Promise.reject(`Podczas przesyłania wiadomości do programu drukującego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (response.result === 'ok') {
				console.log('Wydrukowano');
				return Promise.resolve(response.result);
			} else {
				console.log('Błąd! Nie wydrukowano');
				return Promise.reject('Program drukujący nie zwrócił prawidłowej odpowiedzi informującej o wydrukowaniu etykiety.');
			}
		}

		case 'getInPostSendMode': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['inPostSendMode']);
			} catch (error) {
				return Promise.reject(`Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost. ${error?.message ? error.message : error}`);
			}

			if (readedValue.inPostSendMode !== undefined) return Promise.resolve(readedValue.inPostSendMode);
			else return Promise.reject('Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost.');
		}

		case 'saveInPostSendMode': {
			try {
				await saveDataToLocalStorage({ inPostSendMode: request.sendMode });
			} catch (error) {
				return Promise.reject(`Podczas zapisu sposobu nadawnia przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'sendAnonymizedSample': {
			let fetchResponse;
			let fetchData;
			try {
				fetchResponse = await fetch(`https://tomsyty.pl/allegro-extensions/validate-buyer-errors.php`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify(request.sample)
				});
			} catch (error) {	
				return Promise.reject(`${FETCH_ERROR_MESSAGE} ${SAMPLE_NOT_SEND}`);
			}
		
			if (fetchResponse.status !== 200) return Promise.reject(`${SAMPLE_NOT_SEND} ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);

			try {
				fetchData = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`${JSON_DECODE_ERROR} ${SAMPLE_NOT_SEND}`);
			}
			return Promise.resolve(true);
		}

		case 'updateSendParcelLink': {
			let tabs;
			try {
				tabs = await chrome.tabs.query({ url: `https://salescenter.allegro.com${request.environment}/orders*` });
				for (let tab of tabs) {
					sendMessage(tab.id, { action: 'updateSendParcelLink', orderId: request.orderId }).catch(error => { console.log(`Błąd podczas deaktywowania przycisku "Nadaj przesyłkę", ${error.message}`) });
				}
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return Promise.resolve(true);
		}

		case 'fillRefundForm': {
			let tabs;
			let response;
			try {
				tabs = await chrome.tabs.query({ url: `https://www.ifirma.pl/app/wo/*` });
				if (tabs.length === 0) return Promise.reject('Nie znaleziono otwartej karty z protokołem anulowania sprzedaży.');
				for (let tab of tabs) {
					response = await sendMessage(tab.id, { action: 'fillRefundForm', restoreList: request.restoreList });
					if (response?.success === false) {
						return Promise.reject(response.result);
					} else {
						await chrome.tabs.update(tab.id, { active: true });
						break;
					};
				}
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return Promise.resolve(true);
		}

		case 'debug': {
			console.log(request.info);
			break;
		}
	}
}

async function getShortcut() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['shortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.shortcut === undefined) {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {

		}
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.changeAuctionTitle.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ shortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}		
		}
	} else {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			
		}
		
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.shortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ shortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}
		}
	}
}

chrome.commands.onCommand.addListener(command => {
	asyncOnCommandCallback(command);
	return true;
});

async function asyncOnCommandCallback(command) {
  if (command === 'changeAuctionTitle') {
		async function getCurrentTab() {
			const queryOptions = { active: true, currentWindow: true, url: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'] };
			try {
				const [tab] = await chrome.tabs.query(queryOptions);
				if (tab === undefined) throw new Error('Skrót klawiaturowy aktywny jest tylko na stronie "Mój asortyment". Jeśli masz otwartą kartę na tej stronie - odśwież ją i spróbuj ponownie.');
				return Promise.resolve(tab.id);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
		}
		let tab;
		let readedValue;
		try {
			tab = await getCurrentTab();
		} catch (error) {
			optionsPageMessage(`Błąd! ${error}`);
			return;
		}
		try {
			readedValue = await readDataFromLocalStorage(['shortcut']);
		} catch (error) {
			optionsPageMessage(`${SHORTCUT_READING_ERROR} ${error?.message ? error.message : error}`);
			return;
		}
		let contentScripts;
		try {
			contentScripts = await chrome.scripting.getRegisteredContentScripts();
			if (contentScripts.length) {			
				if (!contentScripts.some(registeredScript => registeredScript.id === 'changeAuctionsTitle')) {
					throw new Error('Jeśli masz otwartą kartę na stronie "Mój asortyment" - odśwież ją i spróbuj ponownie');
				} else {
					await sendMessage(tab, { action: 'allowEditing', shortcut: readedValue.shortcut });
				}
			} else throw new Error('Jeśli masz otwartą kartę na stronie "Mój asortyment" - odśwież ją i spróbuj ponownie.');
		} catch (error) {
			optionsPageMessage(`Błąd! ${error?.message ? error.message : error}`);
			return
		}
	}
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Allegro-Extensions/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
})();