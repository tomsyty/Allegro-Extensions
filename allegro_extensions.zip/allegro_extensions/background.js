chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

let pwWorkEnabled = false;
let csWorkEnabled = false;
let scrollingText = {
  toDisplay: [],
  intervalId: null,
  index: 0
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(tab, data) {
	try {
		const response = await chrome.tabs.sendMessage(tab, data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

async function getWindows() {
	let result;
	try {
		result = await chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] });
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

function getErrorMessage(error) {
  if (error?.message) return error.message;
  if (typeof error === 'string') return error;
  return JSON.stringify(error);
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		console.log('Ustawianie domyślnych wartości...');
		chrome.storage.local.set({
			extensions: { changeInvoicesIconColor: false, highlightMessageFromBuyer: false, autofillPackageSize: false, autoprintLabel: false, changeAuctionsTitle: false, validateBuyerAddressErrors: false, inPostSendMode: false, fastStockManager: false, restoreCancelled: false, restoreReturned: false, showProductName: false, offerTags: false, showStockLeft: false, shipmentExistsWarning: false, sendMessageFromOrdersPage: false, additionalOrdersSortingOptions: false, showShipmentStatus: false, buyerStats: false, erliActions: false, additionalActions: false, parametersWatcher: false, allegroAPI: false },
			allegroAPIClientId: '',
			allegroAPIClientSecret: '',
			allegroAccessToken: '',
			allegroRefreshToken: '',
			allegroTokenScopes: '',
			allegroAPIClientIdSandbox: '',
			allegroAPIClientSecretSandbox: '',
			allegroAccessTokenSandbox: '',
			allegroRefreshTokenSandbox: '',
			allegroTokenScopesSandbox: '',
			erliToken: '',
			erliTokenSandbox: '',
			erliAlwaysSyncToSandbox: false,
			erliPriceListName: '', 
			erliObligatoryName: '',
			erliVoluntaryName: '',
			erliReturnsName: '',
			erliPriceApplyDiscountCheckbox: false,
			erliPriceAmountRadio: true,
			erliPricePercentRadio: false,
			erliPriceStepsRadio: false,
			erliPriceAmountValue: 0,
			erliPricePercentValue: 0,
			erliPriceSteps: [],
			erliFastStockMaganerCheckbox: false,
			erliRestoreCancelledCheckbox: false,
			erliRestoreReturnedCheckbox: false,
			erliShowStockLeftCheckbox: false,
			responsibleProducers: [],
			responsiblePersons: [],
			parametersWatcherTimerCheckbox: false,
			parametersWatcherSandbox: false,
			parametersWatcherPeriodInput: 3,
			parametersWatcherScheduledTime: 0,
			checkShipmentsStatusTimerCheckbox: false,
			checkShipmentsStatusPeriodInput: 3,
			checkShipmentsStatusScheduledTime: 0,
			color: '#4a86e8',
			filter: 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);',
			cssHmfb: 'color: #ff0000;',
			inPostSendMode: 1,
			iFirmaReturns: false,
			buyerAddressErrorsFeedback: false,
			defaultPrinter: '',
			sumatraPath: '',
			changeAuctionsTitleShortcut: '',
			offerTagsShortcut: '',
			offerTagsDefaultHidden: false,
			updateLastChecked: '',
			returnsDoneList: [],
			shippingMethods: [
				{	name: 'Allegro Paczkomaty InPost',										weight: '0', size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost' },
				{	name: 'Allegro Paczkomaty InPost pobranie',						weight: '0', size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost pobranie' },
				{	name: 'Allegro miniKurier24 InPost',									weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost'	},
				{	name: 'Allegro miniKurier24 InPost pobranie',					weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost pobranie' },
				{	name: 'Allegro Kurier24 InPost',											weight1: '', maxWeight: '30',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost' },
				{	name: 'Allegro Kurier24 InPost pobranie',							weight1: '', maxWeight: '30', length1: '', minLength: '1',	maxLength: '80', width1: '', minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost pobranie' },
				{	name: 'Allegro Automat ORLEN Paczka',									weight: '0', size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Automat ORLEN Paczka' },
				{	name: 'Allegro Odbiór w Punkcie ORLEN Paczka',				weight: '0', size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Odbiór w Punkcie ORLEN Paczka' },
				{	name: 'Allegro Automat DHL BOX 24/7 (AD)',						weight: '0', size1: 'Gabaryt S 64x38x8cm, 20kg', size2: "Gabaryt M 64x38x19cm, 20kg", size3: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro Automat DHL BOX 24/7 (AD)' },
				{	name: 'Allegro Odbiór w Punkcie DHL (AD)',						weight: '0', size1: 'Gabaryt S 64x38x8cm, 20kg', size2: "Gabaryt M 64x38x19cm, 20kg", size3: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro Odbiór w Punkcie DHL (AD)' },
				{	name: 'Allegro Kurier DHL (AD)',											weight1: '', maxWeight: '31.5',	length1: '', minLength: '1',	maxLength: '120', width1: '',	minWidth: '1', maxWidth: '60', height1: '', minHeight: '1', maxHeight: '60', default: '1', defaultName: 'Allegro Kurier DHL (AD)'	},
				{	name: 'Allegro One Box, DPD',													weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Box, DPD' },
				{	name: 'Allegro One Punkt, DPD',												weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', 	height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Punkt, DPD' },
				{	name: 'Allegro One Kurier',														weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '120', width1: '',	minWidth: '1', 	maxWidth: '76', 	height1: '', 	minHeight: '1', maxHeight: '76', 	default: '1',	defaultName: 'Allegro One Kurier' },
				{	name: 'Allegro Kurier DPD',														weight1: '',	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1', 	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD' },
				{	name: 'Allegro Kurier DPD pobranie', 									weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1',	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD pobranie' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup', 					weight1: '', 	maxWeight: '20',		length1: '',	minLength: '1',		maxLength: '100',	width1: '', minWidth: '1',	maxWidth: '100', 	height1: '', 	minHeight: '1', maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup pobranie',	weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '1', 	maxLength: '100', width1: '', minWidth: '1', 	maxWidth: '100', 	height1: '',	minHeight: '1',	maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup pobranie' },
				{	name: 'Allegro Kurier Pocztex', 											weight1: '', 	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120', width1: '', minWidth: '10', maxWidth: '120', 	height1: '', 	minHeight: '1', maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex' },
				{	name: 'Allegro Kurier Pocztex pobranie',							weight1: '',	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120',	width1: '',	minWidth: '10',	maxWidth: '120',	height1: '',	minHeight: '1',	maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex pobranie' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex', 						weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70', 	width1: '',	minWidth: '10', maxWidth: '60', 	height1: '', 	minHeight: '1', maxHeight: '60', 	default: '1',	defaultName: 'Allegro Odbiór w Punkcie Pocztex' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex pobranie',		weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70',	width1: '',	minWidth: '10',	maxWidth: '60',		height1: '',	minHeight: '1',	maxHeight: '60', 	default: '1', defaultName: 'Allegro Odbiór w Punkcie Pocztex pobranie' },
				{	name: 'Allegro Automat Pocztex', 											weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '65', 	width1: '', minWidth: '10', maxWidth: '42', 	height1: '', 	minHeight: '1', maxHeight: '40', 	default: '1',	defaultName: 'Allegro Automat Pocztex' }
			]
		}).then(() => {
			chrome.runtime.openOptionsPage(() => {
			});
		}).catch(error => {
			console.log(error.message);
		});
	} else if (details.reason === 'update') {
		(async () => {
			if (details.previousVersion < '1.0.1') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.shipmentExistsWarning = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.2') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.sendMessageFromOrdersPage = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.4') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.additionalOrdersSortingOptions = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.5') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.showShipmentStatus = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.6') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions', 'shortcut']);
					storageData.extensions.offerTags = false;
					storageData.offerTagsShortcut = '';
					storageData.changeAuctionsTitleShortcut = storageData.shortcut;
					storageData.allegroTokenScopes = '';
					storageData.allegroTokenScopesSandbox = '';
					storageData.updateLastChecked = '';
					storageData.offerTagsDefaultHidden = false;
					await saveDataToLocalStorage(storageData);
					await chrome.storage.local.remove('shortcut');
					optionsPageMessage('Uwaga! Aby na stronie opcji rozszerzenia prawidłowo pokazywały się informacje o przyznanych uprawnieniach, ponownie kliknij przycisk "Zaloguj". Jeśli korzystasz z serwisu testowego Sandbox - przeczytaj zmiany w dokumentacji (changelog).');
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.8') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.buyerStats = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.1') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.erliActions = false;
					storageData.extensions.parametersWatcher = false;
					storageData.erliToken = '';
					storageData.erliTokenSandbox = '';
					storageData.erliAlwaysSyncToSandbox = false;
					storageData.erliPriceListName = '';
					storageData.erliObligatoryName = '';
					storageData.erliVoluntaryName = '';
					storageData.erliReturnsName = '';
					storageData.erliPriceApplyDiscountCheckbox = false;
					storageData.erliPriceAmountRadio = true;
					storageData.erliPricePercentRadio = false;
					storageData.erliPriceStepsRadio = false;
					storageData.erliPriceAmountValue = 0;
					storageData.erliPricePercentValue = 0;
					storageData.erliPriceSteps = [];
					storageData.erliFastStockMaganerCheckbox = false;
					storageData.erliRestoreCancelledCheckbox = false;
					storageData.erliRestoreReturnedCheckbox = false;
					storageData.erliShowStockLeftCheckbox = false;
					storageData.responsibleProducers = [];
					storageData.responsiblePersons = [];
					storageData.parametersWatcherTimerCheckbox = false;
					storageData.parametersWatcherSandbox = false;
					storageData.parametersWatcherPeriodInput = 3,
					storageData.parametersWatcherScheduledTime = 0;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.2') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['shippingMethods']);
					storageData.shippingMethods.forEach(method => {
						if (method.size1 !== undefined && method.weight === undefined) {
							method.weight = '0';
						}
					});
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.4') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions', 'shippingMethods']);
					storageData.extensions.additionalActions = false;
					const methodToRemove = ['Allegro One Box, UPS', 'Allegro One Punkt, UPS', 'Allegro Kurier UPS', 'Allegro Kurier UPS pobranie', 'Allegro Odbiór w Punkcie UPS', 'Allegro Automat DHL POP BOX'];
					storageData.shippingMethods = storageData.shippingMethods.filter(method => !methodToRemove.includes(method.name));
					const methodToAdd = [
						{	name: 'Allegro Automat DHL BOX 24/7 (AD)',						weight: '0', size1: 'Gabaryt S 64x38x8cm, 20kg', size2: "Gabaryt M 64x38x19cm, 20kg", size3: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro Automat DHL BOX 24/7 (AD)' },
						{	name: 'Allegro Odbiór w Punkcie DHL (AD)',						weight: '0', size1: 'Gabaryt S 64x38x8cm, 20kg', size2: "Gabaryt M 64x38x19cm, 20kg", size3: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro Odbiór w Punkcie DHL (AD)' },
						{	name: 'Allegro Kurier DHL (AD)',											weight1: '', maxWeight: '31.5',	length1: '', minLength: '1',	maxLength: '120', width1: '',	minWidth: '1', maxWidth: '60', height1: '', minHeight: '1', maxHeight: '60', default: '1', defaultName: 'Allegro Kurier DHL (AD)'	},
					];
					storageData.shippingMethods = storageData.shippingMethods.concat(methodToAdd);
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.6') {
				let storageData;
				try {
					await chrome.storage.local.remove('allegroAPIOAuthConnectorSandbox');
					storageData = await readDataFromLocalStorage(['inPostSendMode']);
					if (storageData.inPostSendMode === 3) {
						storageData.inPostSendMode = 2;
						await saveDataToLocalStorage(storageData);
						optionsPageMessage('Uwaga! Zaktualizowano sposób nadawania przesyłek InPost, sprawdź poprawność ustawień.');
					}
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.7') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.highlightMessageFromBuyer = false;
					storageData.checkShipmentsStatusTimerCheckbox = false;
					storageData.checkShipmentsStatusPeriodInput = 3;
					storageData.checkShipmentsStatusScheduledTime = 0;
					storageData.cssHmfb = 'color: #ff0000;';
					await saveDataToLocalStorage(storageData);		
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${getErrorMessage(error)}`);
					return;
				}
			}
		})();
	}
});

async function applyRules() {
	const rules = [{
		id: 1,
		action: {
			type: 'modifyHeaders',
			requestHeaders: [{ header: 'Origin', operation: 'set', value: `https://allegro.pl` }],
		},
		condition: {
			regexFilter: `^https:\/\/(allegro\.pl\/auth\/oauth\/*|api\.allegro\.pl\/*)`,
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ['xmlhttprequest']
		}
	}, {
		id: 2,
		action: {
			type: 'modifyHeaders',
			requestHeaders: [{ header: 'Origin', operation: 'set', value: `https://allegro.pl.allegrosandbox.pl` }],
		},
		condition: {
			regexFilter: `^https:\/\/(allegro\.pl\.allegrosandbox\.pl\/auth\/oauth\/*|api\.allegro\.pl\.allegrosanbox\.pl\/*)`,
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ['xmlhttprequest']
		}
	}, {
		id: 3,
		action: {
			type: 'modifyHeaders',
			requestHeaders: [{ header: 'Origin', operation: 'set', value: 'https://erli.pl' }],
		},
		condition: {
			urlFilter: 'https:\/\/erli.pl\/svc\/*',
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ['xmlhttprequest']
		}
	}, {
		id: 4,
		action: {
			type: 'modifyHeaders',
			requestHeaders: [{ header: 'Origin', operation: 'set', value: 'https://sandbox.erli.dev' }],
		},
		condition: {
			urlFilter: 'https:\/\/sandbox.erli.dev\/svc\/*',
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ['xmlhttprequest']
		}
	}];
	await chrome.declarativeNetRequest.updateDynamicRules({
		removeRuleIds: rules.map(r => r.id),
		addRules: rules,
	});
}
applyRules();

chrome.action.onClicked.addListener(openOptionsPage);

async function loadExtensions(retriesLeft = 5) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy rozszerzeń wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}
	if (readedValue.extensions === undefined) {
		console.log('Nie znaleziono listy rozszerzeń, ponawianie próby...');
		if (--retriesLeft) {
			await new Promise(resolve => setTimeout(resolve, 1000));
			return await loadExtensions(retriesLeft);
		}
		else {
			optionsPageMessage('Błąd! Podczas odczytu listy rozszerzeń wystąpił błąd. Usuń i zainstaluj ponownie rozszerenie.');
			return;
		}
	}
	let contentScripts;
	try { 
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy załadowanych skryptów wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}

	if (contentScripts === undefined) return;

	if (readedValue.extensions.changeInvoicesIconColor === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeInvoicesIconColor' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeInvoicesIconColor',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['change_invoices_icon_color.js', 'toast.js'],
			}]).then(() => {
				console.log('Załadowano skrypt changeInvoicesIconColor');
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeInvoicesIconColor');
			});
		}
	}

	if (readedValue.extensions.highlightMessageFromBuyer === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'highlightMessageFromBuyer' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'highlightMessageFromBuyer',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['highlight_message_from_buyer.js', 'toast.js'],
			}]).then(() => {
				console.log('Załadowano skrypt highlightMessageFromBuyer');
			}).catch(() => {
				console.log('Błąd ładowania skryptu highlightMessageFromBuyer');
			});
		}
	}

	if (readedValue.extensions.autoprintLabel === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autoprintLabel' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autoprintLabel',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
				css: ['autoprint_label.css', 'toast.css'],
				js: ['autoprint_label.js', 'toast.js']
			}, {
				id: 'autoprintLabelOrders',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['autoprint_label_orders.css'],
				js: ['autoprint_label_orders.js']
			}]).then(() => {
				console.log('Załadowano skrypt autoprintLabel');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autoprintLabel');
			});
		}
	}

	if (readedValue.extensions.autofillPackageSize === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autofillPackageSize' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autofillPackageSize',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['autofill_package_size.css', 'toast.css'],
				js: ['autofill_package_size.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt autofillPackageSize');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autofillPackageSize');
			});
		}
	}

	if (readedValue.extensions.inPostSendMode === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'inPostSendMode' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'inPostSendMode',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['inpost_send_mode.css', 'toast.css'],
				js: ['inpost_send_mode.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt inPostSendMode');
			}).catch(() => {
				console.log('Błąd ładowania skryptu inPostSendMode');
			});
		}
	}

	if (readedValue.extensions.sendMessageFromOrdersPage === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'sendMessageFromOrdersPage' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'sendMessageFromOrdersPage',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*', 'https://salescenter.allegro.com/message-center/messages/new-message*', 'https://salescenter.allegro.com.allegrosandbox.pl/message-center/messages/new-message*', 'https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*'],
				css: ['toast.css'],
				js: ['send_message_from_orders_page.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt sendMessageFromOrdersPage');
			}).catch(() => {
				console.log('Błąd ładowania skryptu sendMessageFromOrdersPage');
			});
		}
	}

	if (readedValue.extensions.additionalOrdersSortingOptions === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'additionalOrdersSortingOptions' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'additionalOrdersSortingOptions',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['additional_orders_sorting_options.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt additionalOrdersSortingOptions');
			}).catch(() => {
				console.log('Błąd ładowania skryptu additionalOrdersSortingOptions');
			});
		}
	}

	if (readedValue.extensions.validateBuyerAddressErrors === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'validateBuyerAddressErrors' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'validateBuyerAddressErrors',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['validate_buyer_address_errors.css', 'toast.css'],
				js: ['validate_buyer_address_errors.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt validateBuyerAddressErrors');
			}).catch(() => {
				console.log('Błąd ładowania skryptu validateBuyerAddressErrors');
			});
		}
	}
	
	if (readedValue.extensions.changeAuctionsTitle === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeAuctionsTitle' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeAuctionsTitle',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['change_auctions_title.css', 'toast.css'],
				js: ['change_auctions_title.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt changeAuctionsTitle');
				getShortcutChangeAuctionsTitle().catch(() => {});
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeAuctionsTitle');
			});
		}
	}

	if (readedValue.extensions.fastStockManager === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'fastStockManager' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'fastStockManager',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['fast_stock_manager.css', 'toast.css'],
				js: ['fast_stock_manager.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt fastStockManager');
			}).catch(() => {
				console.log('Błąd ładowania skryptu fastStockManager');
			});
		}
	}

	if (readedValue.extensions.restoreCancelled === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreCancelled' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreCancelled',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['restore_cancelled.css', 'toast.css'],
				js: ['restore_cancelled.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreCancelled');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreCancelled');
			});
		}
	}

	if (readedValue.extensions.restoreReturned === true) {
		let localReadedValue;
		try {
			localReadedValue = await readDataFromLocalStorage(['iFirmaReturns']);
		} catch (error) {
			console.log(`Błąd! Podczas odczytywania ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}

		if (localReadedValue.iFirmaReturns === true) {
			if (contentScripts.find(registeredScript => { return registeredScript.id === 'iFirmaReturns' }) === undefined) {
				chrome.scripting.registerContentScripts([{
					id: 'iFirmaReturns',
					matches: ['https://www.ifirma.pl/*'],
					css: ['ifirma_returns.css', 'toast.css'],
					js: ['ifirma_returns.js', 'toast.js']
				}]).then(() => {
					console.log('Załadowano skrypt iFirmaReturns');
				}).catch(() => {
					console.log('Błąd ładowania skryptu iFirmaReturns');
				});
			}
		}

		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreReturned' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreReturned',
				matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
				css: ['restore_returned.css', 'toast.css'],
				js: ['restore_returned.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreReturned');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreReturned');
			});
		}
	}

	if (readedValue.extensions.showProductName === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showProductName' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showProductName',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['show_product_name.css', 'toast.css'],
				js: ['show_product_name.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showProductName');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showProductName');
			});
		}
	}

	if (readedValue.extensions.offerTags === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'offerTags' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'offerTags',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['offer_tags.css', 'toast.css'],
				js: ['offer_tags.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt offerTags');
				getShortcutOfferTags().catch(() => {});
			}).catch(() => {
				console.log('Błąd ładowania skryptu offerTags');
			});
		}
	}

	if (readedValue.extensions.showStockLeft === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showStockLeft' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showStockLeft',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['show_stock_left.css', 'toast.css'],
				js: ['show_stock_left.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showStockLeft');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showStockLeft');
			});
		}
	}

	if (readedValue.extensions.shipmentExistsWarning === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'shipmentExistsWarning' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'shipmentExistsWarning',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['shipment_exists_warning.css', 'toast.css'],
				js: ['shipment_exists_warning.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt shipmentExistsWarning');
			}).catch(() => {
				console.log('Błąd ładowania skryptu shipmentExistsWarning');
			});
		}
	}

	if (readedValue.extensions.showShipmentStatus === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showShipmentStatus' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showShipmentStatus',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/shipments*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/shipments*'],
				css: ['show_shipment_status.css', 'toast.css'],
				js: ['show_shipment_status.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showShipmentStatus');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showShipmentStatus');
			});
		}
	}

	if (readedValue.extensions.parametersWatcher === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'parametersWatcher' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'parametersWatcher',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['parameters_watcher.css', 'toast.css'],
				js: ['parameters_watcher.js', 'toast.js']
			}]).then(async () => {
				console.log('Załadowano skrypt parametersWatcher');
			}).catch(() => {
				console.log('Błąd ładowania skryptu parametersWatcher');
			});
		}
	}

	if (readedValue.extensions.buyerStats === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'buyerStats' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'buyerStats',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['buyer_stats.css', 'toast.css'],
				js: ['buyer_stats.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt buyerStats');
			}).catch(() => {
				console.log('Błąd ładowania skryptu buyerStats');
			});
		}
	}

	if (readedValue.extensions.erliActions === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'erliActions' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'erliActions',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['erli_actions.css', 'toast.css'],
				js: ['erli_actions.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt erliActions');
			}).catch(() => {
				console.log('Błąd ładowania skryptu erliActions');
			});
		}
	}

	if (readedValue.extensions.additionalActions === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'additionalActions' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'additionalActions',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['additional_actions.css', 'toast.css'],
				js: ['additional_actions.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt additionalActions');
			}).catch(() => {
				console.log('Błąd ładowania skryptu additionalActions');
			});
		}
	}

	try {
		await parametersWatcherPrepare();
		await checkShipmentsStatusPrepare();
	} catch (error) {
		showMessageFromBackground(getErrorMessage(error));
	}
}

loadExtensions();

chrome.runtime.onStartup.addListener(async () => {
	await loadExtensions();
});

async function sendNativeMessage(application, data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendNativeMessage(application, data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

async function handleBackgroundFetch(request) {
  const fetchResponse = await fetch(request.url, {
    method: request.options.method || 'GET',
    headers: request.options.headers || {},
    body: request.options.body || null
  });

  const fetchResponseBody = await fetchResponse.text();
  return {
    status: fetchResponse.status,
    statusText: fetchResponse.statusText,
    headers: Array.from(fetchResponse.headers.entries()),
    body: fetchResponseBody
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'backgroundFetch': {
			return await handleBackgroundFetch(request);
		}

		case 'backgroundFetchPartially': {
			return await handleBackgroundFetchPartially(request);
		}

		case 'getAllegroAccessToken': {
			let sandbox;
			let readedValue;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			try {
				readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') return Promise.resolve(readedValue[`allegroAccessToken${sandbox}`]);
			else {
				return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
			}
		}

		case 'refreshAllegroAccessToken': {
			let sandbox;
			let readedValue;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			const environment = sandbox ? '.allegrosandbox.pl' : '';
			try {
				readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

			const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
			const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
			const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
			const redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');

			
			async function login(count = 5) {
				let fetchResponse;
				let fetchData;
				try {
					fetchResponse = await fetch(`https://allegro.pl${environment}/auth/oauth/token`, {
						method: 'POST',
						headers: {
							'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
							'Content-Type': 'application/x-www-form-urlencoded'
						}, 
						body: encodeURI(`grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`)
					});
				} catch (error) {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await login(count);
					} else {
						return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się odświeżyć tokena dostępowego. Jeśli problem dalej będzie występował, spróbuj zalogować aplikację ponownie na stronie opcji rozszerzenia.`);
					}
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
					}

					if (fetchData.access_token === undefined || fetchData.refresh_token === undefined || fetchData.scope === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

					try {
						await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token, allegroTokenScopes: fetchData.scope.split(' ').join(', ') });
					} catch (error) {
						return Promise.reject(`Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów. ${getErrorMessage(error)}`);
					}

					return Promise.resolve(fetchData.access_token);
				} else {
					if (--count) {
						await new Promise(resolve => setTimeout(resolve, 5000));
						return await login(count);
					} else {
						return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
					}
				}
			}
			try {
				const result = await login();
				return Promise.resolve(result);
			} catch (error) {
				return Promise.reject(error);
			}
			
		}

		case 'getExtensions': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['extensions']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. ${getErrorMessage(error)}`);
			}

			if (readedValue.extensions !== undefined) return Promise.resolve(readedValue.extensions);
			else return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. Nie znaleziono listy.`);
		}

		case 'loadExtensions': {
			loadExtensions();
			break;
		}

		case 'getFilter': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['filter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania ustawień koloru dla ikony faktury wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (readedValue.filter !== undefined) return Promise.resolve(readedValue.filter);
			else {
				readedValue.color = '#4a86e8';
				readedValue.filter = 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);';
				try {
					await saveDataToLocalStorage({ color: readedValue.color, filter: readedValue.filter });
				} catch (error) {
					return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. ${getErrorMessage(error)}`);
				}
				return Promise.resolve(readedValue.filter);
			}
		}

		case 'hmfbGet': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['cssHmfb']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania ustawień sposobu wyróżniania wiadomości od kupującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (readedValue.cssHmfb !== undefined) return Promise.resolve(readedValue.cssHmfb);
			else return Promise.reject(`Brak informacji o sposobie wyróżniania wiadomości od kupującego. Przejdź do ustawień rozszerzenia, wybierz króryś sposób i kliknij zapisz.`);
		}

		case 'saveColor': {
			if (request.color === undefined || request.filter === undefined) {
				return Promise.reject('Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane.');
			}
			try {
				await saveDataToLocalStorage({ color: request.color, filter: request.filter });
			} catch (error) {
				return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(true);
		}

		case 'allegroAPISave': {
			if (request.clientId === undefined || request.clientSecret === undefined || request.sandbox === undefined) return Promise.reject('Nie podano wartości parametrów Client ID i Cilent Secret.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			let patternClientId = /^|[0-9a-f]{32}/;
			let patternClientSecret = /^|[0-9a-zA-Z]{64}/;
			if ((!patternClientId.test(request.clientId)) || (!patternClientSecret.test(request.clientSecret))) return Promise.reject('Podane wartości parametrów są niepoprawne.');
			try {
				await saveDataToLocalStorage({ [`allegroAPIClientId${sandbox}`]: request.clientId, [`allegroAPIClientSecret${sandbox}`]: request.clientSecret });
				if (request.clientId === '' || request.clientSecret === '') await saveDataToLocalStorage({ [`allegroAccessToken${sandbox}`]: '', [`allegroRefreshToken${sandbox}`]: '', [`tokenScopes${sandbox}`]: '' });
			} catch (error) {
				return Promise.reject(`Podczas zapisu parametrów wystąpił błąd. ${getErrorMessage(error)}`);
			}
			
			if (request.clientId !== '' && request.clientSecret !== '') return Promise.resolve(true);
			else return Promise.resolve(false);
		}

		case 'erliTokenSave': {
			if (request.token === undefined) return Promise.reject('Nie podano wartości tokena.');
			let patternToken = /^|\S{1,}$/;
			if (!patternToken.test(request.token)) return Promise.reject('Podana wartość tokena jest niepoprawna.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			try {
				await saveDataToLocalStorage({ [`erliToken${sandbox}`]: request.token });
			} catch (error) {
				return Promise.reject(`Podczas zapisu tokena wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(true);
		}

		case 'openLoginPage': {
			if (request.url !== undefined) {
				try {
					await chrome.tabs.create({ active: true, url: request.url });
				} catch (error) {
					return Promise.reject(`Podczas otwierania strony logowania wystąpił błąd. ${getErrorMessage(error)}`);
				}
				return Promise.resolve(true);
			}
			return Promise.reject('Brak wymaganego adresu strony do otwarcia.');
		}

		case 'getPackageTemplates': {
			if (request.shippingMethod !== undefined) {
				let result;
				try {
					result = await readDataFromLocalStorage(['shippingMethods']);
				} catch (error) {
					return Promise.reject(`Podczas wczytywania metod dostawy wystąpił błąd. ${getErrorMessage(error)}`);
				}
				if (result.shippingMethods !== undefined) {
					let found = false;
					let option;
					for (option of result.shippingMethods) {
						if (option.name === request.shippingMethod) {
							found = true;
							break;
						}
					}
					if (!found) return Promise.reject('Nie znaleziono metody dostawy o takiej nazwie. Dodaj ją ręcznie do listy.');
					if (option.weight1 !== undefined) {
						const template = {};
						let i = 1;
						while (option[`weight${i}`] !== undefined) {
							if (i > 9) break;
							template[`weight${i}`] = option[`weight${i}`];
							template[`length${i}`] = option[`length${i}`];
							template[`width${i}`] = option[`width${i}`];
							template[`height${i}`] = option[`height${i}`];
							i++;
						}
						template.default = option.default;
						
						return Promise.resolve({ template: template });
					}
					else return Promise.resolve({ defaultWeight: option['weight'], defaultSize: option['default'] });
				} else return Promise.reject('Nie znaleziono metod dostawy których wartości domyślne mają zostać odczytane.');	
			} else return Promise.reject('Nie określono metody dostawy której wartości domyślne mają zostać odczytane.');
		}

		case 'closeCurrentTab': {
			async function getCurrentTab() {
				let queryOptions = { active: true, lastFocusedWindow: true };
				try {
					let [tab] = await chrome.tabs.query(queryOptions);
					return Promise.resolve(tab);
				} catch(error) {
					return Promise.reject('Nie udało się pobrać aktywnej karty.');
				}
			}
			let tab;
			try {
				tab = await getCurrentTab();
				await chrome.tabs.remove(tab.id);
			} catch (error) {
				return Promise.reject(error);
			}
			
			return Promise.resolve(true);
		}

		case 'closeCallerTab': {
			try {
				await chrome.tabs.remove(sender.tab.id);
			} catch (error) {
				console.log(`Błąd! Podczas zamykania karty wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(true);
		}

		case 'drawAttention': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { drawAttention: true });
			} catch (error) {
				return Promise.reject('Nie udało się wyróżnić okna.');
			}
			return Promise.resolve(true);
		}

		case 'bringWindowToFront': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true });
			} catch (error) {
				return Promise.reject('Nie udało się ustawić okna na pierwszym planie.');
			}
			return Promise.resolve(true);
		}

		case 'getPrinters': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getPrinters' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy drukarek wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(response.result);
		}

		case 'getSumatraPath': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getSumatraPath' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania ścieżki programu SumatraPDF wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(response.result);
		}

		case 'moveTabToNewWindow': {
			try {
				await chrome.windows.create({ type: 'popup', focused: false, height: 30, width: 150, state: 'normal', left: (request.screenx - 150), top: (request.screeny - 30), tabId: sender.tab.id });
			} catch (error) {
				return Promise.reject('Nie udało się przenieść karty do nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'maximizeNewWindow': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true, state: 'maximized' });
			} catch (error) {
				return Promise.reject('Nie udało się zmaksymalizować nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'downloadLabel': {
			async function waitForDownloadFinished() {
				return new Promise((resolve, reject) => {
					let downloadItemId = 0;
					let downloadBackupTimer;
					function downloadEvent(downloadItem) {
						if (downloadItemId === 0) {
						
							downloadBackupTimer = setTimeout(downloadBackupHandler, 20000);
							chrome.downloads.search({
								state: 'in_progress',
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								orderBy: ["-startTime"],
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }).then(windows => {
										const windowFound = windows.some(window => window.id === sender.tab.windowId);
										if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
										try {
											chrome.windows.update(sender.tab.windowId, { state: 'minimized' }).catch(error => { console.log(`Błąd podczas minimalizowania okna. ${error.message}`) });
										} catch (error) {
											console.log(`Błąd podczas minimalizowania okna. ${error.message}`);
										}
									}).catch(error => {
										console.log(`Błąd podczas pobierania listy okien. ${getErrorMessage(error)}`);
										reject(`Podczas pobierania listy okien wystąpił błąd. ${getErrorMessage(error)}`);
									});
									downloadItemId = downloadSearchResult[0].id;
									console.log(`Trwa pobieranie, id: ${downloadItemId}`);
								} else {
									console.log('Nie wykryto rozpoczęcia pobierania pliku.');
								}
							}).catch(error => {
								console.log(`Błąd! Podczas pobierania wystąpił błąd. ${getErrorMessage(error)}`);
								reject(`Podczas pobierania wystąpił błąd. ${getErrorMessage(error)}`);
							});
						} else if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
							clearTimeout(downloadBackupTimer);
							console.log(`Pobrano, id: ${downloadItemId}`);
							chrome.downloads.onChanged.removeListener(downloadEvent);
							chrome.downloads.search({
								state: 'complete',
								exists: true,
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								id: downloadItemId
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
									resolve({ filename: downloadSearchResult[0].filename, backup: false });
								}
							}).catch(error => {
								console.log(`Błąd! Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${getErrorMessage(error)}`);
								reject(`Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${getErrorMessage(error)}`);
							});
						}
					}
					chrome.downloads.onChanged.addListener(downloadEvent);
					chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }).then(windows => {
						const windowFound = windows.some(window => window.id === sender.tab.windowId);
						if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
						try {
							chrome.windows.update(sender.tab.windowId, { drawAttention: false }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
						} catch (error) {
							console.log(`Błąd podczas wyróżniania okna. ${error.message}`);
						}
					}).catch(error => {
						console.log(`Błąd podczas pobierania listy okien. ${getErrorMessage(error)}`);
						reject(`Podczas pobierania listy okien wystąpił błąd. ${getErrorMessage(error)}`);
					});
				
					function downloadBackupHandler() {
						chrome.downloads.search({
							state: 'complete',
							exists: true,
							mime: 'application/pdf',
							finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
							limit: 1,
							orderBy: ["-startTime"]
						}).then(downloadSearchResult => {
							if (downloadSearchResult.length) {
								console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
								chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }).then(windows => {
									const windowFound = windows.some(window => window.id === sender.tab.windowId);
									if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
									try {
										chrome.windows.update(sender.tab.windowId, { focused: true }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
									} catch (error) {
										console.log(`Błąd podczas ustawiania focusa na oknie. ${error.message}`);
									}
								}).catch(error => {
									console.log(`Błąd podczas pobierania listy okien. ${getErrorMessage(error)}`);
									reject(`Podczas pobierania listy okien wystąpił błąd. ${getErrorMessage(error)}`);
								});
								resolve({ filename: downloadSearchResult[0].filename, backup: true });
							}
						});
					}
				});
			}
			return await waitForDownloadFinished();
		}

		case 'printLabel': {
			let readedValue;
			let response;
			if (request.filename === '') return Promise.reject('Nie określono nazwy pliku do wydruku.');
			try {
				readedValue = await readDataFromLocalStorage(['sumatraPath', 'defaultPrinter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania zapisanych wartości ścieżki do programu SumatraPDF i drukarki do wydruku wystąpił błąd. ${getErrorMessage(error)}`);
			}
			console.log(`sumatraPath: ${readedValue.sumatraPath}, defaultPrinter: ${readedValue.defaultPrinter}, filename: ${request.filename}`);
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: "printLabel", sumatraPath: readedValue.sumatraPath, defaultPrinter: readedValue.defaultPrinter, filename: request.filename.replace('\\\\', '\\') });
			} catch (error) {
				return Promise.reject(`Podczas przesyłania wiadomości do programu drukującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (response.result === 'ok') {
				console.log('Wydrukowano');
				return Promise.resolve(response.result);
			} else {
				console.log('Błąd! Nie wydrukowano');
				return Promise.reject('Program drukujący nie zwrócił prawidłowej odpowiedzi informującej o wydrukowaniu etykiety.');
			}
		}

		case 'getInPostSendMode': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['inPostSendMode']);
			} catch (error) {
				return Promise.reject(`Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost. ${getErrorMessage(error)}`);
			}

			if (readedValue.inPostSendMode !== undefined) return Promise.resolve(readedValue.inPostSendMode);
			else return Promise.reject('Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost.');
		}

		case 'saveInPostSendMode': {
			try {
				await saveDataToLocalStorage({ inPostSendMode: request.sendMode });
			} catch (error) {
				return Promise.reject(`Podczas zapisu sposobu nadawnia przesyłek InPost wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(true);
		}

		case 'sendAnonymizedSample': {
			let fetchResponse;
			try {
				fetchResponse = await fetch(`https://tomsyty.pl/allegro-extensions/validate-buyer-errors.php`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify(request.sample)
				});
			} catch (error) {	
				return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Wzorzec nie został przesłany.`);
			}
		
			if (fetchResponse.status !== 200) return Promise.reject(`Wzorzec nie został przesłany. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			return Promise.resolve(true);
		}

		case 'updateSendParcelLink': {
			let tabs;
			try {
				tabs = await chrome.tabs.query({ url: `https://salescenter.allegro.com${request.environment}/orders*` });
				for (let tab of tabs) {
					sendMessage(tab.id, { action: 'updateSendParcelLink', orderId: request.orderId }).catch(error => { console.log(`Błąd podczas deaktywowania przycisku "Nadaj przesyłkę", ${error.message}`) });
				}
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return Promise.resolve(true);
		}

		case 'fillRefundForm': {
			let tabs;
			let response;
			try {
				tabs = await chrome.tabs.query({ url: `https://www.ifirma.pl/app/wo/*` });
				if (tabs.length === 0) return Promise.reject('Nie znaleziono otwartej karty z protokołem anulowania sprzedaży.');
				for (let tab of tabs) {
					response = await sendMessage(tab.id, { action: 'fillRefundForm', restoreList: request.restoreList });
					if (response?.success === false) {
						return Promise.reject(response.result);
					} else {
						await chrome.tabs.update(tab.id, { active: true });
						break;
					};
				}
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return Promise.resolve(true);
		}

		case 'buyerStatsGetBuyer': {
			if (request.login === undefined) return Promise.reject('Nie podano loginu kupującego.');
			let buyer;
			try {
				buyer = await buyerStatsGetBuyer(request.login);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych kupującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(buyer);
		}

		case 'buyerStatsSaveBuyer': {
			if (request.buyer === undefined) return Promise.reject('Nie podano obiektu zawierającego dane kupującego.');
			let buyer;
			try {
				buyer = await buyerStatsSaveBuyer(request.buyer);
			} catch (error) {
				return Promise.reject(`Podczas zapisu danych kupującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			return Promise.resolve(buyer);
		}

		case 'buyerStatsRemoveBase': {
			let result;
			try {
				result = await buyerStatsRemoveBase();
			} catch (error) {
				return Promise.reject(`Podczas usuwania bazy danych kupujących wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (result) return Promise.resolve(true);
			else return Promise.reject('Nie udało się usunąć bazy danych kupujących.');
		}

		case 'offerParametersGet': {
			if (request.id === undefined) return Promise.reject('Nie podano numeru oferty');
			let result;
			try {
				result = await offerParametersGet(request.id);
			} catch (error) {
				return Promise.reject(`Podczas pobierania parametrów z bazy wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (result) return Promise.resolve(result);
			else return Promise.resolve('');
		}

		case 'offerParametersSave': {
			if (request.offer === undefined) return Promise.reject('Nie podano numeru oferty');
			let result;
			try {
				result = await offerParametersSave(request.offer);
			} catch (error) {
				return Promise.reject(`Podczas zapisywania parametrów do bazy wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (result) return Promise.resolve(result);
			else return Promise.resolve('');
		}

		case 'checkShipmentsGetByStatus': {
			if (request.status === undefined) return Promise.reject('Nie wybrano statusu przesyłki');
			let result;
			try {
				result = await checkShipmentsStatusSearch(request.status);
			} catch (error) {
				return Promise.reject(`Podczas odczytywania informacji o statusach przesyłek wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (result) return Promise.resolve(result);
			else return Promise.resolve('');
		}

		case 'checkAlarms': {
			let alarms;
			try {
				alarms = await chrome.alarms.get('checkShipmentsStatusAlarm') || await chrome.alarms.get('parametersWatcherAlarm');
			} catch (error) {
				return Promise.reject(false);
			}
			return Promise.resolve(alarms? true : false)
		}

		case 'parametersWatcherEnableSchedule': {
			if (request.period === undefined || request.period < 1 || request.period > 24) return Promise.reject('Niewłaściwy okres czasu sprawdzania parametrów aukcji');
      const alarm = await parametersWatcherCheckAlarm(request.period);
      if (!alarm) {
        try {        
          await chrome.alarms.create('parametersWatcherAlarm', {
						when: roundUpToFullMinute(Date.now()),
            periodInMinutes: request.period * 60
          });

					const setAlarm = await chrome.alarms.get('parametersWatcherAlarm');
					if (setAlarm) {
						console.log(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${request.period} godzin${request.period === 1 ? 'ę' : ((request.period >= 2 && request.period <= 4) || (request.period >= 22 && request.period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						let actionTitle = await chrome.action.getTitle({});
						actionTitle = actionTitle.split('\n');
						actionTitle[0] = 'Usprawnienia serwisu Allegro';
						actionTitle = actionTitle.map(title => {
							if (title.indexOf('sprawdzanie parametrów') !== -1) {
								return `Następne sprawdzanie parametrów o ${nextAlarm}`;
							} else {
								return title;
							}
						});
						if (!actionTitle.find(title => title.indexOf('sprawdzanie parametrów') !== -1)) {
							actionTitle.push(`Następne sprawdzanie parametrów o ${nextAlarm}`);
						}
						await chrome.action.setTitle({ title: actionTitle.join('\n') });
						await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
						pwWorkEnabled = true;
						return Promise.resolve(request.period);
					}
				} catch (error) {
        	console.log(getErrorMessage(error));
         	console.log(`Nie udało się włączyć automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
					return Promise.reject(getErrorMessage(error));
				}        
        return Promise.reject('Nie udało się potwierdzić ustawienia alarmu.');
      } else {
        return Promise.resolve(alarm.periodInMinutes / 60);
      }   
    }

		case 'parametersWatcherDisableSchedule': {
      try {        
         await chrome.alarms.clear('parametersWatcherAlarm');
				 pwWorkEnabled = false;
			} catch (error) {
        console.log(`Nie udało się wyłączyć automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
        return Promise.reject(getErrorMessage(error));
      }	
			try {
				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.filter(title => title.indexOf('sprawdzanie parametrów') === -1);
				await chrome.action.setTitle({ title: actionTitle.join('\n') });

				if (Array.from(await chrome.alarms.getAll()).find(alarm => alarm.name === 'parametersWatcherAlarm' || alarm.name === 'checkShipmentsStatusAlarm')) await chrome.action.setIcon({ path: 'icon-48-timer.png' });
				else await chrome.action.setIcon({ path: 'icon-48.png' });
      } catch (error) {
        console.log(`Podczas wyłączania automatycznego sprawdzania parametrów w tle wystąpił błąd. ${getErrorMessage(error)}`);
        return Promise.reject(getErrorMessage(error));
      }
      console.log('Wyłączono automatyczne sprawdzanie parametrów w tle');
      return Promise.resolve(true);
    }

		case 'parametersWatcherRun': {
			pwWorkEnabled = true;
			chrome.alarms.onAlarm.dispatch({ name: 'parametersWatcherAlarm' });
      return Promise.resolve(true);
    }

		case 'parametersWatcherPostpone': {
			let result;
			try {
				result = await parametersWatcherPostponeSchedule();
			} catch (error) {
				return Promise.reject(false);
			}
      return Promise.resolve(result);
    }

		case 'parametersWatcherStop': {
			pwWorkEnabled = false;	
      return Promise.resolve(true);
    }

		case 'parametersWatcherRemoveBase': {
			let result;
			try {
				result = await parametersWatcherRemoveBase();
			} catch (error) {
				return Promise.reject(`Podczas usuwania bazy danych z parametrami aukcji wystąpił błąd. ${getErrorMessage(error)}`);
			}
			if (result) return Promise.resolve(true);
			else return Promise.reject('Nie udało się usunąć bazy danych z parametrami aukcji.');
		}

		case 'checkShipmentsStatusEnableSchedule': {
			if (request.period === undefined || request.period < 1 || request.period > 24) return Promise.reject('Niewłaściwy okres czasu sprawdzania statusów przesyłek');
      const alarm = await checkShipmentsStatusCheckAlarm(request.period);
      if (!alarm) {
        try {        
          await chrome.alarms.create('checkShipmentsStatusAlarm', {
						when: roundUpToFullMinute(Date.now()),
            periodInMinutes: request.period * 60
          });

					const setAlarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
					if (setAlarm) {
						console.log(`Włączono automatyczne sprawdzanie statusów przesyłek w tle co ${request.period} godzin${request.period === 1 ? 'ę' : ((request.period >= 2 && request.period <= 4) || (request.period >= 22 && request.period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						let actionTitle = await chrome.action.getTitle({});
						actionTitle = actionTitle.split('\n');
						actionTitle[0] = 'Usprawnienia serwisu Allegro';
						actionTitle = actionTitle.map(title => {
							if (title.indexOf('sprawdzanie statusów') !== -1) {
								return `Następne sprawdzanie statusów przesyłek o ${nextAlarm}`;
							} else {
								return title;
							}
						});
						if (!actionTitle.find(title => title.indexOf('sprawdzanie statusów') !== -1)) {
							actionTitle.push(`Następne sprawdzanie statusów przesyłek o ${nextAlarm}`);
						}
						await chrome.action.setTitle({ title: actionTitle.join('\n') });
						await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
						csWorkEnabled = true;
						return Promise.resolve(request.period);
					}
				} catch (error) {
        	console.log(getErrorMessage(error));
         	console.log(`Nie udało się włączyć automatycznego sprawdzania statusów przesyłek w tle. ${getErrorMessage(error)}`);
					return Promise.reject(getErrorMessage(error));
				}        
        return Promise.reject('Nie udało się potwierdzić ustawienia alarmu.');
      } else {
        return Promise.resolve(alarm.periodInMinutes / 60);
      }   
    }

		case 'checkShipmentsStatusDisableSchedule': {
      try {        
         await chrome.alarms.clear('checkShipmentsStatusAlarm');
				 csWorkEnabled = false;
			} catch (error) {
        console.log(`Nie udało się wyłączyć automatycznego sprawdzania statusów przesyłek w tle. ${getErrorMessage(error)}`);
        return Promise.reject(getErrorMessage(error));
      }	
			try { 
				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.filter(title => title.indexOf('sprawdzanie statusów') === -1);
				await chrome.action.setTitle({ title: actionTitle.join('\n') });

				if (Array.from(await chrome.alarms.getAll()).find(alarm => alarm.name === 'parametersWatcherAlarm' || alarm.name === 'checkShipmentsStatusAlarm')) await chrome.action.setIcon({ path: 'icon-48-timer.png' });
				else await chrome.action.setIcon({ path: 'icon-48.png' });
      } catch (error) {
        console.log(`Podczas wyłączania automatycznego sprawdzania statusów przesyłek w tle wystąpił błąd. ${getErrorMessage(error)}`);
        return Promise.reject(getErrorMessage(error));
      }
      console.log('Wyłączono automatyczne sprawdzanie statusów przesyłek w tle');
      return Promise.resolve(true);
    }

		case 'checkShipmentsRun': {
			csWorkEnabled = true;
			chrome.alarms.onAlarm.dispatch({ name: 'checkShipmentsStatusAlarm' });
      return Promise.resolve(true);
    }

		case 'checkShipmentsPostpone': {
			let result;
			try {
				result = await checkShipmentsPostponeSchedule();
			} catch (error) {
				return Promise.reject(false);
			}
      return Promise.resolve(result);
    }

		case 'checkShipmentsStop': {
			csWorkEnabled = false;			
      return Promise.resolve(true);
    }

		case 'getShortcutOfferTags': {
			getShortcutOfferTags().catch(error => { console.log(`Błąd! ${error.message}`) });
			break;
		}

		case 'getShortcutChangeAuctionsTitle': {
			getShortcutChangeAuctionsTitle().catch(error => { console.log(`Błąd! ${error.message}`) });
			break;
		}

		case 'debug': {
			console.log(request.info);
			break;
		}
	}
}

function roundUpToFullMinute(dateToRound) {
  const date = new Date(dateToRound);
  if (date.getSeconds() > 30) {
    date.setMinutes(date.getMinutes() + 2);
  } else date.setMinutes(date.getMinutes() + 1);
  date.setSeconds(0, 0);
  return date.getTime();
}

function roundDownToFullMinute(dateToRound) {
  const date = new Date(dateToRound);
  date.setSeconds(0, 0);
  return date.getTime();
}

function openOptionsPage() {
	chrome.runtime.openOptionsPage().catch(error => {
		console.log(`Błąd! Podczas otwierania strony opcji rozszerzenia wystąpił błąd. ${getErrorMessage(error)}`);
		showMessageFromBackground(`Błąd! Podczas otwierania strony opcji rozszerzenia wystąpił błąd. ${getErrorMessage(error)}`);
	});	
}

async function parametersWatcherPrepare() {
	await chrome.action.setBadgeBackgroundColor( { color: [0,0,0,255] });
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions', 'parametersWatcherTimerCheckbox', 'parametersWatcherPeriodInput', 'parametersWatcherScheduledTime']);
		if (readedValue.extensions === undefined || !readedValue.extensions['parametersWatcher']) return;
		const period = Number(readedValue['parametersWatcherPeriodInput']);
		if (readedValue['parametersWatcherTimerCheckbox'] && period >= 1 && period <= 24 ) {
			const alarm = await parametersWatcherCheckAlarm(period);
			if (!alarm) {
				try {  
					let alarmInfo = {
						periodInMinutes: period * 60
					}     
					
					if (Date.now() < readedValue['parametersWatcherScheduledTime']) {
						console.log('Znaleziono zaplanowany czas sprawdzania parametrów produktów: ' + new Date(readedValue['parametersWatcherScheduledTime']).toTimeString().slice(0, 5));
						alarmInfo.when = readedValue['parametersWatcherScheduledTime'];
					} else {
						alarmInfo.when = roundUpToFullMinute(Date.now());
					}
					await chrome.alarms.create('parametersWatcherAlarm', alarmInfo);	
					const setAlarm = await chrome.alarms.get('parametersWatcherAlarm');
					if (setAlarm) {
						await saveDataToLocalStorage({ parametersWatcherScheduledTime: roundDownToFullMinute(setAlarm.scheduledTime) })
						console.log(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						console.log(`Następne sprawdzanie parametrów o ${nextAlarm}`);

						let actionTitle = await chrome.action.getTitle({});
						actionTitle = actionTitle.split('\n');
						actionTitle[0] = 'Usprawnienia serwisu Allegro';
						actionTitle = actionTitle.map(title => {
							if (title.indexOf('sprawdzanie parametrów') !== -1) {
								return `Następne sprawdzanie parametrów o ${nextAlarm}`;
							} else {
								return title;
							}
						});
						if (!actionTitle.find(title => title.indexOf('sprawdzanie parametrów') !== -1)) {
							actionTitle.push(`Następne sprawdzanie parametrów o ${nextAlarm}`);
						}
						await chrome.action.setTitle({ title: actionTitle.join('\n') });
						await chrome.action.setIcon({ path: 'icon-48-timer.png' });
						pwWorkEnabled = true;
					}
				} catch (error) {
					console.log(getErrorMessage(error));
					showMessageFromBackground(`Błąd! W trakcie uruchamiania automatycznego sprawdzania parametrów produktów w tle wystąpił błąd. ${getErrorMessage(error)}`);
				}
			} else {
				const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
				console.log(`Automatyczne sprawdzanie parametrów produktów w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')} jest już aktywne. Następne sprawdzenie o ${nextAlarm}`);	
				
				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.map(title => {
					if (title.indexOf('sprawdzanie parametrów') !== -1) {
						return `Następne sprawdzanie parametrów o ${nextAlarm}`;
					} else {
						return title;
					}
				});
				if (!actionTitle.find(title => title.indexOf('sprawdzanie parametrów') !== -1)) {
					actionTitle.push(`Następne sprawdzanie parametrów o ${nextAlarm}`)
				}
				await chrome.action.setTitle({ title: actionTitle.join('\n') });
				
				await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
				pwWorkEnabled = true;
			}	
		}
		chrome.action.setPopup({ popup: 'actions_popup.html' });
	} catch (error) {
		console.log('Błąd uruchamiania automatycznego sprawdzania parametrów produktów');
	}
}

async function parametersWatcherCheckAlarm(alarmPeriod) {
  let alarm;
  try {
    alarm = await chrome.alarms.get('parametersWatcherAlarm');    
    if (alarm && (alarm.periodInMinutes === alarmPeriod * 60)) return Promise.resolve(alarm);
    else return Promise.resolve(false);
  } catch (error) {
    return Promise.reject(false);
  }
}

async function parametersWatcherDisableSchedule() {
  try {
		await chrome.alarms.clear('parametersWatcherAlarm');
		await saveDataToLocalStorage({ parametersWatcherScheduledTime: 0 })
	} catch (error) {
		console.log(getErrorMessage(error));
		return Promise.reject(`Nie udało się wyłączyć automatycznego sprawdzania parametrów w tle. ${getErrorMessage(error)}`);
	}	
	pwWorkEnabled = false;
  console.log('Wyłączono automatyczne sprawdzanie parametrów w tle');
  return Promise.resolve(true);
}

async function parametersWatcherPostponeSchedule() {
	try {
	 	const alarm = await chrome.alarms.get('parametersWatcherAlarm');
		if (alarm) {
    	await chrome.alarms.create('parametersWatcherAlarm', {
				when: roundDownToFullMinute(alarm.scheduledTime + (60 * 60000)),
        periodInMinutes: alarm.periodInMinutes
      });
			const nextAlarm = await chrome.alarms.get('parametersWatcherAlarm');
			if (nextAlarm) {
				await saveDataToLocalStorage({ parametersWatcherScheduledTime: roundDownToFullMinute(nextAlarm.scheduledTime) });
				return Promise.resolve(new Date(nextAlarm.scheduledTime).toTimeString().slice(0, 5));
			} else return Promise.reject(false);
    }
	}	catch (error) {
    return Promise.reject(false);
  }
	return Promise.resolve(true);
}


async function checkShipmentsPostponeSchedule() {
	try {
	 	const alarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
		if (alarm) {
    	await chrome.alarms.create('checkShipmentsStatusAlarm', {
				when: roundDownToFullMinute(alarm.scheduledTime + (60 * 60000)),
        periodInMinutes: alarm.periodInMinutes
      });
			const nextAlarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
			if (nextAlarm) {
				await saveDataToLocalStorage({ checkShipmentsStatusScheduledTime: roundDownToFullMinute(nextAlarm.scheduledTime) });
				return Promise.resolve(new Date(nextAlarm.scheduledTime).toTimeString().slice(0, 5));
			} else return Promise.reject(false);
    }
	}	catch (error) {
    return Promise.reject(false);
  }
	return Promise.resolve(true);
}

async function checkShipmentsStatusPrepare() {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions', 'checkShipmentsStatusTimerCheckbox', 'checkShipmentsStatusPeriodInput', 'checkShipmentsStatusScheduledTime']);
		if (readedValue.extensions === undefined || !readedValue.extensions['showShipmentStatus']) return;
		const period = Number(readedValue['checkShipmentsStatusPeriodInput']);
		if (readedValue['checkShipmentsStatusTimerCheckbox'] && period >= 1 && period <= 24 ) {
			const alarm = await checkShipmentsStatusCheckAlarm(period);
			if (!alarm) {
				try {  
					let alarmInfo = {
						periodInMinutes: period * 60
					}     
					
					if (Date.now() < readedValue['checkShipmentsStatusScheduledTime']) {
						console.log('Znaleziono zaplanowany czas sprawdzania statusów przesyłek: ' + new Date(readedValue['checkShipmentsStatusScheduledTime']).toTimeString().slice(0, 5));
						alarmInfo.when = readedValue['checkShipmentsStatusScheduledTime'];
					} else {
						alarmInfo.when = roundUpToFullMinute(Date.now());
					}
					await chrome.alarms.create('checkShipmentsStatusAlarm', alarmInfo);	
					const setAlarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
					if (setAlarm) {
						await saveDataToLocalStorage({ checkShipmentsStatusScheduledTime: roundDownToFullMinute(setAlarm.scheduledTime) })
						console.log(`Włączono automatyczne sprawdzanie statusów przesyłek w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						console.log(`Następne sprawdzanie statusów przesyłek o ${nextAlarm}`);

						let actionTitle = await chrome.action.getTitle({});
						actionTitle = actionTitle.split('\n');
						actionTitle[0] = 'Usprawnienia serwisu Allegro';
						actionTitle = actionTitle.map(title => {
							if (title.indexOf('sprawdzanie statusów') !== -1) {
								return `Następne sprawdzanie statusów przesyłek o ${nextAlarm}`;
							} else {
								return title;
							}
						});
						if (!actionTitle.find(title => title.indexOf('sprawdzanie statusów') !== -1)) {
							actionTitle.push(`Następne sprawdzanie statusów przesyłek o ${nextAlarm}`);
						}
						await chrome.action.setTitle({ title: actionTitle.join('\n') });

						await chrome.action.setIcon({ path: 'icon-48-timer.png' });
						csWorkEnabled = true;
					}
				} catch (error) {
					console.log(getErrorMessage(error));
					showMessageFromBackground(`Błąd! W trakcie uruchamiania automatycznego sprawdzania parametrów produktów w tle wystąpił błąd. ${getErrorMessage(error)}`);
				}
			} else {
				const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
				console.log(`Automatyczne sprawdzanie statusów przesyłek w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')} jest już aktywne. Następne sprawdzenie o ${nextAlarm}`);	
				
				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.map(title => {
					if (title.indexOf('sprawdzanie statusów') !== -1) {
						return `Następne sprawdzanie statusów przesyłek o ${nextAlarm}`;
					} else {
						return title;
					}
				});
				if (!actionTitle.find(title => title.indexOf('sprawdzanie statusów') !== -1)) {
					actionTitle.push(`Następne sprawdzanie statusów przesyłek o ${nextAlarm}`);
				}
				await chrome.action.setTitle({ title: actionTitle.join('\n') });
				
				await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
				csWorkEnabled = true;
			}	
		}
		chrome.action.setPopup({ popup: 'actions_popup.html' });
	} catch (error) {
		console.log('Błąd uruchamiania automatycznego sprawdzania statusów przesyłek');
	}
}

async function checkShipmentsStatusCheckAlarm() {
  let alarm;
  try {
    alarm = await chrome.alarms.get('checkShipmentsStatusAlarm');    
    if (alarm) return Promise.resolve(alarm);
    else return Promise.resolve(false);
  } catch (error) {
    return Promise.reject(false);
  }
}

async function checkShipmentsStatusDisableSchedule() {
  try {
		await chrome.alarms.clear('checkShipmentsStatusAlarm');
		await saveDataToLocalStorage({ checkShipmentsStatusScheduledTime: 0 })
		await chrome.action
	} catch (error) {
		console.log(getErrorMessage(error));
		return Promise.reject(`Nie udało się wyłączyć automatycznego sprawdzania statusów przesyłek w tle. ${getErrorMessage(error)}`);
	}	
	pwWorkEnabled = false;
  console.log('Wyłączono automatyczne sprawdzanie statusów przesyłek w tle');
  return Promise.resolve(true);
}

async function checkShipmentsStatusPostponeSchedule() {
	try {
	 	const alarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
		if (alarm) {
    	await chrome.alarms.create('checkShipmentsStatusAlarm', {
				when: roundDownToFullMinute(alarm.scheduledTime + (60 * 60000)),
        periodInMinutes: alarm.periodInMinutes
      });
			const nextAlarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
			if (nextAlarm) {
				await saveDataToLocalStorage({ checkShipmentsStatusScheduledTime: roundDownToFullMinute(nextAlarm.scheduledTime) });
				return Promise.resolve(new Date(nextAlarm.scheduledTime).toTimeString().slice(0, 5));
			} else return Promise.reject(false);
    }
	}	catch (error) {
    return Promise.reject(false);
  }
	return Promise.resolve(true);
}

function openDB(databaseName, objectStoreName, keyPath) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, 1);

    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(objectStoreName)) {
        db.createObjectStore(objectStoreName, { keyPath: keyPath });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function buyerStatsGetBuyer(login) {
  const db = await openDB('buyerStats', 'buyers', 'login');
  return new Promise((resolve, reject) => {
    const tx = db.transaction('buyers', 'readonly');
    const store = tx.objectStore('buyers');
    const request = store.get(login);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function buyerStatsSaveBuyer(buyer) {
  const db = await openDB('buyerStats', 'buyers', 'login');
  const tx = db.transaction('buyers', 'readwrite');
  const store = tx.objectStore('buyers');
  store.put(buyer);
  return tx.complete;
}

async function buyerStatsRemoveBase() {
	return new Promise((resolve, reject) => {
		const dbDeleteRequest = indexedDB.deleteDatabase('buyerStats');
		dbDeleteRequest.onsuccess = () => resolve(true);
		dbDeleteRequest.onerror = () => reject(false);
	});
}


async function offerParametersGet(id) {
	const db = await openDB('offerProducts', 'offers', 'id');
	return new Promise((resolve, reject) => {
		const tx = db.transaction('offers', 'readonly');
		const store = tx.objectStore('offers');
		const request = store.get(id);
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
}

async function offerParametersSave(offer) {
	const db = await openDB('offerProducts', 'offers', 'id');
	const tx = db.transaction('offers', 'readwrite');
	const store = tx.objectStore('offers');
	store.put(offer);	
	return tx.complete;
}

async function parametersWatcherRemoveBase() {
	return new Promise((resolve, reject) => {
		const dbDeleteRequest = indexedDB.deleteDatabase('offerProducts');
		dbDeleteRequest.onsuccess = () => resolve(true);
		dbDeleteRequest.onerror = () => reject(false);
	});
}

async function checkShipmentsStatusGetOrder(order) {
  const db = await openDB('shipmentStatus', 'orders', 'id');
  return new Promise((resolve, reject) => {
    const tx = db.transaction('orders', 'readonly');
    const store = tx.objectStore('orders');
    const request = store.get(order);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function checkShipmentsStatusSaveOrder(order) {
  const db = await openDB('shipmentStatus', 'orders', 'id');
  const tx = db.transaction('orders', 'readwrite');
  const store = tx.objectStore('orders');
  store.put(order);
  return tx.complete;
}

async function checkShipmentsStatusRemoveBase() {
	return new Promise((resolve, reject) => {
		const dbDeleteRequest = indexedDB.deleteDatabase('shipmentStatus');
		dbDeleteRequest.onsuccess = () => resolve(true);
		dbDeleteRequest.onerror = () => reject(false);
	});
}

async function checkShipmentsStatusSearch(status) {
	const db = await openDB('shipmentStatus', 'orders', 'id');
	const tx = db.transaction('orders', 'readonly');
	const store = tx.objectStore('orders');
	let orders = [];
	return new Promise((resolve, reject) => {
		store.openCursor().onsuccess = (event) => {
			const cursor = event.target.result;
			if (cursor) {
				let delivered = cursor.value.shipments.filter(shipment => shipment.status === status);
				if (delivered.length) {
					orders.push(...delivered);
				}
				cursor.continue();
			} else {
				resolve(orders)
			}
		}
		store.openCursor().onerror = (event) => {
    	reject(event);
    }
	});
}

async function checkShipmentsStatusDeleteOld() {
	const msIn24Hours = 24 * 60 * 60 * 1000;
	const currentDate = new Date();
	const db = await openDB('shipmentStatus', 'orders', 'id');
	const tx = db.transaction('orders', 'readwrite');
	const store = tx.objectStore('orders');
	return new Promise((resolve, reject) => {
		store.openCursor().onsuccess = (event) => {
			const cursor = event.target.result;
			if (cursor) {
				const shipmentsBeforeLength = cursor.value.shipments.length;
				if (shipmentsBeforeLength) {
					const shipmentsAfter = cursor.value.shipments.filter(shipment => currentDate - new Date(shipment.date) < msIn24Hours * 14);
					if (shipmentsAfter.length !== shipmentsBeforeLength) {
						if (shipmentsAfter.length === 0) {
							cursor.delete();
						} else {
							try {
								cursor.value.shipments = shipmentsAfter;
								cursor.update(cursor.value);
							} catch (error) {
								return Promise.reject(`Podczas aktualizowania w bazie danych przesyłek z zamówienia ${cursor.value.orderId} wystąpił błąd. ${getErrorMessage(error)}`);
							}
						}
					}
				}
				cursor.continue();
			} else {
				resolve(true)
			}
		}
		store.openCursor().onerror = (event) => {
    	reject(event);
    }
	});
}

async function getShortcutChangeAuctionsTitle() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['changeAuctionsTitleShortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.changeAuctionsTitleShortcut === '') {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${getErrorMessage(error)}`);
			return;
		}
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionsTitle')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.changeAuctionsTitle.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ changeAuctionsTitleShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`Podczas zapisu skrótu aktywującego wystąpił błąd. ${getErrorMessage(error)}`);
			}		
		}
	} else {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${getErrorMessage(error)}`);
			return;
		}
		
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionsTitle')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.changeAuctionsTitleShortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ changeAuctionsTitleShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`Podczas zapisu skrótu aktywującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
		}
	}
}

async function getShortcutOfferTags() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsShortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.offerTagsShortcut === '') {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${getErrorMessage(error)}`);
			return;
		}
		const assignedShortcut = commands.find(command => command.name === 'offerTags')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.offerTags.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ offerTagsShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`Podczas zapisu skrótu aktywującego wystąpił błąd. ${getErrorMessage(error)}`);
			}		
		}
	} else {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${getErrorMessage(error)}`);
			return;
		}
		
		const assignedShortcut = commands.find(command => command.name === 'offerTags')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.offerTagsShortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ offerTagsShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`Podczas zapisu skrótu aktywującego wystąpił błąd. ${getErrorMessage(error)}`);
			}
		}
	}
}

chrome.commands.onCommand.addListener(command => {
	asyncOnCommandCallback(command);
	return true;
});

async function asyncOnCommandCallback(command) {
  if (command === 'changeAuctionsTitle' || command === 'offerTags') {
		async function getCurrentTab() {
			const queryOptions = { active: true, currentWindow: true, url: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'] };
			try {
				const [tab] = await chrome.tabs.query(queryOptions);
				if (tab === undefined) throw new Error('Skrót klawiaturowy aktywny jest tylko na stronie "Mój asortyment". Jeśli masz otwartą kartę na tej stronie - odśwież ją i spróbuj ponownie.');
				return Promise.resolve(tab.id);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
		}
		let tab;
		let readedValue;
		try {
			tab = await getCurrentTab();
		} catch (error) {
			optionsPageMessage(`Błąd! ${error}`);
			return;
		}
		try {
			readedValue = await readDataFromLocalStorage([`${command + 'Shortcut'}`]);
		} catch (error) {
			optionsPageMessage(`Podczas odczytu skrótu aktywującego wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}
		let contentScripts;
		try {
			contentScripts = await chrome.scripting.getRegisteredContentScripts();
			if (contentScripts.length) {			
				if (contentScripts.some(registeredScript => registeredScript.id === command)) {
					await sendMessage(tab, { action: command, shortcut: readedValue[`${command + 'Shortcut'}`]});
				}
			} else throw new Error('Jeśli masz otwartą kartę na stronie "Mój asortyment" - odśwież ją i spróbuj ponownie.');
		} catch (error) {
			optionsPageMessage(`Błąd! ${getErrorMessage(error)}`);
			return
		}
	}
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
	let keepAlive;
  if (alarm.name === 'parametersWatcherAlarm') {
		try {
			alarm = await chrome.alarms.get('parametersWatcherAlarm');
		} catch (error) {
			console.log(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${getErrorMessage(error)}`);
			showMessageFromBackground(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		let sandbox = '';
		let readedValue;	
		try {
			const currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			if (currentBadgeColor[0] === 1) {
				const nextAlarm = await parametersWatcherPostponeSchedule();
				if (typeof(nextAlarm) === 'string') {
					console.log(nextAlarm);
					const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      		if (notificationsAllowed) {
						chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Poprzednie sprawdzania parametrów nie zostało jeszcze zakończone. Przesunięto o godzinę.' });
					} else {
						optionsPageMessage('Poprzednie sprawdzania parametrów nie zostało jeszcze zakończone. Przesunięto o godzinę.');
					}
					let actionTitle = await chrome.action.getTitle({});
					actionTitle = actionTitle.split('\n');
					actionTitle[0] = 'Usprawnienia serwisu Allegro';
					actionTitle = actionTitle.map(title => {
						if (title.indexOf('sprawdzanie parametrów') !== -1) {
							return `Następne sprawdzanie parametrów o ${nextAlarm}`;
						} else {
							return title;
						}
					});
					await chrome.action.setTitle({ title: actionTitle.join('\n') });

					return Promise.resolve(true);
				}
			}
		} catch (error) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Nie udało się sprawdzić czy poprzednie sprawdzania parametrów zostało zakończone. Pomijam sprawdzanie.' });
			} else {
				optionsPageMessage('Nie udało się sprawdzić czy poprzednie sprawdzania parametrów zostało zakończone. Pomijam sprawdzanie.');
			}
			console.log('Nie udało się sprawdzić czy poprzednie sprawdzania parametrów zostało zakończone.');
			return Promise.reject(false);
		}

    try {
			if (alarm) {
				const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
				console.log(`Następne sprawdzanie parametrów o ${nextAlarm}`);

				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.map(title => {
					if (title.indexOf('sprawdzanie parametrów') !== -1) {
						return `Następne sprawdzanie parametrów o ${nextAlarm}`;
					} else {
						return title;
					}
				});
				await chrome.action.setTitle({ title: actionTitle.join('\n') });
			}
			
			if (!keepAlive) keepAlive = setInterval(chrome.runtime.getPlatformInfo, 25000);

			readedValue = await readDataFromLocalStorage(['parametersWatcherSandbox']);
			if (readedValue.parametersWatcherSandbox === true) {
				sandbox = 'Sandbox';
			} else {
				sandbox = '';
			}
			
			readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') {
				const accessToken = readedValue[`allegroAccessToken${sandbox}`];
				let parameters = {
					accessToken: accessToken,
					environment: '',
					offset: 0
				};

				let offersCount = 0;

				await chrome.storage.session.remove('auctionsWithChangesInProducts');
				await saveDataToSessionStorage({ auctionsWithChangesInProducts: [] });

				await chrome.action.setBadgeText({ text: 'PW...' });
				let currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
				currentBadgeColor[0] = 1;
				await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });

				offersCount = await getOffersCount(parameters, 5);
				await pwProcessOffers(parameters, offersCount);

				scrollingText.toDisplay = scrollingText.toDisplay.filter(item => item.slice(0,2) !== 'PW');
				if (scrollingText.toDisplay.length === 0) {
					clearInterval(scrollingText.intervalId);
					await chrome.action.setBadgeText({ text: '' });
				}
				currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
				currentBadgeColor[0] = 0;
				await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });

				const pwChangesList = await readDataFromSessionStorage('auctionsWithChangesInProducts')
				if (pwChangesList.length) {
					const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
					if (notificationsAllowed) {
						chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: `Zakończono sprawdzanie parametrów aukcji. Wykryto zmiany w ${pwChangesList.length} aukcjach.` });
					}
				}
			} else {
				showMessageFromBackground('Błąd! Nie znaleziono tokena dostępowego Allegro. Wykonywanie sprawdzania parametrów zostało anulowane.');
			}
    } catch (error) {
			scrollingText.toDisplay = scrollingText.toDisplay.filter(item => item.slice(0,2) !== 'PW');
			if (scrollingText.toDisplay.length === 0) {
				clearInterval(scrollingText.intervalId);
				await chrome.action.setBadgeText({ text: '' });
			}
			let currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			currentBadgeColor[0] = 0;
			await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });
      console.log(getErrorMessage(error));
      showMessageFromBackground(`Błąd! ${getErrorMessage(error)}`);
    }
	}

	if (alarm.name === 'checkShipmentsStatusAlarm') {
		try {
			alarm = await chrome.alarms.get('checkShipmentsStatusAlarm');
		} catch (error) {
			console.log(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${getErrorMessage(error)}`);
			showMessageFromBackground(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${getErrorMessage(error)}`);
			return Promise.reject(false);
		}
		const sandbox = '';
		const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
		let readedValue;
		let parameters;

		try {
			const currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			if (currentBadgeColor[1] === 1) {
				const nextAlarm = await checkShipmentsPostponeSchedule();
				if (typeof(nextAlarm) === 'string') {
					console.log(nextAlarm);
					const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
					if (notificationsAllowed) {
						chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Poprzednie sprawdzania statusów przesyłek nie zostało jeszcze zakończone. Przesunięto o godzinę.' });
					} else {
						showMessageFromBackground('Poprzednie sprawdzania statusów przesyłek nie zostało jeszcze zakończone. Przesunięto o godzinę.');
					}
					let actionTitle = await chrome.action.getTitle({});
					actionTitle = actionTitle.split('\n');
					actionTitle[0] = 'Usprawnienia serwisu Allegro';
					actionTitle = actionTitle.map(title => {
						if (title.indexOf('sprawdzanie statusów') !== -1) {
							return `Następne sprawdzanie statusów przesyłek o ${nextAlarm}`;
						} else {
							return title;
						}
					});
					await chrome.action.setTitle({ title: actionTitle.join('\n') });

					return Promise.resolve(true);
				}
			}
		} catch (error) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Nie udało się sprawdzić czy poprzednie sprawdzania statusów przesyłek zostało zakończone. Pomijam sprawdzanie.' });
			} else {
				optionsPageMessage('Nie udało się sprawdzić czy poprzednie sprawdzania statusów przesyłek zostało zakończone. Pomijam sprawdzanie.');
			} console.log('Nie udało się sprawdzić czy poprzednie sprawdzania statusów przesyłek zostało zakończone.');
			return Promise.reject(false);
		}

		try {
			if (alarm) {
				const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
				console.log(`Następne sprawdzanie statusów przesyłek o ${nextAlarm}`);

				let actionTitle = await chrome.action.getTitle({});
				actionTitle = actionTitle.split('\n');
				actionTitle[0] = 'Usprawnienia serwisu Allegro';
				actionTitle = actionTitle.map(title => {
					if (title.indexOf('sprawdzanie statusów') !== -1) {
						return `Następne sprawdzanie statusów przesyłek o ${nextAlarm}`;
					} else {
						return title;
					}
				});
				await chrome.action.setTitle({ title: actionTitle.join('\n') });
			}

			if (!keepAlive) keepAlive = setInterval(chrome.runtime.getPlatformInfo, 25000);

			const currentTimestamp = Date.now();
			const searchAfterDate = new Date(currentTimestamp - (24 * 60 * 60 * 14 * 1000));
			const searchAfterDateISO = searchAfterDate.toISOString().replace(/:/g, '%3A');

			try {
				readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			} catch (error) {
				console.log(getErrorMessage(error));
				showMessageFromBackground(`Błąd! ${getErrorMessage(error)}`);
			}

			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') {
				const accessToken = readedValue[`allegroAccessToken${sandbox}`];
				parameters = {
					accessToken: accessToken,
					sandbox: sandbox,
					environment: environment,
					searchAfterDateISO: searchAfterDateISO,
					orders: [],
					offset: 0,
					totalCount: 0,
					ordersCount: 0,
					currentProgress: 0,
					previousProgress: -1,
					intervalId: 0
				};
			} else {
				showMessageFromBackground('Błąd! Nie znaleziono tokena dostępowego Allegro. Wykonywanie sprawdzania statusu przesyłek zostało anulowane.');
				return;
			}
		
			await chrome.storage.session.remove('checkShipmentsUpdate');
			await chrome.storage.session.remove('checkShipmentsStatusDone');
			await saveDataToSessionStorage({ checkShipmentsUpdate : [] });
			await chrome.action.setBadgeText({ text: 'CS...' });
			let currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			currentBadgeColor[1] = 1;
			await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });

			await checkShipmentsStatusDeleteOld();
			await csGetOrders(parameters);

			scrollingText.toDisplay = scrollingText.toDisplay.filter(item => item.slice(0,2) !== 'CS');
			if (scrollingText.toDisplay.length === 0) {
				clearInterval(scrollingText.intervalId);
				await chrome.action.setBadgeText({ text: '' });
			}
			currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			currentBadgeColor[1] = 0;
			await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });
			await saveDataToSessionStorage({ checkShipmentsStatusDone: true });
		} catch (error) {
			scrollingText.toDisplay = scrollingText.toDisplay.filter(item => item.slice(0,2) !== 'CS');
			if (scrollingText.toDisplay.length === 0) {
				clearInterval(scrollingText.intervalId);
				await chrome.action.setBadgeText({ text: '' });
			}
			let currentBadgeColor = await chrome.action.getBadgeBackgroundColor({});
			currentBadgeColor[1] = 0;
			await chrome.action.setBadgeBackgroundColor( { color: currentBadgeColor });
			await saveDataToSessionStorage({ checkShipmentsStatusDone: true });
			console.log(getErrorMessage(error));
			showMessageFromBackground(`Błąd! ${getErrorMessage(error)}`);
		}
		const csChangesList = await readDataFromSessionStorage('checkShipmentsUpdate')
		if (csChangesList?.checkShipmentsUpdate.length) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: `Zakończono sprawdzanie statusów przesyłek. Znaleziono ${csChangesList.checkShipmentsUpdate.length} przesyłek wymagających uwagi.` });
			}
		}
	}
});

async function csGetOrders(parameters) {
  try {
    await csFetchOrders(5, parameters);
  } catch (error) {
    return Promise.reject(getErrorMessage(error));
  }
}

async function csFetchOrders(count, parameters) {
  let fetchResponse;
	let response;
	let orderObject;

	if (csWorkEnabled === false) return Promise.resolve(true);

  try {
    fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms?offset=${parameters.offset}&fulfillment.status=SENT&status=READY_FOR_PROCESSING&lineItems.boughtAt.gte=${parameters.searchAfterDateISO}` , { //&lineItems.boughtAt.lte=${parameters.searchBeforeDateISO}
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csFetchOrders(count, parameters);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać listy zamówień. ${getErrorMessage(error)}`);
    }
  }
  if (fetchResponse.status === 200) {
    let result;
    try {
      result = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
    
    parameters['totalCount'] = result.totalCount;

		let i = 0;
		while (result.checkoutForms[i]) {
			const orderId = result.checkoutForms[i].id;
			try {
				orderObject = await checkShipmentsStatusGetOrder(orderId);
				if (!orderObject) {
					orderObject  = {
						id: orderId,
						shipments: []
					};
					await checkShipmentsStatusSaveOrder(orderObject);
					parameters.orders.push(orderObject);
				} else {
					if (orderObject.shipments.length === 0 || orderObject.shipments.find(shipment => shipment.status === 'ISSUE' || shipment.status === 'NOTICE_LEFT' || shipment.status === 'RETURNED' || shipment.status === 'AVAILABLE_FOR_PICKUP' || shipment.status === 'TIME_RUNNING_OUT')) {
						parameters.orders.push(orderObject);
					}
				}
			} catch (error) {
				console.log(`Podczas odczytu zamówienia ${orderId} z bazy danych wystąpił błąd. ${getErrorMessage(error)}`);
			}
			i++;
		}

		if (parameters.offset + 100 < parameters.totalCount) {
			parameters.offset += 100;
			return await csFetchOrders(5, parameters);
		}

    try {
			parameters.ordersCount = parameters.orders.length;
      await csGetOrder(5, 0, parameters);
    } catch (error) {
      return Promise.reject(getErrorMessage(error));
    } 
  } else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
        return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response;
      return await csFetchOrders(count, parameters);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await csFetchOrders(count, parameters); 
    } else {
      return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania listy zamówień. Spróbuj ponownie później.');
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csFetchOrders(count, parameters); 
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania listy zamówień, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csFetchOrders(count, parameters);      
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }	
}

async function csGetOrder(count = 5, i, parameters) {
	let fetchResponse;
	let response;
	let fetchData;
	
	if (csWorkEnabled === false) return Promise.resolve(true);
	parameters.currentProgress = Math.ceil((i / parameters.ordersCount) * 100);
	if (parameters.currentProgress > parameters.previousProgress) {
		parameters.previousProgress = parameters.currentProgress;
		clearInterval(scrollingText.intervalId);
		if (parameters.currentProgress < 100) showScrollingBadge(`CS${parameters.currentProgress}%`);
	}

	const msIn24Hours = 24 * 60 * 60 * 1000;
	const currentDate = new Date();

  if (parameters.orders[i] === undefined) {
		console.log('Zakończono sprawdzanie statusów przesyłek.');
		clearInterval(parameters.intervalId);
  	return Promise.resolve(true);
  }
  let orderId = parameters.orders[i].id;
	let trackingNumber;
	let carrier;
	let date;

	try {
    fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/order/checkout-forms/${orderId}/shipments` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${parameters.accessToken}`,
        'Content-Type': 'application/vnd.allegro.public.v1+json',
        'Accept': 'application/vnd.allegro.public.v1+json'
      }
    });
  } catch (error) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csGetOrder(count, i, parameters);      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać numerów przesyłek dla zamówienia ${orderId}. ${getErrorMessage(error)}`);
    }
  }

	if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
      return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
    }
	}	else if (fetchResponse.status === 401) {
    if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
        return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response;
      return await csGetOrder(count, i, parameters);  
    } else {
      return Promise.reject(`Nie udało się pobrać numerów przesyłek dla zamówienia ${orderId}. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else if (fetchResponse.status === 429) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
      return await csGetOrder(count, i, parameters); 
    } else {
      return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania numerów przesyłek dla zamówienia ${orderId}. Spróbuj ponownie później.`);
    }
  } else if (fetchResponse.status === 500) {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csGetOrder(count, i, parameters); 
    } else {
      return Promise.reject(`Błąd serwera podczas pobierania numerów przesyłek dla zamówienia ${orderId}, spróbuj ponownie później.`);
    }
  } else {
    if (--count) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await csGetOrder(count, i, parameters);      
    } else {
      return Promise.reject(`Nie udało się pobrać numerów przesyłek dla zamówienia ${orderId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }											
  }	

	let shipmentsCounter = 0;
	let shipments = fetchData.shipments;
	while (shipments[shipmentsCounter]) {
		trackingNumber = shipments[shipmentsCounter].waybill;
		carrier = shipments[shipmentsCounter].carrierId;
		date = shipments[shipmentsCounter].createdAt;
		let trackingStatus;
		let fetchResponse;
		let fetchData;
		let count = 5;
		while (count) {
			try {
				fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/order/carriers/${carrier}/tracking?waybill=${trackingNumber}`, {
					'method': 'GET',
					'headers': {
						'Authorization': `Bearer ${parameters.accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					}
				});
			} catch (error) {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					continue;
				} else {
					return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać statusu przesyłki ${trackingNumber} dla zamówienia ${orderId}. ${getErrorMessage(error)}`);
				}
			}

			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}
			}	else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await refreshAllegroAccessToken();
						parameters.accessToken = response;
						continue;
					} catch (error) {
						return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
					}
				} else {
					return Promise.reject('Nie udało się zalogować użytkownika.');
				}
			} else if (fetchResponse.status === 403) {
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			} else if (fetchResponse.status === 429) {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
					continue;
				} else {
					return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania statusu przesyłki ${trackingNumber} dla zamówienia ${orderId}. Spróbuj ponownie później.`);
				}
			} else if (fetchResponse.status === 500) {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					continue;
				} else {
					return Promise.reject(`Błąd serwera podczas sprawdzania statusu przesyłki ${trackingNumber} dla zamówienia ${orderId}, spróbuj ponownie później.`);
				}
			} else {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					continue;
				} else {
					return Promise.reject(`Nie udało się pobrać statusu przesyłki ${trackingNumber} dla zamówienia ${orderId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}
			}

			trackingStatus = fetchData?.waybills?.[0]?.trackingDetails?.statuses.find(status => status.code === 'DELIVERED' || status.code === 'RETURNED');
			if (trackingStatus) {
				if (parameters.orders[i].shipments.length === 0) {
					parameters.orders[i].shipments.push({
						waybill: trackingNumber,
						carrier: carrier,
						date: date,
						status: trackingStatus.code
					});
				} else {
					parameters.orders[i].shipments = shipments.map(shipment => {
						if (shipment.waybill === trackingNumber) {
							return {
								waybill: trackingNumber,
								carrier: carrier,
								date: date,
								status: trackingStatus.code
							}
						} else {
							return shipment;
						}
					});
				}
				try {
					await checkShipmentsStatusSaveOrder({
						id: orderId,
						shipments: parameters.orders[i].shipments
					});
				} catch (error) {
					return Promise.reject(`Podczas zapisu do bazy danych statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
				}
				if (trackingStatus.code === 'RETURNED') {
					try {
						let changesList = await readDataFromSessionStorage('checkShipmentsUpdate');
						changesList.checkShipmentsUpdate.push({ 
							waybill: trackingNumber,
							carrier: carrier,
							status: trackingStatus.code  
						});
						await saveDataToSessionStorage({ checkShipmentsUpdate: changesList.checkShipmentsUpdate });
					} catch (error) {
						console.log(`Podczas zapisu do pamięci statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
					}
				}
				
			} else {
 				trackingStatus = fetchData?.waybills?.[0]?.trackingDetails?.statuses.find(status => status.code === 'ISSUE' || status.code === 'NOTICE_LEFT');
				if (trackingStatus) {
					if (parameters.orders[i].shipments.length === 0) {
						parameters.orders[i].shipments.push({
							waybill: trackingNumber,
							carrier: carrier,
							date: date,
							status: trackingStatus.code
						});
					} else {
						parameters.orders[i].shipments = shipments.map(shipment => {
							if (shipment.waybill === trackingNumber) {
								return {
									waybill: trackingNumber,
									carrier: carrier,
									date: date,
									status: trackingStatus.code
								}
							} else {
								return shipment;
							}
						});
					}
					try {
						await checkShipmentsStatusSaveOrder({
							id: orderId,
							shipments: parameters.orders[i].shipments
						});
					} catch (error) {
						return Promise.reject(`Podczas zapisu do bazy danych statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
					}

					try {
						let changesList = await readDataFromSessionStorage('checkShipmentsUpdate');
						changesList.checkShipmentsUpdate.push({ 
							waybill: trackingNumber,
							carrier: carrier,
							status: trackingStatus.code  
						});
						await saveDataToSessionStorage({ checkShipmentsUpdate: changesList.checkShipmentsUpdate });
					} catch (error) {
						console.log(`Podczas zapisu do pamięci statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
					}
				
				} else {
					trackingStatus = fetchData?.waybills?.[0]?.trackingDetails?.statuses.filter(status => status.code === 'AVAILABLE_FOR_PICKUP');
					if (trackingStatus.length) {
						if (trackingStatus.length > 1) {
							let firstStatus = trackingStatus.reduce((earlier, later) => {
								return new Date(later.occurredAt) < new Date(earlier.occurredAt) ? later : earlier
							});
							trackingStatus = firstStatus;
						}
						
						const lastChecked = new Date(trackingStatus.occurredAt);
						const msDifference = currentDate - lastChecked;

						if (msDifference >= msIn24Hours) {
							if (fetchData.carrierId === 'ORLEN' && msDifference < msIn24Hours * 2) break;
							parameters.orders[i].shipments = shipments.map(shipment => {
								if (shipment.waybill === trackingNumber) {
									return {
										waybill: trackingNumber,
										carrier: carrier,
										date: date,
										status: 'TIME_RUNNING_OUT'
									}
								} else {
									return shipment;
								}
							});
							try {
								await checkShipmentsStatusSaveOrder({
									id: orderId,
									shipments: parameters.orders[i].shipments
								});
								
							} catch (error) {
								return Promise.reject(`Podczas zapisu do bazy danych statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
							}
							
							try {
								let changesList = await readDataFromSessionStorage('checkShipmentsUpdate');
								changesList.checkShipmentsUpdate.push({ 
									waybill: trackingNumber,
									carrier: carrier,
									status: 'TIME_RUNNING_OUT'  
								});
								await saveDataToSessionStorage({ checkShipmentsUpdate: changesList.checkShipmentsUpdate });
							} catch (error) {
								console.log(`Podczas zapisu do pamięci statusu przesyłki ${trackingNumber} z zamówienia ${orderId} wystąpił błąd. ${getErrorMessage(error)}`);
							}
						}
					}
				}
			}
			break;
		}
					
		shipmentsCounter++;
	}
	return await csGetOrder(5, ++i, parameters);
} 

async function getOffersCount(parameters, count) {
	let result, response, fetchResponse, offersCount;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1&publication.status=ACTIVE&publication.status=ENDED`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać liczby aukcji.');
		}
	}
	if (fetchResponse.status === 200) {
		try {
			result = await fetchResponse.json();
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}
		offersCount = result.totalCount;
		return Promise.resolve(offersCount);
	} else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await refreshAllegroAccessToken();
			} catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
			}
			parameters.accessToken = response;  
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject('Nie udało się zalogować użytkownika.');
		}		
	} else if (fetchResponse.status === 403) {
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject(`Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}											
	}	
}

async	function pwProcessOffers(parameters, offersCount) {
	let intervalId;
	let currentProgress = 0, previousProgress = -1;
	let result, response, fetchResponse;

	try {
		await getOffers(0, 5, parameters, offersCount);
	} catch (error) {
		console.log('Błąd podczas sprawdzania parametrów aukcji.');
		return Promise.reject(`Błąd podczas sprawdzania parametrów aukcji. ${getErrorMessage(error)}`);
	}

	async function getOffers(offset, count, parameters, offersCount) {
		if (pwWorkEnabled === false) return Promise.resolve(true);
		currentProgress = Math.ceil((offset / offersCount) * 100);
		if (currentProgress > previousProgress) {
			previousProgress = currentProgress;
			clearInterval(scrollingText.intervalId);
			if (currentProgress < 100) showScrollingBadge(`PW${currentProgress}%`);
		}

		if (offset > offersCount) {
			console.log('Zakończono pobieranie parametrów ofert.');
			clearInterval(intervalId);
			return Promise.resolve(true);
		}
		try {
			fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=10&publication.status=ACTIVE&publication.status=ENDED`, {
				'method': 'GET',
				'headers': {
					'Authorization': `Bearer ${parameters.accessToken}`,
					'Content-Type': 'application/vnd.allegro.public.v1+json',
					'Accept': 'application/vnd.allegro.public.v1+json'
				}
			});
		} catch (error) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać aukcji.');
			}
		}
		if (fetchResponse.status === 200) {
			try {
				result = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
			}
						
			let offersList = [];
			result.offers.forEach(offer => {
				offersList.push(offer.id);
			});

			if (offersList.length) {
				do {
					if (pwWorkEnabled === false) break;
					const offerId = offersList.shift();
					if (offerId === undefined) {
						if (result.totalCount > (offset + 10)) {
							await new Promise(resolve => setTimeout(resolve, 0));
							return await getOffers(offset + 10, 5, parameters, offersCount);
						} else {
							console.log('Zakończono pobieranie parametrów ofert.');
							clearInterval(intervalId);
							return Promise.resolve(true);
						}
					}

					let offer, offerStored, changeOccured, updatedImages;
					try {
						offer = await pwGetOfferProductData(5, offerId, parameters);
						console.log('Aktualne dane aukcji:');
						console.log(offer);
						offerStored = await offerParametersGet(offerId);
						if (offerStored === undefined) {
							console.log('Brak aukcji w bazie, zapisano');
							offerParametersSave(offer);
							continue;
						}

						console.log('Zapisane dane aukcji:');
						console.log(offerStored);

						for (let i = 0; i < offer.products.length; i++) {
							[changeOccured, updatedImages] = await compareObjects(offer.products[i], offerStored.products[i]);
							if (updatedImages.updated) {
								console.log('Nastąpiła zmiana adresu obrazka przy zachowaniu tej samej wielkości, aktualizuję zapisane dane');
								for (let j = 0; j < updatedImages.images.length; j++) {
									console.log(`Zmiana z ${updatedImages.images[j].stored} na ${updatedImages.images[j].current}`);
									const imageIndex = offerStored.products[i].images.indexOf(updatedImages.images[j].stored);
									if (imageIndex !== -1) {
										offerStored.products[i].images[imageIndex] = updatedImages.images[j].current;
										try {
											await offerParametersSave(offerStored);
										} catch (error) {
											console.log(`Błąd podczas zapisywania zaktualizowanych danych aukcji ${offerId} do bazy. ${getErrorMessage(error)}`);
										}
									}
								}
							}
							if (changeOccured) {
								console.log(`Produkt w ofercie ${offerId} uległ zmianie`);
								const pwChangesList = await readDataFromSessionStorage('auctionsWithChangesInProducts');
								pwChangesList.auctionsWithChangesInProducts.push({ number: offerId, visited: false });
								await saveDataToSessionStorage({ auctionsWithChangesInProducts: pwChangesList.auctionsWithChangesInProducts });
								const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      					if (notificationsAllowed) {
									chrome.notifications.create('AllegroExtensionsProductChange', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: `Znaleziono zmiany w produktach`, buttons: [{ title: 'Pokaż wyniki sprawdzania' }], silent: true }).catch(() => {});
								}
							}
						}
					} catch (error) {
						console.log(`Błąd! ${getErrorMessage(error)}`);
					}
				} while (offersList.length > 0);

				if (result.totalCount > (offset + 10) && pwWorkEnabled) {
					await new Promise(resolve => setTimeout(resolve, 0));
					return await getOffers(offset + 10, 5, parameters, offersCount);
				} else {
					console.log('Zakończono pobieranie parametrów ofert.');
					clearInterval(intervalId);
					return Promise.resolve(true);
				}
			}
		} else if (fetchResponse.status === 401) {
			if (--count) {
				try {
					response = await refreshAllegroAccessToken();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				parameters.accessToken = response; 
				return await getOffers(offset, count, parameters, offersCount) 
			} else {
				return Promise.reject('Nie udało się zalogować użytkownika.');
			}		
		} else if (fetchResponse.status === 403) {
			return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
		} else if (fetchResponse.status === 429) {
			if (--count) {
        await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject('Przekroczono limit zapytań do API Allegro podczas pobierania listy aukcji. Spróbuj ponownie później.');
			}
		}	else if (fetchResponse.status === 500) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject(`Błąd serwera w trakcie pobierania listy aukcji, spróbuj ponownie później.`);
			}
		} else {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject(`Nie udało się pobrać listy aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			}
		}
	}
}

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
	if (buttonIndex === 0) {
		if (notificationId.indexOf('AllegroExtensionsProductChange') === 0) {
			chrome.tabs.create({ url: chrome.runtime.getURL('actions_popup.html') }).catch(() => {});
		}
	}
});

async function pwGetOfferProductData(count, offerId, parameters) {
	let fetchResponse, response;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać parametrów produktu w ofercie ${offerId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let offerData;
		let offerProducts = [];
		try {
			offerData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (offerData.productSet !== undefined) {
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        let product;
        try {
          product = await pwGetProductData(5, productId, parameters);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        offerProducts.push(product);
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts });
		}
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response;
      return await pwGetOfferProductData(count, offerId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania parametrów produktu w ofercie ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów produktu w ofercie ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać parametrów produktu w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}

async function pwGetProductData(count, productId, parameters) {
	let fetchResponse, response;
  const product = {
    id: productId,
    name: '',
    parameters: [],
    images: []
  }
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać parametrów produktu ${productId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let productData;
		try {
			productData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}	
													
		if (productData.name !== undefined) {
      product.name = productData.name;
      productData.parameters.forEach(parameter => product.parameters.push({ name: parameter.name, values: parameter.valuesLabels }));
      productData.images.forEach(image => product.images.push(image.url));
			return Promise.resolve(product);
		} else return Promise.reject(`W pobranych danych produktu nie znaleziono wymaganych parametrów.`);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      parameters.accessToken = response;
      return await pwGetProductData(count, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
      await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas pobierania parametrów produktu ${productId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów produktu ${productId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać parametrów produktu ${productId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
		}
	}
}

async function compareObjects(current, stored) {
	let changeOccured = false; 
	let updatedImages = {
		 updated: false,
		 images: []
	};

	if (current.name !== stored.name) {
		changeOccured = true;
	}

	if (current.images.length !== stored.images.length && current.images.length) {
		changeOccured = true;
	}

	for (let i = 0; i < current.images.length; i++) {
		let image;
		image = stored.images.find(image => image === current.images[i]);
		if (image === undefined) {
			let foundImageBySize = false;
			const currentImageSize = await getImageSize(current.images[i]);
			if (currentImageSize) {
				for (let j = 0; j < stored.images.length; j++) {
					const storedImageSize = await getImageSize(stored.images[j]);
					if (storedImageSize && currentImageSize === storedImageSize) {
						foundImageBySize = true;
						updatedImages.updated = true;
						updatedImages.images.push({ 'current': current.images[i], 'stored': stored.images[j] });
						break;
					}
				}
			} else changeOccured = true;

			if (!foundImageBySize) {
				changeOccured = true;
      }
		}
	}

	for (let i = 0; i < stored.images.length; i++) {
		let image;
		image = current.images.find(image => image === stored.images[i]);
		if (image === undefined && !updatedImages.images.some(updatedImage => updatedImage.stored === stored.images[i])) {
			changeOccured = true;
		}
	}	

	if (current.images.length) {
		for (let i = 0; i < stored.images.length; i++) {
			let image;
			image = current.images.find(image => image === stored.images[i]);
			if (image === undefined && !updatedImages.images.some(updatedImage => updatedImage.stored === stored.images[i])) {
				changeOccured = true;
			}
		}
	}
	
	if (current.parameters.length !== stored.parameters.length) {
		changeOccured = true;
	}

	for (let i = 0; i < current.parameters.length; i++) {
		let parameter;
		parameter = stored.parameters.find(parameter => parameter.name === current.parameters[i].name);
		if (parameter === undefined) {
			changeOccured = true;
		} 
	}

	for (let i = 0; i < stored.parameters.length; i++) {
		let parameter;
		parameter = current.parameters.find(parameter => parameter.name === stored.parameters[i].name);
		if (parameter === undefined) {
			changeOccured = true;
		}
	}
	
	return Promise.resolve([changeOccured, updatedImages]);
}

async function getImageSize(imageUrl) {
  try {
    const fetchResponse = await fetch(imageUrl, { method: 'HEAD' });
    const contentLength = fetchResponse.headers.get('content-length');
    return contentLength ? parseInt(contentLength, 10) : null;
  } catch (error) {
    console.log(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać informacji o rozmiarze obrazka ${imageUrl}. ${error.message ? error.message : error}`);
    return null;
  }
}

function showScrollingBadge(text) {
  if (!scrollingText.toDisplay.find(item => item.slice(0,2).indexOf(text.slice(0,2)) !== -1)) {
    scrollingText.toDisplay.push(text);
  } else {
    scrollingText.toDisplay = scrollingText.toDisplay.filter(item => item.slice(0,2) !== text.slice(0,2));
    scrollingText.toDisplay.unshift(text);
    scrollingText.index = 1;
  }

  if (scrollingText.toDisplay.length === 1) scrollingText.index = 1;

	let badgeText = scrollingText.toDisplay.join('/');
	chrome.action.setBadgeText({ text: badgeText.slice(0,4).padEnd(4) });
	scrollingText.intervalId = setInterval(() => {
		if (scrollingText.index >= badgeText.length) {
			scrollingText.index = 0;
		}
		const slicedText = badgeText.slice(scrollingText.index, scrollingText.index + 4);
		chrome.action.setBadgeText({ text: slicedText.padEnd(8 - slicedText.length) });
		scrollingText.index += 1;
	}, 1000);
}

async function refreshAllegroAccessToken(mode) {
	let sandbox = (mode === 'sandbox' ? 'Sandbox' : '');
	const environment = (mode === 'sandbox' ? '.allegrosandbox.pl' : '');
	let readedValue;
	
	try {
		readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
	} catch (error) {
		return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
	}
	if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

	const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
	const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
	const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
	const redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');

	async function refreshToken(count = 5) {
		let fetchResponse;
		let fetchData;
		try {
			fetchResponse = await fetch(`https://allegro.pl${environment}/auth/oauth/token`, {
				method: 'POST',
				headers: {
					'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				body: encodeURI(`grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`)
			});
		} catch (error) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await refreshToken(count);
			} else {
				return Promise.reject('Podczas wysyłania żądania wystąpił błąd. Nie udało się odświeżyć tokena dostępowego. Jeśli problem dalej będzie występował, spróbuj zalogować aplikację ponownie na stronie opcji rozszerzenia.');
			}
		}

		if (fetchResponse.status === 200) {
			try {
				fetchData = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
			}

			if (fetchData.access_token === undefined || fetchData.refresh_token === undefined || fetchData.scope === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

			try {
				await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token, allegroTokenScopes: fetchData.scope.split(' ').join(', ') });
			} catch (error) {
				return Promise.reject(`Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów. ${getErrorMessage(error)}`);
			}

			return Promise.resolve(fetchData.access_token);
		} else {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await refreshToken(count);
			} else {
				return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Jeśli problem dalej będzie występował, spróbuj zalogować aplikację ponownie na stronie opcji rozszerzenia.');
			}
		}
	}
	try {
		const result = await refreshToken();
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(result);
	}
	
}

async function getCurrentTab() {
  const queryOptions = { active: true, currentWindow: true, status: 'complete', url: [`https://salescenter.allegro.com/*`, `https://salescenter.allegro.com.allegrosandbox.pl/*`] };
  try {
    let [tab] = await chrome.tabs.query(queryOptions);
    return Promise.resolve(tab);
  } catch (error) {
    return Promise.reject('Nie udało się pobrać aktywnej karty.');
  }
}

async function showMessageFromBackground(message) {
  let tab;
  let response;
  try {
    tab = await getCurrentTab();
  } catch (error) {
    console.log(error);
  }

  if (tab !== undefined) {
    try {
      response = await sendMessage(tab.id, { action: 'toast', message: message });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      console.log(getErrorMessage(error));
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: message });
      } else {
        optionsPageMessage(message);
      }
    }
  } else {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: message });
		} else {
			optionsPageMessage(message);
		}    
  }
  return Promise.resolve(true);
}


(async function checkUpdate() {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['updateLastChecked']);
	} catch (error) {
		optionsPageMessage(`Błąd! Podczas odczytu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}
	if (!readedValue.updateLastChecked) {
		const currentDate = new Date();
		readedValue.updateLastChecked = currentDate.toString();
		try {
			await saveDataToLocalStorage({ updateLastChecked: readedValue.updateLastChecked });
			return;
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}
	}

	const currentDate = new Date();
	const lastChecked = new Date(readedValue.updateLastChecked);

	const msDifference = currentDate - lastChecked;
	const msIn24Hours = 24 * 60 * 60 * 1000;

	if (msDifference >= msIn24Hours) {
		try {
			await saveDataToLocalStorage({ updateLastChecked: currentDate.toString() });
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}
	} else {
		console.log('Nie minęły 24h od ostatniego sprawdzania aktualizacji. Pomijam sprawdzanie aktualizacji.');
		return;
	}
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Allegro-Extensions/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
})();
