const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const SHORTCUT_SAVING_ERROR = 'Podczas zapisu skrótu aktywującego wystąpił błąd.';
const SHORTCUT_READING_ERROR = 'Podczas odczytu skrótu aktywującego wystąpił błąd.';
const UNABLE_TO_REFRESH_TOKENS = 'Nie udało się odświeżyć tokenów dostępowych.';
const REFRESHED_TOKENS_SAVE_ERROR = 'Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów.';

chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
const environment = '.allegrosandbox.pl';
let pwWorkEnabled = false;

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(true);
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(result);
    });
  });
}

async function sendMessage(tab, data) {
	return new Promise((resolve, reject) => {
		chrome.tabs.sendMessage(tab, data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(response);
		});
	});
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

function getWindows() {
	return new Promise((resolve, reject) => {
		chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(response);
		});
	});
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		console.log('Ustawianie domyślnych wartości...');
		chrome.storage.local.set({
			extensions: { changeInvoicesIconColor: false, autofillPackageSize: false, autoprintLabel: false, changeAuctionsTitle: false, validateBuyerAddressErrors: false, inPostSendMode: false, fastStockManager: false, restoreCancelled: false, restoreReturned: false, showProductName: false, offerTags: false, showStockLeft: false, shipmentExistsWarning: false, sendMessageFromOrdersPage: false, additionalOrdersSortingOptions: false, showShipmentStatus: false, buyerStats: false, erliActions: false, parametersWatcher: false, allegroAPI: false },
			allegroAPIClientId: '',
			allegroAPIClientSecret: '',
			allegroAccessToken: '',
			allegroRefreshToken: '',
			allegroTokenScopes: '',
			allegroAPIClientIdSandbox: '',
			allegroAPIClientSecretSandbox: '',
			allegroAPIOAuthConnectorSandbox: '',
			allegroAccessTokenSandbox: '',
			allegroRefreshTokenSandbox: '',
			allegroTokenScopesSandbox: '',
			erliToken: '',
			erliTokenSandbox: '',
			erliAlwaysSyncToSandbox: false,
			erliPriceListName: '', 
			erliObligatoryName: '',
			erliVoluntaryName: '',
			erliReturnsName: '',
			erliPriceApplyDiscountCheckbox: false,
			erliPriceAmountRadio: true,
			erliPricePercentRadio: false,
			erliPriceStepsRadio: false,
			erliPriceAmountValue: 0,
			erliPricePercentValue: 0,
			erliPriceSteps: [],
			erliFastStockMaganerCheckbox: false,
			erliRestoreCancelledCheckbox: false,
			erliRestoreReturnedCheckbox: false,
			erliShowStockLeftCheckbox: false,
			responsibleProducers: [],
			responsiblePersons: [],
			parametersWatcherTimerCheckbox: false,
			parametersWatcherSandbox: false,
			parametersWatcherPeriodInput: 3,
			parametersWatcherScheduledTime: 0,
			color: '#4a86e8',
			filter: 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);',
			inPostSendMode: 1,
			iFirmaReturns: false,
			buyerAddressErrorsFeedback: false,
			defaultPrinter: '',
			sumatraPath: '',
			changeAuctionsTitleShortcut: '',
			offerTagsShortcut: '',
			offerTagsDefaultHidden: false,
			updateLastChecked: '',
			returnsDoneList: [],
			shippingMethods: [
				{	name: 'Allegro Paczkomaty InPost',										size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost' },
				{	name: 'Allegro Paczkomaty InPost pobranie',						size1: 'Gabaryt A 64x38x8cm, 25kg', size2: 'Gabaryt B 64x38x19cm, 25kg', size3: 'Gabaryt C 64x38x41cm, 25kg', default: '1', defaultName: 'Allegro Paczkomaty InPost pobranie' },
				{	name: 'Allegro miniKurier24 InPost',									weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost'	},
				{	name: 'Allegro miniKurier24 InPost pobranie',					weight1: '', maxWeight: '10',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro miniKurier24 InPost pobranie' },
				{	name: 'Allegro Kurier24 InPost',											weight1: '', maxWeight: '30',	length1: '', minLength: '1',	maxLength: '80', width1: '',	minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost' },
				{	name: 'Allegro Kurier24 InPost pobranie',							weight1: '', maxWeight: '30', length1: '', minLength: '1',	maxLength: '80', width1: '', minWidth: '1', maxWidth: '80', height1: '', minHeight: '1', maxHeight: '80', default: '1', defaultName: 'Allegro Kurier24 InPost pobranie' },
				{	name: 'Allegro Automat ORLEN Paczka',									size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Automat ORLEN Paczka' },
				{	name: 'Allegro Odbiór w Punkcie ORLEN Paczka',				size1: 'Gabaryt S 60x38x8cm, 25kg', size2: "Gabaryt M 60x38x19cm, 25kg", size3: "Gabaryt L 60x38x41cm, 25kg", default: '1', defaultName: 'Allegro Odbiór w Punkcie ORLEN Paczka' },
				{	name: 'Allegro One Box, DPD',													weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Box, DPD' },
				{	name: 'Allegro One Box, UPS',													size1: 'Gabaryt S 64x38x8cm, 1kg', size2: 'Gabaryt S 64x38x8cm, 5kg', size3: 'Gabaryt S 64x38x8cm, 10kg', size4: "Gabaryt M 64x38x19cm, 1kg", size5: "Gabaryt M 64x38x19cm, 5kg", size6: "Gabaryt M 64x38x19cm, 10kg", size7: "Gabaryt L 64x38x41cm, 1kg", size8: "Gabaryt L 64x38x41cm, 5kg", size9: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro One Box, UPS' },
				{	name: 'Allegro One Punkt, DPD',												weight1: '',	maxWeight: '20', 	length1: '', minLength: '1', 	maxLength: '64', width1: '', 	minWidth: '1', 	maxWidth: '38', 	height1: '', minHeight: '1', maxHeight: '41', default: '1', defaultName: 'Allegro One Punkt, DPD' },
				{	name: 'Allegro One Punkt, UPS',												size1: 'Gabaryt S 64x38x8cm, 1kg', size2: 'Gabaryt S 64x38x8cm, 5kg', size3: 'Gabaryt S 64x38x8cm, 10kg', size4: "Gabaryt M 64x38x19cm, 1kg", size5: "Gabaryt M 64x38x19cm, 5kg", size6: "Gabaryt M 64x38x19cm, 10kg", size7: "Gabaryt L 64x38x41cm, 1kg", size8: "Gabaryt L 64x38x41cm, 5kg", size9: "Gabaryt L 64x38x41cm, 20kg", default: '1', defaultName: 'Allegro One Punkt, UPS' },
				{	name: 'Allegro One Kurier',														weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '120', width1: '',	minWidth: '1', 	maxWidth: '76', 	height1: '', 	minHeight: '1', maxHeight: '76', 	default: '1',	defaultName: 'Allegro One Kurier' },
				{	name: 'Allegro Kurier UPS',														weight1: '',	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '100', width1: '',	minWidth: '1', 	maxWidth: '76', 	height1: '',	minHeight: '1', maxHeight: '76', 	default: '1', defaultName: 'Allegro Kurier UPS'	},
				{	name: 'Allegro Kurier UPS pobranie', 									weight1: '',	maxWeight: '31.5', 	length1: '',	minLength: '1',		maxLength: '100',	width1: '', minWidth: '1',	maxWidth: '76',		height1: '',	minHeight: '1',	maxHeight: '76', 	default: '1', defaultName: 'Allegro Kurier UPS pobranie' },
				{	name: 'Allegro Odbiór w Punkcie UPS',									weight1: '',	maxWeight: '20',		length1: '',	minLength: '1',		maxLength: '97',	width1: '', minWidth: '1',	maxWidth: '97',		height1: '',	minHeight: '1',	maxHeight: '97', 	default: '1', defaultName: 'Allegro Odbiór w Punkcie UPS'	},
				{	name: 'Allegro Kurier DPD',														weight1: '',	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1', 	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD' },
				{	name: 'Allegro Kurier DPD pobranie', 									weight1: '', 	maxWeight: '31.5', 	length1: '', 	minLength: '1', 	maxLength: '150', width1: '', minWidth: '1',	maxWidth: '150', 	height1: '', 	minHeight: '1', maxHeight: '150', default: '1', defaultName: 'Allegro Kurier DPD pobranie' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup', 					weight1: '', 	maxWeight: '20',		length1: '',	minLength: '1',		maxLength: '100',	width1: '', minWidth: '1',	maxWidth: '100', 	height1: '', 	minHeight: '1', maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup' },
				{	name: 'Allegro Odbiór w Punkcie DPD Pickup pobranie',	weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '1', 	maxLength: '100', width1: '', minWidth: '1', 	maxWidth: '100', 	height1: '',	minHeight: '1',	maxHeight: '100', default: '1', defaultName: 'Allegro Odbiór w Punkcie DPD Pickup pobranie' },
				{	name: 'Allegro Automat DHL POP BOX',									weight1: '',	maxWeight: '25', 		length1: '', 	minLength: '1', 	maxLength: '64', 	width1: '', minWidth: '1', 	maxWidth: '38', 	height1: '', 	minHeight: '1', maxHeight: '41', 	default: '1',	defaultName: 'Allegro Kurier DPD' },
				{	name: 'Allegro Kurier Pocztex', 											weight1: '', 	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120', width1: '', minWidth: '10', maxWidth: '120', 	height1: '', 	minHeight: '1', maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex' },
				{	name: 'Allegro Kurier Pocztex pobranie',							weight1: '',	maxWeight: '30', 		length1: '', 	minLength: '16',	maxLength: '120',	width1: '',	minWidth: '10',	maxWidth: '120',	height1: '',	minHeight: '1',	maxHeight: '120', default: '1', defaultName: 'Allegro Kurier Pocztex pobranie' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex', 						weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70', 	width1: '',	minWidth: '10', maxWidth: '60', 	height1: '', 	minHeight: '1', maxHeight: '60', 	default: '1',	defaultName: 'Allegro Odbiór w Punkcie Pocztex' },
				{	name: 'Allegro Odbiór w Punkcie Pocztex pobranie',		weight1: '',	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '70',	width1: '',	minWidth: '10',	maxWidth: '60',		height1: '',	minHeight: '1',	maxHeight: '60', 	default: '1', defaultName: 'Allegro Odbiór w Punkcie Pocztex pobranie' },
				{	name: 'Allegro Automat Pocztex', 											weight1: '', 	maxWeight: '20', 		length1: '', 	minLength: '16',	maxLength: '65', 	width1: '', minWidth: '10', maxWidth: '42', 	height1: '', 	minHeight: '1', maxHeight: '40', 	default: '1',	defaultName: 'Allegro Automat Pocztex' }
			]
		}).then(() => {
			chrome.runtime.openOptionsPage(() => {
			});
		}).catch(error => {
			console.log(error.message);
		});
	} else if (details.reason === 'update') {
		(async () => {
			if (details.previousVersion < '1.0.1') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.shipmentExistsWarning = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.2') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.sendMessageFromOrdersPage = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.4') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.additionalOrdersSortingOptions = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.5') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.showShipmentStatus = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.6') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions', 'shortcut']);
					storageData.extensions.offerTags = false;
					storageData.offerTagsShortcut = '';
					storageData.changeAuctionsTitleShortcut = storageData.shortcut;
					storageData.allegroTokenScopes = '';
					storageData.allegroTokenScopesSandbox = '';
					storageData.updateLastChecked = '';
					storageData.offerTagsDefaultHidden = false;
					await saveDataToLocalStorage(storageData);
					await chrome.storage.local.remove('shortcut');
					optionsPageMessage('Uwaga! Aby na stronie opcji rozszerzenia prawidłowo pokazywały się informacje o przyznanych uprawnieniach, ponownie kliknij przycisk "Zaloguj". Jeśli korzystasz z serwisu testowego Sandbox - przeczytaj zmiany w dokumentacji (changelog).');
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.0.8') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.buyerStats = false;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.1') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['extensions']);
					storageData.extensions.erliActions = false;
					storageData.extensions.parametersWatcher = false;
					storageData.erliToken = '';
					storageData.erliTokenSandbox = '';
					storageData.erliAlwaysSyncToSandbox = false;
					storageData.erliPriceListName = '';
					storageData.erliObligatoryName = '';
					storageData.erliVoluntaryName = '';
					storageData.erliReturnsName = '';
					storageData.erliPriceApplyDiscountCheckbox = false;
					storageData.erliPriceAmountRadio = true;
					storageData.erliPricePercentRadio = false;
					storageData.erliPriceStepsRadio = false;
					storageData.erliPriceAmountValue = 0;
					storageData.erliPricePercentValue = 0;
					storageData.erliPriceSteps = [];
					storageData.erliFastStockMaganerCheckbox = false;
					storageData.erliRestoreCancelledCheckbox = false;
					storageData.erliRestoreReturnedCheckbox = false;
					storageData.erliShowStockLeftCheckbox = false;
					storageData.responsibleProducers = [];
					storageData.responsiblePersons = [];
					storageData.parametersWatcherTimerCheckbox = false;
					storageData.parametersWatcherSandbox = false;
					storageData.parametersWatcherPeriodInput = 3,
					storageData.parametersWatcherScheduledTime = 0;
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}

			if (details.previousVersion < '1.1.2') {
				let storageData;
				try {
					storageData = await readDataFromLocalStorage(['shippingMethods']);
					storageData.shippingMethods.forEach(method => {
						if (method.size1 !== undefined && method.weight === undefined) {
							method.weight = '0';
						}
					});
					await saveDataToLocalStorage(storageData);
				} catch (error) {
					optionsPageMessage(`Błąd! Podczas aktualizacji rozszerzenia wystąpił błąd. Usuń i zainstaluj ponownie rozszerzenie. ${error?.message ? error.message : error}`);
					return;
				}
			}
		})();
	}

});

chrome.action.onClicked.addListener(openOptionsPage);

async function loadExtensions(retriesLeft = 5) {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions']);
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}
	if (readedValue.extensions === undefined) {
		console.log('Nie znaleziono listy rozszerzeń, ponawianie próby...');
		if (--retriesLeft) {
			await new Promise(resolve => setTimeout(resolve, 1000));
			return await loadExtensions(retriesLeft);
		}
		else {
			optionsPageMessage('Błąd! Podczas odczytu listy rozszerzeń wystąpił błąd. Usuń i zainstaluj ponownie rozszerenie.');
			return;
		}
	}
	let contentScripts;
	try { 
		contentScripts = await chrome.scripting.getRegisteredContentScripts();
	} catch (error) {
		console.log(`Błąd! Podczas odczytu listy załadowanych skryptów wystąpił błąd. ${ error?.message ? error.message : error }`);
		return;
	}

	if (contentScripts === undefined) return;

	if (readedValue.extensions.changeInvoicesIconColor === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeInvoicesIconColor' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeInvoicesIconColor',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['change_invoices_icon_color.js', 'toast.js'],
			}]).then(() => {
				console.log('Załadowano skrypt changeInvoicesIconColor');
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeInvoicesIconColor');
			});
		}
	}

	if (readedValue.extensions.autoprintLabel === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autoprintLabel' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autoprintLabel',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment-status/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment-status/*'],
				css: ['autoprint_label.css', 'toast.css'],
				js: ['autoprint_label.js', 'toast.js']
			}, {
				id: 'autoprintLabelOrders',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['autoprint_label_orders.css'],
				js: ['autoprint_label_orders.js']
			}]).then(() => {
				console.log('Załadowano skrypt autoprintLabel');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autoprintLabel');
			});
		}
	}

	if (readedValue.extensions.autofillPackageSize === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'autofillPackageSize' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'autofillPackageSize',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['autofill_package_size.css', 'toast.css'],
				js: ['autofill_package_size.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt autofillPackageSize');
			}).catch(() => {
				console.log('Błąd ładowania skryptu autofillPackageSize');
			});
		}
	}

	if (readedValue.extensions.inPostSendMode === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'inPostSendMode' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'inPostSendMode',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['inpost_send_mode.css', 'toast.css'],
				js: ['inpost_send_mode.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt inPostSendMode');
			}).catch(() => {
				console.log('Błąd ładowania skryptu inPostSendMode');
			});
		}
	}

	if (readedValue.extensions.sendMessageFromOrdersPage === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'sendMessageFromOrdersPage' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'sendMessageFromOrdersPage',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*', 'https://salescenter.allegro.com/message-center/messages/new-message*', 'https://salescenter.allegro.com.allegrosandbox.pl/message-center/messages/new-message*', 'https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*'],
				css: ['toast.css'],
				js: ['send_message_from_orders_page.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt sendMessageFromOrdersPage');
			}).catch(() => {
				console.log('Błąd ładowania skryptu sendMessageFromOrdersPage');
			});
		}
	}

	if (readedValue.extensions.additionalOrdersSortingOptions === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'additionalOrdersSortingOptions' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'additionalOrdersSortingOptions',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['toast.css'],
				js: ['additional_orders_sorting_options.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt additionalOrdersSortingOptions');
			}).catch(() => {
				console.log('Błąd ładowania skryptu additionalOrdersSortingOptions');
			});
		}
	}

	if (readedValue.extensions.validateBuyerAddressErrors === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'validateBuyerAddressErrors' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'validateBuyerAddressErrors',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['validate_buyer_address_errors.css', 'toast.css'],
				js: ['validate_buyer_address_errors.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt validateBuyerAddressErrors');
			}).catch(() => {
				console.log('Błąd ładowania skryptu validateBuyerAddressErrors');
			});
		}
	}
	
	if (readedValue.extensions.changeAuctionsTitle === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeAuctionsTitle' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'changeAuctionsTitle',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['change_auctions_title.css', 'toast.css'],
				js: ['change_auctions_title.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt changeAuctionsTitle');
				getShortcutChangeAuctionsTitle().catch(() => {});
			}).catch(() => {
				console.log('Błąd ładowania skryptu changeAuctionsTitle');
			});
		}
	}

	if (readedValue.extensions.fastStockManager === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'fastStockManager' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'fastStockManager',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['fast_stock_manager.css', 'toast.css'],
				js: ['fast_stock_manager.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt fastStockManager');
			}).catch(() => {
				console.log('Błąd ładowania skryptu fastStockManager');
			});
		}
	}

	if (readedValue.extensions.restoreCancelled === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreCancelled' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreCancelled',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['restore_cancelled.css', 'toast.css'],
				js: ['restore_cancelled.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreCancelled');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreCancelled');
			});
		}
	}

	if (readedValue.extensions.restoreReturned === true) {
		let localReadedValue;
		try {
			localReadedValue = await readDataFromLocalStorage(['iFirmaReturns']);
		} catch (error) {
			console.log(`Błąd! Podczas odczytywania ustawień uzupełniania protokołu anulowania sprzedaży na stronie iFirma.pl wystąpił błąd. ${error?.message ? error.message : error}`);
			return;
		}

		if (localReadedValue.iFirmaReturns === true) {
			if (contentScripts.find(registeredScript => { return registeredScript.id === 'iFirmaReturns' }) === undefined) {
				chrome.scripting.registerContentScripts([{
					id: 'iFirmaReturns',
					matches: ['https://www.ifirma.pl/*'],
					css: ['ifirma_returns.css', 'toast.css'],
					js: ['ifirma_returns.js', 'toast.js']
				}]).then(() => {
					console.log('Załadowano skrypt iFirmaReturns');
				}).catch(() => {
					console.log('Błąd ładowania skryptu iFirmaReturns');
				});
			}
		}

		if (contentScripts.find(registeredScript => { return registeredScript.id === 'restoreReturned' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'restoreReturned',
				matches: ['https://salescenter.allegro.com/returns*', 'https://salescenter.allegro.com/payment-refund-form*', 'https://salescenter.allegro.com.allegrosandbox.pl/returns*', 'https://salescenter.allegro.com.allegrosandbox.pl/payment-refund-form*'],
				css: ['restore_returned.css', 'toast.css'],
				js: ['restore_returned.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt restoreReturned');
			}).catch(() => {
				console.log('Błąd ładowania skryptu restoreReturned');
			});
		}
	}

	if (readedValue.extensions.showProductName === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showProductName' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showProductName',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['show_product_name.css', 'toast.css'],
				js: ['show_product_name.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showProductName');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showProductName');
			});
		}
	}

	if (readedValue.extensions.offerTags === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'offerTags' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'offerTags',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['offer_tags.css', 'toast.css'],
				js: ['offer_tags.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt offerTags');
				getShortcutOfferTags().catch(() => {});
			}).catch(() => {
				console.log('Błąd ładowania skryptu offerTags');
			});
		}
	}

	if (readedValue.extensions.showStockLeft === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showStockLeft' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showStockLeft',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['show_stock_left.css', 'toast.css'],
				js: ['show_stock_left.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showStockLeft');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showStockLeft');
			});
		}
	}

	if (readedValue.extensions.shipmentExistsWarning === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'shipmentExistsWarning' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'shipmentExistsWarning',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/swa/create-shipment/*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/swa/create-shipment/*'],
				css: ['shipment_exists_warning.css', 'toast.css'],
				js: ['shipment_exists_warning.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt shipmentExistsWarning');
			}).catch(() => {
				console.log('Błąd ładowania skryptu shipmentExistsWarning');
			});
		}
	}

	if (readedValue.extensions.showShipmentStatus === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'showShipmentStatus' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'showShipmentStatus',
				matches: ['https://salescenter.allegro.com/ship-with-allegro/shipments*', 'https://salescenter.allegro.com.allegrosandbox.pl/ship-with-allegro/shipments*'],
				css: ['show_shipment_status.css', 'toast.css'],
				js: ['show_shipment_status.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt showShipmentStatus');
			}).catch(() => {
				console.log('Błąd ładowania skryptu showShipmentStatus');
			});
		}
	}

	if (readedValue.extensions.parametersWatcher === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'parametersWatcher' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'parametersWatcher',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['parameters_watcher.css', 'toast.css'],
				js: ['parameters_watcher.js', 'toast.js']
			}]).then(async () => {
				console.log('Załadowano skrypt parametersWatcher');
			}).catch(() => {
				console.log('Błąd ładowania skryptu parametersWatcher');
			});
		}
	}

	if (readedValue.extensions.buyerStats === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'buyerStats' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'buyerStats',
				matches: ['https://salescenter.allegro.com/orders*', 'https://salescenter.allegro.com.allegrosandbox.pl/orders*'],
				css: ['buyer_stats.css', 'toast.css'],
				js: ['buyer_stats.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt buyerStats');
			}).catch(() => {
				console.log('Błąd ładowania skryptu buyerStats');
			});
		}
	}

	if (readedValue.extensions.erliActions === true) {
		if (contentScripts.find(registeredScript => { return registeredScript.id === 'erliActions' }) === undefined) {
			chrome.scripting.registerContentScripts([{
				id: 'erliActions',
				matches: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'],
				css: ['erli_actions.css', 'toast.css'],
				js: ['erli_actions.js', 'toast.js']
			}]).then(() => {
				console.log('Załadowano skrypt erliActions');
			}).catch(() => {
				console.log('Błąd ładowania skryptu erliActions');
			});
		}
	}
}

loadExtensions();

chrome.runtime.onStartup.addListener(async () => {
	await loadExtensions();
});

async function sendNativeMessage(application, data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendNativeMessage(application, data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}
/*
(async() => {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['property']);
		console.log(readedValue);
	} catch (error) {
		console.log(error.message);
	}
})();
*/

/*
(async() => {
	try {
		await saveDataToLocalStorage({property: value});
		console.log('Zapisano');
	} catch (error) {
		console.log(error.message);
	}
})();
*/
async function handleBackgroundFetch(request) {
  const response = await fetch(request.url, {
    method: request.options.method || 'GET',
    headers: request.options.headers || {},
    body: request.options.body || null
  });

  const responseBody = await response.text();
  return {
    status: response.status,
    statusText: response.statusText,
    headers: Array.from(response.headers.entries()),
    body: responseBody
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'backgroundFetch': {
			return await handleBackgroundFetch(request);
		}

		case 'backgroundFetchPartially': {
			return await handleBackgroundFetchPartially(request);
		}

		case 'getAllegroAccessToken': {
			let sandbox;
			let readedValue;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			//console.log(`Sandbox Mode: ${sandbox}`);
			try {
				readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') return Promise.resolve(readedValue[`allegroAccessToken${sandbox}`]);
			else {
				return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
			}
		}

		case 'refreshAllegroAccessToken': {
			let sandbox;
			let readedValue;
			let fetchResponse;
			let fetchData;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			try {
				readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

			const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
			const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
			const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
			const redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');

			if (sandbox === 'Sandbox') {
				try {
					readedValue = await	readDataFromLocalStorage(['allegroAPIOAuthConnectorSandbox']);
				} catch (error) {
					return Promise.reject(`Podczas odczytu wymaganych parametrów (adres skryptu) wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				if (!readedValue.allegroAPIOAuthConnectorSandbox) {
					return Promise.reject('Brak wymaganych parametrów (adres skryptu).');
				}

				try {
					fetchResponse = await fetch(readedValue.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'refreshTokens', clientId: allegroAPIClientId, clientSecret: allegroAPIClientSecret, refreshToken: allegroRefreshToken })
					});
				} catch (error) {
					return Promise.reject(`Nie udało się uzyskać tokenów dostępowych za pośrednictwem skryptu. ${error?.message ? error.message : error}`);
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
					}

					if (fetchData?.status === 'success') {
						try {
							await saveDataToLocalStorage({
								allegroAccessTokenSandbox: fetchData.accessToken,
								allegroRefreshTokenSandbox: fetchData.refreshToken,
								allegroTokenScopesSandbox: fetchData.scope
							});
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
						}

						return Promise.resolve(fetchData.accessToken);
					} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
						return Promise.reject(`${UNABLE_TO_REFRESH_TOKENS} ${fetchData.details}`);
					} else return Promise.reject(UNABLE_TO_REFRESH_TOKENS);
				} else {
					return Promise.reject(`Podczas odświeżania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}.`);
				}
			} else {
				async function login(count = 3) {
					let fetchResponse;
					let fetchData;
					try {
						fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
							method: 'POST',
							headers: {
								'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
								'Content-Type': 'application/x-www-form-urlencoded'
							}
						});
					} catch (error) {
						if (--count) {
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}
					}

					if (fetchResponse.status === 200) {
						try {
							fetchData = await fetchResponse.json();
						} catch (error) {
							return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
						}

						if (fetchData.access_token === undefined || fetchData.refresh_token === undefined || fetchData.scope === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

						try {
							await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token, allegroTokenScopes: fetchData.scope.split(' ').join(', ') });
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
						}

						return Promise.resolve(fetchData.access_token);
					} else {
						if (--count) {
							await new Promise(resolve => setTimeout(resolve, 5000));
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}
					}
				}
				try {
					const result = await login();
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(result);
				}
			}
		}

		case 'getExtensions': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['extensions']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. ${error?.message ? error.message : error}`);
			}

			if (readedValue.extensions !== undefined) return Promise.resolve(readedValue.extensions);
			else return Promise.reject(`Podczas pobierania listy aktywnych rozszerzeń wystąpił błąd. Nie znaleziono listy.`);
		}

		case 'loadExtensions': {
			loadExtensions();
			break;
		}

		case 'getFilter': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['filter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania ustawień koloru dla ikony faktury wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (readedValue.filter !== undefined) return Promise.resolve(readedValue.filter);
			else {
				readedValue.color = '#4a86e8';
				readedValue.filter = 'filter: brightness(0) opacity(1) invert(37%) sepia(74%) saturate(7497%) hue-rotate(213deg) brightness(106%) contrast(104%);';
				try {
					await saveDataToLocalStorage({ color: readedValue.color, filter: readedValue.filter });
				} catch (error) {
					return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				return Promise.resolve(readedValue.filter);
			}
		}

		case 'saveColor': {
			if (request.color === undefined || request.filter === undefined) {
				return Promise.reject('Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane.');
			}
			try {
				await saveDataToLocalStorage({ color: request.color, filter: request.filter });
			} catch (error) {
				return Promise.reject(`Podczas zapisu ustawień koloru dla ikony faktury wystąpił błąd. Wartości nie zostały zapisane. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'allegroAPISave': {
			if (request.clientId === undefined || request.clientSecret === undefined || request.oAuthConnector === undefined || request.sandbox === undefined) return Promise.reject('Nie podano wartości parametrów Client ID i Cilent Secret.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			let patternClientId = /^|[0-9a-f]{32}/;
			let patternClientSecret = /^|[0-9a-zA-Z]{64}/;
			let patternOAuthConnector = /^|https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z\-_]{1,}\/exec$/;
			if ((!patternClientId.test(request.clientId)) || (!patternClientSecret.test(request.clientSecret)) || (!patternOAuthConnector.test(request.oAuthConnector))) return Promise.reject('Podane wartości parametrów są niepoprawne.');
			try {
				await saveDataToLocalStorage({ [`allegroAPIClientId${sandbox}`]: request.clientId, [`allegroAPIClientSecret${sandbox}`]: request.clientSecret, allegroAPIOAuthConnectorSandbox: request.oAuthConnector });
				if (request.clientId === '' || request.clientSecret === '' || (sandbox === 'Sandbox' && request.oAuthConnector === '')) await saveDataToLocalStorage({ [`allegroAccessToken${sandbox}`]: '', [`allegroRefreshToken${sandbox}`]: '', [`tokenScopes${sandbox}`]: '' });
			} catch (error) {
				return Promise.reject(`Podczas zapisu parametrów wystąpił błąd. ${error?.message ? error.message : error}`);
			}

			if (sandbox === 'Sandbox') {
				if (request.clientId !== '' && request.clientSecret !== '' && request.oAuthConnector !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			} else {
				if (request.clientId !== '' && request.clientSecret !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			}
		}

		case 'erliTokenSave': {
			if (request.token === undefined) return Promise.reject('Nie podano wartości tokena.');
			let patternToken = /^|\S{1,}$/;
			if (!patternToken.test(request.token)) return Promise.reject('Podana wartość tokena jest niepoprawna.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			try {
				await saveDataToLocalStorage({ [`erliToken${sandbox}`]: request.token });
			} catch (error) {
				return Promise.reject(`Podczas zapisu tokena wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'openLoginPage': {
			if (request.url !== undefined) {
				try {
					await chrome.tabs.create({ active: true, url: request.url });
				} catch (error) {
					return Promise.reject(`Podczas otwierania strony logowania wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				return Promise.resolve(true);
			}
			return Promise.reject('Brak wymaganego adresu strony do otwarcia.');
		}

		case 'getPackageTemplates': {
			if (request.shippingMethod !== undefined) {
				let result;
				try {
					result = await readDataFromLocalStorage(['shippingMethods']);
				} catch (error) {
					return Promise.reject(`Podczas wczytywania metod dostawy wystąpił błąd. ${error?.message ? error.message : error}`);
				}
				if (result.shippingMethods !== undefined) {
					let found = false;
					let option;
					for (option of result.shippingMethods) {
						if (option.name === request.shippingMethod) {
							found = true;
							break;
						}
					}
					if (!found) return Promise.reject('Nie znaleziono metody dostawy o takiej nazwie. Dodaj ją ręcznie do listy.');
					if (option.weight1 !== undefined) {
						const template = {};
						let i = 1;
						while (option[`weight${i}`] !== undefined) {
							if (i > 9) break;
							template[`weight${i}`] = option[`weight${i}`];
							template[`length${i}`] = option[`length${i}`];
							template[`width${i}`] = option[`width${i}`];
							template[`height${i}`] = option[`height${i}`];
							i++;
						}
						template.default = option.default;
						
						return Promise.resolve({ template: template });
					}
					else return Promise.resolve({ defaultWeight: option['weight'], defaultSize: option['default'] });
				} else return Promise.reject('Nie znaleziono metod dostawy których wartości domyślne mają zostać odczytane.');	
			} else return Promise.reject('Nie określono metody dostawy której wartości domyślne mają zostać odczytane.');
		}

		case 'closeCurrentTab': {
			async function getCurrentTab() {
				let queryOptions = { active: true, lastFocusedWindow: true };
				try {
					let [tab] = await chrome.tabs.query(queryOptions);
					return Promise.resolve(tab);
				} catch(error) {
					return Promise.reject('Nie udało się pobrać aktywnej karty.');
				}
			}
			let tab;
			try {
				tab = await getCurrentTab();
				await chrome.tabs.remove(tab.id);
			} catch (error) {
				return Promise.reject(error);
			}
			
			return Promise.resolve(true);
		}

		case 'closeCallerTab': {
			try {
				await chrome.tabs.remove(sender.tab.id);
			} catch (error) {
				console.log(`Błąd! Podczas zamykania karty wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'drawAttention': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { drawAttention: true });
			} catch (error) {
				return Promise.reject('Nie udało się wyróżnić okna.');
			}
			return Promise.resolve(true);
		}

		case 'bringWindowToFront': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true });
			} catch (error) {
				return Promise.reject('Nie udało się ustawić okna na pierwszym planie.');
			}
			return Promise.resolve(true);
		}

		case 'getPrinters': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getPrinters' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania listy drukarek wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(response.result);
		}

		case 'getSumatraPath': {
			let response;
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: 'getSumatraPath' });
			} catch (error) {
				return Promise.reject(`Podczas pobierania ścieżki programu SumatraPDF wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(response.result);
		}

		case 'moveTabToNewWindow': {
			try {
				await chrome.windows.create({ type: 'popup', focused: false, height: 30, width: 150, state: 'normal', left: (request.screenx - 150), top: (request.screeny - 30), tabId: sender.tab.id });
			} catch (error) {
				return Promise.reject('Nie udało się przenieść karty do nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'maximizeNewWindow': {
			try {
				const windows = await getWindows();
				const windowFound = windows.some(window => window.id === sender.tab.windowId);
				if (!windowFound) throw new Error('Nie znaleziono okna o podanym ID.');
				await chrome.windows.update(sender.tab.windowId, { focused: true, state: 'maximized' });
			} catch (error) {
				return Promise.reject('Nie udało się zmaksymalizować nowego okna.');
			}
			return Promise.resolve(true);
		}

		case 'downloadLabel': {
			async function waitForDownloadFinished() {
				return new Promise((resolve, reject) => {
					let downloadItemId = 0;
					let downloadBackupTimer;
					function downloadEvent(downloadItem) {
						if (downloadItemId === 0) {
						
							downloadBackupTimer = setTimeout(downloadBackupHandler, 20000);
							chrome.downloads.search({
								state: 'in_progress',
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								orderBy: ["-startTime"],
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
										if (chrome.runtime.lastError) return;
										const windowFound = windows.some(window => window.id === sender.tab.windowId);
										if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
										try {
											chrome.windows.update(sender.tab.windowId, { state: 'minimized' }).catch(error => { console.log(`Błąd podczas minimalizowania okna. ${error.message}`) });
										} catch (error) {
											console.log(`Błąd podczas minimalizowania okna. ${error.message}`);
										}
									});
									downloadItemId = downloadSearchResult[0].id;
									console.log(`Trwa pobieranie, id: ${downloadItemId}`);
								} else {
									console.log('Nie wykryto rozpoczęcia pobierania pliku.');
								}
							}).catch(error => {
								console.log(`Błąd! Podczas pobierania wystąpił błąd. ${error?.message ? error.message : error}`);
								reject(`Podczas pobierania wystąpił błąd. ${error?.message ? error.message : error}`);
							});
						} else if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
							clearTimeout(downloadBackupTimer);
							console.log(`Pobrano, id: ${downloadItemId}`);
							chrome.downloads.onChanged.removeListener(downloadEvent);
							chrome.downloads.search({
								state: 'complete',
								exists: true,
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								id: downloadItemId
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
									resolve({ filename: downloadSearchResult[0].filename, backup: false });
								}
							}).catch(error => {
								console.log(`Błąd! Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${error?.message ? error.message : error}`);
								reject(`Podczas przeszukiwania listy pobranych plików wystąpił błąd. ${error?.message ? error.message : error}`);
							});
						}
					}
					chrome.downloads.onChanged.addListener(downloadEvent);
					chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
						if (chrome.runtime.lastError) return;
						const windowFound = windows.some(window => window.id === sender.tab.windowId);
						if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
						try {
							chrome.windows.update(sender.tab.windowId, { drawAttention: false }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
						} catch (error) {
							console.log(`Błąd podczas wyróżniania okna. ${error.message}`);
						}
					});
				
					function downloadBackupHandler() {
						chrome.downloads.search({
							state: 'complete',
							exists: true,
							mime: 'application/pdf',
							finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
							limit: 1,
							orderBy: ["-startTime"]
						}).then(downloadSearchResult => {
							if (downloadSearchResult.length) {
								console.log(`Nazwa pobranego pliku: ${downloadSearchResult[0].filename}`);
								chrome.windows.getAll({ populate: true, windowTypes: ['normal', 'popup'] }, (windows) => {
									if (chrome.runtime.lastError) return;
									const windowFound = windows.some(window => window.id === sender.tab.windowId);
									if (!windowFound) reject('Nie znaleziono okna o podanym ID.');
									try {
										chrome.windows.update(sender.tab.windowId, { focused: true }).catch(error => { console.log(`Błąd podczas wyróżniania okna. ${error.message}`) });
									} catch (error) {
										console.log(`Błąd podczas ustawiania focusa na oknie. ${error.message}`);
									}
								});
								resolve({ filename: downloadSearchResult[0].filename, backup: true });
							}
						});
					}
				});
			}
			return await waitForDownloadFinished();
		}

		case 'printLabel': {
			let readedValue;
			let response;
			if (request.filename === '') return Promise.reject('Nie określono nazwy pliku do wydruku.');
			try {
				readedValue = await readDataFromLocalStorage(['sumatraPath', 'defaultPrinter']);
			} catch (error) {
				return Promise.reject(`Podczas pobierania zapisanych wartości ścieżki do programu SumatraPDF i drukarki do wydruku wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			console.log(`sumatraPath: ${readedValue.sumatraPath}, defaultPrinter: ${readedValue.defaultPrinter}, filename: ${request.filename}`);
			try {
				response = await sendNativeMessage('com.tomsyty.allegro_extensions', { action: "printLabel", sumatraPath: readedValue.sumatraPath, defaultPrinter: readedValue.defaultPrinter, filename: request.filename.replace('\\\\', '\\') });
			} catch (error) {
				return Promise.reject(`Podczas przesyłania wiadomości do programu drukującego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (response.result === 'ok') {
				console.log('Wydrukowano');
				return Promise.resolve(response.result);
			} else {
				console.log('Błąd! Nie wydrukowano');
				return Promise.reject('Program drukujący nie zwrócił prawidłowej odpowiedzi informującej o wydrukowaniu etykiety.');
			}
		}

		case 'getInPostSendMode': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['inPostSendMode']);
			} catch (error) {
				return Promise.reject(`Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost. ${error?.message ? error.message : error}`);
			}

			if (readedValue.inPostSendMode !== undefined) return Promise.resolve(readedValue.inPostSendMode);
			else return Promise.reject('Nie udało się odczytać domyślnego sposobu nadawania przesyłek InPost.');
		}

		case 'saveInPostSendMode': {
			try {
				await saveDataToLocalStorage({ inPostSendMode: request.sendMode });
			} catch (error) {
				return Promise.reject(`Podczas zapisu sposobu nadawnia przesyłek InPost wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(true);
		}

		case 'sendAnonymizedSample': {
			let fetchResponse;
			let fetchData;
			try {
				fetchResponse = await fetch(`https://tomsyty.pl/allegro-extensions/validate-buyer-errors.php`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify(request.sample)
				});
			} catch (error) {	
				return Promise.reject(`${FETCH_ERROR_MESSAGE} ${SAMPLE_NOT_SEND}`);
			}
		
			if (fetchResponse.status !== 200) return Promise.reject(`${SAMPLE_NOT_SEND} ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);

			try {
				fetchData = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`${JSON_DECODE_ERROR} ${SAMPLE_NOT_SEND}`);
			}
			return Promise.resolve(true);
		}

		case 'updateSendParcelLink': {
			let tabs;
			try {
				tabs = await chrome.tabs.query({ url: `https://salescenter.allegro.com${request.environment}/orders*` });
				for (let tab of tabs) {
					sendMessage(tab.id, { action: 'updateSendParcelLink', orderId: request.orderId }).catch(error => { console.log(`Błąd podczas deaktywowania przycisku "Nadaj przesyłkę", ${error.message}`) });
				}
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return Promise.resolve(true);
		}

		case 'fillRefundForm': {
			let tabs;
			let response;
			try {
				tabs = await chrome.tabs.query({ url: `https://www.ifirma.pl/app/wo/*` });
				if (tabs.length === 0) return Promise.reject('Nie znaleziono otwartej karty z protokołem anulowania sprzedaży.');
				for (let tab of tabs) {
					response = await sendMessage(tab.id, { action: 'fillRefundForm', restoreList: request.restoreList });
					if (response?.success === false) {
						return Promise.reject(response.result);
					} else {
						await chrome.tabs.update(tab.id, { active: true });
						break;
					};
				}
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return Promise.resolve(true);
		}

		case 'buyerStatsGetBuyer': {
			if (request.login === undefined) return Promise.reject('Nie podano loginu kupującego.');
			let buyer;
			try {
				buyer = await buyerStatsGetBuyer(request.login);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych kupującego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(buyer);
		}

		case 'buyerStatsSaveBuyer': {
			if (request.buyer === undefined) return Promise.reject('Nie podano obiektu zawierającego dane kupującego.');
			let buyer;
			try {
				buyer = await buyerStatsSaveBuyer(request.buyer);
			} catch (error) {
				return Promise.reject(`Podczas zapisu danych kupującego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			return Promise.resolve(buyer);
		}

		case 'buyerStatsRemoveBase': {
			let result;
			try {
				result = await buyerStatsRemoveBase();
			} catch (error) {
				return Promise.reject(`Podczas usuwania bazy danych kupujących wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (result) return Promise.resolve(true);
			else return Promise.reject('Nie udało się usunąć bazy danych kupujących.');
		}

		case 'offerParametersGet': {
			if (request.id === undefined) return Promise.reject('Nie podano numeru oferty');
			let result;
			try {
				result = await offerParametersGet(request.id);
			} catch (error) {
				return Promise.reject(`Podczas pobierania parametrów z bazy wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (result) return Promise.resolve(result);
			else return Promise.resolve('');
			//else return Promise.reject('Nie udało się pobrać parametrów z bazy.');
		}

		case 'offerParametersSave': {
			if (request.offer === undefined) return Promise.reject('Nie podano numeru oferty');
			let result;
			try {
				result = await offerParametersSave(request.offer);
			} catch (error) {
				return Promise.reject(`Podczas zapisywania parametrów do bazy wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (result) return Promise.resolve(result);
			else return Promise.resolve('');
		}

		case 'parametersWatcherEnableSchedule': {
			if (request.period === undefined || request.period < 1 || request.period > 24) return Promise.reject('Niewłaściwy okres czasu sprawdzania parametrów aukcji');
      const alarm = await parametersWatcherCheckAlarm(request.period);
      if (!alarm) {
        try {        
          await chrome.alarms.create('parametersWatcherAlarm', {
						when: roundUpToFullMinute(Date.now()),
            periodInMinutes: request.period * 60
          });

					const setAlarm = await chrome.alarms.get('parametersWatcherAlarm');
					if (setAlarm) {
						console.log(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${request.period} godzin${request.period === 1 ? 'ę' : ((request.period >= 2 && request.period <= 4) || (request.period >= 22 && request.period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${nextAlarm}` });
						await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
						pwWorkEnabled = true;
						return Promise.resolve(request.period);
					}
				} catch (error) {
        	console.log(error instanceof Error ? error.message : error);
         	console.log(`Nie udało się włączyć automatycznego sprawdzania parametrów w tle. ${error instanceof Error ? error.message : error}`);
					return Promise.reject(error?.message ? error.message : error);
				}        
        return Promise.reject('Nie udało się potwierdzić ustawienia alarmu.');
      } else {
        return Promise.resolve(alarm.periodInMinutes);
      }   
    }

		case 'parametersWatcherDisableSchedule': {
      try {        
         await chrome.alarms.clear('parametersWatcherAlarm');
				 pwWorkEnabled = false;
			} catch (error) {
        console.log(`Nie udało się wyłączyć automatycznego sprawdzania parametrów w tle. ${error instanceof Error ? error.message : error}`);
        return Promise.reject(error instanceof Error ? error.message : error);
      }	
			try { 
				 await chrome.action.setBadgeText({ text: '' });
				 await chrome.action.setTitle({ title: 'Usprawnienia serwisu Allegro' });
				 await chrome.action.setIcon({ path: 'icon-48.png' });
      } catch (error) {
        console.log(`Podczas wyłączania automatycznego sprawdzania parametrów w tle wystąpił błąd. ${error instanceof Error ? error.message : error}`);
        return Promise.reject(error instanceof Error ? error.message : error);
      }
      console.log('Wyłączono automatyczne sprawdzanie parametrów w tle');
      return Promise.resolve(true);
    }

		case 'parametersWatcherRun': {
			pwWorkEnabled = true;
			chrome.alarms.onAlarm.dispatch({ name: 'parametersWatcherAlarm' });
      return Promise.resolve(true);
    }

		case 'parametersWatcherPostpone': {
			let result;
			try {
				result = await parametersWatcherPostponeSchedule();
			} catch (error) {
				return Promise.reject(false);
			}
      return Promise.resolve(result);
    }

		case 'parametersWatcherStop': {
			pwWorkEnabled = false;	
      return Promise.resolve(true);
    }

		case 'parametersWatcherRemoveBase': {
			let result;
			try {
				result = await parametersWatcherRemoveBase();
			} catch (error) {
				return Promise.reject(`Podczas usuwania bazy danych z parametrami aukcji wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			if (result) return Promise.resolve(true);
			else return Promise.reject('Nie udało się usunąć bazy danych z parametrami aukcji.');
		}

		case 'getShortcutOfferTags': {
			getShortcutOfferTags().catch(error => { console.log(`Błąd! ${error.message}`) });
			break;
		}

		case 'getShortcutChangeAuctionsTitle': {
			getShortcutChangeAuctionsTitle().catch(error => { console.log(`Błąd! ${error.message}`) });
			break;
		}

		case 'debug': {
			console.log(request.info);
			break;
		}
	}
}

function roundUpToFullMinute(dateToRound) {
  const date = new Date(dateToRound);
  if (date.getSeconds() > 30) {
    date.setMinutes(date.getMinutes() + 2);
  } else date.setMinutes(date.getMinutes() + 1);
  date.setSeconds(0, 0);
  return date.getTime();
}

function roundDownToFullMinute(dateToRound) {
  const date = new Date(dateToRound);
  date.setSeconds(0, 0);
  return date.getTime();
}

async function parametersWatcherRun() {
	let readedValue;
	let keepAlive;
	try {
		await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nSprawdzanie parametrów` });
		keepAlive = setInterval(chrome.runtime.getPlatformInfo, 25000);
		
		readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
		if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') {
			const accessToken = readedValue[`allegroAccessToken${sandbox}`];
			let parameters = {
				accessToken: accessToken,
				environment: '',
				offset: 0
			};

			let offersCount = 0;
	
			offersCount = await getOffersCount(parameters, 5);
			await pwProcessOffers(parameters, offersCount);
		}
	} catch (error) {
		console.log(error instanceof Error ? error.message : error);
		showMessageFromBackground(`Błąd! ${error instanceof Error ? error.message : error}`);
	}

	await chrome.action.setBadgeText({ text: '' });
	clearInterval(keepAlive);
}

function openOptionsPage() {
	chrome.runtime.openOptionsPage(() => {
		if (chrome.runtime.lastError) {
			console.log(`Błąd! Podczas otwierania strony opcji rozszerzenia wystąpił błąd. ${chrome.runtime.lastError.message}`);
			showMessageFromBackground(`Błąd! Podczas otwierania strony opcji rozszerzenia wystąpił błąd. ${chrome.runtime.lastError.message}`);
		}
	});
}

(async function parametersWatcherPrepare() {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions', 'parametersWatcherTimerCheckbox', 'parametersWatcherPeriodInput', 'parametersWatcherScheduledTime']);
		if (readedValue.extensions === undefined || !readedValue.extensions['parametersWatcher']) return;
		const period = Number(readedValue['parametersWatcherPeriodInput']);
		if (readedValue['parametersWatcherTimerCheckbox'] && period >= 1 && period <= 24 ) {
			const alarm = await parametersWatcherCheckAlarm(period);
			if (!alarm) {
				try {  
					let alarmInfo = {
						periodInMinutes: period * 60
					}     
					
					if (Date.now() < readedValue['parametersWatcherScheduledTime']) {
						console.log('Znaleziono zaplanowany czas sprawdzania: ' + new Date(readedValue['parametersWatcherScheduledTime']).toTimeString().slice(0, 5));
						alarmInfo.when = readedValue['parametersWatcherScheduledTime'];
					} else {
						alarmInfo.when = roundUpToFullMinute(Date.now());
					}
					await chrome.alarms.create('parametersWatcherAlarm', alarmInfo);	
					const setAlarm = await chrome.alarms.get('parametersWatcherAlarm');
					if (setAlarm) {
						await saveDataToLocalStorage({ parametersWatcherScheduledTime: roundDownToFullMinute(setAlarm.scheduledTime) })
						console.log(`Włączono automatyczne sprawdzanie parametrów produktów w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')}`);
						const nextAlarm = new Date(setAlarm.scheduledTime).toTimeString().slice(0, 5);
						console.log(`Następne sprawdzanie parametrów o ${nextAlarm}`);
						await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${nextAlarm}` });
						await chrome.action.setIcon({ path: 'icon-48-timer.png' });
						pwWorkEnabled = true;
					}
				} catch (error) {
					console.log(error instanceof Error ? error.message : error);
					showMessageFromBackground(`Błąd! W trakcie uruchamiania automatycznego sprawdzania parametrów produktów w tle wystąpił błąd. ${error instanceof Error ? error.message : error}`);
				}
			} else {
				const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
				console.log(`Automatyczne sprawdzanie parametrów produktów w tle co ${period} godzin${period === 1 ? 'ę' : ((period >= 2 && period <= 4) || (period >= 22 && period <= 24) ? 'y' : '')} jest już aktywne. Następne sprawdzenie o ${nextAlarm}`);				
				await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${nextAlarm}` });
				await chrome.action.setIcon({ path: 'icon-48-timer.png' }); 
				pwWorkEnabled = true;
			}	
			chrome.action.setPopup({ popup: 'parameters_watcher_popup.html' });
		}
	} catch (error) {
		console.log('Błąd uruchamiania automatycznego sprawdzania parametrów produktów');
	}
})();

async function parametersWatcherCheckAlarm(alarmPeriod) {
  let alarm;
  try {
    alarm = await chrome.alarms.get('parametersWatcherAlarm');    
    if (alarm && (alarm.periodInMinutes === alarmPeriod * 60)) return Promise.resolve(alarm);
    else return Promise.resolve(false);
  } catch (error) {
    return Promise.reject(false);
  }
}

async function parametersWatcherDisableSchedule() {
  try {
		await chrome.alarms.clear('parametersWatcherAlarm');
		await saveDataToLocalStorage({ parametersWatcherScheduledTime: 0 })
		await chrome.action
	} catch (error) {
		console.log(error instanceof Error ? error.message : error);
		return Promise.reject(`Nie udało się wyłączyć automatycznego sprawdzania parametrów w tle. ${error instanceof Error ? error.message : error}`);
	}	
	pwWorkEnabled = false;
  console.log('Wyłączono automatyczne sprawdzanie parametrów w tle');
  return Promise.resolve(true);
}

async function parametersWatcherPostponeSchedule() {
	try {
	 	const alarm = await chrome.alarms.get('parametersWatcherAlarm');
		if (alarm) {
    	await chrome.alarms.create('parametersWatcherAlarm', {
				when: roundDownToFullMinute(alarm.scheduledTime + (60 * 60000)),
        periodInMinutes: alarm.periodInMinutes
      });
			const nextAlarm = await chrome.alarms.get('parametersWatcherAlarm');
			if (nextAlarm) {
				await saveDataToLocalStorage({ parametersWatcherScheduledTime: roundDownToFullMinute(nextAlarm.scheduledTime) });
				return Promise.resolve(new Date(nextAlarm.scheduledTime).toTimeString().slice(0, 5));
			} else return Promise.reject(false);
    }
	}	catch (error) {
    return Promise.reject(false);
  }
	return Promise.resolve(true);
}

function openDB(databaseName, objectStoreName, keyPath) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, 1);

    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(objectStoreName)) {
        db.createObjectStore(objectStoreName, { keyPath: keyPath });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function buyerStatsGetBuyer(login) {
  const db = await openDB('buyerStats', 'buyers', 'login');
  return new Promise((resolve, reject) => {
    const tx = db.transaction('buyers', 'readonly');
    const store = tx.objectStore('buyers');
    const request = store.get(login);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function buyerStatsSaveBuyer(buyer) {
  const db = await openDB('buyerStats', 'buyers', 'login');
  const tx = db.transaction('buyers', 'readwrite');
  const store = tx.objectStore('buyers');
  store.put(buyer);
  return tx.complete;
}

async function buyerStatsRemoveBase() {
	return new Promise((resolve, reject) => {
		const dbDeleteRequest = indexedDB.deleteDatabase('buyerStats');
		dbDeleteRequest.onsuccess = () => resolve(true);
		dbDeleteRequest.onerror = () => reject(false);
	});
}

async function parametersWatcherRemoveBase() {
	return new Promise((resolve, reject) => {
		const dbDeleteRequest = indexedDB.deleteDatabase('offerProducts');
		dbDeleteRequest.onsuccess = () => resolve(true);
		dbDeleteRequest.onerror = () => reject(false);
	});
}

async function offerParametersGet(id) {
	const db = await openDB('offerProducts', 'offers', 'id');
	return new Promise((resolve, reject) => {
		const tx = db.transaction('offers', 'readonly');
		const store = tx.objectStore('offers');
		const request = store.get(id);
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
}

async function offerParametersSave(offer) {
	const db = await openDB('offerProducts', 'offers', 'id');
	const tx = db.transaction('offers', 'readwrite');
	const store = tx.objectStore('offers');
	store.put(offer);	
	return tx.complete;
}

async function getShortcutChangeAuctionsTitle() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['changeAuctionsTitleShortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.changeAuctionsTitleShortcut === '') {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${error?.message ? error.message : error}`);
			return;
		}
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionsTitle')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.changeAuctionsTitle.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ changeAuctionsTitleShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}		
		}
	} else {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${error?.message ? error.message : error}`);
			return;
		}
		
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionsTitle')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.changeAuctionsTitleShortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ changeAuctionsTitleShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}
		}
	}
}

async function getShortcutOfferTags() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['offerTagsShortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.offerTagsShortcut === '') {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${error?.message ? error.message : error}`);
			return;
		}
		const assignedShortcut = commands.find(command => command.name === 'offerTags')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.offerTags.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ offerTagsShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}		
		}
	} else {
		try {
			commands = await chrome.commands.getAll();
		} catch (error) {
			optionsPageMessage(`Błąd! Nie udało się pobrać listy skrótów klawiaturowych. ${error?.message ? error.message : error}`);
			return;
		}
		
		const assignedShortcut = commands.find(command => command.name === 'offerTags')?.shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.offerTagsShortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ offerTagsShortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error?.message ? error.message : error}`);
			}
		}
	}
}

chrome.commands.onCommand.addListener(command => {
	asyncOnCommandCallback(command);
	return true;
});

async function asyncOnCommandCallback(command) {
  if (command === 'changeAuctionsTitle' || command === 'offerTags') {
		async function getCurrentTab() {
			const queryOptions = { active: true, currentWindow: true, url: ['https://salescenter.allegro.com/my-assortment*', 'https://salescenter.allegro.com.allegrosandbox.pl/my-assortment*'] };
			try {
				const [tab] = await chrome.tabs.query(queryOptions);
				if (tab === undefined) throw new Error('Skrót klawiaturowy aktywny jest tylko na stronie "Mój asortyment". Jeśli masz otwartą kartę na tej stronie - odśwież ją i spróbuj ponownie.');
				return Promise.resolve(tab.id);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
		}
		let tab;
		let readedValue;
		try {
			tab = await getCurrentTab();
		} catch (error) {
			optionsPageMessage(`Błąd! ${error}`);
			return;
		}
		try {
			readedValue = await readDataFromLocalStorage([`${command + 'Shortcut'}`]);
		} catch (error) {
			optionsPageMessage(`${SHORTCUT_READING_ERROR} ${error?.message ? error.message : error}`);
			return;
		}
		let contentScripts;
		try {
			contentScripts = await chrome.scripting.getRegisteredContentScripts();
			if (contentScripts.length) {			
				if (contentScripts.some(registeredScript => registeredScript.id === command)) {
					await sendMessage(tab, { action: command, shortcut: readedValue[`${command + 'Shortcut'}`]});
				}
			} else throw new Error('Jeśli masz otwartą kartę na stronie "Mój asortyment" - odśwież ją i spróbuj ponownie.');
		} catch (error) {
			optionsPageMessage(`Błąd! ${error?.message ? error.message : error}`);
			return
		}
	}
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'parametersWatcherAlarm') {
		try {
			alarm = await chrome.alarms.get('parametersWatcherAlarm');
		} catch (error) {
			console.log(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${error instanceof Error ? error.message : error}`);
			showMessageFromBackground(`Błąd! Podczas pobierania alarmu wystąpił błąd. ${error instanceof Error ? error.message : error}`);
			return Promise.reject(false);
		}
		let sandbox = '';
		let readedValue;
		let keepAlive;
		try {
			const currentBadgeText = await chrome.action.getBadgeText({});
			if (currentBadgeText !== '') {
				const nextAlarm = await parametersWatcherPostponeSchedule();
				if (typeof(nextAlarm) === 'string') {
					console.log(nextAlarm);
					chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Poprzednie sprawdzania parametrów nie zostało jeszcze zakończone. Przesunięto o godzinę.' });
					await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${nextAlarm}` });
					return Promise.resolve(true);
				}
			}
		} catch (error) {
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: 'Nie udało się sprawdzić czy poprzednie sprawdzania parametrów zostało zakończone. Pomijam sprawdzanie.' });
			console.log('Nie udało się sprawdzić czy poprzednie sprawdzania parametrów zostało zakończone.');
			return Promise.reject(false);
		}

    try {
			const nextAlarm = new Date(alarm.scheduledTime).toTimeString().slice(0, 5);
			console.log(`Następne sprawdzanie parametrów o ${nextAlarm}`);
			await chrome.action.setTitle({ title: `Usprawnienia serwisu Allegro\nNastępne sprawdzanie parametrów o ${nextAlarm}` });
			keepAlive = setInterval(chrome.runtime.getPlatformInfo, 25000);

			readedValue = await readDataFromLocalStorage(['parametersWatcherSandbox']);
			if (readedValue.parametersWatcherSandbox === true) {
				sandbox = 'Sandbox';
			} else {
				sandbox = '';
			}
			
			readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') {
				const accessToken = readedValue[`allegroAccessToken${sandbox}`];
				let parameters = {
					accessToken: accessToken,
					environment: '',
					offset: 0
				};

				let offersCount = 0;

				await chrome.storage.session.remove('auctionsWithChangesInProducts');
				let changesList = [];
		
				offersCount = await getOffersCount(parameters, 5);
				await pwProcessOffers(parameters, offersCount, changesList);

				if (changesList.length) {
					chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: `Zakończono sprawdzanie parametrów aukcji. Wykryto zmiany w ${changesList.length} aukcjach.` });
				}
			} else {
				showMessageFromBackground('Błąd! Nie znaleziono tokena dostępowego Allegro. Wykonywanie sprawdzania parametrów zostało anulowane.');
			}
    } catch (error) {
      console.log(error instanceof Error ? error.message : error);
      showMessageFromBackground(`Błąd! ${error instanceof Error ? error.message : error}`);
    }

		await chrome.action.setBadgeText({ text: '' });
		clearInterval(keepAlive);
	}
});

async function getOffersCount(parameters, count) {
	let result, response, fetchResponse, offersCount;
	try {
		fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?limit=1&publication.status=ACTIVE&publication.status=ENDED`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject('Nie udało się pobrać liczby aukcji.');
		}
	}
	if (fetchResponse.status === 200) {
		try {
			result = await fetchResponse.json();
		} catch (error) {
			return Promise.reject(`${JSON_DECODE_ERROR}. ${error?.message ? error.message : error}`);
		}
		offersCount = result.totalCount;
		return Promise.resolve(offersCount);
	} else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await refreshAllegroAccessToken();
			} catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
			}
			parameters.accessToken = response;  
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject('Nie udało się zalogować użytkownika.');
		}		
	} else if (fetchResponse.status === 403) {
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await getOffersCount(parameters, count);
		} else {
			return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
		}											
	}	
}

async	function pwProcessOffers(parameters, offersCount, changesList) {
	let intervalId;
	let currentProgress = 0, previousProgress = -1;
	let result, response, fetchResponse;

	try {
		await chrome.action.setBadgeText({ text: '' });
		await chrome.action.setBadgeBackgroundColor( { color: [0,0,0,255] });
		await getOffers(0, 5, parameters, offersCount);
	} catch (error) {
		console.log('Błąd podczas sprawdzania parametrów aukcji.');
		await chrome.action.setBadgeText({ text: '' });
		return Promise.reject(`Błąd podczas sprawdzania parametrów aukcji. ${error?.message ? error.message : error}`);
	}

	async function getOffers(offset, count, parameters, offersCount) {
		if (pwWorkEnabled === false) return Promise.resolve(true);
		currentProgress = Math.ceil((offset / offersCount) * 100);
		if (currentProgress > previousProgress) {
			previousProgress = currentProgress;
			clearInterval(intervalId);
			intervalId = showScrollingBadge(`PW${currentProgress}%`);
		}

		if (offset > offersCount) {
			console.log('Zakończono pobieranie parametrów ofert.');
			clearInterval(intervalId);
			await chrome.action.setBadgeText({ text: '' });
			return Promise.resolve(true);
		}
		try {
			fetchResponse = await fetch(`https://api.allegro.pl${parameters.environment}/sale/offers?offset=${offset}&limit=10&publication.status=ACTIVE&publication.status=ENDED`, {
				'method': 'GET',
				'headers': {
					'Authorization': `Bearer ${parameters.accessToken}`,
					'Content-Type': 'application/vnd.allegro.public.v1+json',
					'Accept': 'application/vnd.allegro.public.v1+json'
				}
			});
		} catch (error) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject('Nie udało się pobrać aukcji.');
			}
		}
		if (fetchResponse.status === 200) {
			try {
				result = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`${JSON_DECODE_ERROR}. ${error?.message ? error.message : error}`);
			}
						
			let offersList = [];
			result.offers.forEach(offer => {
				offersList.push(offer.id);
			});

			if (offersList.length) {
				do {
					if (pwWorkEnabled === false) break;
					const offerId = offersList.shift();
					if (offerId === undefined) {
						if (result.totalCount > (offset + 10)) {
							await new Promise(resolve => setTimeout(resolve, 0));
							return await getOffers(offset + 10, 5, parameters, offersCount);
						} else {
							console.log('Zakończono pobieranie parametrów ofert.');
							clearInterval(intervalId);
							await chrome.action.setBadgeText({ text: '' });
							return Promise.resolve(true);
						}
					}

					let offer, offerStored, changeOccured;
					try {
						offer = await pwGetOfferProductData(5, offerId, parameters);
						console.log('Aktualne dane aukcji:');
						console.log(offer);
						offerStored = await offerParametersGet(offerId);
						if (offerStored === undefined) {
							console.log('Brak aukcji w bazie, zapisano');
							offerParametersSave(offer);
							continue;
						}

						console.log('Zapisane dane aukcji:');
						console.log(offerStored);

						for (let i = 0; i < offer.products.length; i++) {
							changeOccured = compareObjects(offer.products[i], offerStored.products[i]);
							if (changeOccured) {
								console.log(`Produkt w ofercie ${offerId} uległ zmianie`);
								changesList.push(offerId);
								await chrome.storage.session.set({ auctionsWithChangesInProducts: changesList });
								chrome.notifications.create('AllegrExtensionsProductChange', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: `Znaleziono zmiany w produktach`, buttons: [{ title: 'Pokaż wyniki sprawdzania' }], silent: true }).catch(() => {});
							}
						}
					} catch (error) {
						console.log(`Błąd! ${error?.message ? error.message : error}`);
					}
				} while (offersList.length > 0);

				if (result.totalCount > (offset + 10) && pwWorkEnabled) {
					await new Promise(resolve => setTimeout(resolve, 0));
					return await getOffers(offset + 10, 5, parameters, offersCount);
				} else {
					console.log('Zakończono pobieranie parametrów ofert.');
					clearInterval(intervalId);
					await chrome.action.setBadgeText({ text: '' });
					return Promise.resolve(true);
				}
			}
		} else if (fetchResponse.status === 401) {
			if (--count) {
				try {
					response = await refreshAllegroAccessToken();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				parameters.accessToken = response; 
				return await getOffers(offset, count, parameters, offersCount) 
			} else {
				return Promise.reject('Nie udało się zalogować użytkownika.');
			}		
		} else if (fetchResponse.status === 403) {
			return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
		} else if (fetchResponse.status === 429) {
			console.log('zbyt duża liczba żądań');
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 65000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject('Zbyt duża liczba zapytań API.');
			}
		}	else if (fetchResponse.status === 500) {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject(`Błąd serwera w trakcie pobierania aukcji, spróbuj ponownie później.`);
			}
		} else {
			if (--count) {
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await getOffers(offset, count, parameters, offersCount);
			} else {
				return Promise.reject(`Nie udało się pobrać aukcji. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			}
		}
	}
}

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
	if (buttonIndex === 0) {
		if (notificationId.indexOf('AllegrExtensionsProductChange') === 0) {
			chrome.tabs.create({ url: chrome.runtime.getURL('parameters_watcher_popup.html') }).catch(() => {});
		}
	}
});

async function pwGetOfferProductData(count, offerId, parameters) {
	let response;
	try {
		response = await fetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let offerData;
		let offerProducts = [];
		try {
			offerData = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (offerData.productSet !== undefined) {
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        let product;
        try {
          product = await pwGetProductData(5, productId, parameters);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
        offerProducts.push(product);
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts });
		}
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response;
      return await pwGetOfferProductData(count, offerId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Błąd serwera w trakcie pobierania parametrów produktu w ofercie ${offerId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać parametrów produktu w ofercie ${offerId}. Kod odpowiedzi HTTP: ${response.status}`);
		}
	}
}

async function pwGetProductData(count, productId, parameters) {
	let response;
  const product = {
    id: productId,
    name: '',
    parameters: [],
    images: []
  }
	try {
		response = await fetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let productData;
		try {
			productData = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}	
													
		if (productData.name !== undefined) {
      product.name = productData.name;
      productData.parameters.forEach(parameter => product.parameters.push({ name: parameter.name, values: parameter.valuesLabels }));
      productData.images.forEach(image => product.images.push(image.url));
			return Promise.resolve(product);
		} else return Promise.reject(`W pobranych danych produktu nie znaleziono wymaganych parametrów.`);
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await refreshAllegroAccessToken();
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response;
      return await pwGetProductData(count, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania parametrów produktu ${productId}, spróbuj ponownie później.`);
		}
	} else {
		if (--count) {
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Nie udało się pobrać parametrów produktu ${productId}. Kod odpowiedzi HTTP: ${response.status}`);
		}
	}
}

function compareObjects(current, stored) {
	let changeOccured = false; 

	if (current.name !== stored.name) {
		changeOccured = true;
	}

	if (current.images.length !== stored.images.length && current.images.length) {
		changeOccured = true;
	}

	for (let i = 0; i < current.images.length; i++) {
		let image;
		image = stored.images.find(image => image === current.images[i]);
		if (image === undefined) {
			changeOccured = true;
		}
	}

	if (current.images.length) {
		for (let i = 0; i < stored.images.length; i++) {
			let image;
			image = current.images.find(image => image === stored.images[i]);
			if (image === undefined) {
				changeOccured = true;
			}
		}
	}
	
	if (current.parameters.length !== stored.parameters.length) {
		changeOccured = true;
	}

	for (let i = 0; i < current.parameters.length; i++) {
		let parameter;
		parameter = stored.parameters.find(parameter => parameter.name === current.parameters[i].name);
		if (parameter === undefined) {
			changeOccured = true;
		} 
	}

	for (let i = 0; i < stored.parameters.length; i++) {
		let parameter;
		parameter = current.parameters.find(parameter => parameter.name === stored.parameters[i].name);
		if (parameter === undefined) {
			changeOccured = true;
		}
	}
	
	return changeOccured;
}

function showScrollingBadge(text) {
	let badgeText = text;
	let index = 0;
	const interval = setInterval(() => {
		if (index >= badgeText.length) {
			index = 0;
		}
		const slicedText = badgeText.slice(index, index + 4);
		chrome.action.setBadgeText({ text: slicedText.padEnd(8 - slicedText.length) });
		index += 1;
	}, 1000);
	return interval;
}

async function refreshAllegroAccessToken(mode) {
	let sandbox = (mode === 'sandbox' ? 'Sandbox' : '');
	let readedValue;
	let fetchResponse;
	let fetchData;
	
	try {
		readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
	} catch (error) {
		return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
	}
	if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');

	const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
	const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
	const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
	const redirectUrl = chrome.identity.getRedirectURL('allegro_extensions');

	if (sandbox === 'Sandbox') {
		try {
			readedValue = await	readDataFromLocalStorage(['allegroAPIOAuthConnectorSandbox']);
		} catch (error) {
			return Promise.reject(`Podczas odczytu wymaganych parametrów (adres skryptu) wystąpił błąd. ${error?.message ? error.message : error}`);
		}
		if (!readedValue.allegroAPIOAuthConnectorSandbox) {
			return Promise.reject('Brak wymaganych parametrów (adres skryptu).');
		}

		try {
			fetchResponse = await fetch(readedValue.allegroAPIOAuthConnectorSandbox, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ action: 'refreshTokens', clientId: allegroAPIClientId, clientSecret: allegroAPIClientSecret, refreshToken: allegroRefreshToken })
			});
		} catch (error) {
			return Promise.reject(`Nie udało się uzyskać tokenów dostępowych za pośrednictwem skryptu. ${error?.message ? error.message : error}`);
		}

		if (fetchResponse.status === 200) {
			try {
				fetchData = await fetchResponse.json();
			} catch (error) {
				return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
			}

			if (fetchData?.status === 'success') {
				try {
					await saveDataToLocalStorage({
						allegroAccessTokenSandbox: fetchData.accessToken,
						allegroRefreshTokenSandbox: fetchData.refreshToken,
						allegroTokenScopesSandbox: fetchData.scope
					});
				} catch (error) {
					return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
				}

				return Promise.resolve(fetchData.accessToken);
			} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
				return Promise.reject(`${UNABLE_TO_REFRESH_TOKENS} ${fetchData.details}`);
			} else return Promise.reject(UNABLE_TO_REFRESH_TOKENS);
		} else {
			return Promise.reject(`Podczas odświeżania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}.`);
		}
	} else {
		async function refreshToken(count = 3) {
			let fetchResponse;
			let fetchData;
			try {
				fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
					method: 'POST',
					headers: {
						'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
						'Content-Type': 'application/x-www-form-urlencoded'
					}
				});
			} catch (error) {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await refreshToken(count);
				} else {
					return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
				}
			}

			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`${JSON_DECODE_ERROR} ${error?.message ? error.message : error}.`);
				}

				if (fetchData.access_token === undefined || fetchData.refresh_token === undefined || fetchData.scope === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

				try {
					await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token, allegroTokenScopes: fetchData.scope.split(' ').join(', ') });
				} catch (error) {
					return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error?.message ? error.message : error}`);
				}

				return Promise.resolve(fetchData.access_token);
			} else {
				if (--count) {
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await refreshToken(count);
				} else {
					return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
				}
			}
		}
		try {
			const result = await refreshToken();
			return Promise.resolve(result);
		} catch (error) {
			return Promise.reject(result);
		}
	}
}

async function getCurrentTab() {
  const queryOptions = { active: true, currentWindow: true, status: 'complete', url: `https://salescenter.allegro.com${environment}/*` };
  try {
    let [tab] = await chrome.tabs.query(queryOptions);
    return Promise.resolve(tab);
  } catch (error) {
    return Promise.reject('Nie udało się pobrać aktywnej karty.');
  }
}

async function showMessageFromBackground(message) {
  let tab;
  let response;
  try {
    tab = await getCurrentTab();
  } catch (error) {
    console.log(error);
  }

  if (tab !== undefined) {
    try {
      response = await sendMessage(tab.id, { action: 'toast', message: message });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      console.log(error instanceof Error ? error.message : error);
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: message });
      } else {
        optionsPageMessage(message);
      }
    }
  } else {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Allegro Extensions', message: message });
		} else {
			optionsPageMessage(message);
		}    
  }
  return Promise.resolve(true);
}


(async function checkUpdate() {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['updateLastChecked']);
	} catch (error) {
		optionsPageMessage(`Błąd! Podczas odczytu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${error?.message ? error.message : error}`);
		return;
	}
	if (!readedValue.updateLastChecked) {
		const currentDate = new Date();
		readedValue.updateLastChecked = currentDate.toString();
		try {
			await saveDataToLocalStorage({ updateLastChecked: readedValue.updateLastChecked });
			return;
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${error?.message ? error.message : error}`);
			return;
		}
	}

	const currentDate = new Date();
	const lastChecked = new Date(readedValue.updateLastChecked);

	const msDifference = currentDate - lastChecked;
	const msIn24Hours = 24 * 60 * 60 * 1000;

	if (msDifference >= msIn24Hours) {
		try {
			await saveDataToLocalStorage({ updateLastChecked: currentDate.toString() });
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${error?.message ? error.message : error}`);
			return;
		}
	} else {
		console.log('Nie minęły 24h od ostatniego sprawdzania aktualizacji. Pomijam sprawdzanie aktualizacji.');
		return;
	}
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Allegro-Extensions/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Allegro-Extensions' }).catch(() => {});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
})();