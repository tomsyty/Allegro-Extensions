window.addEventListener('load', async () => {
	console.log('Załadowano skrypt sendMessageFromOrdersPage');
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;

  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders`)) {
    try {
      await sendMessageFromOrdersPageAwaitOrdersTable();
      await sendMessageFromOrdersPageAwaitOrders();
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    }
  } else if (location.href.startsWith(`https://salescenter.allegro.com${environment}/returns`)) {
    try {
      await sendMessageFromOrdersPageAddMessageButton();
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    }
  }	else if (location.href.startsWith(`https://salescenter.allegro.com${environment}/message-center/messages/new-message`)) {
    try {
      await sendMessageFromOrdersPageFillFields();
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    }
  }
});

async function returnPageSendMessageButtonClick(e) {
  e.target.disabled = true;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  const returnParentElement = this.closest('div[class~="_992f8_KF-cc"]');
  const orderId = returnParentElement.querySelector('a[data-analytics-click-label="goToOrder"]')?.href.split('=')[1];
  const buyerLogin = returnParentElement.querySelector('a[data-analytics-click-label="buyerLink"]')?.textContent;
  if (!orderId || !buyerLogin) {
    toastMessage('Błąd! Nie znaleziono wymaganych parametrów - numer zamówienia lub nazwa użytkownika.');
    e.target.disabled = false;
    return;
  }
  const linkElement = document.createElement('a');
  linkElement.href = `https://salescenter.allegro.com${environment}/message-center/messages/new-message?login=${buyerLogin}&orderid=${orderId}`;
  linkElement.target = '_blank';
  document.body.appendChild(linkElement);
  linkElement.click();
  document.body.removeChild(linkElement);
  e.target.disabled = false;
}

async function sendMessageFromOrdersPageAddMessageButton() {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(element => {
          if (element.nodeName === 'DIV' && element.classList.contains('_992f8_KF-cc') && (!element.querySelector('button[class~="sendMessageFromOrdersPage"]'))) {
            const returnDecisionButton = element.querySelector('button[data-analytics-interaction-label="dropdownReturnDecision"]');
            const sendMessageButton = document.createElement('button');
            sendMessageButton.className = returnDecisionButton.className;
            sendMessageButton.classList.remove('m7er_k4');
            sendMessageButton.classList.remove('m3h2_0');
            sendMessageButton.style.marginRight = '20px';
            sendMessageButton.classList.add('sendMessageFromOrdersPage');
            sendMessageButton.textContent = 'Wyślij wiadomość';
            sendMessageButton.addEventListener('click', returnPageSendMessageButtonClick);
            returnDecisionButton.parentElement.parentElement.firstElementChild.insertAdjacentElement('afterend', sendMessageButton);
          }
        });
      }
    });
  });
  observer.observe(document.querySelector('div[data-box-name="allegro.returns.listing_condition"]'), { subtree: true, childList: true });

  document.querySelectorAll('div[class~="_992f8_KF-cc"]').forEach(element => {
    if (!element.querySelector('button[class~="sendMessageFromOrdersPage"]')) {
      const returnDecisionButton = element.querySelector('button[data-analytics-interaction-label="dropdownReturnDecision"]');
      const sendMessageButton = document.createElement('button');
      sendMessageButton.className = returnDecisionButton.className;
      sendMessageButton.classList.remove('m7er_k4');
      sendMessageButton.classList.remove('m3h2_0');
      sendMessageButton.style.marginRight = '20px';
      sendMessageButton.classList.add('sendMessageFromOrdersPage');
      sendMessageButton.textContent = 'Wyślij wiadomość';
      sendMessageButton.addEventListener('click', returnPageSendMessageButtonClick);
      returnDecisionButton.parentElement.parentElement.firstElementChild.insertAdjacentElement('afterend', sendMessageButton);
    }
  });
  return Promise.resolve(true);
}

async function sendMessageFromOrdersPageAwaitOrdersTable() {
	const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	let previousUrl = '';
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
						return await sendMessageFromOrdersPageAwaitOrdersTable();
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				return await sendMessageFromOrdersPageAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      urlObserver.observe(document, {	subtree: true, childList: true });
			await new Promise(resolve => setTimeout(resolve, 2000));
			try {
      	await sendMessageFromOrdersPageAwaitOrders();
			} catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      }
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function sendMessageFromOrdersPageAwaitOrders() {
  let ordersRows, ordersRowsFound;

  do {
    ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
    ordersRowsFound = ordersRows.length;
    if (ordersRowsFound) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
      if (ordersRowsFound !== ordersRows.length) {
        ordersRowsFound = ordersRows.length;
        continue;
      }
    }
    break;
  } while (1);

  ordersRows.forEach(element => {
    element = element.nextElementSibling;
    if (!element.querySelector('button[class~="sendMessageFromOrdersPage"]')) {
      const sellerNoteButton = element.querySelector('button[data-test-id="sellerNoteButton"]');
      const sendMessageButton = document.createElement('button');
      sendMessageButton.className = sellerNoteButton.className;
      sendMessageButton.classList.add('sendMessageFromOrdersPage');
      sendMessageButton.textContent = 'Wyślij wiadomość';
      sendMessageButton.addEventListener('click', ordersPageButtonClick);
      sellerNoteButton.insertAdjacentElement('afterend', sendMessageButton);
    }
  });

  return Promise.resolve(true);
}

async function ordersPageButtonClick(e) {
  e.target.disabled = true;
  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  const orderParentElement = this.closest('div[class^="order"]');
  const buyerLogin = orderParentElement.querySelector('span[class="buyer-details"] a').textContent;
  const orderId = orderParentElement.querySelector('a[aria-label="Szczegóły zamówienia"]').getAttribute('orderid');
  console.log(buyerLogin + ': ' + orderId);
  const linkElement = document.createElement('a');
  linkElement.href = `https://salescenter.allegro.com${environment}/message-center/messages/new-message?login=${buyerLogin}&orderid=${orderId}`;
  linkElement.target = '_blank';
  document.body.appendChild(linkElement);
  linkElement.click();
  document.body.removeChild(linkElement);
  e.target.disabled = false;
}

async function sendMessageFromOrdersPageFillFields(e) {
  const urlParams = new URLSearchParams(window.location.search);
  const buyerLogin = urlParams.get('login');
  const orderId = urlParams.get('orderid');
  let loginInput;
  let orderIdInput;
  let textAreaInput;

  const inputEvent = new Event('input', { bubbles: true });

  const delay = t => new Promise(resolve => setTimeout(resolve, t));
  let i = 50;

  do {
    loginInput = document.getElementById('recipient');
    orderIdInput = document.getElementById('order');
    textAreaInput = document.getElementById('message');
    if (loginInput === null || orderIdInput === null || textAreaInput === null) {
      await delay(100);
    } else break;
  } while (i--);
  
  if (i > 0) {
    await delay(10);
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(loginInput, buyerLogin);
    loginInput.dispatchEvent(inputEvent);
    await delay(10);
    nativeInputValueSetter.call(orderIdInput, orderId);
    orderIdInput.dispatchEvent(inputEvent);
    await delay(10);
    textAreaInput.setAttribute('tabindex', -1);
    textAreaInput.focus();
    textAreaInput.dispatchEvent(new Event('focus', { bubbles: true }));
  } else {
    toastMessage('Błąd! Nie znaleziono wszystkich pól formularza w wyznaczonym czasie. Uzupełnij odpowiednie pola ręcznie.');
  }

  return Promise.resolve(true);
}