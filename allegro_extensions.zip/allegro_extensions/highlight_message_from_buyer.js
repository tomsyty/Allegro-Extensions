async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt highlightMessageFromBuyer');

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;
   
  let response;
  try {
    response = await sendMessage({ action: 'hmfbGet' });
    if (!response.success) throw new Error(response.result);
  } catch (error) {
    toastMessage(`Błąd! Podczas odczytu informacji o sposobie wyróżniania wiadomości od kupującego wystąpił błąd. ${getErrorMessage(error)}`);
    return;
  }
  const css = '<style>.aeHMFB {' + response.result + '}</style>';
  document.head.insertAdjacentHTML('beforeend', css);
  document.querySelectorAll('div[class*="buyer-note"] > div > p[data-test-id="buyerNoteContent"]:not(.aeHMFB)').forEach(msg => { msg.classList.add('aeHMFB'); });
  try {
    await highlightMessageFromBuyer();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }
});

async function highlightMessageFromBuyer() {
  let observedElement;

	async function hmfbWaitForOrdersTable(count = 50) {
		observedElement = document.querySelectorAll('div[data-box-name="allegro.orders.listing"]');
		if (!observedElement.length) {
			if (--count) {
        await new Promise(resolve => setTimeout(resolve, 500));
				await hmfbWaitForOrdersTable(count);	
			} else return Promise.reject(false);		
		} else return Promise.resolve(true);
  }

  try {
    await hmfbWaitForOrdersTable();
  } catch (error) {
    return Promise.reject('Nie znaleziono listy zamówień. Wiadomości do zakupu nie zostaną wyróżnione.');
  } 
  highlightMessageFromBuyerObserve(observedElement[0]);
  return Promise.resolve(true);
}

function highlightMessageFromBuyerObserve(observedElement) {
	const observer = new MutationObserver(() => {
		observer.disconnect();			
		document.querySelectorAll('div[class*="buyer-note"] > div > p[data-test-id="buyerNoteContent"]:not(.aeHMFB)').forEach(msg => { msg.classList.add('aeHMFB'); });
		highlightMessageFromBuyerObserve(observedElement);
	});	
	
	observer.observe(observedElement, { subtree: true, childList: true });
}