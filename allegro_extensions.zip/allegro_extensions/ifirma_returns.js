async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

async function addItemButtonClick() {
  const returnsListTable = document.getElementById('returnsList');
  if (returnsListTable === null) return;
  const returnsListRows = returnsListTable.rows;
  const restoreTable = document.querySelector('div[class="table-responsive"] table');
  if (returnsListRows.length > 1) {
    const currentRow = returnsListRows[1];
    const restoreTableRowPosition = restoreTable.rows.length - 2;
    restoreTable.rows[restoreTableRowPosition].cells[1].firstElementChild.value = currentRow.cells[0].innerText;
    restoreTable.rows[restoreTableRowPosition].cells[2].firstElementChild.value = currentRow.cells[1].innerText;
    restoreTable.rows[restoreTableRowPosition].cells[3].firstElementChild.value = currentRow.cells[2].innerText;
    returnsListTable.deleteRow(1);
  }
  await new Promise(resolve => setTimeout(resolve, 500));
  let addItemButton;
  do {
    addItemButton = document.querySelector('div[class="table-responsive"] table');
    if (addItemButton === null) {
      await new Promise(resolve => setTimeout(resolve, 500));
      continue;
    }

    addItemButton = Array.from(addItemButton.querySelectorAll('a')).find(element => element.innerText === 'Dodaj pozycję');
    if (addItemButton === undefined) {
      await new Promise(resolve => setTimeout(resolve, 500));
      continue;
    } 
  } while (addItemButton === undefined || addItemButton === null);

  addItemButton.addEventListener('click', addItemButtonClick);
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt iFirmaReturns');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});


async function asyncOnMessageCallback(request, sender) {
	const action = request.action;

	switch (action) {
    case 'fillRefundForm': {
      let i = 0;

      const header = document.getElementById('pozycjeUpdateArea');
      if (header === null) return Promise.reject('Nie znaleziono otwartej karty z protokołem anulowania sprzedaży.');
      
      let returnsList = document.getElementById('returnsList');
      if (returnsList !== null) {
        returnsList.remove();
      }
      
      returnsList = '<div><table id="returnsList"><thead><tr><th>Nazwa</th><th>Ilość</th><th>Cena</th></tr></thead><tbody>';

      for (let item of request.restoreList) {
        i++;
        console.log(`${item.itemName}, ${item.quantity} szt., ${item.price} zł/szt.`);
        returnsList += `<tr><td>${item.itemName}</td><td>${item.quantity}</td><td>${item.price}</td></tr>`;
      }
      returnsList += '</tbody></table></div>';
      header.insertAdjacentHTML('beforebegin', returnsList);
      const restoreTable = document.querySelector('div[class="table-responsive"] table');
      const addItemButton = Array.from(restoreTable.querySelectorAll('a')).find(element => element.innerText === 'Dodaj pozycję');
      addItemButton.addEventListener('click', addItemButtonClick);
      toastMessage('Klikaj przycisk "Dodaj pozycję" aby uzupełniać protokół anulowania sprzedaży o kolejne pozycje z powyższej listy zwróconych przedmiotów.');
      return Promise.resolve(true);
    }
  }
}