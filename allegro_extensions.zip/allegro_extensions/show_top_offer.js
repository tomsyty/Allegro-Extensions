async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

function backgroundFetchPartially(url, offerId) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'backgroundFetchPartially',
      url: url,
      offerId: offerId
    }, (response) => {
      if (response.success) {
        resolve(response.result);
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', () => {
	console.log('Załadowano skrypt showTopOffer');
  let offers = {};
	awaitOffersTable(offers);
});

async function awaitOffersTable(offers) {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable,
    stopWorking: false
	}

  const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
	parameters.environment = environment;

	if (offersTable === null) {
		const pageObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
            pageObserver.takeRecords();
						pageObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						await awaitOffersTable(offers);
					}
				}
			}
		});
		pageObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				await awaitOffersTable(offers);
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
      await getAuctions(parameters, offers);
		}
		urlObserver.observe(document, { subtree: true, childList: true });

    const offersTableObserver = new MutationObserver(async (mutations) => {
      if (parameters.stopWorking) {
        offersTableObserver.takeRecords();
        offersTableObserver.disconnect();
        urlObserver.disconnect();
      } 
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          if (Array.from(mutation.addedNodes).filter(element => element.nodeName === 'TR' && element.dataset.cy !== undefined)?.length) {
            offersTableObserver.takeRecords();
            offersTableObserver.disconnect();
            await getAuctions(parameters, offers);
            offersTableObserver.observe(parameters.offersTable, { subtree: true, childList: true });
          }
        }
      }	
    });
    offersTableObserver.observe(parameters.offersTable, { subtree: true, childList: true });
	}	
}

async function getAuctions(parameters, offers) {
	let offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="top_${element.dataset.cy}"]`) === null);
	
	if (!offersList.length) {
		return;
	}

  let offersToGet = [];
  let topOfferState;
  let offerId;
	for (const offer of offersList) {
    offerId = offer.dataset.cy;
		if (!offers[offerId]) {
      offers[offerId] = null;
      offersToGet.push(offerId);
      if (!offer.querySelector(`div[data-id="top_${offerId}"]`)) {
        const badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">TOP</div>`;
        offer.children[5].insertAdjacentHTML('beforeend', badge);
      }
    } else {
      if (offer === null) continue;
      let badge = offer.querySelector(`div[data-id="top_${offerId}"]`);
      if (offers[offerId] === 'top') {
        if (badge === null) {
          badge = `<div data-id="top_${offerId}" class="topOfferBadge">TOP</div>`;
          offer.children[5].insertAdjacentHTML('beforeend', badge);
        } else {
          badge.innerText = 'TOP';
          badge.classList = 'topOfferBadge';
        }
      } else {
        if (badge === null) {
          badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">NOR</div>`;
          offer.children[5].insertAdjacentHTML('beforeend', badge);
        } else {
          badge.innerText = 'NOR';
          badge.classList = 'unknownOfferBadge';
        }
      }
    }
	}
	
	while (offersToGet.length > 0) {
		const offerId = offersToGet.shift();
		const offer = parameters.offersTable.querySelector(`tr[data-cy="${offerId}"]`);
		if (offer === null) continue;
		const productIdHrefElement = offer.querySelector('a[href*="/changes-in-product-catalogue/report/"]');
		if (productIdHrefElement === null) continue;
		const productId = productIdHrefElement.href.slice(productIdHrefElement.href.lastIndexOf('/') + 1);
    if (!offers[offerId]) {
      try {
        topOfferState = await checkTopOffer(offerId, productId, parameters);
        offers[offerId] = topOfferState;
        let badge = offer.querySelector(`div[data-id="top_${offerId}"]`);
        if (topOfferState === 'top') {
          if (badge === null) {
            const badge = `<div data-id="top_${offerId}" class="topOfferBadge">TOP</div>`;
            offer.children[5].insertAdjacentHTML('beforeend', badge);
          } else {
            badge.innerText = 'TOP';
            badge.classList = 'topOfferBadge';
          }
        } else {
          if (badge === null) {
            badge = `<div data-id="top_${offerId}" class="unknownOfferBadge">NOR</div>`;
            offer.children[5].insertAdjacentHTML('beforeend', badge);
          } else {
            badge.innerText = 'NOR';
            badge.classList = 'unknownOfferBadge';
          }
        }
      } catch (error) {
        if (error === 'tooManyRequests') {
          if (window.confirm('Błąd! Przekroczono limit zapytań. Otwórz dowolną stronę allegro.pl (ale nie w domenie salescenter.allegro.com) i rozwiąż captcha aby zdjąć blokadę Allegro a następnie kliknij OK aby kontynuować.')) {
            try {
              topOfferState = await checkTopOffer(offerId, productId, parameters);
              offers[offerId] = topOfferState;
            } catch (error) {
              if (error === 'tooManyRequests') {
                toastMessage('Błąd! Przekroczono limit zapytań. Otwórz dowolną stronę allegro.pl (ale nie w domenie salescenter.allegro.com) i rozwiąż captcha aby zdjąć blokadę Allegro. Anulowano dalsze pobieranie aukcji.');
              } else {
                toastMessage(`Błąd! ${getErrorMessage(error)}`);
              }
              parameters.stopWorking = true;
              return;
            }
          } else {
            toastMessage('Błąd! Przekroczono limit zapytań. Otwórz dowolną stronę allegro.pl (ale nie w domenie salescenter.allegro.com) i rozwiąż captcha aby zdjąć blokadę Allegro. Anulowano dalsze pobieranie aukcji.');
            parameters.stopWorking = true;
            return;
          }
        } else {
          toastMessage(`Błąd! ${getErrorMessage(error)}`);
          return;
        }
      }
    }
	}

  await new Promise(resolve => setTimeout(resolve, 5000));

  offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => parameters.offersTable.querySelector(`div[data-id="top_${element.dataset.cy}"]`) === null);
  if (offersList.length) {
    return await getAuctions(parameters, offers);
  }
}
		
async function checkTopOffer(offerId, productId, parameters) {
  const url =  `https://allegro.pl${parameters.environment}/produkt/${productId}`;
  let response;
  try {
    response = await backgroundFetchPartially(url, offerId);
  } catch (error) {
    console.log(getErrorMessage(error));
    await new Promise(resolve => setTimeout(resolve, 3000));
    return Promise.reject(getErrorMessage(error));
  }
  console.log(`auction ${offerId} is ${response} offer`);
  await new Promise(resolve => setTimeout(resolve, 3000));
  return Promise.resolve(response);
}