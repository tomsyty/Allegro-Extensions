async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt parametersWatcher');
	try {
		await pwAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
	}
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'toast': {
      toastMessage(request.message);
      return Promise.resolve(true);
    }
  }
}

async function pwAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await pwAwaitOffersTable();
						} catch (error) {
							return Promise.reject(getErrorMessage(error));
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await pwAwaitOffersTable();
				} catch (error) {
					return Promise.reject(getErrorMessage(error));
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await pwGetOffersListPrepare(parameters);
			} catch (error) {
				return Promise.reject(getErrorMessage(error));
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function pwGetOffersListPrepare(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
	}

  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['extensions']);
    if (readedValue.extensions.showProductName) {
      parameters.showProductName = true;
    }
  } catch (error) {
    return Promise.reject(`Błąd podczas sprawdzania aktywności modułu "Pokazuj nazwę produktu i jego ocenę na liście ofert". ${getErrorMessage(error)}`);
  }
  
  let accessToken = response.result; 
  parameters.accessToken = accessToken;
  parameters.environment = environment;

  const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

  const observer = new IntersectionObserver(pwIntersectionCallback, options);
  let offerProducts = {};

  async function pwIntersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.pw = false;
          observer.observe(offerRow);
        });

        try {
          await pwProcessOffersList(parameters, offersList, offerProducts);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
      }   
    });
  }

  let offersList;
  do {
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
    const offersListLength = offersList?.length;
    await new Promise(resolve => setTimeout(resolve, 2000));
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
    if (!offersList || offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);
  
  offersList.forEach(offerRow => {
    offerRow.dataset.pw = false;
    observer.observe(offerRow);
  });

	try {
		await pwProcessOffersList(parameters, offersList, offerProducts);
	} catch (error) {
		return Promise.reject(getErrorMessage(error));
	}
}

async function pwProcessOffersList(parameters, offersList, offerProducts) {
  let offerRow = offersList.shift();
	if (offerRow === undefined) return;
  if (!offerRow.isConnected) return await pwProcessOffersList(parameters, offersList, offerProducts);
  const offerId = offerRow.dataset.cy;
  offerRow.dataset.pw = true;

  if (offerProducts[offerId] !== undefined) {				
    const cached = offerProducts[offerId];
    let response;
    try {
      response = await sendMessage({ action: 'offerParametersGet', id: offerId });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      toastMessage(`Błąd! Podczas pobierania produktu z bazy wystąpił błąd. ${getErrorMessage(error)}`);
      return await pwProcessOffersList(parameters, offersList, offerProducts);
    }
    const stored = response.result;
    let changes = false;
    let comparison;
    for (let i = 0; i < cached.length; i++) {
      comparison = compareObjects(cached[i], stored.products[i]);
      if (comparison['result'] === false) changes = true;
      console.log('Produkt zapisany w bazie i obecny produkt (pobrany z cache) ' + (changes ? 'różnią się od siebie' : 'są takie same'));
      if (changes) {
        if (offerRow.isConnected && !offerRow.querySelector('parametersDiv')) {
          let parametersDivCode = /*html*/ `<div class="parametersDivTooltip">`;
          if (comparison.details.name) parametersDivCode += /*html*/ `<span class="parameterType">Nazwa</span> jest: ${comparison.details.name.current}, było: ${comparison.details.name.stored}<br />`;
          if (comparison.details.imagesCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba zdjęć</span> jest: ${comparison.details.imagesCount.current}, było: ${comparison.details.imagesCount.stored}<br />`;
          if (comparison.details.images.length > 0) {
            comparison.details.images.forEach(image => {
              parametersDivCode += /*html*/ `<span class="parameterType">Zdjęcie</span> jest: ${image.current === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.current}">link<img class="hover-image" src="${image.current}"></a>`}, było: ${image.stored === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.stored}">link<img class="hover-image" src="${image.stored}"></a>`}<br />`;
            })
          }
          if (comparison.details.parametersCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba parametrów</span> jest: ${comparison.details.parametersCount.current}, było: ${comparison.details.parametersCount.stored}<br />`;
          if (comparison.details.parameters.length > 0) {
            comparison.details.parameters.forEach(parameter => {
              parametersDivCode += /*html*/ `<span class="parameterType">Parametr</span> jest: ${parameter.current.name} - ${parameter.current.values.concat('')}, było: ${parameter.stored.name} - ${parameter.stored.values.concat('')}<br />`;
            })
          }
          parametersDivCode += /*html*/ `</div>`;
          offerRow.children[1].insertAdjacentHTML('beforeend', /*html*/ `
            <div class="parametersDiv">
              <span class="parametersDivTooltipWrapper">
                <span class="parametersDivLink">zmiany w produkcie</span>
                ${parametersDivCode}
              </span>
            </div>
          `);
          
          const parametersDivTooltip = offerRow.querySelector('.parametersDivTooltip');              
          if (comparison.details.images.length > 0) {
            parametersDivTooltip.classList.add('biggerSize');
            const spanImages = [...parametersDivTooltip.querySelectorAll('span')].filter(e => e.innerText === 'Zdjęcie');
            const lastSpanImage = spanImages[spanImages.length - 1];
            let count = 0;
            let nextSpan = lastSpanImage.nextElementSibling;
            while (nextSpan) {
              if (nextSpan.nodeName === 'SPAN') count++;
              nextSpan = nextSpan.nextElementSibling;
            }
            let addHeight = 0;
            switch(count) {
              case 1: {
                addHeight = 89; 
                break;
              }
              case 2: {
                addHeight = 68; 
                break;
              }
              case 3: {
                addHeight = 47; 
                break;
              }
              case 4: {
                addHeight = 26; 
                break;
              }
            }
            parametersDivTooltip.style.minHeight = `calc-size(fit-content, size + ${addHeight}px)`;
          }

          const parametersDivTooltipHeight = parametersDivTooltip.clientHeight;
          parametersDivTooltip.style.top = `-${parametersDivTooltipHeight > 240 ? 120 : parametersDivTooltipHeight / 2}px`;
          parametersDivTooltip.style.display = 'none';
          const parametersDivTooltipWrapper = offerRow.querySelector('.parametersDivTooltipWrapper');
          parametersDivTooltipWrapper.addEventListener('mouseenter', () => {
            parametersDivTooltip.style.display = 'block';
          });
          parametersDivTooltipWrapper.addEventListener('mouseleave', () => {
            parametersDivTooltip.style.display = 'none';
          });
        }
      }
    }
  } else {
    let offer, offerStored;
    try {
      offer = await pwGetOfferProductData(5, offerId, parameters, offerProducts);
      if (offer !== null) {
        console.log('Aktualne dane aukcji:');
        console.log(offer);
        let response = await sendMessage({ action: 'offerParametersGet', id: offerId });
        if (!response.success) throw new Error(response.result);
        if (response.result === '') {
          await sendMessage({ action: 'offerParametersSave', offer: offer });
          console.log('Zapisano produkt w bazie');
          return await pwProcessOffersList(parameters, offersList, offerProducts);
        }
        offerStored = response.result;
        console.log('Dane aukcji zapisane w bazie:');
        console.log(offerStored);
        let changes = false;
        let comparison;
        if (offer?.products?.length) {
          let i = 0;
          while(i < offer.products.length) {
            comparison = await compareObjects(offer.products[i], offerStored.products[i]);
            if (comparison.result === false) changes = true;
            console.log('Produkt zapisany w bazie i obecny produkt ' + (changes ? 'różnią się od siebie' : 'są takie same'));
            if (comparison?.updatedImages?.updated) {
              console.log('Nastąpiła zmiana adresu obrazka przy zachowaniu tej samej wielkości, aktualizuję zapisane dane');
              for (let j = 0; j < comparison.updatedImages.images.length; j++) {
                console.log(`Zmiana z ${comparison.updatedImages.images[j].stored} na ${comparison.updatedImages.images[j].current}`);
                const imageIndex = offerStored.products[i].images.indexOf(comparison.updatedImages.images[j].stored);
                if (imageIndex !== -1) {
                  offerStored.products[i].images[imageIndex] = comparison.updatedImages.images[j].current;
                  try {
                    await sendMessage({ action: 'offerParametersSave', offer: offer });
                  } catch (error) {
                    console.log(`Błąd podczas zapisywania zaktualizowanych danych aukcji ${offerId} do bazy. ${getErrorMessage(error)}`);
                  }
                }
              }
            }
            if (changes) {           
              if (offerRow.isConnected && !offerRow.querySelector('parametersDiv')) {
                let parametersDivCode = /*html*/ `<div class="parametersDivTooltip">`;
                if (comparison.details.name) parametersDivCode += /*html*/ `<span class="parameterType">Nazwa</span> jest: <span>${comparison.details.name.current}, było: ${comparison.details.name.stored}</span><br />`;
                if (comparison.details.imagesCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba zdjęć</span> jest: ${comparison.details.imagesCount.current}, było: ${comparison.details.imagesCount.stored}<br />`;
                if (comparison.details.images.length > 0) {
                  comparison.details.images.forEach(image => {
                    parametersDivCode += /*html*/ `<span class="parameterType">Zdjęcie</span> jest: ${image.current === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.current}">link<img class="hover-image" src="${image.current}"></a>`}, było: ${image.stored === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.stored}">link<img class="hover-image" src="${image.stored}"></a>`}<br />`;
                  })
                }
                if (comparison.details.parametersCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba parametrów</span> jest: ${comparison.details.parametersCount.current}, było: ${comparison.details.parametersCount.stored}<br />`;
                if (comparison.details.parameters.length > 0) {
                  comparison.details.parameters.forEach(parameter => {
                    parametersDivCode += /*html*/ `<span class="parameterType">Parametr</span> jest: ${parameter.current.name} - ${parameter.current.values.concat('')} było: ${parameter.stored.name} - ${parameter.stored.values.concat('')}<br />`;
                  })
                }
                parametersDivCode += /*html*/ `<span class="pwSaveChanges">zapisz zmiany</span></div>`;
                offerRow.children[1].insertAdjacentHTML('beforeend', /*html*/ `
                  <div class="parametersDiv">
                    <span class="parametersDivTooltipWrapper">
                      <span class="parametersDivLink">zmiany w produkcie</span>
                      ${parametersDivCode}
                    </span>
                  </div>
                `); 
                const parametersDivTooltip = offerRow.querySelector('.parametersDivTooltip');              
                if (comparison.details.images.length > 0) {
                  parametersDivTooltip.classList.add('biggerSize');
                  const spanImages = [...parametersDivTooltip.querySelectorAll('span')].filter(e => e.innerText === 'Zdjęcie');
                  const lastSpanImage = spanImages[spanImages.length - 1];
                  let count = 0;
                  let nextSpan = lastSpanImage.nextElementSibling;
                  while (nextSpan) {
                    if (nextSpan.nodeName === 'SPAN') count++;
                    nextSpan = nextSpan.nextElementSibling;
                  }
                  let addHeight = 0;
                  switch(count) {
                    case 1: {
                      addHeight = 89; 
                      break;
                    }
                    case 2: {
                      addHeight = 68; 
                      break;
                    }
                    case 3: {
                      addHeight = 47; 
                      break;
                    }
                    case 4: {
                      addHeight = 26; 
                      break;
                    }
                  }
                  parametersDivTooltip.style.minHeight = `calc-size(fit-content, size + ${addHeight}px)`;
                }
                /*min-height: calc-size(fit-content, size + 62px);*/
                if (parametersDivTooltip.clientWidth > (offerRow.getBoundingClientRect().right - offerRow.querySelector('.parametersDivLink').getBoundingClientRect().right - 20)) {
                  parametersDivTooltip.style.minWidth = 'fit-content';
                  parametersDivTooltip.style.width = offerRow.getBoundingClientRect().right - offerRow.querySelector('.parametersDivLink').getBoundingClientRect().right - 20 + 'px';
                }
                //parametersDivTooltip.style.width = offerRow.getBoundingClientRect().right - offerRow.querySelector('.parametersDivLink').getBoundingClientRect().right - 20 + 'px';
                const parametersDivTooltipHeight = parametersDivTooltip.clientHeight;

                parametersDivTooltip.style.top = `-${parametersDivTooltipHeight > 240 ? 120 : parametersDivTooltipHeight / 2}px`;
                if (offerRow === parameters.offersTable.tBodies[0].lastElementChild) {
                  if (parameters?.showProductName) {
                    do {
                      if (offerRow.querySelector('.productName')) {
                        offerRow.style.height = `${offerRow.clientHeight + (parametersDivTooltipHeight > 240 ? parametersDivTooltipHeight - 120 : parametersDivTooltipHeight / 2) + 5}px`;
                        break;
                      }
                      await new Promise(resolve => setTimeout(resolve, 100));
                    } while (true);
                  }
                  
                }
                parametersDivTooltip.style.display = 'none';
                const parametersDivTooltipWrapper = offerRow.querySelector('.parametersDivTooltipWrapper');
                parametersDivTooltipWrapper.addEventListener('mouseenter', () => {
                  parametersDivTooltip.style.display = 'block';
                });
                parametersDivTooltipWrapper.addEventListener('mouseleave', () => {
                  parametersDivTooltip.style.display = 'none';
                });
                offerRow.children[1].querySelector('.pwSaveChanges').addEventListener('click', saveOfferChange.bind(null, offer, offerRow.querySelector('.parametersDiv')));
              }
            }
            i++;
          }
        }
      }
    } catch (error) {
      toastMessage(`Błąd! Podczas pobierania produktu wystąpił błąd. ${getErrorMessage(error)}`);
      return await pwProcessOffersList(parameters, offersList, offerProducts);
    }
  }
  
	
 async function compareObjects(current, stored) {
    const returnData = {
      result: true,
      updatedImages: {
        updated: false,
        images: []
      },
      details: {
        name: null,
        imagesCount: null,
        images: [],
        parametersCount: null,
        parameters: []
      }
    };

    if (current.name !== stored.name) {
      returnData.details.name = { current: current.name, stored: stored.name };
      returnData.result = false;
    }

    if (current.images?.length !== stored.images?.length) {
      returnData.details.imagesCount = { current: current.images.length, stored: stored.images.length };
      returnData.result = false;
    }

    for (let i = 0; i < current.images.length; i++) {
      let image;
      image = stored.images.find(image => image === current.images[i]);
      if (image === undefined) {
        let foundImageBySize = false;
        const currentImageSize = await getImageSize(current.images[i]);
        if (currentImageSize) {
          for (let j = 0; j < stored.images.length; j++) {
            const storedImageSize = await getImageSize(stored.images[j]);
            if (storedImageSize && currentImageSize === storedImageSize) {
              returnData.updatedImages.updated = true;
              returnData.updatedImages.images.push({ current: current.images[i], stored: stored.images[j] });
              foundImageBySize = true;
              break;
            }
          }
        }
        if (!foundImageBySize) {
          returnData.details.images.push({ current: current.images[i], stored: '(brak)' });
          returnData.result = false;
        }
      }
    }

    for (let i = 0; i < stored.images.length; i++) {
      let image;
      image = current.images.find(image => image === stored.images[i]);
      if (image === undefined && !returnData.updatedImages.images.find(image => image.stored === stored.images[i])) {
        returnData.details.images.push({ current: '(brak)', stored: stored.images[i] });
        returnData.result = false;
      }
    }

    if (current.parameters.length !== stored.parameters.length) {
      returnData.details.parametersCount = { current: current.parameters.length, stored: stored.parameters.length };
      returnData.result = false;
    }

    for (let i = 0; i < current.parameters.length; i++) {
      let parameter;
      parameter = stored.parameters.find(parameter => parameter.name === current.parameters[i].name);
      if (parameter === undefined) {
        returnData.details.parameters.push(
          { 
            current: {
              name: current.parameters[i].name,
              values: current.parameters[i].values
            },
            stored: {
              name: '(brak)',
              values: ['(brak)']
            }
          }
        );
        returnData.result = false;
      } 
    }

    for (let i = 0; i < stored.parameters.length; i++) {
      let parameter;
      parameter = current.parameters.find(parameter => parameter.name === stored.parameters[i].name);
      if (parameter === undefined) {
        returnData.details.parameters.push(
          { 
            current: {
              name: '(brak)',
              values: ['(brak)']
            },
            stored: {
              name: stored.parameters[i].name,
              values: stored.parameters[i].values
            }
          }
        );
        returnData.result = false;
      }
    }
   
    return returnData;
  }

  return await pwProcessOffersList(parameters, offersList, offerProducts);
}

async function getImageSize(imageUrl) {
  try {
    const fetchResponse = await backgroundFetch(imageUrl, { method: 'HEAD' });
    const contentLength = fetchResponse.headers.get('content-length');
    return contentLength ? parseInt(contentLength, 10) : null;
  } catch (error) {
    console.log(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać informacji o rozmiarze obrazka ${imageUrl}. ${error.message ? error.message : error}`);
    return null;
  }
}

async function saveOfferChange(offer, parametersDiv) {
  if (window.confirm('Zapamiętać obecne dane produktu?')) {
    try {
      await sendMessage({ action: 'offerParametersSave', offer: offer });
      if (parametersDiv.isConnected) parametersDiv.remove();
      console.log('Zapisano produkt w bazie');
    } catch (error) {
      toastMessage(`Błąd! Podczas zapisu produktu w bazie wystąpił błąd. ${getErrorMessage(error)}`);
    }
  }
}

async function pwGetOfferProductData(count, offerId, parameters, offerProducts) {
	let fetchResponse, response;
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let offerData;
		try {
			offerData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (offerData.productSet !== undefined && offerData.productSet[0].product.id !== null) {
      offerProducts[offerId] = [];
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        let product;
        try {
          product = await pwGetProductData(5, productId, parameters);
        } catch (error) {
          return Promise.reject(getErrorMessage(error));
        }
        offerProducts[offerId].push(product);
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts[offerId] });
		} else return Promise.resolve(null);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await pwGetOfferProductData(count, offerId, parameters, offerProducts);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas sprawdzania parametrów produktu w ofercie ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(`Błąd serwera podczas sprawdzania parametrów produktu w ofercie ${offerId}, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
      return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
    } else {
      return Promise.reject(`Nie udało się sprawdzić parametrów produktu w ofercie ${offerId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
	}
}

async function pwGetProductData(count, productId, parameters) {
	let fetchResponse, response;
  const product = {
    id: productId,
    name: '',
    parameters: [],
    images: []
  }
	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych produktu ${productId}. ${getErrorMessage(error)}`);
		}
	}

	if (fetchResponse.status === 200) {
		let productData;
		try {
			productData = await fetchResponse.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
		}												
		if (productData.name !== undefined) {
      product.name = productData.name;
      productData.parameters.forEach(parameter => product.parameters.push({ name: parameter.name, values: parameter.valuesLabels }));
      productData.images.forEach(image => product.images.push(image.url));
			return Promise.resolve(product);
		} else return Promise.reject(`W pobranych danych produktu nie znaleziono wymaganych parametrów.`);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${getErrorMessage(error)}`);
      }
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      parameters.accessToken = response.result;
      return await pwGetProductData(count, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (fetchResponse.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject('Przekroczono limit zapytań do API Allegro. Spróbuj ponownie później.');
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(`Błąd serwera podczas pobierania danych produktu ${productId}, spróbuj ponownie później.`);
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
    } else {
		  return Promise.reject(`Nie udało się pobrać danych produktu ${productId}. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }
	}
}

