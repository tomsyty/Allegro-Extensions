async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError)) : resolve(result); 
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt parametersWatcher');
	try {
		await pwAwaitOffersTable();
	} catch (error) {
		toastMessage(`Błąd! ${error?.message ? error.message : error}`);
	}
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'toast': {
      toastMessage(request.message);
      return Promise.resolve(true);
    }
  }
}

async function pwAwaitOffersTable() {
	const offersTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	const parameters = {
		offersTable: offersTable
	}
	if (offersTable === null) {
		const offersTableObserver = new MutationObserver(async (mutations) => {
			for (const mutation of mutations) {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						await new Promise(resolve => setTimeout(resolve, 100));
						try {
							await pwAwaitOffersTable();
						} catch (error) {
							return Promise.reject(error?.message ? error.message : error);
						}
						break;
					}
				}
			}
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	} else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				await new Promise(resolve => setTimeout(resolve, 100));
				try {
					await pwAwaitOffersTable();
				} catch (error) {
					return Promise.reject(error?.message ? error.message : error);
				}
				return;
			}
		});
		
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			urlObserver.observe(document, { subtree: true, childList: true });
			try {
				await pwGetOffersListPrepare(parameters);
			} catch (error) {
				return Promise.reject(error?.message ? error.message : error);
			}
			return;
		}
		urlObserver.observe(document, { subtree: true, childList: true });
	}		
}

async function pwGetOffersListPrepare(parameters) {
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  let response;
	try {
		response = await sendMessage({ action: 'getAllegroAccessToken' });
		if (!response.success) throw new Error(response.result);
	} catch (error) {
		return Promise.reject(`Nie udało się wczytać tokena dostępowego. ${error?.message ? error.message : error}`);
	}

  let accessToken = response.result; 
  parameters.accessToken = accessToken;
  parameters.environment = environment;

  const options = {
    root: null,
    rootMargin: '100px',
    threshold: 0.1
  }

  const observer = new IntersectionObserver(pwIntersectionCallback, options);
  let offerProducts = {};

  async function pwIntersectionCallback(entries, observer) {
    entries.forEach(async (entry) => {
      if (entry.isIntersecting) {
        const offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
        offersList.forEach(offerRow => {
          offerRow.dataset.pw = false;
          observer.observe(offerRow);
        });

        try {
          await pwProcessOffersList(parameters, offersList, offerProducts);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
      }   
    });
  }

  let offersList;
  do {
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
    const offersListLength = offersList?.length;
    await new Promise(resolve => setTimeout(resolve, 2000));
    offersList = Array.from(parameters.offersTable.querySelectorAll('tr[data-cy]')).filter(element => element.dataset.pw === undefined);
    if (!offersList || offersList.length === 0 || (offersList.length !== offersListLength)) await new Promise(resolve => setTimeout(resolve, 2000));
    else break;
  } while (1);
  
  offersList.forEach(offerRow => {
    offerRow.dataset.pw = false;
    observer.observe(offerRow);
  });

	try {
		await pwProcessOffersList(parameters, offersList, offerProducts);
	} catch (error) {
		return Promise.reject(error?.message ? error.message : error);
	}
}

async function pwProcessOffersList(parameters, offersList, offerProducts) {
  let offerRow = offersList.shift();
	if (offerRow === undefined) return;
  if (!offerRow.isConnected) return await pwProcessOffersList(parameters, offersList, offerProducts);
  const offerId = offerRow.dataset.cy;
  offerRow.dataset.pw = true;

  if (offerProducts[offerId] !== undefined) {				
    const cached = offerProducts[offerId];
    let response;
    try {
      response = await sendMessage({ action: 'offerParametersGet', id: offerId });
      if (!response.success) throw new Error(response.result);
    } catch (error) {
      toastMessage(`Błąd! Podczas pobierania produktu z bazy wystąpił błąd. ${error?.message ? error.message : error}`);
      return await pwProcessOffersList(parameters, offersList, offerProducts);
    }
    const stored = response.result;
    let changes = false;
    let comparison;
    for (let i = 0; i < cached.length; i++) {
      comparison = compareObjects(cached[i], stored.products[i]);
      if (comparison['result'] === false) changes = true;
      console.log('Produkt zapisany w bazie i obecny produkt (pobrany z cache) ' + (changes ? 'różnią się od siebie' : 'są takie same'));
      if (changes) {
        if (offerRow.isConnected && !offerRow.querySelector('parametersDiv')) {
          let parametersDivCode = /*html*/ `<div class="parametersDivTooltip">`;
          if (comparison.details.name) parametersDivCode += /*html*/ `<span class="parameterType">Nazwa</span> jest: ${comparison.details.name.current}, było: ${comparison.details.name.stored}<br />`;
          if (comparison.details.imagesCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba zdjęć</span> jest: ${comparison.details.imagesCount.current}, było: ${comparison.details.imagesCount.stored}<br />`;
          if (comparison.details.images.length > 0) {
            comparison.details.images.forEach(image => {
              parametersDivCode += /*html*/ `<span class="parameterType">Zdjęcie</span> jest: ${image.current === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.current}">link<img class="hover-image" src="${image.current}"></a>`}, było: ${image.stored === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.stored}">link<img class="hover-image" src="${image.stored}"></a>`}<br />`;
            })
          }
          if (comparison.details.parametersCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba parametrów</span> jest: ${comparison.details.parametersCount.current}, było: ${comparison.details.parametersCount.stored}<br />`;
          if (comparison.details.parameters.length > 0) {
            comparison.details.parameters.forEach(parameter => {
              parametersDivCode += /*html*/ `<span class="parameterType">Parametr</span> jest: ${parameter.current.name} - ${parameter.current.values.concat('')}, było: ${parameter.stored.name} - ${parameter.stored.values.concat('')}<br />`;
            })
          }
          parametersDivCode += /*html*/ `</div>`;
          offerRow.children[1].insertAdjacentHTML('beforeend', /*html*/ `
            <div class="parametersDiv">
              <span class="parametersDivTooltipWrapper">
                <span class="parametersDivLink">zmiany w produkcie</span>
                ${parametersDivCode}
              </span>
            </div>
          `); 
        }
      }
    }
  } else {
    let offer;
    try {
      offer = await pwGetOfferProductData(5, offerId, parameters, offerProducts);
      if (offer !== null) {
        console.log('Aktualne dane aukcji:');
        console.log(offer);
        let response = await sendMessage({ action: 'offerParametersGet', id: offerId });
        if (!response.success) throw new Error(response.result);
        if (response.result === '') {
          await sendMessage({ action: 'offerParametersSave', offer: offer });
          console.log('Zapisano produkt w bazie');
          return await pwProcessOffersList(parameters, offersList, offerProducts);
        }
        console.log('Dane aukcji zapisane w bazie: ');
        console.log(response.result);
        let changes = false;
        let comparison;
        if (offer?.products?.length) {
          for (let i = 0; i < offer.products.length; i++) {
            comparison = compareObjects(offer.products[i], response.result.products[i]);
            if (comparison['result'] === false) changes = true;
            console.log('Produkt zapisany w bazie i obecny produkt ' + (changes ? 'różnią się od siebie' : 'są takie same'));
            if (changes) {           
              if (offerRow.isConnected && !offerRow.querySelector('parametersDiv')) {
                let parametersDivCode = /*html*/ `<div class="parametersDivTooltip">`;
                if (comparison.details.name) parametersDivCode += /*html*/ `<span class="parameterType">Nazwa</span> jest: ${comparison.details.name.current}, było: ${comparison.details.name.stored}<br />`;
                if (comparison.details.imagesCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba zdjęć</span> jest: ${comparison.details.imagesCount.current}, było: ${comparison.details.imagesCount.stored}<br />`;
                if (comparison.details.images.length > 0) {
                  comparison.details.images.forEach(image => {
                    parametersDivCode += /*html*/ `<span class="parameterType">Zdjęcie</span> jest: ${image.current === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.current}">link<img class="hover-image" src="${image.current}"></a>`}, było: ${image.stored === '(brak)' ? '(brak)' : `<a class="hover-link" target="_blank" href="${image.stored}">link<img class="hover-image" src="${image.stored}"></a>`}<br />`;
                  })
                }
                if (comparison.details.parametersCount) parametersDivCode += /*html*/ `<span class="parameterType">Liczba parametrów</span> jest: ${comparison.details.parametersCount.current}, było: ${comparison.details.parametersCount.stored}<br />`;
                if (comparison.details.parameters.length > 0) {
                  comparison.details.parameters.forEach(parameter => {
                    parametersDivCode += /*html*/ `<span class="parameterType">Parametr</span> jest: ${parameter.current.name} - ${parameter.current.values.concat('')} było: ${parameter.stored.name} - ${parameter.stored.values.concat('')}<br />`;
                  })
                }
                parametersDivCode += /*html*/ `<span class="pwSaveChanges">zapisz zmiany</span></div>`;
                offerRow.children[1].insertAdjacentHTML('beforeend', /*html*/ `
                  <div class="parametersDiv">
                    <span class="parametersDivTooltipWrapper">
                      <span class="parametersDivLink">zmiany w produkcie</span>
                      ${parametersDivCode}
                    </span>
                  </div>
                `); 
                if (comparison.details.images.length > 0) {
                  offerRow.querySelector('.parametersDivTooltip').classList.add('biggerSize');
                }
                if (offerRow === parameters.offersTable.tBodies[0].lastElementChild) {
                  offerRow.style.height = `${offerRow.clientHeight + (comparison.details.images.length ? 50 : 0) + (18 * offerRow.querySelector('.parametersDivTooltip').querySelectorAll('span').length)}px`;
                }
                offerRow.children[1].querySelector('.pwSaveChanges').addEventListener('click', saveOfferChange.bind(null, offer));
              }
            }
          }
        }
      }
    } catch (error) {
      toastMessage(`Błąd! Podczas pobierania produktu wystąpił błąd. ${error?.message ? error.message : error}`);
      return await pwProcessOffersList(parameters, offersList, offerProducts);
    }
  }
  
	
  function compareObjects(current, stored) {
    const returnData = {
      result: true,
      details: {
        name: null,
        imagesCount: null,
        images: [],
        parametersCount: null,
        parameters: []
      }
    };

    if (current.name !== stored.name) {
      returnData.details.name = { current: current.name, stored: stored.name };
      returnData.result = false;
    }

    

    if (current.images?.length !== stored.images?.length) {
      returnData.details.imagesCount = { current: current.images.length, stored: stored.images.length };
      returnData.result = false;
    }

    for (let i = 0; i < current.images.length; i++) {
      let image;
      image = stored.images.find(image => image === current.images[i]);
      if (image === undefined) {
        returnData.details.images.push({ current: current.images[i], stored: '(brak)' });
        returnData.result = false;
      }
    }

    for (let i = 0; i < stored.images.length; i++) {
      let image;
      image = current.images.find(image => image === stored.images[i]);
      if (image === undefined) {
        returnData.details.images.push({ current: '(brak)', stored: stored.images[i] });
        returnData.result = false;
      }
    }
   
    if (current.parameters.length !== stored.parameters.length) {
      returnData.details.parametersCount = { current: current.parameters.length, stored: stored.parameters.length };
      returnData.result = false;
    }

    for (let i = 0; i < current.parameters.length; i++) {
      let parameter;
      parameter = stored.parameters.find(parameter => parameter.name === current.parameters[i].name);
      if (parameter === undefined) {
        returnData.details.parameters.push(
          { 
            current: {
              name: current.parameters[i].name,
              values: current.parameters[i].values
            },
            stored: {
              name: '(brak)',
              values: ['(brak)']
            }
          }
        );
        returnData.result = false;
      } 
    }

    for (let i = 0; i < stored.parameters.length; i++) {
      let parameter;
      parameter = current.parameters.find(parameter => parameter.name === stored.parameters[i].name);
      if (parameter === undefined) {
        returnData.details.parameters.push(
          { 
            current: {
              name: '(brak)',
              values: ['(brak)']
            },
            stored: {
              name: stored.parameters[i].name,
              values: stored.parameters[i].values
            }
          }
        );
        returnData.result = false;
      }
    }
   
    return returnData;
  }

  return await pwProcessOffersList(parameters, offersList, offerProducts);
}

async function saveOfferChange(offer) {
  if (window.confirm('Zapamiętać obecne dane produktu?')) {
    try {
      await sendMessage({ action: 'offerParametersSave', offer: offer });
      console.log('Zapisano produkt w bazie');
    } catch (error) {
      toastMessage(`Błąd! Podczas zapisu produktu w bazie wystąpił błąd. ${error?.message ? error.message : error}`);
    }
  }
}

async function pwGetOfferProductData(count, offerId, parameters, offerProducts) {
	let response;
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/product-offers/${offerId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let offerData;
		try {
			offerData = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (offerData.productSet !== undefined && offerData.productSet[0].product.id !== null) {
      offerProducts[offerId] = [];
      const productsToGet = [];
      offerData.productSet.forEach(product => productsToGet.push(product.product.id));

      do {
        const productId = productsToGet.shift();
        if (productId === undefined) break;
        let product;
        try {
          product = await pwGetProductData(5, productId, parameters);
        } catch (error) {
          return Promise.reject(error?.message ? error.message : error);
        }
        offerProducts[offerId].push(product);
      } while (productsToGet.length > 0);

			return Promise.resolve({ id: offerId, products: offerProducts[offerId] });
		} else return Promise.resolve(null);
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await pwGetOfferProductData(count, offerId, parameters, offerProducts);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
		} else {
			return Promise.reject('Błąd serwera, spróbuj ponownie później.');
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
      return await pwGetOfferProductData(count, offerId, parameters, offerProducts);
    } else {
      return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
    }
	}
}

async function pwGetProductData(count, productId, parameters) {
	let response;
  const product = {
    id: productId,
    name: '',
    parameters: [],
    images: []
  }
	try {
		response = await backgroundFetch(`https://api.allegro.pl${parameters.environment}/sale/products/${productId}`, {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${parameters.accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${3 - count} z 3), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject(error?.message ? error.message : error);
		}
	}

	if (response.status === 200) {
		let productData;
		try {
			productData = await response.json();		
		} catch (error) {
			return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${error?.message ? error.message : error}`);
		}												
		if (productData.name !== undefined) {
      product.name = productData.name;
      productData.parameters.forEach(parameter => product.parameters.push({ name: parameter.name, values: parameter.valuesLabels }));
      productData.images.forEach(image => product.images.push(image.url));
			return Promise.resolve(product);
		} else return Promise.reject(`W pobranych danych produktu nie znaleziono wymaganych parametrów.`);
	} else if (response.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
				return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error?.message ? error.message : error}`);
      }
      parameters.accessToken = response.result;
      return await pwGetProductData(count, productId, parameters);  
    } else {
      return Promise.reject(`Nie udało się zalogować użytkownika.`);
    }
	} else if (response.status === 429) {
		console.log('zbyt duża liczba żądań');
		if (--count) {
			toastMessage('Zbyt duża liczba zapytań, wstrzymano na ok. 1 minutę');
			await new Promise(resolve => setTimeout(resolve, 65000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject('Zbyt duża liczba zapytań API. Odczekaj minutę i odśwież stronę celem ponowienia próby.');
		}
	} else if (response.status === 500) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
		} else {
			return Promise.reject('Błąd serwera, spróbuj ponownie później.');
		}
	} else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await pwGetProductData(count, productId, parameters);
    } else {
		  return Promise.reject(`Kod odpowiedzi HTTP: ${response.status}`);
    }
	}
}

