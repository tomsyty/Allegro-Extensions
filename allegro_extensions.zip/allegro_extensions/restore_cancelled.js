async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function backgroundFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: "backgroundFetch",
      url: url,
      options: options
    }, (response) => {
      if (response.success) {
        resolve({
          status: response.result.status,
          statusText: response.result.statusText,
          headers: new Headers(response.result.headers),
          json: () => Promise.resolve(JSON.parse(response.result.body)),
          text: () => Promise.resolve(response.result.body)
        });
      } else {
        reject(new Error(response.result));
      }
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt restoreCancelled');
	
	const sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  if (location.href.startsWith(`https://salescenter.allegro.com${environment}/orders/settings`)) return;

	restoreCancelledAwaitOrdersTable();
});

async function restoreCancelledAwaitOrdersTable() {
	const ordersTable = document.querySelector('div[data-box-name="allegro.orders.listing"]');
	let previousUrl = '';
	if (ordersTable === null) {
    const ordersTableObserver = new MutationObserver(async (mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') { 
          if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.dataset.boxName === 'allegro.orders.listing')) {
            ordersTableObserver.disconnect();
						return await restoreCancelledAwaitOrdersTable();
          }
        }
      }
    });
    ordersTableObserver.observe(document, { subtree: true,	childList: true	});
  } else {
		const urlObserver = new MutationObserver(async () => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				return await restoreCancelledAwaitOrdersTable();
			}
		});	

    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      urlObserver.observe(document, {	subtree: true, childList: true });
			await new Promise(resolve => setTimeout(resolve, 5000));
			try {
      	awaitCancelledOrders(ordersTable);
			} catch (error) {
        toastMessage(`Błąd! ${getErrorMessage(error)}`);
      }
    }
    urlObserver.observe(document, {	subtree: true, childList: true });
	}
}

async function awaitCancelledOrders(ordersTable) {
	let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}
	if (!preloadIconsContainer.querySelector('span[data-icon="check_circle"]')) {
		const iconCheckCircleOutline = document.createElement('span');
		iconCheckCircleOutline.className = 'material-symbols-outlined';
		iconCheckCircleOutline.dataset.icon = 'check_circle';
		preloadIconsContainer.appendChild(iconCheckCircleOutline);
	}

	if (!preloadIconsContainer.querySelector('span[data-icon="highlight_off"]')) {
		const iconHighlightOff = document.createElement('span');
		iconHighlightOff.className = 'material-symbols-outlined';
		iconHighlightOff.dataset.icon = 'highlight_off';
		preloadIconsContainer.appendChild(iconHighlightOff);
	}
	const params = new URLSearchParams(document.location.search);
	const status = params.get('status');
	if (status === 'CANCELLED') return;

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['extensions', 'erliRestoreCancelledCheckbox']);
	} catch (error) {
		toastMessage(`Błąd! ${getErrorMessage(error)}`);
		return;
	}

	const erliActions = readedValue.extensions['erliActions'];
	const erliRestoreCancelled = readedValue.erliRestoreCancelledCheckbox;

	if (document.getElementById('restoreItemsDialog') === null) {
		ordersTable.insertAdjacentHTML('beforeend', /*html*/ `
		<dialog id="restoreItemsDialog">
			<form method="dialog">
				<div class="row">
          <span id="closeContainer" class="material-symbols-outlined fs28">close</span>
        </div>
				<div class="dialogHead">
					<span>Zamówienie nr <span id="orderIdSpan"></span></span>
					<span id="skipStatusChangeInfo" class="hidden">Status zamówienia nie zostanie zmieniony</span>
					<span>Przedmioty do przywrócenia</span>
				</div>
				<div class="row">
					<table id="itemsToRestoreTable">
						<thead>
							<tr>
								${erliActions && erliRestoreCancelled ? '<th>A</th><th>E</th>' : '<th></th>'}
								<th></th>
								<th>Przedmiot</th>
								<th>nr aukcji</th>
								<th>szt.</th>
							</tr>	
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
				<div class="row">
					<button id="restoreItemsDialogCancel" class="actionButton"><span class="material-symbols-outlined fs28">cancel</span>Anuluj</button>
					<button id="restoreItemsDialogConfirm" class="actionButton"><span class="material-symbols-outlined fs28">replay</span>Przywróć</button>
				</div>
			</form>
		</dialog>`);
	}

	document.getElementById('restoreItemsDialogCancel').addEventListener('click', (e) => {
    /*if (document.getElementById('restoreItemsDialogConfirm').disabled === false) {
      const element = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
			if (element) element.disabled = false;
    }*/
    document.getElementById('restoreItemsDialog').close();
  });

	document.getElementById('closeContainer').addEventListener('click', () => {
    /*if (document.getElementById('restoreItemsDialogConfirm').disabled === false) {
      const element = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
			if (element) element.disabled = false;
    }*/
    document.getElementById('restoreItemsDialog').close();
  });

	document.getElementById('restoreItemsDialog').addEventListener('close', () => {
		const element = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
		if (element) element.disabled = false;
	});

	if (Array.from(document.querySelectorAll('button')).find(element => element.ariaLabel === 'Usuń element status zamówienia: anulowane') === undefined) {
		let cancelledOrders = [];
		let ordersRows, ordersRowsFound;

		do {
			ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
			ordersRowsFound = ordersRows.length;
			if (ordersRowsFound) {
				await new Promise(resolve => setTimeout(resolve, 2000));
				ordersRows = document.querySelectorAll('div[class^="order-group-operation"]');
				if (ordersRowsFound !== ordersRows.length) {
					ordersRowsFound = ordersRows.length;
					continue;
				}
			}
			break;
		} while (1);
		
		ordersRows.forEach(element => {
			element = element.nextElementSibling;
			if (element.querySelector('p[class~="buyer-cancelled-information"]') || element.querySelector('p[data-analytics-view-label="openCancelledByBuyerMessage_view"]') || element.querySelector('p[data-analytics-view-label="openCancelledBySystemMessage_view"]') || element.querySelector('p[data-analytics-view-label="openOrderReturnedInfo_view"]') || Array.from(element.querySelectorAll('span')).find(e => e.textContent.includes('Kupujący zgłosił zwrot') || e.textContent.includes('Kupujący anulował')) || Array.from(element.querySelectorAll('button')).find(e => e.title === 'Automatyczne anulowanie - informacja') || (element.querySelector('a[href="/funds-and-operations-history"]') && element.querySelector('a[href="/funds-and-operations-history"]').innerText === 'rabat transakcyjny')) {
				cancelledOrders.push(element);
			}
		});
		
		if (cancelledOrders.length) {
			cancelledOrders.forEach(cancelledOrder => {
				addRestoreButton(cancelledOrder);
			});
		}
	}

	document.getElementById('restoreItemsDialogConfirm').addEventListener('click', async (e) => {
		const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
		const numericInputs = itemsToRestoreTable.querySelectorAll('input[type="number"]');
		let numericInputsInvalid = false;
		numericInputs.forEach(input => {
			if (!input.reportValidity()) numericInputsInvalid = true;
		});

		if (numericInputsInvalid) return;

		(e.target.nodeName === 'SPAN' ? e.target.parentElement.disabled = true : e.target.disabled = true);
		
		let restoreItemsButton;
		restoreItemsButton = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
		if (restoreItemsButton) restoreItemsButton.remove();
		else {
			do {
				await new Promise(resolve => setTimeout(resolve, 500));
				restoreItemsButton = Array.from(document.querySelectorAll('button:disabled')).find(element => element.textContent === 'PRZYWRÓĆ STAN');
			} while (!restoreItemsButton);
			restoreItemsButton.remove();
		}

		document.getElementById('restoreItemsDialogCancel').disabled = true;
		
		const orderId = document.getElementById('orderIdSpan').innerText;
		const checkboxes = itemsToRestoreTable.querySelectorAll('input[type="checkbox"]');
		checkboxes.forEach(checkbox => checkbox.disabled = true);
    numericInputs.forEach(input => input.disabled = true);
		const itemsToRestore = Array.from(itemsToRestoreTable.tBodies[0].rows);
		let sandbox = (window.location.href.startsWith('https://salescenter.allegro.com.allegrosandbox.pl') ? 'Sandbox' : '');
  	let environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');

		let readedValue;
		let erliToken, erliEnvironment;
		try {
			readedValue = await readDataFromLocalStorage(['extensions', 'erliRestoreCancelledCheckbox', 'erliToken', 'erliTokenSandbox', 'erliAlwaysSyncToSandbox']);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}

		if (readedValue.extensions['erliActions'] && readedValue.erliRestoreCancelledCheckbox) {
			if (readedValue.erliAlwaysSyncToSandbox) {
				erliToken = readedValue.erliTokenSandbox;
				erliEnvironment = 'sandbox.erli.dev';
			} else {
				if (sandbox === 'Sandbox') {
					erliToken = readedValue.erliTokenSandbox;
					erliEnvironment = 'sandbox.erli.dev';
				} else {
					erliToken = readedValue.erliToken;
					erliEnvironment = 'erli.pl';
				}
			}
		}
		const shift = (erliToken && erliEnvironment ? 1 : 0);

		let response;
		try {
			response = await sendMessage({ action: 'getAllegroAccessToken' });
			if (!response.success) throw new Error(response.result);
		} catch (error) {
			toastMessage(`Błąd! Nie udało się wczytać tokena dostępowego. ${getErrorMessage(error)}`);
			return;
		}
		if (response.result === undefined) {
			toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			return;
		}	
		const accessToken = response.result;
		let restoreStatusAllegro, restoreStatusErli;;
		try {
			if (!document.getElementById('skipStatusChangeInfo').checkVisibility()) await changeOrderStatus(orderId, environment, accessToken);
			restoreStatusAllegro = await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift);
			restoreStatusErli = await restoreItemsOnErli(itemsToRestore, erliEnvironment, erliToken);
		} catch (error) {
			toastMessage(`Błąd! ${getErrorMessage(error)}`);
			return;
		}

		let restoreStatusText = '';
		if (restoreStatusAllegro.cancelled) restoreStatusText += 'Anulowano przywracanie stanu magazynowego, część aukcji została już zmieniona; ';
		if (restoreStatusAllegro.errorOccured) restoreStatusText += 'Podczas przywracania na Allegro wystąpiły błędy, sprawdź aukcje; ';
		if (restoreStatusErli.errorOccured) restoreStatusText += 'Podczas przywracania w Erli wystąpiły błędy, sprawdź aukcje; ';
		if (restoreStatusText === '') toastMessage('Zakończono przywracanie stanów magazynowych.');
		else toastMessage(restoreStatusText);
	});
}

async function addRestoreButton(cancelledOrder) {
	const actionsContainer = cancelledOrder.querySelector('div[class~="desktop__actions"]');
	if (actionsContainer === null) return; 
	let actionsContainerButtons = actionsContainer.querySelectorAll('button');
	if (actionsContainerButtons.length === 0 || Array.from(actionsContainerButtons).find(element => element.innerText === 'PRZYWRÓĆ STAN') !== undefined) return;
	const restoreButton = document.createElement('button');
	restoreButton.innerText = 'PRZYWRÓĆ STAN';
	restoreButton.className = actionsContainerButtons[0].className;
	actionsContainer.firstElementChild.insertAdjacentElement('afterbegin', restoreButton);
	restoreButton.addEventListener('click', async (e) => {
		e.target.disabled = true;
		
		const hrefString = e.target.parentElement.lastElementChild.href;
		if (!hrefString) {
			toastMessage('Błąd! Nie znaleziono wymaganej wartości parametru (hrefString)');
			return;
		}
		const charIndex = hrefString.lastIndexOf('/') + 1; 
		const orderId = hrefString.slice(charIndex, charIndex + 36);
		if (orderId.length !== 36) {
			toastMessage('Błąd! Nieprawidłowa wartość numeru zamówienia.');
			return;	
		}
		
		const offersList = cancelledOrder.querySelectorAll('div[data-test-id="item-offer"]');
		if (!offersList.length) return;

		const restoreItemsDialog = document.getElementById('restoreItemsDialog');
		if (restoreItemsDialog) {
			const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
			if (itemsToRestoreTable === null) {
				toastMessage('Błąd! Nie znaleziono tabeli z listą przedmiotów do przywrócenia.');
				return;
			}
			document.getElementById('orderIdSpan').innerText = orderId;
			const headerSection = itemsToRestoreTable.tHead;
			const erli = (headerSection.rows[0].cells.length > 5 ? true : false); 
			const bodySection = itemsToRestoreTable.tBodies[0];
			bodySection.innerHTML = '';
			let auctionTitle;
			let quantity;
			let partialReturn = false;
			if (Array.from(cancelledOrder.querySelectorAll('p')).find(e => e.textContent === 'Kupujący zgłosił zwrot części zamówienia')) partialReturn = true;
			if (partialReturn) document.getElementById('skipStatusChangeInfo').classList.remove('hidden');
			else document.getElementById('skipStatusChangeInfo').classList.add('hidden');
			
			offersList.forEach(offer => {
				if (!partialReturn || Array.from(offer.querySelectorAll('span')).find(e => e.textContent.includes('Zgłoszone do zwrotu'))) {
					auctionTitle = offer.querySelector('a');
					if (partialReturn) {
						const returnSpan = Array.from(offer.querySelectorAll('span')).find(e => e.textContent.includes('Zgłoszone do zwrotu'));
						if (returnSpan.textContent === 'Zgłoszone do zwrotu') {
							quantity = auctionTitle.parentElement.nextElementSibling?.innerText.split('x ')[0];
						} else quantity = returnSpan.textContent.split(' z ')[0].replace('Zgłoszone do zwrotu ', '');
					} else quantity = auctionTitle.parentElement.nextElementSibling?.innerText.split('x ')[0];

					let newRow = document.createElement('tr');
					newRow.innerHTML = /*html*/ `
						${(erli ? '<td></td><td></td>' : '<td></td>')}
						<td><input type="checkbox" checked></td>
						<td>${auctionTitle.innerText}</td>
						<td>${offer.querySelector('a[data-analytics-interaction-label="actualOfferFromOfferId_click"]').innerText}</td>
						<td><input type="number" step="1" min="0" max="9999" value="${quantity}" required /></td>
					`;
					let insertedRow = bodySection.insertRow();
					insertedRow.innerHTML = newRow.innerHTML;
				}
			});

			itemsToRestoreTable.querySelectorAll('input[type="number"]').forEach(input => input.addEventListener('blur', numericInputBlur));
			document.getElementById('restoreItemsDialogCancel').disabled = false;
      document.getElementById('restoreItemsDialogConfirm').disabled = false;
			restoreItemsDialog.showModal();
		} else {
			toastMessage('Błąd! Nie znaleziono okna z listą przedmiotów do przywrócenia.');
		}
	});
}

function numericInputBlur(e) {
	if (!e.target.reportValidity()) e.target.focus();
}

async function restoreItemsOnErli(itemsToRestore, environment, accessToken, count = 5, i = 0) {
	if (document.getElementById('restoreItemsDialog').open === false) {
		const errorOccured = false;
		return Promise.resolve({ cancelled: true, errorOccured: (errorOccured ? true : false) });
	}
	let frozenFields = [];
	let fetchResponse;
	let fetchData;
	if (i === itemsToRestore.length) {
		const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
		const errorOccured = Array.from(itemsToRestoreTable.querySelectorAll('span')).find(e => e.innerText === 'highlight_off');
		return Promise.resolve({ cancelled: false, errorOccured: (errorOccured ? true : false) });
	}

	const row = itemsToRestore[i];
	if (!row.cells[2].childNodes[0].checked) {
		return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
	}

	const offerId = row.cells[4].innerText;
	const quantityToRestore = Number(row.cells[5].firstChild.value);
	if (row.cells[1].childElementCount === 0) {
		const spinner = document.createElement('progress');
		spinner.className = 'pure-material-progress-circular';
		row.cells[1].appendChild(spinner);
	}

	try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'GET',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, i);      
    } else {
			setIconInCell('highlight_off', row.cells[1], true);
			toastMessage(`Błąd! Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
    }
  }

	if (fetchResponse.status === 200) {
    try {
      fetchData = await fetchResponse.json();
    } catch (error) {
			setIconInCell('highlight_off', row.cells[1], true);
      toastMessage(`Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd dla aukcji ${offerId}. ${getErrorMessage(error)}`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
    }
		if (fetchData?.frozen) {
			frozenFields = Object.entries(fetchData.frozen).filter(field => field[1] === true && ['stock', 'status'].indexOf(field[0]) !== -1).map(element => element[0]);
			if (frozenFields.length) {
				setIconInCell('highlight_off', row.cells[1], true);
				toastMessage(`Uwaga! Aukcja ${offerId} jest zablokowana w Erli, nie można zmienić stanu magazynowego. Zablokowane pola: ${frozenFields.join(', ')}.`);
				return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
			}
		}
  } else if (fetchResponse.status === 404) {
		setIconInCell('highlight_off', row.cells[1], true);
		toastMessage(`Uwaga! Nie znaleziono aukcji ${offerId} w Erli.`);
    return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, i);
    } else {
			setIconInCell('highlight_off', row.cells[1], true);
      toastMessage(`Błąd! Nie udało się pobrać danych aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
    }
  }

	const offerData = {
		stock: fetchData.stock + quantityToRestore,
		status: (fetchData.stock + quantityToRestore > 0 ? 'active' : 'inactive')
	}

	if (fetchData.status === 'inactive') {
		if (fetchData.stock !== 0) {	
			setIconInCell('highlight_off', row.cells[1], true);
			toastMessage(`Uwaga! Aukcja ${fetchData.id} (${fetchData.name}) została zakończona z niezerowym stanem magazynowym. Tą aukcję wznów ręcznie.`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, 5, ++i);
		}
	}

	try {
    fetchResponse = await backgroundFetch(`https://${environment}/svc/shop-api/products/${offerId}` , {
      'method': 'PATCH',
      'headers': {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      'body': JSON.stringify(offerData)
    });
  } catch (error) {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, i);      
    } else {
			setIconInCell('highlight_off', row.cells[1], true);
      toastMessage(`Błąd! Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. ${getErrorMessage(error)}`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
    }
  }

  if (fetchResponse.status === 200 || fetchResponse.status === 202) {
		setIconInCell('check_circle', row.cells[1], true);
    return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
  } else if (fetchResponse.status === 404) {
    setIconInCell('highlight_off', row.cells[1], true);
		toastMessage(`Uwaga! Nie znaleziono aukcji ${offerId} w Erli.`);
    return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, i);      
    } else {
			setIconInCell('highlight_off', row.cells[1], true);
     	toastMessage(`Błąd! Nie udało się zmienić stanu magazynowego aukcji ${offerId} w Erli. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			return await restoreItemsOnErli(itemsToRestore, environment, accessToken, count, ++i);
    }
  }
}


async function restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count = 5, i = 0) {
	if (document.getElementById('restoreItemsDialog').open === false) {
		const errorOccured = false;
		return Promise.resolve({ cancelled: true, errorOccured: (errorOccured ? true : false) });
	}
	let response;
	let fetchResponse;
	let fetchData;
  if (i === itemsToRestore.length) {
		const itemsToRestoreTable = document.getElementById('itemsToRestoreTable');
		const errorOccured = Array.from(itemsToRestoreTable.querySelectorAll('span')).find(e => e.innerText === 'highlight_off');
		return Promise.resolve({ cancelled: false, errorOccured: (errorOccured ? true : false) });
	}
	const row = itemsToRestore[i];
  if (!row.cells[1 + shift].childNodes[0].checked) {
		return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
	}

	const offerId = row.cells[3 + shift].innerText;
	const quantityToRestore = Number(row.cells[4 + shift].firstChild.value);
	if (row.cells[0].childElementCount === 0) {
		const spinner = document.createElement('progress');
		spinner.className = 'pure-material-progress-circular';
		row.cells[0].appendChild(spinner);
	}

	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
			'method': 'GET',
			'headers': {
				'Authorization': `Bearer ${accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			}
		});
	} catch (error) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
		} else {
			setIconInCell('highlight_off', row.cells[0], true);
			toastMesssage(`Błąd! Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId}. ${getErrorMessage(error)}`);
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
		}
	}

	if (fetchResponse.status === 200) {
		try {
			fetchData = await fetchResponse.json();
		} catch (error) {
      setIconInCell('highlight_off', row.cells[0], true);
      toastMessage(`Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd dla aukcji ${offerId}. ${getErrorMessage(error)}`);
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
    }

		if (fetchData.stock.available !== undefined) {
			const stock = {
				'stock': {
					'available': Number(fetchData.stock.available + quantityToRestore),
					'unit': fetchData.stock.unit
				}
			}
			if (fetchData.publication.status === 'ENDED') {
				if (fetchData.stock.available === 0) {
					stock.publication = {
						'status': 'ACTIVE'
					}
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					toastMessage(`Uwaga! Aukcja ${fetchData.id} (${fetchData.name}) została zakończona z niezerowym stanem magazynowym. Tą aukcję wznów ręcznie.`);
					return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, 5, ++i);
				}
			}

			try {
				await backgroundFetch(`https://api.allegro.pl${environment}/sale/product-offers/${offerId}` , {
					'method': 'PATCH',
					'headers': {
						'Authorization': `Bearer ${accessToken}`,
						'Content-Type': 'application/vnd.allegro.public.v1+json',
						'Accept': 'application/vnd.allegro.public.v1+json'
					},
					body: JSON.stringify(stock)
				});
			}	catch (error) {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					toastMessage(`Błąd! Podczas wysyłania żądania wystąpił błąd. Nie udało się pobrać danych aukcji ${offerId}. ${getErrorMessage(error)}`);
					return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
				}
			}
			if (fetchResponse.status === 200 || fetchResponse.status === 202) {
				setIconInCell('check_circle', row.cells[0], true);
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, 5, ++i);
			} else if (fetchResponse.status === 401) {
				if (--count) {
					try {
						response = await sendMessage({ action: 'refreshAllegroAccessToken' });
            if (!response.success) throw new Error(response.result);
					} catch (error) {
						setIconInCell('highlight_off', row.cells[0], true);
						return Promise.reject(getErrorMessage(error));
					}  
					if (response.result === undefined) {
						setIconInCell('highlight_off', row.cells[0], true);
						return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
					}
					return await restoreItemsOnAllegro(itemsToRestore, environment, response.result, shift, count, i);
				} else {
          setIconInCell('highlight_off', row.cells[0], true);
					return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. Nie udało się zalogować użytkownika.`);
				}
			} else if (fetchResponse.status === 403) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
			}  else {
				if (--count) {
					toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
					await new Promise(resolve => setTimeout(resolve, 5000));
					return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);   
				} else {
					setIconInCell('highlight_off', row.cells[0], true);
					toastMessage(`Błąd! Nie udało się zmienić stanu produktu na aukcji ${offerId}`);
					return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
				}												
			}
		} else if (fetchResponse.status === 429) {
			if (--count) {
				toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
				await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
			} else {
				return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas zmiany stanu produktu na aukcji ${offerId}. Spróbuj ponownie później.`);
			}
		} else if (fetchResponse.status === 500) {
			if (--count) {
				toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
			} else {
				setIconInCell('highlight_off', row.cells[0], true);
				toastMessage(`Błąd! Wystąpił błąd serwera. Nie udało się zmienić stanu produktu na aukcji ${offerId}`);
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
			}
		} else {
			if (--count) {
				toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
				await new Promise(resolve => setTimeout(resolve, 5000));
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);   
			} else {
				setIconInCell('highlight_off', row.cells[0], true);
				toastMessage(`Błąd! Nie udało się zmienić stanu produktu na aukcji ${offerId}`);
				return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
			}												
		}
	}	else if (fetchResponse.status === 401) {
		if (--count) {
			try {
				response = await sendMessage({ action: 'refreshAllegroAccessToken' });
        if (!response.success) throw new Error(response.result);
			} catch (error) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject(getErrorMessage(error));
			}  
			if (response.result === undefined) {
				setIconInCell('highlight_off', row.cells[0], true);
				return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
			}
			return await restoreItemsOnAllegro(itemsToRestore, environment, response.result, shift, count, i);  
		} else {
      setIconInCell('highlight_off', row.cells[0], true);
			return Promise.reject(`Nie udało się zmienić stanu produktu na aukcji. Nie udało się zalogować użytkownika.`);
		}
	} else if (fetchResponse.status === 403) {
		setIconInCell('highlight_off', row.cells[0], true);
		return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
	} else if (fetchResponse.status === 429) {
		if (--count) {
			toastMessage(`Osiągnięto limit zapytań do API Allegro. Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, (6 - count) * (6 - count) * 3000));
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
		} else {
			return Promise.reject(`Przekroczono limit zapytań do API Allegro podczas zmiany stanu produktu na aukcji ${offerId}. Spróbuj ponownie później.`);
		}
	} else if (fetchResponse.status === 500) {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);
		} else {
			setIconInCell('highlight_off', row.cells[0], true);
			toastMessage(`Błąd! Wystąpił błąd serwera. Nie udało się zmienić stanu produktu na aukcji ${offerId}`);
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
		}
	} else {
		if (--count) {
			toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, i);   
		} else {
			setIconInCell('highlight_off', row.cells[0], true);
			toastMessage(`Błąd! Nie udało się zmienić stanu produktu na aukcji ${offerId}`);
			return await restoreItemsOnAllegro(itemsToRestore, environment, accessToken, shift, count, ++i);
		}												
	}
}

function setIconInCell(iconName, place, replace = false) {
	const icon = document.createElement('span');
	icon.className = 'material-symbols-outlined';
	icon.innerText = iconName;
	if (!replace) place.appendChild(icon);
	else place.firstElementChild.replaceWith(icon);
}

async function changeOrderStatus(orderId, environment, accessToken, count = 5) {
	let response;
	let fetchResponse;

	try {
		fetchResponse = await backgroundFetch(`https://api.allegro.pl${environment}/order/checkout-forms/${orderId}/fulfillment` , {
			'method': 'PUT',
			'headers': {
				'Authorization': `Bearer ${accessToken}`,
				'Content-Type': 'application/vnd.allegro.public.v1+json',
				'Accept': 'application/vnd.allegro.public.v1+json'
			},
			'body': JSON.stringify({'status': 'CANCELLED'})
		});
	} catch (error) {
		if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
      return await changeOrderStatus(orderId, environment, accessToken, count)      
    } else {
      return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Nie udało się zmienić statusu zamówienia ${orderId} na "anulowane". ${getErrorMessage(error)}`);
    }
	}

	if (fetchResponse.status === 204) {
		return Promise.resolve(true);
	} else if (fetchResponse.status === 401) {
		if (--count) {
      try {
        response = await sendMessage({ action: 'refreshAllegroAccessToken' });
				if (!response.success) throw new Error(response.result);
      } catch (error) {
        return Promise.reject(getErrorMessage(error));
      }  
      if (response.result === undefined) {
        return Promise.reject('Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
      }
      return await changeOrderStatus(orderId, environment, response.result, count);  
    } else {
      return Promise.reject(`Nie udało się pobrać listy zamówień. Nie udało się zalogować użytkownika.`);
    }
  } else if (fetchResponse.status === 403) {
    return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
  } else {
    if (--count) {
      toastMessage(`Ponawianie próby wysyłania żądania (${5 - count} z 5), proszę czekać...`, true);
			await new Promise(resolve => setTimeout(resolve, 5000));
      return await changeOrderStatus(orderId, environment, accessToken, count);   
    } else {
      return Promise.reject(`Nie udało się zmienić statusu zamówienia ${orderId} na "anulowane".`);
    }												
	}
}

